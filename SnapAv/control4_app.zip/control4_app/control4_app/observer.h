#ifndef OBSERVER_H
#define OBSERVER_H
#include <iostream>


class Observable;
struct Argument{
    int type;
    void *data;
};
class Observer {
public:

    virtual void update(Observable* o,Argument* arg)=0;
    virtual ~Observer(){}

};

#include <set>

class Observable {
    bool changed;
    std::set<Observer*> observers;
protected:
    virtual void setChanged(){  changed=true; }
    virtual void clearChaged(){ changed=false; }
public:
    virtual void addObserver(Observer &obsver) {
        observers.insert( &obsver );
    }
    virtual void deleteObserver(Observer& obsver) {
        observers.erase( &obsver );
    }
    virtual void deleteObservers(){ observers.clear(); }
    virtual int countObservers(){   return observers.size(); }
    virtual bool hasChanged() { return changed;}
    virtual void notifyObservers( Argument*arg = nullptr ){
        if(!hasChanged()) return;
        clearChaged();
        std::set<Observer*>::iterator it;
         for(it = observers.begin() ; it !=observers.end();it++){
             (*it)->update(this,arg);
        }
    }
    virtual ~Observable(){}

};


#endif // OBSERVER_H

