#ifndef SOCKET_H
#define SOCKET_H

#include "tinythread.h"
#include "common.h"
#include "comhandleapi.h"
#include "adau1466.h"

typedef enum {
    cmd_type_null=0,
    cmd_type_sys,
    cmd_type_input,
    cmd_type_output,
    cmd_type_group,
    cmd_type_trigger,
    cmd_type_firmware,
    cmd_type_allgroup,
    cmd_type_network,
    cmd_type_internaltest,
    cmd_type_audiosense,
    cmd_type_resetcommand,
    cmd_type_max,
}cmd_type_t ;

enum
{
  MSG_No                  =   0,
  MSG_SYS_PowerOn         =   1,
  MSG_SYS_PowerOff        =   2,
  MSG_SYS_PowerToggle     =   3,
  MSG_Channel_InputLevel_Ctrl=4,
  MSG_KeyButton           =   0xA,
  /*******************/
  MSG_Channel_StereoON    =   0x10,//<---0x10
  MSG_Channel_MonoON       ,
  MSG_Channel_StereoMonoToggle,
  MSG_Channel_VolUp           ,
  MSG_Channel_VolDown         ,
  MSG_Channel_VolInc3db       ,
  MSG_Channel_VolDec3db       ,
  MSG_Channel_MuteOn          ,
  MSG_Channel_MuteOff         ,
  MSG_Channel_MuteToggle      ,
  MSG_Channel_LoundnessOn     ,
  MSG_Channel_LoundnessOFF    ,
  MSG_Channel_LoundnessTog    ,
  MSG_Channel_Source1     ,
  MSG_Channel_Vol_Ctrl    ,
  MSG_Channel_Vol_max     ,

  MSG_Channel_EQ1_Fre=0x20     ,
  MSG_Channel_EQ2_Fre     ,
  MSG_Channel_EQ3_Fre     ,
  MSG_Channel_EQ4_Fre     ,
  MSG_Channel_EQ5_Fre     ,
  MSG_Channel_EQ1_Gain    ,
  MSG_Channel_EQ2_Gain    ,
  MSG_Channel_EQ3_Gain    ,
  MSG_Channel_EQ4_Gain    ,
  MSG_Channel_EQ5_Gain    ,
  MSG_Channel_EQ1_Q       ,
  MSG_Channel_EQ2_Q       ,
  MSG_Channel_EQ3_Q       ,
  MSG_Channel_EQ4_Q       ,
  MSG_Channel_EQ5_Q       ,

  MSG_Channel_Bass        ,
  MSG_Channel_Treble      ,
  MSG_Channel_balance ,
  MSG_Channel_GROUP       ,//<---0x32
  MSG_Channel_TurnOnVol   ,//<---0x33

  MSG_GROUP_VolUp=0x40    ,
  MSG_GROUP_VolDown       ,
  MSG_GROUP_VolInc3db     ,
  MSG_GROUP_VolDec3db     ,
  MSG_GROUP_Mute_ON       ,
  MSG_GROUP_Mute_OFF      ,
  MSG_GROUP_Mute_Toggle   ,
  MSG_GROUP_Volset        ,
  MSG_GROUP_SOURCE_SET    ,//<--0X48
 /*******************/
  MSG_TRIGGER_ON_ZONE = 0x50,
  MSG_TRIGGER_OFF_ZONE,
  MSG_TRIGGER_TOG_ZONE,
  MSG_TRIGGER_ASG_CHANNEL,
  MSG_TRIGGER_ASG_ALL,
  /******************/
  MSG_FIRMWARE_IMAGE_PATH =0x64,
  MSG_FIRMWARE_VERSION,
  MSG_FIRMWARE_UPGRADE,
  MSG_FIRMWARE_lOADER_STATUS,
  MSG_FIRMWARE_UPDATE_STATUS,

  /****************/
  MSG_GROUP_ALL_VOLUP = 0x70,
  MSG_GROUP_ALL_VOLDOWN   ,
  MSG_GROUP_ALL_VolIn3db  ,
  MSG_GROUP_ALL_VolDec3db ,
  MSG_GROUP_ALL_MUTE      ,
  MSG_GROUP_ALL_UNMUTE    ,
  MSG_GROUP_ALL_MUTETog   ,
  MSG_GROUP_ALL_VOLSET    ,
  MSG_GROUP_ALL_SOURCE    ,
    /****************/
    MSG_NETWORK_MAC= 0x80,
    MSG_NETWORK_DHCP,
    MSG_NETWORK_STATIC,
    MSG_NETWORK_AUTONETWORKSTANDBY,
    /****************/
    MSG_LED_TEST= 0x90,
    MSG_BOOTLOAER_VERSION= 0x91,
    MSG_BOOTLOAER_UPDATE= 0x92,
    MSG_BOOTLOAER_UPDATE_STATUS= 0x93,
    /****************/
    MSG_AUDIO_SENSE=0xA0,
    MSG_AUDIO_SENSE_STATUS,
    MSG_AUDIO_SENSE_ENABLE,
    MSG_AUDIO_ANALOGNOSIGNAL_SLEEPTIMEOUT,
     /****************/
    MSG_RESET_COMMAD=0xB0,
    MSG_FACTORYRESET_MASSAGE_COMMAD,
     /****************/
    MSG_SYS_Save,        // 1
    MSG_SaveSerial,      // 2
    MSG_REBOOT_COMMAD,
};
enum
{
  MSG_Output_HighSf=0x01,
  MSG_Output_HighSq,
  MSG_Output_LowSf,
  MSG_Output_LowSq,
  MSG_Output_Cf,
  MSG_Output_Ct,
  MSG_Output_LowPassGain,
  MSG_Output_RoomLock,
  MSG_Output_Delay,
  MSG_Output_Trigger,
  MSG_Output_MusicType,
  MSG_Output_HighSgain,
  MSG_Output_LowSgain,
  MSG_Output_LineoutMute,
};
enum
{
  MSG_Input_SPThreshold=0x01,
  MSG_Input_SPReleaseTime ,
  MSG_Input_ADetect ,
  MSG_Input_Delay ,
};
enum
{
  MSG_EqFreq=0x00,
  MSG_EqGain ,
  MSG_EqQ ,
};
enum
{
  MSG_Misc_TestGain=0x01,
  MSG_Misc_SampleRate ,
  MSG_Misc_DspVersion ,
  MSG_SERTAGE,
  MSG_Set_Allvolume,
};
enum
{
  MSG_Upgrade=0x01,
  MSG_Credential,
};

enum
{
  MSG_Input=0x02,
  MSG_Output,
  MSG_Misc,
  MSG_EQ,
  MSG_SYS,

};
#pragma pack(1)

struct control4pack
{
    unsigned char len;
    unsigned char OptMaster;
    unsigned char optSecond;
    union
    {
        struct {
                    unsigned char channel;
                    unsigned char value;
                }Set;
        struct {
                    unsigned char channel;
                    unsigned int value;
                }Setint;
        struct {
                    unsigned char query;
                    unsigned char channel;
               }Get;
        struct {
                    char url[100];
               }Data;
        struct {
                    unsigned char ip[4];
                    unsigned char subnet[4];
                    unsigned char gateway[4];
                }Ip;
        unsigned char mac[4];
        unsigned char credential[200];
    };
};

#pragma pack()

class SocketServer:public TinyThread,public ComHandleApi,public ADAU1466
{
public:

    void decode(int len);
    void Commhandle_Input_New(struct control4pack data);
    void Commhandle_Output_New(struct control4pack data);
    void Commhandle_EQ(struct control4pack data);
    void Commhandle_Sys_Old(struct control4pack data);
    void Commhandle_Group_Old(struct control4pack data);
    void Commhandle_Input_Old(struct control4pack data);
    void Commhandle_Output_Old(struct control4pack data);
    void Commhandle_Old(struct control4pack data);
    void Commhandle_Misc_New(struct control4pack data);
    void Commhandle_System(struct control4pack data);
    void Commhandle(struct control4pack data,int newcom);
    unsigned int SocketBasstreble(unsigned char a);
    float SocketBasstreblef(unsigned char a);
    unsigned int SocketQ(unsigned char q);
    float SocketQf(unsigned char q);
    unsigned int SocketGain(unsigned char gain);
    float SocketGainf(unsigned char gain);
    float Gainfneg24to0(unsigned char gain);
    float dsp2float(int gainq);
    unsigned int SocketFrequency(unsigned char fre);
    float SocketInputLeve(unsigned char leve);
    float SocketOutPutLeve(unsigned char leve);
    const char* SocketMusicType(unsigned char odd,unsigned char type);
    const char* SocketXoverType(unsigned char type);
    float DataToGainFloat(unsigned int data);
    const char *FreqChar(unsigned char leve);
    const char *FreqChar(int fre);
    const char *GroupChar(unsigned int group);
    const char *BalanceChar(unsigned char balance);
    const char *PowerChar(unsigned char power);
    const char *SelectChar(unsigned char Select);
    void QueryBack(struct control4pack data,int newcom);
    void QueryBack_Sys_Old(struct control4pack data);
    void QueryBack_Input_Old(struct control4pack data);
    void QueryBack_Old(struct control4pack data);
    void QueryBack_Out_New(struct control4pack data);
    void QueryBack_EQ(struct control4pack data);
    void QueryBack_Output_Old(struct control4pack data);
    void QueryBack_Group_Old(struct control4pack data);
    void QueryBack_Input_New(struct control4pack data);
    void QueryBack_Misc_New(struct control4pack data);
    void report_Signal_detect(unsigned char channel);
    static SocketServer *getInstance() {
        static SocketServer s;
        return &s;
    }
    void run();
private:
    char bufSend[150];
    char bufReceive[1024];
    SocketServer();
    ~SocketServer();
    int server_sockfd;
    int client_sockfd;
    char lineout_mute;
};

#endif //
