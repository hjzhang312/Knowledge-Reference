#ifndef SQLITE3BASE_H
#define SQLITE3BASE_H
#include "common.h"
#include "tools/types.h"
#include <sqlite3.h>
#include "types.h"
#include <map>


using namespace std ;
typedef int (*sqlite3_callback)(void*,int,char**,char**);

class Sqlite3Base
{
public:
    Sqlite3Base(string db_path);
    ~Sqlite3Base();

    S_ret UpdateDspVolume(int volume,int i );
    S_ret UpdateDspVolume(int volume);
    S_ret UpdateDspSource(int source,int i );
    S_ret UpdateDspSource(int source);
    S_ret UpdateDsp(int channel, int index,int vol );
    S_ret UpdateDspPEQ(int channel, int index,int vol );
    S_ret UpdateDspShelf(int channel, int index,int vol);

    S_ret CreatDevice();
    S_ret InsertDevice(DeviceSet device);
    S_ret UpdateDevice(DeviceSet device);
    S_ret SelectDevice(DeviceSet &device, _deviceinfo &info);

    S_ret CreateDsp();
    S_ret InsertDsp(DSPstreaming *dspset);
    S_ret UpdateDsp(DSPstreaming *dspset);
    S_ret UpdateDsp(DSPstreaming *info, int channel );
    S_ret getDSPStreamingInfo(DSPstreaming *dspset);


    S_ret SelectDsp(DSPstreaming &info);
    S_ret deleteDatabase();
    //S_ret init_ovrcsetting(_cloudinfo info);
    S_ret init_loginInfo();

    S_ret init_SystemSetting51();
    S_ret init_inputsetting51();
    S_ret init_OutputSetting51();

    S_ret runsqlcmd(string sqlcmd);
    S_ret runsqlcmd(string sqlcmd,sqlite3_callback func,void *data);
    S_ret runsqlcmd(string sqlcmd,char ** sqlresoult,int &row,int &col);

    S_ret CreateLogin();
    S_ret initLoginInfo();
    S_ret getLoginInfo(_logininfo &info);
    S_ret updateLoginInfo(_logininfo info);
    //S_ret updateOvrcNetInfo(_cloudinfo info);

    S_ret CreateWebExtraInfo();
    S_ret initWebExtraInfo();
    S_ret getWebExtraInfo(_webextrainfo &info);

    S_ret create_tables();
    S_ret create_version_table();
    S_ret get_database_version();
    S_ret updateVersionInfo(string dbname, string key, int ver);

    //room preset
#if 0
    S_ret CreateDspInfoTab();
    S_ret initDspInfoTab();
    S_ret getDspInfoFromTab(vector<_dspPresetItemInfo> &info);
#endif
    S_ret CreateRoomDspPresetInfoTab();
    S_ret initRoomDspPresetInfoTab();
    S_ret getRoomDspPresetInfoFromTab(vector<_roomDspPresetItemInfo> &info);

    //speaker preset
    S_ret CreateSpeakerDspPresetInfoTab();
    S_ret initSpeakerDspPresetInfoTab();
    S_ret getSpeakerDspPresetInfoFromTab(SPEAKER_PRESET_MAP &info);

#if 0
    S_ret CreateEqItemTab();
    S_ret initEqItemTab();
    S_ret getEqItemFromTab(vector<_dspEqItemInfo> &info);
#endif

    S_ret CreateOutputDspTab();
    S_ret initOutputDspTab();
    S_ret getOutputDspFromTab();

    S_ret CreateSubDspTab();
    S_ret initSubDspTab();
    S_ret getSubDspFromTab();


    //S_ret getInOutPutDataInfo51(vector<_inPutSettingInfo51> &inPutInfo,vector<_outPutSettingInfo51> &outPutInfo);
    //S_ret getSystemSettingInfo51(_systemConfigSetting51 &info);
    bool isrecordexist(string sqlcmd);
    S_ret writeBinary(std::ofstream &fout,string &md5,const string value);
    S_ret readBinary(string &value,string &md5,char **p);
    string stringToLower(string s);


    sqlite3* getDB() { return db; }

private:
    sqlite3 *db;
    char * errmsg;
    int result;

private:
   // std::map<ConfigureStrValue51,std::string> s_mapTabVal;

};

#endif // SQLITE3BASE_H
