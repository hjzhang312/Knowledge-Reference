#ifndef TYPES_H
#define TYPES_H

#include <string>
#include <vector>
#include <map>

using namespace std;
#define MAX_PEQ_NUM 12
#define MAX_SHELF_NUM 2

#define MAX_EQ_NUM 6

enum ENUM_PEQ {

    PEQ_Freq=0,
    PEQ_Gain,
    PEQ_Q,
    PEQ_SR,
    PEQ_Index,
    PEQ_N,
};

enum ENUM_Shelf {

    Shelf_Freq=0,
    Shelf_Gain,
    Shelf_Q,
    Shelf_SR,
    Shelf_Index,
    Shelf_N,
};

enum ENUM_Xover {

    Xover_Freq=0,
    Xover_SR,
    Xover_Index,
    Xover_Gain,
    Xover_N,
};

enum ENUM_Switch {

    Switch_bypass=0,
    Switch_stereo,
    Switch_mono,
    Switch_StereoHP,
    Switch_Monhp,
    Switch_test,
    XSwitch_N,
};

enum ENUM_DSP {

    ENUM_Optical=0,
    ENUM_Inputdelay,
    ENUM_Inputvolume,
    ENUM_Outputsource,

    ENUM_loudness,
    ENUM_outputdelay,
    ENUM_startvolume,
    ENUM_maxvolume,
    ENUM_volume,

    ENUM_dspmute,
    ENUM_balance,
    ENUM_merge,
    Enum_mergeBefore,
    ENUM_group,
    ENUM_oscgain,
    ENUM_dspfirmware,
    ENUM_dspsamplerate,
    ENUM_dspAutoSense,

    ENUM_crossover_freq,
    ENUM_crossover_sr,
    ENUM_crossover_index,
    ENUM_crossover_gain,

    ENUM_signalpresence_threshold,
    ENUM_signalpresence_releasetime,

    DSP_N,
};
enum ENUM_DSP_PEQ{
    ENUM_PEQ_Freq=0,
    ENUM_PEQ_Gain,
    ENUM_PEQ_Q,
    ENUM_PEQ_SR,
    ENUM_PEQ_N
};


//Tone Control
enum ENUM_DSP_SHELF{
    ENUM_shelf_freq=0,
    ENUM_shelf_gain,
    ENUM_shelf_q,
    ENUM_shelf_sr,
    ENUM_SHELF_N
};
#define BASS 0
#define TREBLE 1
struct DSPstreaming
{
    int dsp[DSP_N];
    int dsppeq[ENUM_PEQ_N * MAX_PEQ_NUM];
    int dspshelf[ENUM_SHELF_N * MAX_SHELF_NUM];
};

struct DeviceSet
{
    int autostandby;
    int audiosens;
    int linemute;
    int asg;
    int zoon[4];
    int power;

};
struct _networkinfo {
    string ip;
    string netmask;
    string gateway;
    string mac;
    string dhcpEnabled;
    string dnsServer1;
    string dnsServer2;
    //string webpageport;
};
struct _deviceinfo {
    string devicename;
    string devicemodel;
    string autoonmethod;
    string powerondelay;
    string serialnumber;
    string firmware;
    string flashEnabled;
    string currentIeDsp;
    string currentEqDsp;
};
struct _cloudinfo {
    string enable;
    string url;
    string port;
    string webpageport;
    string updatefrequency;
};

struct _logininfo {
    string mUserName;
    string mUserPasswd;
    int mStatus;
    int mChangeType;
    int mFailNumber;
    string mLockTime;
};

struct _webextrainfo {
    string inputname[CHANNELS];
    string outputname[CHANNELS];
    string assigntrigger[CHANNELS];
};

struct _outputDspInfo
{
    string mOutputLoudnessEN;
    string mOutputToneBassEN;
    string mOutputToneBassFreq;
    string mOutputToneBassQ;
    string mOutputToneBass;//bass Gain

    string mOutputToneTrebleEN;
    string mOutputToneTrebleFreq;
    string mOutputToneTrebleQ;
    string mOutputToneTreble;//Treble Gain
    // add lock to output
    string mOutputLock;

    string mOutputRoomDspPreset;
    string mOutputSpeakerDspPreset;
};

struct _subDspInfo
{
    string mSubDspEnable;
    string mSubVolOffset;
    string mSubCrossoverType;
    string mSubCrossoverSlop;
    string mSubCrossoverFreq;
};

struct _dspPresetItemInfo
{
    string mDspItemName;
};

struct _dspEqItemInfo
{
    string mDspPresetIndex;

    string mDspEqEnable;
    string mDspEqUuid;
    string mDspEqFreq;
    string mDspEqQratio;
    string mDspEqGain;
};


struct _roomDspPresetItemInfo
{
    string mRoomDspIndex;
    string mRoomDspName;
    string mRoomEqIndex[MAX_EQ_NUM];
    string mRoomEqEnable[MAX_EQ_NUM];
    string mRoomEqFreq[MAX_EQ_NUM];
    string mRoomEqQratio[MAX_EQ_NUM];
    string mRoomEqGain[MAX_EQ_NUM];
};

struct _speakerDspPresetItemInfo
{
    string mSpeakerDspIndex;
    string mSpeakerDspName;
    string mSpeakerEqIndex[MAX_EQ_NUM];
    string mSpeakerEqEnable[MAX_EQ_NUM];
    string mSpeakerEqFreq[MAX_EQ_NUM];
    string mSpeakerEqQratio[MAX_EQ_NUM];
    string mSpeakerEqGain[MAX_EQ_NUM];
};

typedef std::map<unsigned long long, _speakerDspPresetItemInfo> SPEAKER_PRESET_MAP;

// The test version number of all versions starts with 2.
#define AppVersion 10055
#define DATABASE_VERSION  1
#endif // TYPES_H
