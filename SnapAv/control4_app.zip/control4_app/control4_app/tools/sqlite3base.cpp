#include "sqlite3base.h"
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <algorithm>
#include "sysdata.h"
#include "log.h"

Sqlite3Base::Sqlite3Base(string db_path):db(nullptr)
{
    int ret = sqlite3_open(db_path.c_str(),&db);
    if(SQLITE_OK != ret)
    {
        DEBUG_LOG("cannot open database:%s %s",db_path.c_str() , sqlite3_errmsg(db));
        db=nullptr;
    }
    else
    {
        DEBUG_LOG("open database sucess");
    }
}
Sqlite3Base::~Sqlite3Base()
{
    if(db != nullptr) sqlite3_close(db);
}



S_ret Sqlite3Base::CreatDevice()
{
    if(db == nullptr) return ERROR;
    string sqlcmd = "create table if not exists Devicetab ("
                    "id int,"
                    "devicename text,"
                    "autostandby int,"
                    "audiosens int,"
                    "asg int,"
                    "zoon_0 int,"
                    "zoon_1 int,"
                    "zoon_2 int,"
                    "zoon_3 int "
                    ");";
    result = sqlite3_exec(db,sqlcmd.c_str(),0, 0, &errmsg);
    LOGOUT("create device %s",errmsg);
    return SUCESS;
}

S_ret Sqlite3Base::InsertDevice(DeviceSet device)
{
    if( ! isrecordexist("select * from Devicetab") ) {

        char *zSQL = sqlite3_mprintf("INSERT INTO Devicetab VALUES"
                                     "(%d,"//id
                                     "'%s',"          //devicename
                                     "%d,"          //autostandby
                                     "%d,"          //audiosens
                                     "%d,"          //asg
                                     "%d,%d,%d,%d"  //zoon
                                     ")",
                                     0,
                                     (CHANNELS == 8 ? "TRIAD AMS8" : "TRIAD AMS16"),
                                     device.autostandby,
                                     device.audiosens,
                                     device.asg,
                                     device.zoon[0],device.zoon[1],device.zoon[2],device.zoon[3]
                );

        //LOGOUT("&&&: %s", zSQL);
        result = sqlite3_exec(db,zSQL, 0, 0, &errmsg);
        sqlite3_free(zSQL);
        LOGOUT("inset device:%s",errmsg);

        return SUCESS;
    }
    else
        return FAILED;
}


//int audiosens;
//int zoon[4];
//int asg;
S_ret Sqlite3Base::UpdateDevice(DeviceSet device)
{

    char * sql;
    sql = sqlite3_mprintf("update Devicetab set "
                          "autostandby=%d,"
                          "audiosens=%d,"
                          "asg=%d,"
                          "zoon_0=%d,"
                          "zoon_1=%d,"
                          "zoon_2=%d,"
                          "zoon_3=%d "
                          "where id = %d",
                          device.autostandby,device.audiosens,device.asg,device.zoon[0],device.zoon[1],device.zoon[2],device.zoon[3],
            0);

    result = sqlite3_exec(db,sql,0,0,&errmsg);
    sqlite3_free(sql);
    LOGOUT("UpdateDspsettings:%s",errmsg);
    return SUCESS;
}

S_ret Sqlite3Base::SelectDevice(DeviceSet &device, _deviceinfo &info)
{

    sqlite3_stmt * stmt = NULL;
    const char *zTail;

    if (sqlite3_prepare_v2(db,
                           "SELECT * FROM Devicetab;", -1, &stmt, &zTail) ==SQLITE_OK){
        while( sqlite3_step(stmt) ==SQLITE_ROW ) {
            int row=sqlite3_column_int(stmt,0);
            if(row==0)
            {
                info.devicename = (char *)sqlite3_column_text(stmt,1);
                LOGOUT("=========== %s ============", info.devicename.c_str());
                device.autostandby=sqlite3_column_int(stmt,2);

                device.audiosens=sqlite3_column_int(stmt,3);
                device.asg=sqlite3_column_int(stmt,4);
                device.zoon[0]=sqlite3_column_int(stmt,5);
                device.zoon[1]=sqlite3_column_int(stmt,6);
                device.zoon[2]=sqlite3_column_int(stmt,7);
                device.zoon[3]=sqlite3_column_int(stmt,8);
            }

        }
    }
    sqlite3_finalize(stmt);
    return SUCESS;
}
#define DSP_SQL_NAME "dsp_"
#define PEQ_SQL_NAME "peq_"
#define SHE_SQL_NAME "she_"
S_ret Sqlite3Base::CreateDsp()
{
    if(db == nullptr) return ERROR;
    string sqlcmd = "create table if not exists DSPsettings ( "
                    "id int,";

    //"dsp1 int,...,dsp18 int,"
    for (int i = 0 ;i < DSP_N;i++) {
        sqlcmd += DSP_SQL_NAME;
        sqlcmd += std::to_string(i);
        sqlcmd +=" int,";
    }
    //"peq_0 int,...,peq_ENUM_PEQ_N int,"
    for (int i = 0 ;i < ENUM_PEQ_N * MAX_PEQ_NUM;i++) {
        sqlcmd += PEQ_SQL_NAME;
        sqlcmd += std::to_string(i);
        sqlcmd +=" int,";
    }
    //"she_0 int,,she_ENUM_PEQ_N int,"
    for (int i = 0 ;i < ENUM_SHELF_N * MAX_SHELF_NUM ;i++) {
        sqlcmd += SHE_SQL_NAME;
        sqlcmd += std::to_string(i);
        if( i != (ENUM_SHELF_N * MAX_SHELF_NUM - 1) ){
            sqlcmd +=" int,";
        } else {
            sqlcmd +=" int";
        }
    }
    sqlcmd +=  ");";
    DEBUG_LOG("DSPsettings cmd: %s",sqlcmd.c_str());
    result = sqlite3_exec(db,sqlcmd.c_str(),0, 0, &errmsg);
    LOGOUT("create_tables %s",errmsg);
    return SUCESS;
}

S_ret Sqlite3Base::InsertDsp(DSPstreaming *dspset)
{

    int channel,i;
    string cmd ;
    if( ! isrecordexist("select * from DSPsettings") )
    {
        for(channel=0;channel<CHANNELS;channel++)
        {
            DEBUG_LOG("start InsertDsp %d.....",channel);
            cmd = "INSERT INTO DSPsettings VALUES(";
            cmd += std::to_string(channel) +"," ; // id
            for(i = 0 ; i < DSP_N;i++) cmd += std::to_string(dspset[channel].dsp[i]) +","; //dsp
            for(i = 0 ; i < ENUM_PEQ_N * MAX_PEQ_NUM;i++)cmd +=std::to_string(dspset[channel].dsppeq[i]) +","; //peq
            for(i = 0 ;i < ENUM_SHELF_N * MAX_SHELF_NUM ;i++) { //tone control
                cmd +=std::to_string(dspset[channel].dspshelf[i]);
                if(i != ENUM_SHELF_N * MAX_SHELF_NUM -1 ) cmd +=",";
                else cmd +=");";
            }

            result = sqlite3_exec(db,cmd.c_str(), 0, 0, &errmsg);
            //sqlite3_free(zSQL);
            // LOGOUT("inset DSP settings:%s",errmsg);
        }
        return SUCESS;
    }
    return FAILED;
}

S_ret Sqlite3Base::UpdateDsp(DSPstreaming *dspset)
{
    string cmd ;
    int channel,i;

    for(channel=0;channel<CHANNELS;channel++)
    {
        cmd = "update DSPsettings set ";

        for(i = 0 ; i < DSP_N;i++) {
            //dsp_i=value,
            cmd += DSP_SQL_NAME;
            cmd += std::to_string(i) + "=";
            cmd += std::to_string(dspset[channel].dsp[i]) +","; //dsp
        }
        for(i = 0 ; i < ENUM_PEQ_N * MAX_PEQ_NUM;i++){
            //peq_i=value,
            cmd += PEQ_SQL_NAME;
            cmd += std::to_string(i) + "=";
            cmd += std::to_string(dspset[channel].dsppeq[i]) +","; //peq
        }
        for(i = 0 ;i < ENUM_SHELF_N * MAX_SHELF_NUM ;i++) {
            //she_i=value,
            cmd += SHE_SQL_NAME;
            cmd += std::to_string(i) + "=";
            cmd += std::to_string(dspset[channel].dspshelf[i]);
            if(i != ENUM_SHELF_N * MAX_SHELF_NUM -1 ) cmd +=",";
            else cmd +=" ";
        }
        cmd += " where id = "+ std::to_string(channel) ; // id
        //DEBUG_LOG("Dsp UpdateDsp cmd:%s",cmd.c_str());
        result = sqlite3_exec(db,cmd.c_str(), 0, 0, &errmsg);

        LOGOUT("UpdateDsp settings:%s",errmsg);
        return SUCESS;
    }
    return FAILED;
}

S_ret Sqlite3Base::UpdateDsp(DSPstreaming *dspset,int channel )
{
    string cmd ;
    int i;
    //    if( ! isrecordexist("select * from DSPsettings") ) {

    cmd = "update DSPsettings set ";

    for(i = 0 ; i < DSP_N;i++) {
        //dsp_i=value,
        cmd += DSP_SQL_NAME;
        cmd += std::to_string(i) + "=";
        cmd += std::to_string(dspset[channel].dsp[i]) +","; //dsp
    }
    for(i = 0 ; i < ENUM_PEQ_N * MAX_PEQ_NUM;i++){
        //peq_i=value,
        cmd += PEQ_SQL_NAME;
        cmd += std::to_string(i) + "=";
        cmd += std::to_string(dspset[channel].dsppeq[i]) +","; //peq
    }
    for(i = 0 ;i < ENUM_SHELF_N * MAX_SHELF_NUM ;i++) {
        //she_i=value,
        cmd += SHE_SQL_NAME;
        cmd += std::to_string(i) + "=";
        cmd += std::to_string(dspset[channel].dspshelf[i]);
        if(i != ENUM_SHELF_N * MAX_SHELF_NUM -1 ) cmd +=",";
        else cmd +=" ";
    }
    cmd += " where id = "+ std::to_string(channel) ; // id
    LOGOUT("cmd:%s",cmd.c_str());
    result = sqlite3_exec(db,cmd.c_str(), 0, 0, &errmsg);
    //sqlite3_free(zSQL);
    LOGOUT("UpdateDsp settings:%s",errmsg);

    return SUCESS;
    //   }
}

S_ret Sqlite3Base::getDSPStreamingInfo(DSPstreaming* dspset)
{
    sqlite3_stmt * stmt = NULL;
    const char *zTail;
    int i = 0;
    if (sqlite3_prepare_v2(db,
                           "SELECT * FROM DSPsettings;", -1, &stmt, &zTail) ==SQLITE_OK){
        while( sqlite3_step(stmt) ==SQLITE_ROW ) {
#if 0
            dspset[i].dsp[ENUM_Optical] = sqlite3_column_int(stmt,1);
                       dspset[i].dsp[ENUM_Inputdelay] = sqlite3_column_int(stmt,2);
                       dspset[i].dsp[ENUM_Inputvolume] = sqlite3_column_int(stmt,3);
                       dspset[i].dsp[ENUM_Outputsource] = sqlite3_column_int(stmt,4);
                       dspset[i].dsp[ENUM_loudness] = sqlite3_column_int(stmt,5);

                       dspset[i].dsp[ENUM_outputdelay] = sqlite3_column_int(stmt,6);
                       dspset[i].dsp[ENUM_startvolume] = sqlite3_column_int(stmt,7);
                       dspset[i].dsp[ENUM_maxvolume] = sqlite3_column_int(stmt,8);
                       dspset[i].dsp[ENUM_volume] = sqlite3_column_int(stmt,9);
                       dspset[i].dsp[ENUM_dspmute] = sqlite3_column_int(stmt,10);

                       dspset[i].dsp[ENUM_balance] = sqlite3_column_int(stmt,11);
                       dspset[i].dsp[ENUM_merge] = sqlite3_column_int(stmt,12);
                       dspset[i].dsp[ENUM_group] = sqlite3_column_int(stmt,13);
                       dspset[i].dsp[ENUM_oscgain] = sqlite3_column_int(stmt,14);
                       dspset[i].dsp[ENUM_dspfirmware] = sqlite3_column_int(stmt,15);

                       dspset[i].dsp[ENUM_dspsamplerate] = sqlite3_column_int(stmt,16);
                       dspset[i].dsp[ENUM_crossover_freq] = sqlite3_column_int(stmt,17);
                       dspset[i].dsp[ENUM_crossover_sr] = sqlite3_column_int(stmt,18);
                       dspset[i].dsp[ENUM_crossover_index] = sqlite3_column_int(stmt,19);

                       //peq
                       for(int peq = 0; peq < ENUM_PEQ_N * MAX_PEQ_NUM; peq = peq+4)
                       {
                           dspset[i].dsppeq[ENUM_PEQ_Freq + peq] = sqlite3_column_int(stmt,20+peq);
                           dspset[i].dsppeq[ENUM_PEQ_Gain + peq] = sqlite3_column_int(stmt,21+peq);
                           dspset[i].dsppeq[ENUM_PEQ_Q + peq] = sqlite3_column_int(stmt,22+peq);
                           dspset[i].dsppeq[ENUM_PEQ_SR + peq] = sqlite3_column_int(stmt,23+peq);
                       }

                       //shelf
                       for(int shelf = 0; shelf < ENUM_SHELF_N * MAX_SHELF_NUM; shelf = shelf+4)
                       {
                           dspset[i].dspshelf[ENUM_shelf_freq + shelf] = sqlite3_column_int(stmt,67+shelf);
                           dspset[i].dspshelf[ENUM_shelf_gain + shelf] = sqlite3_column_int(stmt,68+shelf);
                           dspset[i].dspshelf[ENUM_shelf_q + shelf] = sqlite3_column_int(stmt,69+shelf);
                           dspset[i].dspshelf[ENUM_shelf_sr + shelf] = sqlite3_column_int(stmt,70+shelf);
                       }
#endif

            for(int j=0;j<DSP_N;j++)
            {
               dspset[i].dsp[j] = sqlite3_column_int(stmt,j+1);
            }

            for(int j = 0; j < ENUM_PEQ_N * MAX_PEQ_NUM; j++)
            {
                dspset[i].dsppeq[j] = sqlite3_column_int(stmt,DSP_N+1+j);
                if(i==0)printf("dsppeq-<channel:%d>-<%d:%x>\r\n",i,j,dspset[i].dsppeq[j]);
            }

            //shelf
            for(int j = 0; j < ENUM_SHELF_N * MAX_SHELF_NUM; j ++)
            {
                dspset[i].dspshelf[j] = sqlite3_column_int(stmt,DSP_N+ENUM_PEQ_N * MAX_PEQ_NUM+1+j);

            }

            i++;
            if(i == (CHANNELS))
                break;
        }
    }
    sqlite3_finalize(stmt);
}

S_ret Sqlite3Base::UpdateDsp(int channel, int index, int vol)
{
    string cmd ;

    //   if( ! isrecordexist("select * from DSPsettings") ) {
    cmd = "update DSPsettings set ";
    //dsp_i=value,
    cmd += DSP_SQL_NAME;
    cmd += std::to_string(index) + "=";
    cmd += std::to_string(vol) ; //dsp

    cmd += " where id = "+ std::to_string(channel) ; // id
    //DEBUG_LOG("UpdateDsp cmd:%s",cmd.c_str());
    result = sqlite3_exec(db,cmd.c_str(), 0, 0, &errmsg);
    //sqlite3_free(zSQL);

    return SUCESS;
    //  }
}

S_ret Sqlite3Base::UpdateDspPEQ(int channel, int index, int vol)
{
    string cmd ;

    //   if( ! isrecordexist("select * from DSPsettings") ) {

    cmd = "update DSPsettings set ";
    //dsp_i=value,
    cmd += PEQ_SQL_NAME;
    cmd += std::to_string(index) + "=";
    cmd += std::to_string(vol) ; //dsp

    cmd += " where id = "+ std::to_string(channel) ; // id
    result = sqlite3_exec(db,cmd.c_str(), 0, 0, &errmsg);
    //sqlite3_free(zSQL);
    //LOGOUT("UpdateDsp settings:%s",errmsg);

    return SUCESS;
    //   }

}

S_ret Sqlite3Base::UpdateDspShelf(int channel, int index, int vol)
{
    string cmd ;

    //   if( ! isrecordexist("select * from DSPsettings") ) {

    cmd = "update DSPsettings set ";
    //dsp_i=value,
    cmd += SHE_SQL_NAME;
    cmd += std::to_string(index) + "=";
    cmd += std::to_string(vol) ; //dsp

    cmd += " where id = "+ std::to_string(channel) ; // id
    result = sqlite3_exec(db,cmd.c_str(), 0, 0, &errmsg);
    //sqlite3_free(zSQL);
    //LOGOUT("UpdateDsp settings:%s",errmsg);


    return SUCESS;
    //   }

}

S_ret Sqlite3Base::UpdateDspSource(int source,int i )
{

    //    char * sql;
    //    sql = sqlite3_mprintf("update DSPsettings set "
    //                          "outputsource=%d "
    //                          "where id = %d",
    //                          source,
    //                          i);
    //    result = sqlite3_exec(db,sql,0,0,&errmsg);
    //    sqlite3_free(sql);
    //    LOGOUT("UpdateDspsettings:%s",errmsg);
    return SUCESS;
}

S_ret Sqlite3Base::UpdateDspSource(int source)
{

    //    char * sql;
    //    sql = sqlite3_mprintf("update DSPsettings set "
    //                          "outputsource=%d",
    //                          source);
    //    result = sqlite3_exec(db,sql,0,0,&errmsg);
    //    sqlite3_free(sql);
    //    LOGOUT("UpdateDspsettings:%s",errmsg);
    return SUCESS;
}

S_ret Sqlite3Base::UpdateDspVolume(int volume,int i )
{

    //    char * sql;
    //    if(i>=CHANNELS)return 0;
    //    sql = sqlite3_mprintf("update DSPsettings set "
    //                          "volume=%d "
    //                          "where id = %d",
    //                          volume,i
    //                          );

    //    result = sqlite3_exec(db,sql,0,0,&errmsg);
    //    sqlite3_free(sql);
    //    LOGOUT("UpdateDspsettings:%s",errmsg);
    return SUCESS;
}

S_ret Sqlite3Base::UpdateDspVolume(int volume)
{

    //    char * sql;
    //    sql = sqlite3_mprintf("update DSPsettings set "
    //                          "volume=%d",
    //                          volume
    //                          );

    //    result = sqlite3_exec(db,sql,0,0,&errmsg);
    //    sqlite3_free(sql);
    //    LOGOUT("UpdateDspsettings:%s",errmsg);
    return SUCESS;
}

S_ret Sqlite3Base::SelectDsp(DSPstreaming &info)
{
    sqlite3_stmt * stmt = NULL;
    const char *zTail;

    //    if (sqlite3_prepare_v2(db,
    //                           "SELECT * FROM DSPsettings;", -1, &stmt, &zTail) ==SQLITE_OK){
    //        while( sqlite3_step(stmt) ==SQLITE_ROW ) {
    //            int row=sqlite3_column_int(stmt,0);
    //            if(row<CHANNELS)
    //            {
    //                info.inputvolume[row]=sqlite3_column_int(stmt,1);
    //                info.inputdelay[row]=sqlite3_column_int(stmt,2);
    //                info.outputdelay[row]=sqlite3_column_int(stmt,3);
    //                info.outputsource[row]=sqlite3_column_int(stmt,4);

    //                info.peq[row][0]=sqlite3_column_int(stmt,5);
    //                info.peq[row][1]=sqlite3_column_int(stmt,6);
    //                info.peq[row][2]=sqlite3_column_int(stmt,7);
    //                info.peq[row][3]=sqlite3_column_int(stmt,8);
    //                info.peq[row][4]=sqlite3_column_int(stmt,9);


    //                info.shelf[row][0]=sqlite3_column_int(stmt,10);
    //                info.shelf[row][1]=sqlite3_column_int(stmt,11);
    //                info.shelf[row][2]=sqlite3_column_int(stmt,12);
    //                info.shelf[row][3]=sqlite3_column_int(stmt,13);
    //                info.shelf[row][4]=sqlite3_column_int(stmt,14);


    //                info.xover[row][0]=sqlite3_column_int(stmt,15);
    //                info.xover[row][1]=sqlite3_column_int(stmt,16);
    //                info.xover[row][2]=sqlite3_column_int(stmt,17);


    //                info.loudness[row]=sqlite3_column_int(stmt,18);
    //                info.startvolume[row]=sqlite3_column_int(stmt,19);
    //                info.maxvolume[row]=sqlite3_column_int(stmt,20);
    //                info.volume[row]=sqlite3_column_int(stmt,21);
    //                info.dspmute[row]=sqlite3_column_int(stmt,22);


    //                info.balance[row]=sqlite3_column_int(stmt,23);
    //                info.merge[row]=sqlite3_column_int(stmt,24);
    //                info.group[row]=sqlite3_column_int(stmt,25);
    //                info.oscgain[row]=sqlite3_column_int(stmt,26);
    //                info.dspfirmware[row]=sqlite3_column_int(stmt,27);
    //                info.dspsamplerate[row]=sqlite3_column_int(stmt,28);
    //            }

    //        }
    //    }
    //    sqlite3_finalize(stmt);
    return SUCESS;
}

S_ret Sqlite3Base::deleteDatabase()
{
    sqlite3_close(db);
    //system(FACTORYDATA);
    return SUCESS;
}

S_ret Sqlite3Base::runsqlcmd(string sqlcmd)
{
    if(db == nullptr) return ERROR;
    LOGOUT("%s",sqlcmd.c_str());
    result = sqlite3_exec( db , sqlcmd.c_str(),0, 0, &errmsg);
    if(result != SQLITE_OK) {
        LOGOUT("%s",errmsg);
    }
    return SUCESS;
}

S_ret Sqlite3Base::runsqlcmd(string sqlcmd,sqlite3_callback func,void *data)
{
    if(db == nullptr) return ERROR;
    result = sqlite3_exec( db , sqlcmd.c_str(),func, data, &errmsg);
    if(result != SQLITE_OK) {
        LOGOUT("%s",errmsg);
    }
    return SUCESS;
}

S_ret Sqlite3Base::runsqlcmd(string sqlcmd,char ** sqlresoult,int &row,int &col)
{
    char **pazResult;
    sqlresoult=sqlresoult;
    sqlite3_get_table(db, sqlcmd.c_str(), &pazResult, &row, &col, 0);



    sqlite3_free_table(pazResult);
    return SUCESS;
}

S_ret Sqlite3Base::CreateLogin()
{
    if(db == nullptr)
        return ERROR;

    string sqlcmd = "create table if not exists t_account "
                    "(id int,username text, passwd text,changetype int,status int,"
                    "failnumber int,locktime text,logintime timestamp not null default current_timestamp,"
                    "updatetime timestamp not null default current_timestamp"
                    ");";
    result = sqlite3_exec(db, sqlcmd.c_str(), 0, 0, &errmsg);
    if(result != SQLITE_OK)
    {
        LOGOUT("%s", errmsg);
        return FAILED;
    }

    return SUCESS;
}

S_ret Sqlite3Base::initLoginInfo()
{
    if( !isrecordexist("select * from t_account") )
    {
        char *zSQL = sqlite3_mprintf("INSERT INTO t_account VALUES(%d,'%s','%s','%d','%d','%d','%s','%s','%s')",
                                     0, "triad", "triad", 0, 0, 0, "0", "0", "0");
        result = sqlite3_exec(db, zSQL, 0, 0, &errmsg);
        sqlite3_free(zSQL);

        if(result != SQLITE_OK)
        {
            LOGOUT("%s", errmsg);
            return FAILED;
        }
    }
    return SUCESS;
}

S_ret Sqlite3Base::getLoginInfo(_logininfo &info)
{
    sqlite3_stmt * stmt = NULL;
    const char *zTail;
    if (sqlite3_prepare_v2(db,
                           "SELECT * FROM t_account;", -1, &stmt, &zTail) == SQLITE_OK)
    {
        while( sqlite3_step(stmt) == SQLITE_ROW) {

            info.mUserName = (char *)sqlite3_column_text(stmt,1);
            info.mUserPasswd = (char *)sqlite3_column_text( stmt,2);
            info.mChangeType = sqlite3_column_int(stmt,3);
            info.mStatus = sqlite3_column_int(stmt,4);
            info.mFailNumber = sqlite3_column_int(stmt,5);
            info.mLockTime = (char *)sqlite3_column_text(stmt,6);
        }
        info.mStatus = 0;
    }
    sqlite3_finalize(stmt);
    return SUCESS;
}

S_ret Sqlite3Base::updateLoginInfo(_logininfo info)
{
    char * sql;
    char * zErrMsg = NULL;

    sql = sqlite3_mprintf("update t_account set username='%s',passwd='%s',changetype=%d,status=%d,"
                          "failnumber=%d,locktime='%s' where id = 0",info.mUserName.c_str(),
                          info.mUserPasswd.c_str(),info.mChangeType,info.mStatus,
                          info.mFailNumber,info.mLockTime.c_str());
    sqlite3_exec(getDB(), sql, 0, 0, &zErrMsg);
    sqlite3_free(sql);
    return SUCESS;
}

S_ret Sqlite3Base::CreateWebExtraInfo()
{
    if(db == nullptr)
        return ERROR;

    string sqlcmd = "create table if not exists webInfoTab "
                    "(id int, inputname text, outputname text, assigntrigger text);";
    result = sqlite3_exec(db, sqlcmd.c_str(), 0, 0, &errmsg);
    if(result != SQLITE_OK)
    {
        LOGOUT("%s", errmsg);
        return FAILED;
    }

    return SUCESS;
}

S_ret Sqlite3Base::initWebExtraInfo()
{
    if( !isrecordexist("select * from webInfoTab") )
    {
        for(int i = 0; i < CHANNELS; i++)
        {
            char *zSQL = sqlite3_mprintf("INSERT INTO webInfoTab VALUES(%d,'%s','%s','%s')",
                                         i, (string("Input")+to_string(i+1)).c_str(),
                                         (string("Output")+to_string(i+1)).c_str(), "0");
            result = sqlite3_exec(db, zSQL, 0, 0, &errmsg);
            sqlite3_free(zSQL);

            if(result != SQLITE_OK)
            {
                LOGOUT("%s", errmsg);
                return FAILED;
            }
        }
    }
    return SUCESS;
}

S_ret Sqlite3Base::getWebExtraInfo(_webextrainfo &info)
{
    sqlite3_stmt * stmt = NULL;
    const char *zTail;
    if (sqlite3_prepare_v2(db,
                           "SELECT * FROM webInfoTab;", -1, &stmt, &zTail) == SQLITE_OK)
    {
        while( sqlite3_step(stmt) == SQLITE_ROW)
        {
            int row=sqlite3_column_int(stmt,0);
            if(row < CHANNELS)
            {
                info.inputname[row] = (char *)sqlite3_column_text(stmt,1);
                info.outputname[row] = (char *)sqlite3_column_text( stmt,2);
                info.assigntrigger[row] = (char *)sqlite3_column_text( stmt,3);
            }
        }
    }
    sqlite3_finalize(stmt);
    return SUCESS;
}

#if 0
S_ret Sqlite3Base::CreateDspInfoTab()
{
    if(db == nullptr)
        return ERROR;

    string sqlcmd = "create table if not exists dspInfo (id int,"
                    "'dsp_preset_name' text);";

    result = sqlite3_exec(db,sqlcmd.c_str(),0, 0, &errmsg);
    if(result != SQLITE_OK)
    {
        DEBUG_LOG("create table dspInfo: %s", errmsg);
        return FAILED;
    }

    return SUCESS;
}

S_ret Sqlite3Base::initDspInfoTab()
{
    if(isrecordexist("select * from dspInfo"))
    {
        return FAILED;
    }

    for(int i = 0; i < sysdata::getInstance()->mDspPresetInfo.size(); i++)
    {
        char *zSQL = sqlite3_mprintf("INSERT INTO dspInfo VALUES('%d','%s')",
                                     i,
                                     sysdata::getInstance()->mDspPresetInfo[i].mDspItemName.c_str());
        result = sqlite3_exec(db,zSQL, 0, 0, &errmsg);
        sqlite3_free(zSQL);
        if(result != SQLITE_OK)
        {
            DEBUG_LOG("initDspInfoTab error:%s", errmsg);
            return FAILED;
        }
    }
    return SUCESS;
}

S_ret Sqlite3Base::getDspInfoFromTab(vector<_dspPresetItemInfo> &info)
{
    sqlite3_stmt * stmt = NULL;
    const char *zTail;
    int nRow = 0;

    if (sqlite3_prepare_v2(db,
                           "SELECT * FROM dspInfo order by id;", -1, &stmt, &zTail) == SQLITE_OK)
    {
        //int rows = sqlite3_column_int(stmt, 0);

        while(sqlite3_step(stmt) == SQLITE_ROW)
        {
            if(info.size() > nRow)
            {
                info[nRow].mDspItemName = (char *)sqlite3_column_text(stmt,1);

                nRow++;
            }
        }
    }
    sqlite3_finalize(stmt);
    return SUCESS;
}

#endif

S_ret Sqlite3Base::CreateRoomDspPresetInfoTab()
{
    if(db == nullptr)
        return ERROR;

    string sqlcmd = "create table if not exists t_room_Dsp_Preset_Info (id int,"
                    "'room_dsp_preset_name' text, 'uuid_0' text,'eq_enable_0' text,'eq_freq_0' text,'eq_qratio_0' text,'eq_gain_0' text,"
                    "'uuid_1' text,'eq_enable_1' text,'eq_freq_1' text,'eq_qratio_1' text,'eq_gain_1' text,"
                    "'uuid_2' text,'eq_enable_2' text,'eq_freq_2' text,'eq_qratio_2' text,'eq_gain_2' text,"
                    "'uuid_3' text,'eq_enable_3' text,'eq_freq_3' text,'eq_qratio_3' text,'eq_gain_3' text,"
                    "'uuid_4' text,'eq_enable_4' text,'eq_freq_4' text,'eq_qratio_4' text,'eq_gain_4' text,"
                    "'uuid_5' text,'eq_enable_5' text,'eq_freq_5' text,'eq_qratio_5' text,'eq_gain_5' text);";

    result = sqlite3_exec(db,sqlcmd.c_str(),0, 0, &errmsg);
    if(result != SQLITE_OK)
    {
        DEBUG_LOG("create table t_room_Dsp_Preset_Info: %s", errmsg);
        return FAILED;
    }

    return SUCESS;
}

S_ret Sqlite3Base::initRoomDspPresetInfoTab()
{
    if(isrecordexist("select * from t_room_Dsp_Preset_Info"))
    {
        return FAILED;
    }

    string cmd;

    for(int i = 0; i < sysdata::getInstance()->mRoomDspVecInfo.size(); i++)
    {
        cmd = "INSERT INTO t_room_Dsp_Preset_Info VALUES(";
        cmd += sysdata::getInstance()->mRoomDspVecInfo.at(i).mRoomDspIndex +",'";
        cmd += sysdata::getInstance()->mRoomDspVecInfo[i].mRoomDspName +"','" ; // Name
        for(int n = 0 ; n < MAX_EQ_NUM;n++)
        {
            cmd += sysdata::getInstance()->mRoomDspVecInfo[i].mRoomEqIndex[n] +"','";
            cmd += sysdata::getInstance()->mRoomDspVecInfo[i].mRoomEqEnable[n] +"','";
            cmd += sysdata::getInstance()->mRoomDspVecInfo[i].mRoomEqFreq[n] +"','";
            cmd += sysdata::getInstance()->mRoomDspVecInfo[i].mRoomEqQratio[n] +"','";
            if(MAX_EQ_NUM == (n+1))
                cmd += sysdata::getInstance()->mRoomDspVecInfo[i].mRoomEqGain[n] +"');";
            else
                cmd += sysdata::getInstance()->mRoomDspVecInfo[i].mRoomEqGain[n] +"','";

        }
        DEBUG_LOG("room cmd: %s",cmd.c_str());
        result = sqlite3_exec(db,cmd.c_str(), 0, 0, &errmsg);
    }
    return SUCESS;
}

S_ret Sqlite3Base::getRoomDspPresetInfoFromTab(vector<_roomDspPresetItemInfo> &info)
{
    info.clear();

    sqlite3_stmt * stmt = NULL;
    const char *zTail;

    if (sqlite3_prepare_v2(db,
                           "SELECT * FROM t_room_Dsp_Preset_Info order by id;", -1, &stmt, &zTail) == SQLITE_OK)
    {
        while(sqlite3_step(stmt) == SQLITE_ROW)
        {

            _roomDspPresetItemInfo tmp;

            int v = sqlite3_column_int(stmt,0);

            tmp.mRoomDspIndex = to_string(v);
            tmp.mRoomDspName = (char *)sqlite3_column_text(stmt,1);
            for(int i = 0; i < MAX_EQ_NUM; i++)
            {
                tmp.mRoomEqIndex[i] = (char *)sqlite3_column_text(stmt,2+5*i);
                tmp.mRoomEqEnable[i] = (char *)sqlite3_column_text(stmt,3+5*i);
                tmp.mRoomEqFreq[i] = (char *)sqlite3_column_text(stmt,4+5*i);
                tmp.mRoomEqQratio[i] = (char *)sqlite3_column_text(stmt,5+5*i);
                tmp.mRoomEqGain[i] = (char *)sqlite3_column_text(stmt,6+5*i);
            }

            info.push_back(tmp);
        }
    }
    sqlite3_finalize(stmt);
    return SUCESS;
}

S_ret Sqlite3Base::CreateSpeakerDspPresetInfoTab()
{
    if(db == nullptr)
        return ERROR;

    string sqlcmd = "create table if not exists t_speaker_Dsp_Preset_Info (id integer PRIMARY KEY autoincrement,"
                    "'speaker_dsp_preset_name' text, 'uuid_0' text,'eq_enable_0' text,'eq_freq_0' text,'eq_qratio_0' text,'eq_gain_0' text,"
                    "'uuid_1' text,'eq_enable_1' text,'eq_freq_1' text,'eq_qratio_1' text,'eq_gain_1' text,"
                    "'uuid_2' text,'eq_enable_2' text,'eq_freq_2' text,'eq_qratio_2' text,'eq_gain_2' text,"
                    "'uuid_3' text,'eq_enable_3' text,'eq_freq_3' text,'eq_qratio_3' text,'eq_gain_3' text,"
                    "'uuid_4' text,'eq_enable_4' text,'eq_freq_4' text,'eq_qratio_4' text,'eq_gain_4' text,"
                    "'uuid_5' text,'eq_enable_5' text,'eq_freq_5' text,'eq_qratio_5' text,'eq_gain_5' text);";

    result = sqlite3_exec(db,sqlcmd.c_str(),0, 0, &errmsg);
    if(result != SQLITE_OK)
    {
        DEBUG_LOG("create table t_speaker_Dsp_Preset_Info: %s", errmsg);
        return FAILED;
    }

    return SUCESS;
}

S_ret Sqlite3Base::initSpeakerDspPresetInfoTab()
{
    if(isrecordexist("select * from t_speaker_Dsp_Preset_Info"))
    {
        return FAILED;
    }

    string cmd;

    for(int i = 0; i < sysdata::getInstance()->mSpeakerDspMapInfo.size(); i++)
    {
        cmd = "INSERT INTO t_speaker_Dsp_Preset_Info VALUES(?,'";
        cmd += sysdata::getInstance()->mSpeakerDspMapInfo[i+1].mSpeakerDspName +"','" ; // Name
        for(int n = 0 ; n < MAX_EQ_NUM;n++)
        {
            cmd += sysdata::getInstance()->mSpeakerDspMapInfo[i+1].mSpeakerEqIndex[n] +"','";
            cmd += sysdata::getInstance()->mSpeakerDspMapInfo[i+1].mSpeakerEqEnable[n] +"','";
            cmd += sysdata::getInstance()->mSpeakerDspMapInfo[i+1].mSpeakerEqFreq[n] +"','";
            cmd += sysdata::getInstance()->mSpeakerDspMapInfo[i+1].mSpeakerEqQratio[n] +"','";
            if(MAX_EQ_NUM == (n+1))
                cmd += sysdata::getInstance()->mSpeakerDspMapInfo[i+1].mSpeakerEqGain[n] +"');";
            else
                cmd += sysdata::getInstance()->mSpeakerDspMapInfo[i+1].mSpeakerEqGain[n] +"','";

        }
        DEBUG_LOG("speaker cmd:%s",cmd.c_str());
        result = sqlite3_exec(db,cmd.c_str(), 0, 0, &errmsg);
    }
    return SUCESS;
}

S_ret Sqlite3Base::getSpeakerDspPresetInfoFromTab(SPEAKER_PRESET_MAP &info)
{
    info.erase(info.begin(),info.end());

    sqlite3_stmt * stmt = NULL;
    const char *zTail;

    if (sqlite3_prepare_v2(db,
                           "SELECT * FROM t_speaker_Dsp_Preset_Info order by id;", -1, &stmt, &zTail) == SQLITE_OK)
    {
        while(sqlite3_step(stmt) == SQLITE_ROW)
        {

            _speakerDspPresetItemInfo tmp;

            sqlite3_int64 v = sqlite3_column_int64(stmt,0);

            tmp.mSpeakerDspIndex = to_string(v);
            tmp.mSpeakerDspName = (char *)sqlite3_column_text(stmt,1);
            for(int i = 0; i < MAX_EQ_NUM; i++)
            {
                tmp.mSpeakerEqIndex[i] = (char *)sqlite3_column_text(stmt,2+5*i);
                tmp.mSpeakerEqEnable[i] = (char *)sqlite3_column_text(stmt,3+5*i);
                tmp.mSpeakerEqFreq[i] = (char *)sqlite3_column_text(stmt,4+5*i);
                tmp.mSpeakerEqQratio[i] = (char *)sqlite3_column_text(stmt,5+5*i);
                tmp.mSpeakerEqGain[i] = (char *)sqlite3_column_text(stmt,6+5*i);
            }

            info[v] = tmp;
        }
    }
    sqlite3_finalize(stmt);
    return SUCESS;
}

#if 0
S_ret Sqlite3Base::CreateEqItemTab()
{
    if(db == nullptr)
        return ERROR;

    string sqlcmd = "create table if not exists eqitemInfo ('dsp_index' text,"
                    "uuid text,'eq_enable' text,'eq_freq' text,'eq_qratio' text,'eq_gain' text);";

    result = sqlite3_exec(db,sqlcmd.c_str(),0, 0, &errmsg);
    if(result != SQLITE_OK)
    {
        DEBUG_LOG("create table eqitemInfo:%s",errmsg);
        return FAILED;
    }

    return SUCESS;
}

S_ret Sqlite3Base::initEqItemTab()
{
    if(db == nullptr)
        return ERROR;

    if(isrecordexist("select * from eqitemInfo"))
    {
        return FAILED;
    }

    for(int i = 0; i < sysdata::getInstance()->mEQItemInfo.size(); i++)
    {
        char *zSQL = sqlite3_mprintf("INSERT INTO eqitemInfo VALUES('%s','%s','%s','%s','%s','%s')",
                                     sysdata::getInstance()->mEQItemInfo[i].mDspPresetIndex.c_str(),
                                     sysdata::getInstance()->mEQItemInfo[i].mDspEqUuid.c_str(),
                                     sysdata::getInstance()->mEQItemInfo[i].mDspEqEnable.c_str(),
                                     sysdata::getInstance()->mEQItemInfo[i].mDspEqFreq.c_str(),
                                     sysdata::getInstance()->mEQItemInfo[i].mDspEqQratio.c_str(),
                                     sysdata::getInstance()->mEQItemInfo[i].mDspEqGain.c_str());
        result = sqlite3_exec(db, zSQL, 0, 0, &errmsg);
        sqlite3_free(zSQL);
        if(result != SQLITE_OK)
        {
            DEBUG_LOG("initEqItemTab error:%s", errmsg);
            return FAILED;
        }
    }
    return SUCESS;
}

S_ret Sqlite3Base::getEqItemFromTab(vector<_dspEqItemInfo> &info)
{
    sqlite3_stmt * stmt = NULL;
    const char *zTail;
    int nRow = 0;

    if (sqlite3_prepare_v2(db,
                           "SELECT * FROM eqitemInfo order by cast(dsp_index as int);", -1, &stmt, &zTail) == SQLITE_OK)
    {
        //int rows = sqlite3_column_int(stmt, 0);

        while(sqlite3_step(stmt) == SQLITE_ROW)
        {
            if(info.size() > nRow)
            {
                info[nRow].mDspPresetIndex = (char *)sqlite3_column_text(stmt,0);
                info[nRow].mDspEqUuid = (char *)sqlite3_column_text(stmt,1);
                info[nRow].mDspEqEnable = (char *)sqlite3_column_text(stmt,2);
                info[nRow].mDspEqFreq = (char *)sqlite3_column_text(stmt,3);
                info[nRow].mDspEqQratio = (char *)sqlite3_column_text(stmt,4);
                info[nRow].mDspEqGain = (char *)sqlite3_column_text(stmt,5);

                nRow++;
            }
        }
    }
    sqlite3_finalize(stmt);
    return SUCESS;
}

#endif

S_ret Sqlite3Base::CreateOutputDspTab()
{
    if(db == nullptr)
        return ERROR;

    string sqlcmd = "create table if not exists outputDspInfo (id int,output_tone_bass_enable text,output_tone_bass_freq text,output_tone_bass_q text,"
                    "output_tone_bass text, output_tone_treble_enable text, output_tone_treble_freq text,output_tone_treble_q text,'output_tone_treble' text,"
            "'output_loudness_enable' text,'output_room_dsp_preset' text, 'output_speaker_dsp_preset' text, output_lock text);";

    result = sqlite3_exec(db,sqlcmd.c_str(),0, 0, &errmsg);
    if(result != SQLITE_OK)
    {
        DEBUG_LOG("create table outputDspInfo:%s",errmsg);
        return FAILED;
    }

    return SUCESS;
}

S_ret Sqlite3Base::initOutputDspTab()
{
    if(db == nullptr)
        return ERROR;

    if(isrecordexist("select * from outputDspInfo"))
    {
        return FAILED;
    }

    for(int i = 0; i < CHANNELS; i++)
    {
        char *zSQL = sqlite3_mprintf("INSERT INTO outputDspInfo VALUES('%d','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')",
                                     i,
                                     sysdata::getInstance()->mOutputDspInfo[i].mOutputToneBassEN.c_str(),
                                     sysdata::getInstance()->mOutputDspInfo[i].mOutputToneBassFreq.c_str(),
                                     sysdata::getInstance()->mOutputDspInfo[i].mOutputToneBassQ.c_str(),
                                     sysdata::getInstance()->mOutputDspInfo[i].mOutputToneBass.c_str(),
                                     sysdata::getInstance()->mOutputDspInfo[i].mOutputToneTrebleEN.c_str(),
                                     sysdata::getInstance()->mOutputDspInfo[i].mOutputToneTrebleFreq.c_str(),
                                     sysdata::getInstance()->mOutputDspInfo[i].mOutputToneTrebleQ.c_str(),
                                     sysdata::getInstance()->mOutputDspInfo[i].mOutputToneTreble.c_str(),
                                     sysdata::getInstance()->mOutputDspInfo[i].mOutputLoudnessEN.c_str(),
                                     sysdata::getInstance()->mOutputDspInfo[i].mOutputRoomDspPreset.c_str(),
                                     sysdata::getInstance()->mOutputDspInfo[i].mOutputSpeakerDspPreset.c_str(),
                                     sysdata::getInstance()->mOutputDspInfo[i].mOutputLock.c_str());
        result = sqlite3_exec(db, zSQL, 0, 0, &errmsg);
        sqlite3_free(zSQL);
        if(result != SQLITE_OK)
        {
            DEBUG_LOG("initOutputDspTab error:%s", errmsg);
            return FAILED;
        }
    }

    return SUCESS;
}

S_ret Sqlite3Base::getOutputDspFromTab()
{
    sqlite3_stmt * stmt = NULL;
    const char *zTail;
    int nRow = 0;

    if (sqlite3_prepare_v2(db,
                           "SELECT * FROM outputDspInfo order by id;", -1, &stmt, &zTail) == SQLITE_OK)
    {
        //int rows = sqlite3_column_int(stmt, 0);

        while(sqlite3_step(stmt) == SQLITE_ROW)
        {
            if(nRow < CHANNELS)
            {
                sysdata::getInstance()->mOutputDspInfo[nRow].mOutputToneBassEN = (char *)sqlite3_column_text(stmt,1);
                sysdata::getInstance()->mOutputDspInfo[nRow].mOutputToneBassFreq = (char *)sqlite3_column_text(stmt,2);
                sysdata::getInstance()->mOutputDspInfo[nRow].mOutputToneBassQ = (char *)sqlite3_column_text(stmt,3);
                sysdata::getInstance()->mOutputDspInfo[nRow].mOutputToneBass = (char *)sqlite3_column_text(stmt,4);
                sysdata::getInstance()->mOutputDspInfo[nRow].mOutputToneTrebleEN = (char *)sqlite3_column_text(stmt,5);
                sysdata::getInstance()->mOutputDspInfo[nRow].mOutputToneTrebleFreq = (char *)sqlite3_column_text(stmt,6);
                sysdata::getInstance()->mOutputDspInfo[nRow].mOutputToneTrebleQ = (char *)sqlite3_column_text(stmt,7);
                sysdata::getInstance()->mOutputDspInfo[nRow].mOutputToneTreble = (char *)sqlite3_column_text(stmt,8);
                sysdata::getInstance()->mOutputDspInfo[nRow].mOutputLoudnessEN = (char *)sqlite3_column_text(stmt,9);
                sysdata::getInstance()->mOutputDspInfo[nRow].mOutputRoomDspPreset = (char *)sqlite3_column_text(stmt,10);
                sysdata::getInstance()->mOutputDspInfo[nRow].mOutputSpeakerDspPreset = (char *)sqlite3_column_text(stmt,11);
                sysdata::getInstance()->mOutputDspInfo[nRow].mOutputLock = (char *)sqlite3_column_text(stmt,12);

                nRow++;
            }
        }
    }
    sqlite3_finalize(stmt);
    return SUCESS;
}

S_ret Sqlite3Base::CreateSubDspTab()
{
    if(db == nullptr)
        return ERROR;

    string sqlcmd = "create table if not exists subDspInfo (id int,"
                    "sub_enable text,'sub_volume_offset' text,'sub_crossover_type' text,"
                    "'sub_crossover_slop' text,'sub_crossover_freq' text);";

    result = sqlite3_exec(db,sqlcmd.c_str(),0, 0, &errmsg);
    if(result != SQLITE_OK)
    {
        DEBUG_LOG("create table subDspInfo:%s",errmsg);
        return FAILED;
    }

    return SUCESS;
}

S_ret Sqlite3Base::initSubDspTab()
{
    if(db == nullptr)
        return ERROR;

    if(isrecordexist("select * from subDspInfo"))
    {
        return FAILED;
    }

    for(int i = 0; i < CHANNELS; i++)
    {
        char *zSQL = sqlite3_mprintf("INSERT INTO subDspInfo VALUES('%d','%s','%s','%s','%s','%s')",
                                     i,
                                     sysdata::getInstance()->mSubDspInfo[i].mSubDspEnable.c_str(),
                                     sysdata::getInstance()->mSubDspInfo[i].mSubVolOffset.c_str(),
                                     sysdata::getInstance()->mSubDspInfo[i].mSubCrossoverType.c_str(),
                                     sysdata::getInstance()->mSubDspInfo[i].mSubCrossoverSlop.c_str(),
                                     sysdata::getInstance()->mSubDspInfo[i].mSubCrossoverFreq.c_str());
        result = sqlite3_exec(db, zSQL, 0, 0, &errmsg);
        sqlite3_free(zSQL);
        if(result != SQLITE_OK)
        {
            DEBUG_LOG("initOutputDspTab error:%s", errmsg);
            return FAILED;
        }
    }

    return SUCESS;
}

S_ret Sqlite3Base::getSubDspFromTab()
{
    sqlite3_stmt * stmt = NULL;
    const char *zTail;
    int nRow = 0;

    if (sqlite3_prepare_v2(db,
                           "SELECT * FROM subDspInfo order by id;", -1, &stmt, &zTail) == SQLITE_OK)
    {
        //int rows = sqlite3_column_int(stmt, 0);

        while(sqlite3_step(stmt) == SQLITE_ROW)
        {
            if(nRow < CHANNELS)
            {
                sysdata::getInstance()->mSubDspInfo[nRow].mSubDspEnable = (char *)sqlite3_column_text(stmt,1);
                sysdata::getInstance()->mSubDspInfo[nRow].mSubVolOffset = (char *)sqlite3_column_text(stmt,2);
                sysdata::getInstance()->mSubDspInfo[nRow].mSubCrossoverType = (char *)sqlite3_column_text(stmt,3);
                sysdata::getInstance()->mSubDspInfo[nRow].mSubCrossoverSlop = (char *)sqlite3_column_text(stmt,4);
                sysdata::getInstance()->mSubDspInfo[nRow].mSubCrossoverFreq = (char *)sqlite3_column_text(stmt,5);

                nRow++;
            }
        }
    }
    sqlite3_finalize(stmt);
    return SUCESS;
}


//S_ret Sqlite3Base::updateOvrcNetInfo(_cloudinfo info)
//{
//    char * sql;
//    char * zErrMsg = NULL;

//    sql = sqlite3_mprintf("update t_ovrcSetting set webpageport='%s' where id = 0",info.webpageport.c_str());
//    sqlite3_exec(db,sql,0,0,&zErrMsg);
//    sqlite3_free(sql);
//    return SUCESS;
//}

//S_ret Sqlite3Base::getInOutPutDataInfo51(vector<_inPutSettingInfo51> &inPutInfo, vector<_outPutSettingInfo51> &outPutInfo)
//{
//    sqlite3_stmt * stmt = NULL;
//    const char *zTail;
//    int i = 0;
//    if (sqlite3_prepare_v2(db,
//                           "SELECT * FROM t_inputsetting;", -1, &stmt, &zTail) ==SQLITE_OK){
//        while( sqlite3_step(stmt) ==SQLITE_ROW ) {
//            inPutInfo[i].mEnable = (char *)sqlite3_column_text(stmt,1);
//            inPutInfo[i].mInputName = (char *)sqlite3_column_text(stmt,2);
//            inPutInfo[i].mSoundMode = (char *)sqlite3_column_text(stmt,3);
//            inPutInfo[i].mMaxVolume = (char *)sqlite3_column_text(stmt,4);
//            inPutInfo[i].mInputGain = (char *)sqlite3_column_text(stmt,5);
//            i++;
//            if(i == SNAPAV)
//                break;
//        }
//    }
//    sqlite3_finalize(stmt);

//    i = 0;
//    if (sqlite3_prepare_v2(db,
//                           "SELECT * FROM t_outputsetting;", -1, &stmt, &zTail) ==SQLITE_OK){
//        while( sqlite3_step(stmt) ==SQLITE_ROW ) {
//            outPutInfo[i].mSpeakerSize = (char *)sqlite3_column_text(stmt,1);
//            outPutInfo[i].mCrossOver = (char *)sqlite3_column_text(stmt,2);
//            outPutInfo[i].mSlope = (char *)sqlite3_column_text(stmt,3);
//            outPutInfo[i].mSpeakerLevel = (char *)sqlite3_column_text(stmt,4);
//            outPutInfo[i].mFeet = (char *)sqlite3_column_text(stmt,5);
//            outPutInfo[i].mMeters = (char *)sqlite3_column_text(stmt,6);
//            outPutInfo[i].mTestSignalEnable = (char *)sqlite3_column_text(stmt,7);
//            i++;
//            if(i == SNAPAV)
//                break;
//        }
//    }
//    sqlite3_finalize(stmt);
//    return SUCESS;
//}

//S_ret Sqlite3Base::getSystemSettingInfo51(_systemConfigSetting51 &info)
//{
//    sqlite3_stmt * stmt = NULL;
//    const char *zTail;
//    if (sqlite3_prepare_v2(db,
//                           "SELECT * FROM dspsettings;", -1, &stmt, &zTail) ==SQLITE_OK){
//        while( sqlite3_step(stmt) ==SQLITE_ROW ) {
//            info.mSystemItem51.mDeviceName = (char *)sqlite3_column_text(stmt,1);
//            info.mSystemItem51.mPowerOnInput = (char *)sqlite3_column_text(stmt,2);
//            info.mCecItem51.mCecEnable = (char *)sqlite3_column_text(stmt,3);
//            info.mCecItem51.mPowerOnEnable = (char *)sqlite3_column_text(stmt,4);
//            info.mCecItem51.mPowerOffEnable = (char *)sqlite3_column_text(stmt,5);
//            info.mCecItem51.mSourceEnable = (char *)sqlite3_column_text(stmt,6);
//            info.mCecItem51.mVolumeEnable = (char *)sqlite3_column_text(stmt,7);
//            info.mGeneralItem.mNetWorkStandy = (char *)sqlite3_column_text(stmt,8);
//            info.mGeneralItem.mHdmiAudioOut = (char *)sqlite3_column_text(stmt,9);
//        }
//    }
//    sqlite3_finalize(stmt);
//    return SUCESS;
//}


bool Sqlite3Base::isrecordexist(string sqlcmd)
{
    //查询记录（返回数据表的方式）
    char **pazResult;
    int nRow, nCol;
    sqlite3_get_table(db,sqlcmd.c_str() , &pazResult, &nRow, &nCol, 0);

    DEBUG_LOG("sqlcmd:%s row:%d col:%d ",sqlcmd.c_str(),nRow,nCol);

    sqlite3_free_table(pazResult);
    if(nRow == 0  ) return false;
    return true;
}

#if 0
S_ret Sqlite3Base::restoreInOutPutTable(_deviceinfo dev,vector<_inPutSettingInfo> input, vector<_outPutSettingInfo> output)
{
    char * sql;
    char * zErrMsg = NULL;
    sql = sqlite3_mprintf("update systemsetting set autoonmethod='%s',powerondelay='%s'"
                          "where id = 0",dev.autoonmethod.c_str(),
                          dev.powerondelay.c_str());
    sqlite3_exec(db,sql,0,0,&zErrMsg);
    sqlite3_free(sql);

    SystemControl::getInstance()->devinfo.autoonmethod = dev.autoonmethod;
    SystemControl::getInstance()->devinfo.powerondelay = dev.powerondelay;
    //SystemControl::getInstance()->devinfo.flashEnabled = dev.flashEnabled;

    for(int i = 0;i < input.size();i++)
    {
        _inPutSettingInfo tmp = input.at(i);

        sql = sqlite3_mprintf("update inputsetting set input_name='%s',input_level_trim='%s'"
                              " where id = %d",tmp.mInputName.c_str(),
                              tmp.mInputDb.c_str(),i);
        sqlite3_exec(db,sql,0,0,&zErrMsg);
        sqlite3_free(sql);

        SystemControl::getInstance()->mInputInfo[i] =tmp;
    }

    for(int i = 0;i < output.size();i++)
    {
        _outPutSettingInfo tmp = output.at(i);

        sql = sqlite3_mprintf("update outputsetting set output_name='%s',sleep_mode='%s',output_source1='%s',"
                              "output_source2='%s',output_source2_mode='%s',bridge_mode='%s',stereo_or_mono='%s',"
                              "dsp_preset='%s',output_group='%s',output_mute='%s',output_volume='%s',"
                              "turnon_volume='%s',max_volume='%s',gain_offset='%s' where id = %d",tmp.mOutputName.c_str(),
                              tmp.mOutputSleepMode.c_str(),tmp.mOutputSource1.c_str(),tmp.mOutputSource2.c_str(),
                              tmp.mOutputSource2Mode.c_str(),tmp.mOutputBridgeMode.c_str(),tmp.mOutputStereoMono.c_str(),
                              tmp.mOutputDspPresent.c_str(),tmp.mOutputGroup.c_str(),tmp.mOutputMute.c_str(),
                              tmp.mOutputVol.c_str(),tmp.mOutputTurnOnVol.c_str(),tmp.mOutputMaxVol.c_str(),
                              tmp.mOutputGain.c_str(),i);
        sqlite3_exec(db,sql,0,0,&zErrMsg);
        sqlite3_free(sql);

        SystemControl::getInstance()->mOutputInfo[i] =tmp;
    }


}
#endif
//"id int,"
//"inputvolume int,"
//"inputdelay int,"
//"outputdelay int,"
//"outputsource int,"
//"merge bit,"
//"eqfreq float,"
//"eqQv float,"
//"eqtreble float,"
//"eqbass float,"
//"balance float,"
//"eqloudness bit,"
//"linemute bit,"
//"dspmute bit,"
//"optical bit);";



//S_ret Sqlite3Base::init_ovrcsetting(_cloudinfo info)
//{
//    if( ! isrecordexist("select * from t_ovrcSetting") ) {
//        char *zSQL = sqlite3_mprintf("INSERT INTO t_ovrcSetting VALUES(%d,'%s','%s','%s')",0,info.url.c_str(),
//                                     info.webpageport.c_str(),info.updatefrequency.c_str());
//        sqlite3_exec(db,zSQL, 0, 0, 0);
//        sqlite3_free(zSQL);
//    }
//    return SUCESS;
//}

S_ret Sqlite3Base::init_loginInfo()
{
    if( ! isrecordexist("select * from t_account") ) {

        char *zSQL = sqlite3_mprintf("INSERT INTO t_account VALUES(%d,'%s','%s','%d','%d','%d','%s','%s','%s')",0,"episode","episode",0,
                                     0,0,"0","0","0");
        sqlite3_exec(db,zSQL, 0, 0, 0);
        sqlite3_free(zSQL);


    }
    return SUCESS;
}


S_ret Sqlite3Base::init_SystemSetting51()
{
    if( ! isrecordexist("select * from t_systemtSetting") ) {
        char *zSQL = sqlite3_mprintf("INSERT INTO t_systemtSetting VALUES(%d,'%s','%s','%s','%s','%s','%s','%s',"
                                     "'%s','%s')",0,"Episode Amp-Theater Room","3","0","0","0","0","0","0","0");

        sqlite3_exec(db,zSQL, 0, 0, 0);
        sqlite3_free(zSQL);

    }
    return SUCESS;
}

//S_ret Sqlite3Base::init_inputsetting51()
//{
//    if( ! isrecordexist("select * from t_inputSetting") ) {
//        vector<string> inPutName = {"HDMI1","HDMI2","HDMI3","Aux","Optical","Bluetooth"};
//        for(int i = 0; i < SNAPAV; i++)
//        {
//            string str = inPutName.at(i);
//            char *zSQL = sqlite3_mprintf("INSERT INTO t_inputsetting VALUES(%d,'%s','%s','%s','%s','%s')",i,"0",str.c_str(),
//                                         "0","80","80");
//            sqlite3_exec(db,zSQL, 0, 0, 0);
//            sqlite3_free(zSQL);
//        }

//    }
//    return SUCESS;
//}

//S_ret Sqlite3Base::init_OutputSetting51()
//{
//    if( ! isrecordexist("select * from t_outputsetting") ) {
//        for(int i = 0; i < SNAPAV; i++)
//        {
//            char *zSQL = sqlite3_mprintf("INSERT INTO t_outputsetting VALUES(%d,'%s','%s','%s','%s','%s',"
//                                         "'%s','%s')",i,"0","0","0","0","3.39","1.01","0");
//            sqlite3_exec(db,zSQL, 0, 0, 0);
//            sqlite3_free(zSQL);
//        }

//    }
//    return SUCESS;
//}


S_ret Sqlite3Base::writeBinary(ofstream &fout, string &md5, const string value)
{
    char endMark = 0;
    fout.write(value.c_str(), sizeof(char) * (value.size()));
    md5 += value;
    fout.write(&endMark,sizeof(char));
    return SUCESS;
}

S_ret Sqlite3Base::readBinary(string &value,string &md5, char **p)
{
    value.clear();
    value = *p;
    md5 +=value;
    *p = *p + strlen(*p) + 1;
    return SUCESS;
}

string Sqlite3Base::stringToLower(string s)
{
    transform(s.begin(),s.end(),s.begin(),::tolower);
    return s;
}

#if 1
S_ret Sqlite3Base::create_tables(){
    if(db == nullptr) return ERROR;
    // 如果version_table不存在，说明是之前的版本
    int ver = get_database_version();
    if(-1 == ver || ver > DATABASE_VERSION ){
        create_version_table();
    }
}

S_ret Sqlite3Base::create_version_table()
{
    string sqlcmd = "create table if not exists version_info(version int not null);";
    DEBUG_LOG("%s", sqlcmd.c_str());
    result = sqlite3_exec(db, sqlcmd.c_str(), 0, 0, &errmsg);
    if(result != SQLITE_OK)
    {
        DEBUG_LOG("create_version_table: %s", errmsg);
        return -1;
    }

    char *zSQL = sqlite3_mprintf("INSERT INTO version_info VALUES(%d)", 1);
    sqlite3_exec(db,zSQL, 0, 0, 0);
    sqlite3_free(zSQL);

    return 0;
}

S_ret Sqlite3Base::get_database_version()
{
    string ver = "0";
    string sqlcmd;
    sqlite3_stmt *stmt = NULL;

    //judge version_info exist
    sqlcmd = "select count(*) from sqlite_master where type='table' and name = 'version_info';";
    int result = sqlite3_prepare_v2(db, sqlcmd.c_str(), -1, &stmt, NULL);
    if(result == SQLITE_OK)
    {
        while(sqlite3_step(stmt) == SQLITE_ROW)
        {
            string count = (char*)sqlite3_column_text(stmt, 0);

            if(0 == stoi(count))
            {
                sqlite3_finalize(stmt);
                DEBUG_LOG("get_database_version: table not exist");
                return -1;      //version_info not exist
            }

            break;
        }
    }
    else
    {
        DEBUG_LOG("get_database_version error 0");
    }
    sqlite3_finalize(stmt);

    sqlcmd = "select version from version_info";
    result = sqlite3_prepare_v2(db, sqlcmd.c_str(), -1, &stmt, NULL);
    if(result == SQLITE_OK)
    {
        while(sqlite3_step(stmt) == SQLITE_ROW)
        {
            ver = (char*)sqlite3_column_text(stmt, 0);
            break;
        }
    }

    sqlite3_finalize(stmt);
    DEBUG_LOG("get_database_version: %s", ver.c_str());
    return stoi(ver);
}

S_ret Sqlite3Base::updateVersionInfo(string dbname, string key, int ver)
{
    char * sql;
    char * zErrMsg = NULL;

    sql = sqlite3_mprintf("update '%s' set '%s' = '%d'", dbname.c_str(), key.c_str(), ver);
    sqlite3_exec(db,sql,0,0,&zErrMsg);
    sqlite3_free(sql);

    return 0;
}
#endif
