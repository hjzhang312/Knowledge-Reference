#ifndef TOOLS_H
#define TOOLS_H
#include "common.h"
#include <vector>
#include "types.h"
class Tools
{
public:

    static  Tools *getInstanc()
    {
        static Tools ins;
        return &ins;
    }

    S_ret myexec(std::string cmd, std::vector<std::string> &resvec);
    bool getip(std::string );
    string getRandom();
    std::string getMacAddress();
    S_ret getNetStatus(_networkinfo &net, std::string );
    std::string getSerialNumber();
    std::string getFirmwareVersion();

    void writeSerialNumber(const string str);
    string readSerialNumber();

private:
    S_ret getgateway(std::string &gateway);
    S_ret getdns(std::vector<std::string> &dns);

private:
    Tools();
    ~Tools();

};

#endif // TOOLS_H
