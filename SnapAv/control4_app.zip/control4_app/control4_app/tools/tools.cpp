#include "tools.h"
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <net/if.h>
#include <sys/ioctl.h>

Tools::Tools()
{

}

Tools::~Tools()
{

}
S_ret Tools::myexec(std::string cmd, std::vector<std::string> &resvec)
{
    resvec.clear();
    FILE *pp = popen(cmd.c_str(), "r"); //建立管道
    if (!pp) {
        LOGOUT("cannot run cmd %s",cmd.c_str());
        return -1;
    }
    char tmp[ 128 ]={'\0'}; //设置一个合适的长度，以存储每一行输出
    while (fgets(tmp, sizeof(tmp), pp) != NULL) {
        if (tmp[strlen(tmp) - 1] == '\n') {
            tmp[strlen(tmp) - 1] = '\0'; //去除换行符
        }
        resvec.push_back(tmp);
        memset(tmp,0,128);

    }
    pclose(pp); //关闭管道
    return resvec.size();
}
bool Tools::getip(std::string ifname )
{
    ifname=ifname;
#ifdef ARM_PLATFORM
    std::vector<std::string> ret;
    myexec(" ifconfig eth0 | grep 'inet addr' | cut -d ':' -f 2 | awk '{print $1}' ",ret);

    if(ret.size() == 0) return false;

#else
    char *temp = NULL;
    int inet_sock;
    struct ifreq ifr;
    inet_sock = socket(AF_INET, SOCK_DGRAM, 0);
    memset(ifr.ifr_name, 0, sizeof(ifr.ifr_name));
    memcpy(ifr.ifr_name, ifname.c_str(), ifname.size());

    if(0 != ioctl(inet_sock, SIOCGIFADDR, &ifr))
    {
        perror("ioctl error");
        return false;
    }

    temp = inet_ntoa(((struct sockaddr_in*)&(ifr.ifr_addr))->sin_addr);

    close(inet_sock);
#endif
    return true;
}

string Tools::getRandom()
{
    string ret = "12345678";
    string cmd = "cat /proc/sys/kernel/random/uuid | sed 's/-//g'";
    std::vector<string> res;
    myexec(cmd,res);
    if(!res.empty())
    {
        ret = res.at(0);
    }
    return ret;
}

string Tools::getMacAddress()
{
    vector<std::string> macAddr;

    myexec("ifconfig eth0 | grep HWaddr | cut -d ' ' -f 11 ",macAddr);
    if(macAddr.size() ==0) return " ";
    return macAddr.at(0);

}

S_ret Tools::getNetStatus(_networkinfo &net,std::string ifname)
{

    LOGOUT("in");
    net.ip.clear();
    net.netmask.clear();
    net.gateway.clear();
    net.dnsServer1.clear();
    net.dhcpEnabled.clear();

    vector<string> tmpbuf;
    getdns(tmpbuf);
    if(tmpbuf.size()>0) net.dnsServer1 = tmpbuf[0];
    myexec("cat /etc/network/interfaces|grep " "eth0" "|grep static",tmpbuf);
    if(tmpbuf.empty())
    {
         net.dhcpEnabled ="1";
    }
    else
    {
        net.dhcpEnabled ="0";
    }
#ifdef ARM_PLATFORM

    std::vector<std::string> ret;
    myexec("ifconfig eth0 | grep HWaddr | cut -d ' ' -f 11 ",ret);
    if(ret.size() ==0) return FAILED;
    net.mac = ret[0];

    myexec(" ifconfig eth0 | grep 'inet addr' | cut -d ':' -f 2 | awk '{print $1}' ",ret);
    if(ret.size() == 0) return FAILED;
    net.ip=ret[0];


    myexec("ifconfig eth0 | grep Mask | cut -d ':' -f4  | awk '{print $1}' ",ret);
    if(ret.size() ==0) return FAILED;
    net.netmask = ret[0];

    getgateway(net.gateway);

    if("0" == net.dhcpEnabled)
    {
        if((0 !=access("/tmp/resolv.conf",F_OK)) || (net.dnsServer1.empty()))
        {
            LOGOUT(" create static ip resolv.conf file");
            string cmd = "echo nameserver " + net.gateway + " > /tmp/resolv.conf";
            system(cmd.c_str());

            net.dnsServer1 = net.gateway;
        }
    }
    if(net.dnsServer1.empty())
    {
        net.dnsServer1 = net.gateway;
    }

 #else
    char *temp = NULL;
    int inet_sock;
    struct ifreq ifr;

    inet_sock = socket(AF_INET, SOCK_DGRAM, 0);
    memset(ifr.ifr_name, 0, sizeof(ifr.ifr_name));
    memcpy(ifr.ifr_name, ifname.c_str(), ifname.size());

    /*get mac address*/
    if(0 != ioctl(inet_sock, SIOCGIFHWADDR, &ifr))
    {
        perror("ioctl error");
        return -1;
    }
    char buf[20]={'\0'};
    for(int i=0;i<6;i++) {
        sprintf(buf + i*3,"%02x:",(uchar)ifr.ifr_hwaddr.sa_data[i]);
    }
    buf[strlen(buf)-1]='\0';
    net.mac=(char *)buf;

    /*get ip address*/
    if(0 != ioctl(inet_sock, SIOCGIFADDR, &ifr))
    {
        perror("ioctl error");
        return -1;
    }

    temp = inet_ntoa(((struct sockaddr_in*)&(ifr.ifr_addr))->sin_addr);
    net.ip=temp;

    /*get netmask*/
    if(0 != ioctl(inet_sock, SIOCGIFNETMASK, &ifr))
    {
        perror("ioctl error");
        return -1;
    }

    temp = inet_ntoa(((struct sockaddr_in*)&(ifr.ifr_addr))->sin_addr);
    net.netmask=temp;

    getgateway(net.gateway);

    close(inet_sock);
#endif

    return SUCESS;
}

std::string Tools::getSerialNumber()
{
    vector<std::string> serialNumber;

    myexec("cat /proc/cmdline | cut -d ' ' -f3",serialNumber);
    if(serialNumber.size() ==0) return " ";
    return serialNumber.at(0);
}

string Tools::getFirmwareVersion()
{
    vector<std::string> firmware;

    myexec(" cat /etc/os-release | grep 'VERSION=' | cut -d '=' -f 2",firmware);
    if(firmware.size() ==0) return "unkown";
    string info = firmware.at(0);
    size_t t = info.find("-");
    if(string::npos == t)
    {
        t = info.size();
    }
    return info.substr(0,t);
}
S_ret Tools::getgateway(std::string &gateway)
{
    LOGOUT("in");
    gateway.clear();
    FILE *pp = popen("route -n | sed -n 3p | awk '{print $2}'", "r"); //建立管道
    if (!pp) {
        return -1;
    }
    char tmp[ 128 ]={'\0'}; //设置一个合适的长度，以存储每一行输出
    while (fgets(tmp, 128, pp) != NULL) {
        if (tmp[strlen(tmp) - 1] == '\n') {
            tmp[strlen(tmp) - 1] = '\0'; //去除换行符
        }
    }
    //LOGOUT("%s",tmp);
    gateway=tmp;
    pclose(pp); //关闭管道

    return SUCESS;
}
S_ret Tools::getdns(std::vector<std::string> &dns)
{
    LOGOUT("in");
    dns.clear();
    return myexec("cat /etc/resolv.conf  | grep nameserver | awk '{print $2}'",dns);
}

void Tools::writeSerialNumber(const string str)
{
    string cmd;

    cmd = "dd if=/dev/zero of=/dev/mtdblock0 seek=1966118 bs=1 count=64";
    system(cmd.c_str());

    cmd.clear();
    cmd = "echo " + str + " > /media/userdata/serialnum.bin";
    system(cmd.c_str());

    cmd.clear();
    cmd = "dd if=/media/userdata/serialnum.bin of=/dev/mtdblock0 seek=1966118 bs=1 count=64";
    system(cmd.c_str());
}

string Tools::readSerialNumber()
{
    string cmd;
    char num[65] = { 0 };

    cmd = "dd if=/dev/mtdblock0 of=/media/userdata/serialnum.bin skip=1966118 bs=1 count=64";
    FILE *fd = fopen("/media/userdata/serialnum.bin", "r");
    if(fd)
    {
        fread(num, 65, 1, fd);
        fclose(fd);
    }

    //DEBUG_LOG("SN: %s", num);
    return num;
}
