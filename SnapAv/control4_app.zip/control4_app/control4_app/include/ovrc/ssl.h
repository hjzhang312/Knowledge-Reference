#ifndef SSL_H
#define SSL_H

typedef struct sslStruct {
    Socket fdSocket;
    SSL_CTX *ctx;
    SSL *ssl;
    SSL_SESSION *sess;
    Mutex sslMutex;
}SslSocket;
#ifdef __cplusplus
extern "C"
{
#endif
void
initSslSocket(
    IN SslSocket *pSslSocket
    );

void
deleteSslSocket(
    IN SslSocket *pSslSocket
    );

BOOL
connectSslSocket(
    IN SslSocket *pSslSocket,
    IN Socket fdSocket
    );

void
closeSslSocket(
    IN SslSocket *pSslSocket
    );

INT32
readSslSocket(
    IN SslSocket *pSslSocket,
    OUT BYTE *buffer,
    IN INT32 length
    );

INT32
writeSslSocket(
    IN SslSocket *pSslSocket,
    OUT BYTE *buffer,
    IN INT32 length
    );
#ifdef __cplusplus
}
#endif
#endif // SSL_H
