/*
 * Websocket client library.
 * Author: Ashish G. Khurange
 *         ashish.khurange@mindstix.com
 */
 

#ifndef WEBSOCKET_CLIENT_H
#define WEBSOCKET_CLIENT_H

#include "utils.h"

#define URL_SIZE 128

#define WEBSOCKET_FRAME_CONT    0X0
#define WEBSOCKET_FRAME_TEXT    0X1
#define WEBSOCKET_FRAME_BINARY  0X2
#define WEBSOCKET_FRAME_CLOSE   0X8
#define WEBSOCKET_FRAME_PING    0X9
#define WEBSOCKET_FRAME_PONG    0XA

#define WBS_STATE_INVALID       0X01
#define WBS_STATE_CONNECTED     0X02
#define WBS_STATE_CLOSED        0X03

typedef void (* wbsCallback)();

typedef struct wbsExtraInfo
{
    wbsCallback pingCallback;
    wbsCallback closeCallback;
}wbsExtraInfo;    

typedef struct websocket
{
    Socket fdSocket;
    Mutex readerMutex;
    Mutex writerMutex;
    BYTE nonce[16];
    BYTE connectionState;
    char host[URL_SIZE];
    char path[URL_SIZE];
    char origin[URL_SIZE];
    int port;
    BOOL isSSL;
    SslSocket sslChannel;
    wbsExtraInfo extraInfo;
}WEBSOCKET;

#ifdef __cplusplus
extern "C"
{
#endif
/* Websocket management functions */

WEBSOCKET *
initWebsocketConnection(
    IN const char *url,
    IN const char *origin,
    IN wbsExtraInfo extraInfo
    );

void
deleteWebsocketConnection(
    IN WEBSOCKET *wbsConnection
    );

BOOL
connectWebSocket(
    IN WEBSOCKET *wbsConnection
    );

int
readWebsocketFrame(
    IN WEBSOCKET *wbsConnection,
    IN BYTE *buffer,
    IN UINT32 bufferLength
    );

int
writeWebsocketFrame(
    IN WEBSOCKET *wbsConnection,
    IN BYTE frameType,
    IN BYTE *data,
    IN UINT32 dataLength
    );

BOOL
sendWebsocketPing(
    IN WEBSOCKET *wbsConnection
    );

void
closeWebsocket(
    IN WEBSOCKET *wbsConnection
    );
#ifdef __cplusplus
}
#endif

#endif // WEBSOCKET_CLIENT_H
