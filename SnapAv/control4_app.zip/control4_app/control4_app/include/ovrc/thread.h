#ifndef THREAD_H
#define THREAD_H

/* POSIX style thread function definition */
typedef void * (* threadFunction) (void *);
#ifdef __cplusplus
extern "C"
{
#endif
void
initThread(
    IN threadFunction functionAddress,
    IN void *parameter,
    OUT Thread *threadID
    );

void
waitForThreadExit(
    IN Thread *threadID
    );

#ifdef __cplusplus
}
#endif
#endif // THREAD_H
