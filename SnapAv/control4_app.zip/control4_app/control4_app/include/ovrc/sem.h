#ifndef SEMAPHORE_H
#define SEMAPHORE_H
#ifdef __cplusplus
extern "C"
{
#endif
void
initSemaphore(
    IN Semaphore *pSemaphore,
    IN UINT32 initialValue
    );

void
deleteSemaphore(    		
    IN Semaphore *pSemaphore
    );

void
waitSemaphore(
    IN Semaphore *pSemaphore
    );

BOOL
trywaitSemaphore(
    IN Semaphore *pSemaphore
    );

void
postSemaphore(
    IN Semaphore *pSemaphore
    );

#ifdef __cplusplus
}
#endif
#endif //SEMAPHORE_H
