#ifndef FTP_DOWNLOADER_H
#define FTP_DOWNLOADER_H

#include "ovrc_pub.h"

typedef void (* ftpCallback) (void *buffer, size_t size);
#ifdef __cplusplus
extern "C"
{
#endif
BOOL
ftpDownloader(
    IN char *url,
    IN ftpCallback callback
    );
#ifdef __cplusplus
}
#endif
#endif // FTP_DOWNLOADER_H
