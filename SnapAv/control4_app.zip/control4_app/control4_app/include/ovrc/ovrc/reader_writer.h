#ifndef READER_WRITER_H
#define READER_WRITER_H

#include "ovrc_pub.h"

/*
 * This reader writer lock gives priority to writer threads.
 * The implementation is inspired from below research paper:
 *
 * Concurrent Control with "Readers" and "Writers"
 *  ~ P.J. Courtois, F. Heymans, and D.L. Parnas
 *    MBLE Research Laboratory
 *    Brussels, Belgium 1971
 *    http://cs.nyu.edu/~lerner/spring10/MCP-S10-Read04-ReadersWriters.pdf
 */

typedef struct rw_lock {
    Mutex mutex1;
    Mutex mutex2;
    Mutex mutex3;
    Semaphore r;
    Semaphore w;
    INT32 readerCount;
    INT32 writerCount;
}RWLock;
#ifdef __cplusplus
extern "C"
{
#endif
void
initRWLock(
    IN RWLock *pRWLock
    );

void
deleteRWLock(
    IN RWLock *pRWLock
    );

void
acquireSharedLock(
    IN RWLock *pRWLock
    );

void
releaseSharedLock(
    IN RWLock *pRWLock
    );

void
acquireExclusiveLock(
    IN RWLock *pRWLock
    );

void
releaseExclusiveLock(
    IN RWLock *pRWLock
    );
#ifdef __cplusplus
}
#endif
#endif // READER_WRITER_H
