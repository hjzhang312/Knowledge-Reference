#ifndef STATUS_FREQUENCY
#define STATUS_FREQUENCY

#include "ovrc_pub.h"
#ifdef __cplusplus
extern "C"
{
#endif
typedef struct status_frequency {
    Semaphore statusSem;
    INT32 frequency;
} statusFrequency;

void
initStatusFrequencyHandler();

void
deleteStatusFrequencyHandler();

INT32
getStatusUpdateFrequency();

void
setStatusUpdateFrequency(
    INT32 frequency
    );
#ifdef __cplusplus
}
#endif
#endif // STATUS_FREQUENCY

