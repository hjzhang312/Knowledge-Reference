#ifndef UPNP_HELPER_HEADER_H
#define UPNP_HELPER_HEADER_H

#include "ovrc_pub.h"

#define UPnP_E_OK                       0
#define UPnP_ERROR_NO_ROUTER_SUPPORT   -1
#define UPnP_ERROR_ROUTER_REFUSED      -2

#define UPnP_PORT_FORWARDING_MAX_RETRIES 5 
#define UPnP_MIN_EXTERNAL_PORT           49152
#define UPnP_MAX_EXTERNAL_PORT           65535
#ifdef __cplusplus
extern "C"
{
#endif
int
addPortForwarding(
    IN int inPort,
    IN int leaseDuration,
    IN char *description,
    OUT char *exIPaddr,
    OUT int *exPort
    );

int
deletePortForwarding(
    IN int exPort
    );

void
initUPnPService();

void
deleteUPnPService();

/* This function is added only for unit testing */
void
displayPortForwardingLease();
#ifdef __cplusplus
}
#endif
#endif // UPNP_HELPER_HEADER_H

