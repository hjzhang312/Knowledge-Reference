#ifndef OVRC_SDK_H
#define OVRC_SDK_H

#include "ovrc_pub.h"

#define OvrC_EVENT_TYPE_INFO "INFO"

typedef void (* ovrcCallback)();

typedef struct ovrc_connector {
    char *deviceUrl;
    char *macAddress;
    char *logFile;
    int logLevel;
    ovrcCallback pingCallback;
    ovrcCallback closeCallback;
    ovrcCallback reconnectCallback;
}OvrCConnector;
#ifdef __cplusplus
extern "C"
{
#endif

WEBSOCKET * getWebSocketInfo();
void
initConnection(
    IN OvrCConnector connectionInfo
    );

char *
getClientMacAddress();

void
readJsonCommand(
    OUT JSON_PARSER_OBJ **jsonCommand
    );

void
writeJsonReply(
    IN JSON_PARSER_OBJ *jsonReply
    );

void
writeJsonStatus(
    IN JSON_PARSER_OBJ *jsonStatus
    );

void
writeJsonEvent(
    IN JSON_PARSER_OBJ *jsonEvent
    );

void
deleteConnection();

#ifdef __cplusplus
}
#endif

#endif // OVRC_SDK_H
