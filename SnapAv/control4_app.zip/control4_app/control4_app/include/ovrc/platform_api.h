#ifndef PLATFORM_API_H
#define PLATFORM_API_H

/*
 * The main objective of this file is to hide platform specific
 * implementation of general functions needed by SDK.
 */
#ifdef __cplusplus
extern "C"
{
#endif
void
osSleep(
    IN UINT32 seconds
    );

void
osHandleSIGPIPE();

int
osFileCreate(
    IN char *fileName
    );

int
osFileWrite(
    IN int fd,
    IN void *data,
    IN int size
    );

void
osFileClose(
    IN int fd
    );

SocketError
osGetSocketError();
#ifdef __cplusplus
}
#endif
#endif // PLATFORM_API_H
