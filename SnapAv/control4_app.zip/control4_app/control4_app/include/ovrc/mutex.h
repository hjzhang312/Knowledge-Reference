#ifndef MUTEX_H
#define MUTEX_H
#ifdef __cplusplus
extern "C"
{
#endif
void
initMutex(
    IN Mutex *pMutex
    );

void
deleteMutex(
    IN Mutex *pMutex
    );

void
lockMutex(
    IN Mutex *pMutex
    );

void
unlockMutex(
    IN Mutex *pMutex
    );

#ifdef __cplusplus
}
#endif
#endif // MUTEX_H
