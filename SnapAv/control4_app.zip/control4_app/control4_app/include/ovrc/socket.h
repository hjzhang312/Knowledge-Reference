#ifndef SOCKET_H
#define SOCKET_H
#ifdef __cplusplus
extern "C"
{
#endif
Socket
connectSocket(
    IN const char *hostAddr,
    IN INT32 port
    );

void
closeSocket(
    IN Socket fdSocket
    );

INT32
readSocket(
    IN Socket fdSocket,
    OUT BYTE *buffer,
    IN INT32 length
    );

INT32
writeSocket(
    IN Socket fdSocket,
    IN BYTE *buffer,
    IN INT32 length
    );

void
setSocketNonBlocking(
    IN Socket fdSocket
    );

BOOL
isValidIPAddress(
    IN char *ipAddr
    );
#ifdef __cplusplus
}
#endif
#endif // SOCKET_H
