#ifndef UTILS_H
#define UTILS_H

#include "platform.h"
#include "socket.h"
#include "mutex.h"
#include "sem.h"
#include "ssl.h"
#include "thread.h"
#include "platform_api.h"

/* Providing facility to use bool varible */
//typedef char bool;
#define true  1
#define false 0

#define ISDIGIT(x) ((x>='0' && x<='9') ? TRUE : FALSE)

#ifdef __cplusplus
extern "C"
{
#endif
/* base64 encoding */
int
base64EncodeString(
    IN const char *in, 
    IN int in_len, 
    OUT char *out, 
    IN int out_size
    );

/* SHA-1 hash calculation */
unsigned char *
SHA1(
    IN const unsigned char *d, 
    IN size_t n, 
    IN unsigned char *md
    );

/* random number generator */
void
random32Seed(
    UINT32 seed
    );

UINT32
random32Simple();
#ifdef __cplusplus
}
#endif

#endif // UTILS_H
