
#include "sysdata.h"
#include "stream.h"
#include "button.h"
#include "ledmisc.h"
#include "tools.h"
#include <socket.h>
using namespace std;
#include "log.h"

#include <sys/types.h>
#include <sys/socket.h>
#include <asm/types.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/ioctl.h>
#include <linux/if.h>
#include <string.h>
#include "ovrchandle.h"
#include "wshandle.h"

#include "fifo.h"
#include "log.h"

#define BUFLEN 2048
int MonitorNetlinkUevent()
{
    int skfd = 0;
    struct ifreq ifr;
    int  previous_status;

    skfd = socket(AF_INET, SOCK_DGRAM, 0);
    if(skfd < 0)
    {
        DEBUG_LOG("%s:%d Open socket error!\n", __FILE__, __LINE__);
        //return -1;
    }

    strcpy(ifr.ifr_name, "eth0");
    previous_status = 0;
    while(1)
    {
        if(skfd < 0)
        {
            DEBUG_LOG("%s:%d Open socket error!\n", __FILE__, __LINE__);
            skfd = socket(AF_INET, SOCK_DGRAM, 0);
        }
        else
        {
            if(ioctl(skfd, SIOCGIFFLAGS, &ifr) <0 )
            {
                printf("%s:%d IOCTL error!\n", __FILE__, __LINE__);
                DEBUG_LOG("Maybe ethernet inferface %s is not valid!", ifr.ifr_name);
                close(skfd);
                skfd = socket(AF_INET, SOCK_DGRAM, 0);
            }
            else
            {
                if(ifr.ifr_flags & IFF_RUNNING)
                {
                    //DEBUG_LOG("%s is running,previous_status:%d", ifr.ifr_name,previous_status);
                    if( previous_status == 0 ){
                        system("/etc/init.d/S40network restart");
                        LEDMISC::getInstance()->SetNetWork(1);
                        printf("eth0 running :)\n");
                        Tools::getInstanc()->getNetStatus(sysdata::getInstance()->netinfo, "eth0");
#if 0
#if(CHANNELS==8)
                        system("udhcpc -b -q -x hostname:control4-8");
#elif(CHANNELS==16)
                        system("udhcpc -b -q -x hostname:control4-16");
#endif
#endif
                        previous_status = 1;
                    }
                }
                else
                {
                    if(previous_status > 0)
                    {
                        //  system("udhcpc");
                        DEBUG_LOG("%s is not running...", ifr.ifr_name);
                        LEDMISC::getInstance()->SetNetWork(0);
                        previous_status = 0;
                    }
                }
            }
        }
        sleep(1);
    }
    close(skfd);
    return 0;

}

#include "stdio.h"

void WriteVersion(void)
{
    FILE *fp;
    char filebuf[50];
    sprintf(filebuf, "/tmp/AppVersionCode.txt");
    fp = fopen(filebuf, "w+");
    DEBUG_LOG("Version write");
    sprintf(filebuf, "%d",AppVersion);
    fwrite(filebuf, strlen(filebuf), 1, fp);
    fclose(fp);
}


int main()
{

    DEBUG_LOG("----------------------------------------");
    DEBUG_LOG("|       SoftName:       %s %d c      |","Control4",CHANNELS);
    DEBUG_LOG("|       SoftType:       %s       |","SoftType");

    DEBUG_LOG("|       Version:        %d       |", AppVersion);
    DEBUG_LOG("|       BuildTime:  [%s-%s]\t    |",__DATE__,__TIME__);
    DEBUG_LOG("----------------------------------------");
    WriteVersion();
    system("/etc/init.d/S50sshd stop");
    //  OvrcHandle oh;
    //  oh.start();
    /**/
    sysdata::getInstance()->init();

    LEDMISC::getInstance()->start();
    Button::getInstance()->start();

    WSHandle::getInstance()->start();
    stream::getInstance()->start();
    SocketServer::getInstance()->start();
    Fifo::getInstance()->start();

    while(0)
    {
        //Eth0Det();
        MonitorNetlinkUevent();
    }

    // DEBUG_LOG("\r\n\r\n\r\n");

    LEDMISC::getInstance()->join();
    Button::getInstance()->join();
    WSHandle::getInstance()->join();
    stream::getInstance()->join();
    SocketServer::getInstance()->join();
    //HdmiHandler::getInstance()->start();
    //HardwareControl51::getInstance()->run();
    //ButtonEventHandle::getInstance()->join();

    return 0;
}
