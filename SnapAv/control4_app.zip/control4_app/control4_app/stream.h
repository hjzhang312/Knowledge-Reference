﻿#ifndef _STEAMING_H
#define _STEAMING_H


#include "sysdata.h"
#include "common.h"
#include "tinythread.h"
#include <mutex>
#include "adau1466.h"
#include "adc.h"
#include "matrix.h"
#include "socket.h"

class stream:public matrix,public PCM1863,public ADAU1466,public TinyThread
{
public:
    static stream *getInstance() {
        static stream sc;
        return &sc;
    }
    void run();
    void SpdifOrRCA();
    int SignalDet();
    DSPstreaming current[CHANNELS];
    int powerc;
    int dsp_init_flag;
private:
    stream();
    void Init();
    void Deinit();
    void UpdataPara();
    void DSPMatrixUpdate();
    void power(int pow);
    int sem_timedwait_millsecs(long msecs);
};






#endif // KEYEVENTHANDLE_H
