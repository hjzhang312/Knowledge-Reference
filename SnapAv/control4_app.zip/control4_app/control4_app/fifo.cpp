#include "fifo.h"
#include<stdio.h>
#include<stdlib.h>   // exit
#include<fcntl.h>    // O_WRONLY
#include<sys/stat.h>
#include<time.h>     // time



void Fifo::FifoSend(string message )
{
    if(Fifofd)
    {
        if(write(Fifofd, message.c_str(), message.size()) < 0)
        {
            printf("message send:%s \n",message.c_str());
        }
    }
}

Fifo::Fifo()
{
    printf("I am %d process.\n", getpid()); // 说明进程ID

    if((Fifofd = open("/tmp/upgradefifo", O_WRONLY)) < 0) // 以写打开一个FIFO
    {
        perror("Open FIFO Failed");
      //  exit(1);
    }
    else printf("Fifo open success\n"); // 说明进程ID
}
Fifo::~Fifo()
{
    if(Fifofd)
    {
        close(Fifofd);  // 关闭FIFO文件
    }

}


void Fifo ::run()
{



    return ;
}
