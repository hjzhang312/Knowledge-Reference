#include "libwsserverbase.h"
#if 1
#include "wshandle.h"

#include <syslog.h>
#include <sys/time.h>
#include <unistd.h>
#include <signal.h>
#include <vector>
#include <string.h>
#include <log.h>




#define MAX_ECHO_PAYLOAD 10 * 1024
struct per_session_data__echo {
    size_t rx, tx;
    unsigned char buf[LWS_PRE + MAX_ECHO_PAYLOAD];
    unsigned int len;
    unsigned int index;
    int final;
    int continuation;
    int binary;
};

static volatile int force_exit = 0;
static int versa, state;
static int times = -1;

#define LOCAL_RESOURCE_PATH "/libwebsockets-test-server"

struct uServer{
    struct lws *lws;
    void *user;
};
vector <struct uServer> mWsi;

LibWSServerBase::LibWSServerBase()
{

}




static int
callback_echo(struct lws *wsi, enum lws_callback_reasons reason, void *user,
          void *in, size_t len)
{
    struct per_session_data__echo *pss =
            (struct per_session_data__echo *)user;
    int n;

    switch (reason) {

    case LWS_CALLBACK_ESTABLISHED:
    {
            struct uServer tmp;
            tmp.lws = wsi;
            tmp.user = user;

            DEBUG_LOG("websock coming.....");
        mWsi.push_back(tmp);
        break;
    }
    case LWS_CALLBACK_SERVER_WRITEABLE:{

        n = LWS_WRITE_CONTINUATION;
        if (!pss->continuation) {
            if (pss->binary)
                n = LWS_WRITE_BINARY;
            else
                n = LWS_WRITE_TEXT;
            pss->continuation = 1;
        }
        if (!pss->final)
            n = n | LWS_WRITE_NO_FIN;
        lwsl_info("+++ test-echo: writing %d, with final %d\n",
              pss->len, pss->final);

        if(pss->len == 0) {
            memcpy(&pss->buf[LWS_PRE], "hello", 6);
            pss->len =6;
        }

        pss->tx += pss->len;

        //string data((char *)(pss->buf + LWS_PRE),pss->len);

        //LOGOUT("send:%s",data.c_str());

        n = lws_write(wsi, &pss->buf[LWS_PRE], pss->len, (lws_write_protocol)n);
        if (n < 0) {
            lwsl_err("ERROR %d writing to socket, hanging up\n", n);
            return 1;
        }
        if (n < (int)pss->len) {
            lwsl_err("Partial write\n");
            return -1;
        }
        pss->len = 0;
        if (pss->final)
            pss->continuation = 0;
        lws_rx_flow_control(wsi, 1);
    }
        break;

    case LWS_CALLBACK_RECEIVE:{

        pss->final = lws_is_final_fragment(wsi);
        pss->binary = lws_frame_is_binary(wsi);
        lwsl_info("+++ test-echo: RX len %d final %d, pss->len=%d\n",
              len, pss->final, (int)pss->len);

        //std::string data(,len);

        std::string response = WSHandle::getInstance()->cmdhandler((char *)in,"a");

        if(string::npos == response.find("heartbeat_request"))
        DEBUG_LOG("response:%s",response.c_str());

        memcpy(&pss->buf[LWS_PRE], response.c_str(), response.size());

        //assert((int)pss->len == -1);
        pss->len = (unsigned int)response.size();
        pss->rx += len;

        lws_rx_flow_control(wsi, 0);
        lws_callback_on_writable(wsi);
    }; break;
    case LWS_CALLBACK_CLOSED:
    {
        vector<struct uServer>::iterator it;
        for(it=mWsi.begin();it !=mWsi.end();)
        {
            if((int*)it->lws == (int*)wsi)
            {
                it = mWsi.erase(it);
                break;
            }
            else
            {
                it++;
            }
        }
        DEBUG_LOG("websock leave.....");
       // mWsi.pop_back();
    }break;

    default:break;

    }

    return 0;
}



static struct lws_protocols protocols[] = {
    /* first protocol must always be HTTP handler */

    {
        "",		/* name - can be overridden with -e */
        callback_echo,
        sizeof(struct per_session_data__echo),	/* per_session_data_size */
        MAX_ECHO_PAYLOAD,
    },
    {
        NULL, NULL, 0		/* End of list */
    }
};

static const struct lws_extension exts[] = {
    {
        "permessage-deflate",
        lws_extension_callback_pm_deflate,
        "permessage-deflate; client_no_context_takeover; client_max_window_bits"
    },
    {
        "deflate-frame",
        lws_extension_callback_pm_deflate,
        "deflate_frame"
    },
    { NULL, NULL, NULL /* terminator */ }
};


void sighandler(int sig)
{
    force_exit = 1;
    sleep(1);
    exit(0);
}


int LibWSServerBase::run_server(int port)
{
    int n = 0;
    int use_ssl = 0;
    struct lws_context *context;
    int opts = 0;
    char interface_name[128] = "";
    const char *_interface = NULL;
    char ssl_cert[256] = LOCAL_RESOURCE_PATH"/libwebsockets-test-server.pem";
    char ssl_key[256] = LOCAL_RESOURCE_PATH"/libwebsockets-test-server.key.pem";
#ifndef _WIN32
/* LOG_PERROR is not POSIX standard, and may not be portable */
    int syslog_options = LOG_PID | LOG_PERROR;
#endif

    int client = 0;

    struct lws_context_creation_info info;
    char passphrase[256];
    char uri[256] = "/";

    int debug_level = 7;


    memset(&info, 0, sizeof info);

#ifndef LWS_NO_SERVER
    lwsl_notice("Built to support server operations\n");
#endif

    /* we will only try to log things according to our debug_level */
    setlogmask(LOG_UPTO (LOG_DEBUG));
    openlog("lwsts", syslog_options, LOG_DAEMON);


    /* tell the library what debug level to emit and to send it to syslog */
    lws_set_log_level(debug_level, lwsl_emit_syslog);

    lwsl_notice("libwebsockets test server echo - license LGPL2.1+SLE\n");
    lwsl_notice("(C) Copyright 2010-2016 Andy Green <andy@warmcat.com>\n");

    lwsl_notice("Running in server mode\n");

    info.port = port;
    info.iface = _interface;
    info.protocols = protocols;
    if (use_ssl && !client) {
        info.ssl_cert_filepath = ssl_cert;
        info.ssl_private_key_filepath = ssl_key;
    } else
        if (use_ssl && client) {
            info.ssl_cert_filepath = NULL;
            info.ssl_private_key_filepath = NULL;
        }
    info.gid = -1;
    info.uid = -1;
    info.options = opts | LWS_SERVER_OPTION_VALIDATE_UTF8;

    if (use_ssl)
        info.options |= LWS_SERVER_OPTION_DO_SSL_GLOBAL_INIT;
#ifndef LWS_NO_EXTENSIONS
    info.extensions = exts;
#endif

    context = lws_create_context(&info);
    if (context == NULL) {
        DEBUG_LOG("libwebsocket init failed\n");
        return -1;
    }

    signal(SIGINT, sighandler);

    n = 0;
    DEBUG_LOG("websocket web server start...");
    while (n >= 0 && !force_exit) {
        n = lws_service(context, 10);
    }

    lws_context_destroy(context);

    DEBUG_LOG("libwebsockets web exited cleanly\n");
#ifndef _WIN32
    closelog();
#endif

    return 0;
}

void LibWSServerBase::sendBoardData(string data)
{
    for(int i = 0; i < mWsi.size(); i++)
    {
        struct per_session_data__echo *pss = (struct per_session_data__echo *)mWsi.at(i).user ;
        pss->len = (unsigned int)data.size();
        pss->rx += pss->len;
        memcpy(&pss->buf[LWS_PRE], data.c_str(), data.size());
        pss->final = lws_is_final_fragment(mWsi.at(i).lws);
        pss->binary = lws_frame_is_binary(mWsi.at(i).lws);
        lws_rx_flow_control(mWsi.at(i).lws, 0);
        lws_callback_on_writable(mWsi.at(i).lws);
    }
}

#endif
