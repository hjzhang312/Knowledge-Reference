#ifndef WSHANDLE_H
#define WSHANDLE_H

#include "tinythread.h"
#include "common.h"
#include "sysdata.h"
#include "cJSON.h"
#include "observer.h"
#ifdef LIBWS
#include "libwsserverbase.h"
#endif

#define LOCK_TIME   300
#define GET         "get"
#define PUT         "put"

class WSHandle : public TinyThread
{
public:
    WSHandle();   
    ~WSHandle();
    static WSHandle *getInstance() {
        static WSHandle s;
        return &s;
    }
    void coremain(int &connector);
    void sendboardcast(std::string string);
    int issomeonethere(){
        return connector;
    }

    class DeviceChangeObserver:public Observer{
        WSHandle *parent;

        public:
            DeviceChangeObserver(WSHandle *p):parent(p){}
        void update( Observable *o , Argument *arg ) {
            try {
                parent->notifyHandle(arg);
            } catch (exception& e) {
                LOGOUT("%s",e.what());
            }
        }
    }wschangeobserver;


#ifdef uWS
    friend class uWS::Hub;
#endif

#ifdef LIBWS
    friend class LibWSServerBase;
#endif
    std::string cmdhandler(std::string json, std::string ipaddress);

protected:
    void run();
#ifdef uWS
    uWS::Hub *h;
#endif
    int connector;

    S_ret logInOutHandle(std::string &user, std::string &password , int type,cJSON *response);
    S_ret modifyPasswdHandle(const string passwd, const string user,cJSON *response);
    S_ret inOutPutHandle(cJSON *msg,cJSON *response);
    S_ret systemConfigHandle(cJSON *msg,cJSON *response);
    S_ret dspSettingsHandle(cJSON *msg,cJSON *retJson);

    S_ret factoryResetHandle(cJSON *msg,cJSON *response);
    S_ret firmwareUpdateHandle(cJSON *msg,cJSON *response);
    S_ret powerOnHandle(cJSON *msg, cJSON *response);
    S_ret ovrcCloudHandle(cJSON *msg,cJSON *response);
    S_ret rebootHandle(cJSON *msg,cJSON *response);
    S_ret notifyHandle(Argument *arg);
    S_ret serialNumHandle(cJSON *msg, cJSON *response);
    S_ret firmwareUpdateRequestHandle(cJSON *msg, cJSON *retJson);
    S_ret heartbeatRequestHandle(cJSON *msg, cJSON *retJson);

public:
    S_ret sendInOutPageInfo(cJSON *retJson);
    S_ret sendSystemConfigPageInfo(cJSON *retJson);
    S_ret getOvrcPageInfo(cJSON *retJson);


};

#endif // WSHANDLE_H
