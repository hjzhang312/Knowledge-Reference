### 2021-03-26 Control4 SW Release
* 	Fw version: 1.0049
* 	HW version: MP
1.[AMS-90]Need Triad Speaker Preset Values.
2.[AMS-225]Disable the SSH service after turn on the amp.


### 2021-03-26 Control4 SW Release
* 	Fw version: 1.0048
* 	HW version: MP
1.[AMS-67]Lower login lockout time,reduced to 5 minutes.
2.[AMS-91]Restore isn't functioning.
3.[AMS-191]2.1 configured subwoofer zones are not muted when the main zone is muted.
4.[AMS-185]AMS8v2 Turning on Zones not called for
5.[AMS-217] Set and query audio sense release time do not work.
6.[AMS-150]add the functions:Get / Set Credentials (Username / Password) and reboot.

### 2021-03-19 Control4 SW Release
* 	Fw version: 1.0046
* 	HW version: MP
1.Solve the problem of import errors.
2.[AMS-151]Assignable trigger should be removed from the WebUI.


### 2021-03-18 Control4 SW Release
* 	Fw version: 1.0045
* 	HW version: MP
1.[AMS-154]Advanced Settings Frequency Graph Does Not Update.
2.[AMS-209]AMS UI does not have an option to show or set an output's source as 'No Input'.
3.[AMS-151]Assignable Trigger Output not showing 12V when assigned outputs are active.


### 2021-03-5 Control4 SW Release
* 	Fw version: 1.0043
* 	HW version: PP
1.[33416]Advanced Settings中添加一个New Speaker Preset后，将Speaker Presets切换至New Speaker Preset，在Custom Speaker Presets中选择delete后，Speaker Presets中出现空白选项.
2.[AMS-160]Room EQ bands inactive by default when selected.
3.[AMS-135]Accuracy changed from 0.001 to 0.01.



### 2020-12-10 Control4 SW Release
* 	Fw version: 1.0042
* 	HW version: PP
1. [AMS-80]Copy Room EQ Presets overwrites names. It should copy just the settings not the entire name.
2. [AMS-88]Out of the box the default volume for the Triad AMSv2 should be 20%. 
3. [AMS-97]The default save name for the AMS Backup file should be changed from it's current control4.gen to something with the Triad Branding. "Triad.gen" or "TriadAMS.gen".
4. [AMS-114]Current default user name and password is Episode and Episode. We need this changed to Triad and Triad in our next firmware update.


### 2020-12-10 Control4 SW Release
* 	Fw version: 1.0041
* 	HW version: VC1.0
1. [AMS-41]Modify the default output lock value to unlock.
2. [AMS-36]Modify the default crossover frequency value to 80hz.
3. [AMS-53]When the output pass is the sub output, the output name can be modified.
4. [AMS-35]Allow user to type in model number to quickly find the preset.
5. [AMS-27]The "PAIRED SUB OUTPUT" and "Output #" text should only show when Enable 2.1 Audio Zone toggle switch is in the right position (enabled).
6. [AMS-66]System Settings tab missing space when on the Inputs/Outputs tab.
7. [AMS-70]Fixed an issue where you could not log in because your user name was changed.
8. [AMS-54] Cannot set EQ for Bands 6-12
9. [AMS-23] Can set an input source for an output to an out-of-bounds source
10. [AMS-25]Unexpected command error message
11. [AMS-24]Cannot disconnect input source from an output
12. [AMS-22]Inconsistent volume command responses
13. [AMS-21]Querying band frequency sometimes returns wrong response
14. [AMS-49]Triad AMS v2 API Document - Holding page
15. [AMS-69]Output volume query has too many spaces

### 2020-11-21 Control4 SW Release
* 	Fw version: 1.0039
* 	HW version: VC1.0
1. change the index of the room eq


### 2020-11-21 Control4 SW Release
* 	Fw version: 1.0038
* 	HW version: VC1.0
1. print page display problem
2. copy function issue
3. output name input issue


### 2020-11-21 Control4 SW Release
* 	Fw version: 1.0037
* 	HW version: VC1.0
1. In the DSP Setting page, after Setting the gain of Low Shelf (bass) to -12dB, it cannot close low Shelf (bass).
2. Input Setting page, MAX VOLUME cannot limit the maximum value of OUTPUT VOLUME
3. In DSP-Settings and DSP-Setting-Advanced, enable 2.1 Audio Zone has no CROSSOVER FREQUENCY
4. Problems ith out-of-frame name changes occurred if the name was too long in the Input/ Output page
5. When the INPUT NAME is too long, the fonts overlap in the print information.
6. In the Input/Output page, the input limit of the input box has been increased



### 2020-11-21 Control4 SW Release
* 	Fw version: 1.0036
* 	HW version: VC1.0
1. output gain cannot be greater than max gain
2. The character length of the output name is locked
3. Added index of several options
4. Solve the problem that the room eq parameter cannot be entered on the advanced page


### 2020-11-20 Control4 SW Release
* 	Fw version: 1.0035
* 	HW version: VC1.0
1. Solve the problem that the test signal does not work
2. Increase the range of tone control Q value judgment
3. Capitalize the first letter of the Input/Output name
4. remove static name from webpage
5. fix font color auto change to black issue
6. lock episode name
7. add select range jude for inputs
8. fix advanced dsp page js sync issue



### 2020-11-18 Control4 SW Release
* 	Fw version: 1.0034
* 	HW version: VC1.0

1. add backup/restore function
2. add tone control
3. add room eq lock
4. add the sub info to the response of the inputOutput webpage
5. change default device names
6. add test signal and test signal volume for each Output



### 2020-10-29 Control4 SW Release
* 	Fw version: 1.0033
* 	HW version: VC1.0

1. fix ip loss issue,app separate IP address detection program
2. add import/export function
3. remove Eq unmute/mute,fix ip lose issue
4. add new dsp file
5. refresh new api control
6. add token field
7. fix import "\n" character issue
8. add DSP Settings should only be accessible by manually adding /advanced at the end of the URL.





### 2020-09-24 Control4 SW Release
* 	Fw version: 1.0032
* 	HW version: VC1.0

1.  modify output volume value 100 issue
2.  Optimize database structure table, add Speaker and Room preset database
3.  Refresh DSP setting interface webpage
4.  add save/delete Speaker preset interface
5.  Reset button to split app program
6.  ssh port 2200 to 22




### 2020-09-03 Control4 SW Release
* 	Fw version: 1.0031
* 	HW version: VC1.0

1.  fix dspSetting database crash
2.  add reset button function
3.  add save database dspset data
4.  modify print webpage show issue
5.  optimize dhcp/static ipaddress issue 



### 2020-09-02 Control4 SW Release
* 	Fw version: 1.0030
* 	HW version: VC1.0

1.  add web advanced settings style
2.  fix print web page issue
3.  fix eq page toggle issue
4.  fix ip page settings
5.  fix webpage device name show issue

### 2020-09-01 Control4 SW Release
* 	Fw version: 1.0029
* 	HW version: VC1.0

1.  add Dsp setting output interface
2.  add static ip judge logic
3.  Realize the modification of user name and password




### 2020-08-28 Control4 SW Release
* 	Fw version: 1.0028
* 	HW version: VC1.0

1.  add sub control
2.  fix eq setting issue



### 2020-08-25 Control4 SW Release
* 	Fw version: 1.0027
* 	HW version: VC1.0

1.  Add init Webpage control
2.  Add PEQ


### 2020-07-24 Control4 SW Release
* 	Fw version: 1.0026
* 	HW version: VC1.0

1.  Add DSP Settings page feature
2.  Add php service

