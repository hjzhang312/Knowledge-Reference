#include "wshandle.h"

#include <exception>
#include <stddef.h>
#include <assert.h>
#include <time.h>
#include <string.h>
#include <log.h>

#include "sqlite3base.h"
#include "types.h"
#include "common.h"
#include "cJSON.h"

//#include "ovrccloudhandle.h"
#include "inoutputhandle.h"
#include "systemconfighandle.h"
#include "eqpagehandle.h"
#include "tools.h"

#include "comhandleapi.h"

#ifdef uWS
using namespace uWS;
#endif

#include "ovrc_sdk.h"
extern WEBSOCKET *wbsConnection;

WSHandle::WSHandle() : wschangeobserver(this)
{
    connector=0;
#ifdef uWS
    h = new uWS::Hub;
#endif
}

WSHandle::~WSHandle()
{

}

void WSHandle::sendboardcast(std::string str)
{
    DEBUG_LOG("sendboardcast: %s",str.c_str());
#ifdef uWS
    h->getDefaultGroup<uWS::SERVER>().broadcast(string.c_str(),string.size(), OpCode::TEXT);
#else
    LibWSServerBase::getInstance()->sendBoardData(str);
#endif
}

S_ret WSHandle::logInOutHandle(std::string  &user,std::string &password,int type,cJSON *retJson){
    if(type == 0) {LOGOUT("login");
        cJSON_AddItemToObject(retJson, "type", cJSON_CreateString("login"));
        LOGOUT("user:%s passwd:%s \n",user.c_str(),password.c_str());
        int ovrcStatus = WBS_STATE_INVALID;
        if(NULL != wbsConnection)
        {
            ovrcStatus = wbsConnection->connectionState;
        }
        cJSON_AddItemToObject(retJson, "ovrc", cJSON_CreateString(to_string(ovrcStatus).c_str()));

        if(sysdata::getInstance()->mLoginInfo.mFailNumber >= 5)
        {
            time_t t;
            t = time(NULL);
            long long lockTime = stoll(sysdata::getInstance()->mLoginInfo.mLockTime);
            if(((long long)t) -lockTime > LOCK_TIME)
            {
                sysdata::getInstance()->mLoginInfo.mFailNumber = 0;
                //updateLoginInfo(sysdata::getInstance()->mLoginInfo);
                sysdata::getInstance()->updateLoginInfo(sysdata::getInstance()->mLoginInfo);
            }
            else
            {
                cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(406));
                return SUCESS;
            }
        }
        LOGOUT("user: %s, pass: %s", sysdata::getInstance()->mLoginInfo.mUserName.c_str(),
               sysdata::getInstance()->mLoginInfo.mUserPasswd.c_str());
        LOGOUT("user: %s, pass: %s,failNum:%d", user.c_str(), password.c_str(),sysdata::getInstance()->mLoginInfo.mFailNumber);
        if((user != sysdata::getInstance()->mLoginInfo.mUserName) || \
                (password != sysdata::getInstance()->mLoginInfo.mUserPasswd))
        {
            sysdata::getInstance()->mLoginInfo.mFailNumber++;
            if(sysdata::getInstance()->mLoginInfo.mFailNumber == 5)
            {
                time_t t;
                t = time(NULL);
                sysdata::getInstance()->mLoginInfo.mLockTime = to_string(long(t));
                cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(406));
            }
            else if(5 > sysdata::getInstance()->mLoginInfo.mFailNumber)
            {
                cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(400));
            }

            //updateLoginInfo(sysdata::getInstance()->mLoginInfo);
            sysdata::getInstance()->updateLoginInfo(sysdata::getInstance()->mLoginInfo);

        }
        /*
        else if(1 == sysdata::getInstance()->mLoginInfo.mStatus)
        {
            cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(300));
        }*/
#if 1
        else if(0 == sysdata::getInstance()->mLoginInfo.mChangeType)
        {
            cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(403));
        }
#endif
        else
        {
            sysdata::getInstance()->mLoginInfo.mStatus = 1;
            sysdata::getInstance()->mLoginInfo.mChangeType = 1;
            sysdata::getInstance()->mLoginInfo.mFailNumber = 0;
            cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(200));
            cJSON_AddItemToObject(retJson, "token", cJSON_CreateString(sysdata::getInstance()->mToken.c_str()));
            //updateLoginInfo(sysdata::getInstance()->mLoginInfo);
            sysdata::getInstance()->updateLoginInfo(sysdata::getInstance()->mLoginInfo);
        }

    }
    else
    {  LOGOUT("logout");
        cJSON_AddItemToObject(retJson, "type", cJSON_CreateString("logout"));
        if(0 ==sysdata::getInstance()->mLoginInfo.mStatus)
        {
            cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(405));
        }
        else //if(user == sysdata::getInstance()->mLoginInfo.mUserName)
        {
            sysdata::getInstance()->mLoginInfo.mStatus = 0;
            cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(200));
            //updateLoginInfo(sysdata::getInstance()->mLoginInfo);
            sysdata::getInstance()->updateLoginInfo(sysdata::getInstance()->mLoginInfo);
        }
    }

    return SUCESS;
}

S_ret WSHandle::modifyPasswdHandle(const string passwd, const string user, cJSON *retJson)
{
    cJSON_AddItemToObject(retJson, "type", cJSON_CreateString("password"));
    /*if(1 == sysdata::getInstance()->mLoginInfo.mChangeType)
    {
        cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(300));
    }else */
    int ovrcStatus = WBS_STATE_INVALID;
    if(NULL != wbsConnection)
    {
        ovrcStatus = wbsConnection->connectionState;
    }
    cJSON_AddItemToObject(retJson, "ovrc", cJSON_CreateString(to_string(ovrcStatus).c_str()));

    if( passwd == sysdata::getInstance()->mLoginInfo.mUserPasswd)
    {
        cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(407));
    }
    else if(0 != passwd.size())
    {
        sysdata::getInstance()->mLoginInfo.mChangeType = 1;
        sysdata::getInstance()->mLoginInfo.mUserPasswd = passwd;
        sysdata::getInstance()->mLoginInfo.mUserName = user;
        cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(200));
        //updateLoginInfo(sysdata::getInstance()->mLoginInfo);
        sysdata::getInstance()->updateLoginInfo(sysdata::getInstance()->mLoginInfo);
        sysdata::getInstance()->mToken = Tools::getInstanc()->getRandom();
    }
}

S_ret WSHandle::inOutPutHandle(cJSON *msg,cJSON *retJson)
{
    char *direction = cJSON_GetObjectItem(msg,"direction")->valuestring;
    char *section =cJSON_GetObjectItem(msg,"section")->valuestring;
    char *token =cJSON_GetObjectItem(msg,"token")->valuestring;
    if(string(token) != sysdata::getInstance()->mToken)
    {
        cJSON_AddItemToObject(retJson,"status", cJSON_CreateNumber(402));
    }
    else if(0 == strcmp(direction,GET))
    {
        if(0 == strcmp(section,"all"))
        {
            sendInOutPageInfo(retJson);
        }
        else if(0 == strcmp(section,"print"))
        {
           // getPrintConfigureAll(retJson);
        }
    }else if(0 == strcmp(direction,PUT))
    {
        if(0 == strcmp(section,"all"))
        {
            InOutPutHandle::getInstance()->setInOutPutPageInfo(msg,retJson);
        }
    }
    else
    {
        DEBUG_LOG("value: %s",cJSON_GetObjectItem(msg,"section")->valuestring);
    }
    return SUCESS;
}

S_ret WSHandle::systemConfigHandle(cJSON *msg, cJSON *response)
{
    char *direction = cJSON_GetObjectItem(msg,"direction")->valuestring;
    char *section =cJSON_GetObjectItem(msg,"section")->valuestring;
    char *token =cJSON_GetObjectItem(msg,"token")->valuestring;
    if(string(token) != sysdata::getInstance()->mToken)
    {
        cJSON_AddItemToObject(response,"status", cJSON_CreateNumber(402));
    }
    else if(0 == strcmp(direction,GET))
    {
        if(0 == strcmp(section,"all"))
        {
            sendSystemConfigPageInfo(response);
        }
        else if(0 == strcmp(section,"print"))
        {
           // getPrintConfigureAll(retJson);
        }
    }else if(0 == strcmp(direction,PUT))
    {
        if(0 == strcmp(section,"all"))
        {
            SystemConfigHandle::getInstance()->setSystemConfigPageInfo(msg,response);
        }
    }
    else
    {
        DEBUG_LOG("value: %s",cJSON_GetObjectItem(msg,"section")->valuestring);
    }
    return SUCESS;
}


S_ret WSHandle::factoryResetHandle(cJSON *msg,cJSON *retJson)
{
    DEBUG_LOG("factoryResetHandle in");
    sysdata::getInstance()->resetDevice();

    return SUCESS;
}

S_ret WSHandle::firmwareUpdateHandle(cJSON *msg,cJSON *retJson)
{
    S_ret ret = sysdata::getInstance()->firmwareUpdate(
                cJSON_GetObjectItem(msg,"firmware-name")->valuestring
                );
    DEBUG_LOG("got %d from ota update", ret);
    
    cJSON_AddItemToObject(retJson, "type", cJSON_CreateString("fw_updated"));
    cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(ret));
   
    string response = string(cJSON_PrintUnformatted(retJson));
    //cJSON_Delete(retJson); // this would cause free twice! @

    WSHandle::getInstance()->sendboardcast(response);

    if (ret == 0) {
        sysdata::getInstance()->rebootDevice();
    }

    return SUCESS;
}

S_ret WSHandle::ovrcCloudHandle(cJSON *msg,cJSON *retJson)
{
    LOGOUT("in");
    char *direction = cJSON_GetObjectItem(msg,"direction")->valuestring;

    if(0 == strcmp(direction, GET))
    {
        //TODO
        //OvrcCloudHandle::getInstance()->getOvrcCloudPageInfo(retJson);
    }
    else if(0 == strcmp(direction, PUT))
    {
        //TODO
        //OvrcCloudHandle::getInstance()->setOvrcCloudPageInfo(msg,retJson);
        sysdata::getInstance()->rebootDevice();
    }
    else
    {
        DEBUG_LOG("unkown data....");
    }
    return SUCESS;
}

S_ret WSHandle::rebootHandle(cJSON *msg,cJSON *retJson) {
    LOGOUT("in");
    sysdata::getInstance()->rebootDevice();
    return SUCESS;
}

S_ret WSHandle::notifyHandle(Argument *arg)
{
    if(arg == nullptr) { LOGOUT("arg == nullptr") return FAILED; }
    LOGOUT("WSHandle::notifyHandle %d",arg->type);
//    switch (arg->type) {
//    case notify_networkchange: {
//        //parent->setNetWork( *((_networkinfo *)arg->data));
//    };break;
//    case notify_updatewebport: {
//        //parent->setWebPort( *((_cloudinfo *)arg->data));
//    };break;
//    case notify_devicechange:{
//        //parent->setDevice(*((_deviceinfo *)arg->data));
//    };break;
//    case notify_resetdevice:{
//        //parent->resetDevice( *((_deviceinfo *) arg->data));
//    };break;
//    case notify_updatefirmware:{
//        //parent->firmwareUpdate(*((string *)arg->data));
//    };break;
//    case notify_updatecloudurl:{
//        //parent->saveCloudurl(*((_cloudinfo *)arg->data));
//    };break;
//    default:LOGOUT("unknow type!!");
//    }

}

S_ret WSHandle::sendInOutPageInfo(cJSON *retJson)
{
    int ovrcStatus = WBS_STATE_INVALID;
    cJSON_AddItemToObject(retJson, "type", cJSON_CreateString("in_output_settings"));

    if(NULL != wbsConnection)
    {
        ovrcStatus = wbsConnection->connectionState;
    }
    cJSON_AddItemToObject(retJson, "ovrc", cJSON_CreateString(to_string(ovrcStatus).c_str()));

    if(0 == sysdata::getInstance()->mLoginInfo.mStatus)
    {
        cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(402));
    }
//    else if(0 == sysdata::getInstance()->dspdata.power)
//    {
//        cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(700));
//    }
    else if(NULL == cJSON_GetObjectItem(retJson,"status"))
    {
        cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(200));
    }

    InOutPutHandle::getInstance()->getInOutPutPageInfo(retJson);
    return 0;
}

S_ret WSHandle::sendSystemConfigPageInfo(cJSON *retJson)
{
    cJSON_AddItemToObject(retJson, "type", cJSON_CreateString("configure_settings"));
    int ovrcStatus = WBS_STATE_INVALID;
    if(NULL != wbsConnection)
    {
        ovrcStatus = wbsConnection->connectionState;
    }
    cJSON_AddItemToObject(retJson, "ovrc", cJSON_CreateString(to_string(ovrcStatus).c_str()));

    if(0 == sysdata::getInstance()->mLoginInfo.mStatus)
    {
        cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(402));
    }
//    else if(0 == sysdata::getInstance()->dspdata.power)
//    {
//        cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(700));
//    }
    else if(NULL == cJSON_GetObjectItem(retJson,"status"))
    {    
        cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(200));
    }

    SystemConfigHandle::getInstance()->getSystemConfigPageInfo(retJson);

    return 0;
}


S_ret WSHandle::getOvrcPageInfo(cJSON *retJson)
{

}


int stringtype_to_inttype(std::string type) {

    if(!type.compare("login"))return 0;
    if(!type.compare("logout"))return 1;
    if(!type.compare("password"))return 2;
    if(!type.compare("in_output_settings"))return 3;
    if(!type.compare("configure_settings"))return 4;
    if(!type.compare("factory_reset"))return 5;
    if(!type.compare("firmware_update"))return 6;
    if(!type.compare("ovrc_cloud_settings"))return 7;
    if(!type.compare("device_reboot"))return 8;
    if(!type.compare("power_status"))return 9;
    if(!type.compare("sn_info"))return 10;
    if(!type.compare("dsp_settings"))return 11;
    if(!type.compare("firmware_update_request"))return 12;
    if(!type.compare("heartbeat_request"))return 13;

    return -1;
}

std::string WSHandle::cmdhandler(std::string json,std::string ipaddress)
{

    std::string response ;
    std::string user;
    string passwd;
    std::string cmdtype;
    cJSON * retJson = NULL;
    retJson = cJSON_CreateObject();
    try {
        if(string::npos == json.find("heartbeat_request"))
            DEBUG_LOG("web send:%s",json.c_str());
        cJSON *item = NULL;
        cJSON *root =  cJSON_Parse(json.c_str());
        if(!root) {
            LOGOUT("cJSON_Parse %s failed!!",json.c_str());
            cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(401));
            response = string(cJSON_Print(retJson));
            cJSON_Delete(retJson);
            return response;
        }

        item = cJSON_GetObjectItem(root,"type");
        if(!item)
        {
            LOGOUT("exit 401");
            cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(401));
            response = string(cJSON_Print(retJson));
            cJSON_Delete(retJson);
            return response;
        }
        cmdtype = item->valuestring;

        LOGOUT("cmdtype %s",cmdtype.c_str());

        int inttype = stringtype_to_inttype(cmdtype);
        switch(inttype) {
        case 0:
        {
            user = cJSON_GetObjectItem(root,"username")->valuestring;
            passwd = cJSON_GetObjectItem(root,"password")->valuestring;
        }
        case 1:{
            logInOutHandle(user , passwd , inttype,retJson);
        };break;
        case 2:
        {
            passwd = cJSON_GetObjectItem(root,"password")->valuestring;
            user = cJSON_GetObjectItem(root,"username")->valuestring;
            modifyPasswdHandle(passwd, user,retJson);
            break;
        }
        case 3: inOutPutHandle( root , retJson);break;
        case 4: systemConfigHandle( root , retJson);break;
        case 5: factoryResetHandle( root , retJson);break;
        case 6: firmwareUpdateHandle( root , retJson);break;
        case 7: ovrcCloudHandle(root , retJson);break;
        case 8: rebootHandle( root , retJson);break;
        case 9: powerOnHandle(root,retJson);break;
        case 10: serialNumHandle(root,retJson);break;
        case 11: dspSettingsHandle(root, retJson);break;
        case 12: firmwareUpdateRequestHandle(root, retJson); break;
        case 13: heartbeatRequestHandle(root, retJson); break;
        default:{
            DEBUG_LOG("unsupport handle");
            response = "{\"status\":401}";
        }
        }
    } catch( std::exception & e) {
        LOGOUT("%s",e.what());
    }
    response = string(cJSON_PrintUnformatted(retJson));
    cJSON_Delete(retJson);
    return response;
}

S_ret WSHandle::powerOnHandle(cJSON *msg, cJSON *response)
{
    char *powerstatus = cJSON_GetObjectItem(msg,"status")->valuestring;

    if(0 == strcmp(powerstatus,"poweron"))
    {
        sysdata::getInstance()->Power(2);
        cJSON_AddItemToObject(response, "status", cJSON_CreateString("poweron"));
        cJSON_AddItemToObject(response, "type", cJSON_CreateString("power_status"));
    }

}

S_ret WSHandle::serialNumHandle(cJSON *msg, cJSON *response)
{
    char *sn = cJSON_GetObjectItem(msg, "value")->valuestring;
    Tools::getInstanc()->writeSerialNumber(sn);

    sysdata::getInstance()->deviceinfo.serialnumber = Tools::getInstanc()->readSerialNumber();
    sendSystemConfigPageInfo(response);
    //sysdata::getInstance()->notifyWebPageInfo(UpdateWebPageType, "configure");

    return SUCESS;
}

S_ret WSHandle::dspSettingsHandle(cJSON *msg,cJSON *retJson)
{
    char *direction = cJSON_GetObjectItem(msg,"direction")->valuestring;
    char *section = cJSON_GetObjectItem(msg,"section")->valuestring;
    char *token =cJSON_GetObjectItem(msg,"token")->valuestring;
    if(string(token) != sysdata::getInstance()->mToken)
    {
        cJSON_AddItemToObject(retJson,"status", cJSON_CreateNumber(402));
    }
    else if(0 == strcmp(direction, GET))
    {
        if(0 == strcmp(section, "all"))
        {
            EqPageHandle::getInstance()->getEqConfigureAll(retJson);
        }
    }
    else if(0 == strcmp(direction, PUT))
    {
        if(0 == strcmp(section,"all"))
        {
            EqPageHandle::getInstance()->setEqPageInfo(msg, retJson);
        }
    }
    else
    {
        DEBUG_LOG("value: %s",cJSON_GetObjectItem(msg,"section")->valuestring);
    }
    return SUCESS;
}

S_ret WSHandle::firmwareUpdateRequestHandle(cJSON *msg, cJSON *retJson)
{
    system("rm -rf /tmp/*.dat /tmp/*.zip");
    cJSON_AddItemToObject(retJson, "type", cJSON_CreateString("firmware_update_request"));
    cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(1000));
    return SUCESS;
}

S_ret WSHandle::heartbeatRequestHandle(cJSON *msg, cJSON *retJson)
{
    cJSON_AddItemToObject(retJson, "type", cJSON_CreateString("heartbeat_request"));
    cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(200));
    return SUCESS;
}

#ifdef LIBWS
void WSHandle::coremain(int &connector)
{

}

void WSHandle::run()
{
    coremain( this->connector );
    LibWSServerBase::getInstance()->run_server(3000);
}
#endif

