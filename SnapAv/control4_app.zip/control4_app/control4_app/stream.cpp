
#include "stream.h"
#include <stdio.h>
#include <linux/input.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <iostream>
#include "tools.h"
#include "log.h"
#include <semaphore.h>
#include "ledmisc.h"
#include "sysdata.h"

extern sem_t sysdatasem;

stream::stream()
{
 // memset(&current,0xff,sizeof(current));

}
extern float eqfremap[6];

void stream::Init()
{
    int i,j,k;;
    ADCInit();
    DspInit();
    matrixInit();
    for(i=0;i<CHANNELS;i++)
    {
        for(j=0;j<DSP_N;j++)
        {
           current[i].dsp[j]=0;
        }
        for(k=0;k<2;k++)
        {
              current[i].dspshelf[ENUM_SHELF_N*k+ENUM_shelf_freq]=1000;
              current[i].dspshelf[ENUM_SHELF_N*k+ENUM_shelf_gain]=1;
              current[i].dspshelf[ENUM_SHELF_N*k+ENUM_shelf_q]=0;
              current[i].dspshelf[ENUM_SHELF_N*k+ENUM_shelf_sr]=0;
        }
        for(k=0;k<12;k++)
        {
            current[i].dsppeq[ENUM_PEQ_N*k+ENUM_PEQ_Freq]=0;
            current[i].dsppeq[ENUM_PEQ_N*k+ENUM_PEQ_Gain]=1;
            current[i].dsppeq[ENUM_PEQ_N*k+ENUM_PEQ_Q]=0;
            current[i].dsppeq[ENUM_PEQ_N*k+ENUM_PEQ_SR]=0;
        }
        current[i].dsp[ENUM_Outputsource]=CHANNELS;
     }
    powerc=1;
    dsp_init_flag = 0;
}
void stream::Deinit()
{
    LineMute(1);
    DspDeinit();
    ADCDeinit();
    matrixDenit();
    DEBUG_LOG("Chip Deinit");
}


void stream::power(int pow)
{
    int i;
    if(pow==1)
    {
        LEDMISC::getInstance()->SetPower(1);
        LineMute(1);
        Init();
        UpdataPara();
        dsp_init_flag = 1;
        for(i=0;i<CHANNELS;i++)
        {
           // Inputvolume(i,0);
            Optical(i,0);
        }
        usleep(1000*100);
        LineMute(0);
        LEDMISC::getInstance()->SetBoot(0);
    }
    else
    {
        LEDMISC::getInstance()->SetPower(0);
        Deinit();
        dsp_init_flag = 0;
      //  LEDMISC::getInstance()->Gled.power=0;
    }


}



void stream::DSPMatrixUpdate()
{
    int i,working[CHANNELS]={0},workk=0;
   // DEBUG_LOG("update");
    for(i=0;i<CHANNELS;i++)
    {
        if(current[i].dsp[ENUM_Outputsource]!=sysdata::getInstance()->dspdata[i].dsp[ENUM_Outputsource])
        {
            working[i]=1;
            //Mute(i,1);
            Outputvolume(i,0);
            workk=1;
        }
    }
    if(workk)
    {
        usleep(1000*100);
        for(i=0;i<CHANNELS;i++)
        {
            if(working[i])
            {
                current[i].dsp[ENUM_Outputsource]=sysdata::getInstance()->dspdata[i].dsp[ENUM_Outputsource];
                sysdata::getInstance()->UpdateDsp(i,ENUM_Outputsource,current[i].dsp[ENUM_Outputsource]);
                MatrixSet(i,current[i].dsp[ENUM_Outputsource]);
                //sysdata::getInstance()->UpdateDsp(current.outputsource[i],i,"outputsource");
                LOGOUT("[%d]MatrixSet:%d",i,current[i].dsp[ENUM_Outputsource]);
            }
        }
        usleep(1000*200);
        for(i=0;i<CHANNELS;i++)
        {
            if(working[i])
            {
               // Mute(i,current.dspmute[i]);
                Outputvolume(i,current[i].dsp[ENUM_volume]);
            }
        }
    }
}





void stream::UpdataPara()
{
    int i,j,k,l;
    int EQ_change_flag = 0;
    static int index_backup_flag = CHANNELS;

    DSPMatrixUpdate();
    for(i=0;i<CHANNELS;i++)
    {
        for(j=0;j<DSP_N;j++)
        {
          if(current[i].dsp[j]!=sysdata::getInstance()->dspdata[i].dsp[j])
          {
              if (ENUM_Outputsource != j)
              {
                current[i].dsp[j]=sysdata::getInstance()->dspdata[i].dsp[j];
              }
              LOGOUT("UpdataPara channel:%d,index:%d",i,j);

           switch(j)
           {
           case ENUM_Optical://do nothing
               {
                   LOGOUT("Opt");
               } break;
           case ENUM_signalpresence_threshold:
               {
                   SetSignalPresence(i,current[i].dsp[j],current[i].dsp[ENUM_signalpresence_releasetime]);
                   LOGOUT("signalpresence_threshold");
               }break;
           case ENUM_signalpresence_releasetime:
               {
                   SetSignalPresence(i,current[i].dsp[ENUM_signalpresence_threshold],current[i].dsp[j]);
                   LOGOUT("signalpresence_releasetime");
               }break;
           case ENUM_Inputdelay:
               {
                   Inputdelay(i,current[i].dsp[j]);
                   LOGOUT("Inputdelay");
               }break;
           case ENUM_Inputvolume:
               {
                   Inputvolume(i,current[i].dsp[j]);
                   LOGOUT("Inputvolume");
               }break;
           case ENUM_Outputsource:
               {
                   LOGOUT("MatrixSource");

               }break;
           case ENUM_loudness:
               {
                   Loudness(i,current[i].dsp[j]);
                   LOGOUT("loudness");

               }break;
           case ENUM_outputdelay:
               {
                   Outputdelay(i,current[i].dsp[j]);
                   LOGOUT("outputdelay");

               }break;
           case ENUM_startvolume:
               {


               }break;
           case ENUM_maxvolume:
               {
                   Outputmaxvolume(i,current[i].dsp[j]);
                   LOGOUT("maxvolume");
               }break;
           case ENUM_volume:
               {
                   Outputvolume(i,current[i].dsp[j]);
                   LOGOUT("volume");

               }break;
           case ENUM_dspmute:
               {
                   Mute(i,current[i].dsp[j]);
                   LOGOUT("DspMute");
               }break;
           case ENUM_balance:
               {
                   BalanceSet(i,current[i].dsp[j]);
                   LOGOUT("Balance");

               }break;
           case ENUM_merge:
               {
                   Mono(i,current[i].dsp[j]);
                   LOGOUT("Mono:%d",current[i].dsp[j]);
               }break;
           case ENUM_group:
               {


               }break;
           case ENUM_oscgain:
               {
                   Oscgain(i,current[i].dsp[j]);
                   LOGOUT("oscgain");

               }break;
           case ENUM_dspfirmware:
               {


               }break;
           case ENUM_dspsamplerate:
               {


               }break;
           case ENUM_crossover_freq:
               {
#if 1
                   if (i % 2 == 0)
                   {
                        CrossSet(i,Xover_Freq,current[i].dsp[j]);
                        LOGOUT("CrossSet freq:%d,%d",i,current[i].dsp[j]);
                   }
                   else
                   {
                       CrossSet(i,Xover_Freq,current[i - 1].dsp[j]);
                       LOGOUT("CrossSet freq:%d,%d",i,current[i - 1].dsp[j]);
                   }
#else
                   CrossSet(i,Xover_Freq,current[i].dsp[j]);
                   LOGOUT("CrossSet");
#endif
               }break;
           case ENUM_crossover_sr:
               {
#if 1
                   if (i % 2 == 0)
                   {
                        CrossSet(i,Xover_SR,current[i].dsp[j]);
                        LOGOUT("CrossSet sr:%d,%d",i,current[i].dsp[j]);
                   }
                   else
                   {
                       CrossSet(i,Xover_SR,current[i - 1].dsp[j]);
                       LOGOUT("CrossSet sr:%d,%d",i,current[i - 1].dsp[j]);
                   }
#else
                   CrossSet(i,Xover_SR,current[i].dsp[j]);
                   LOGOUT("CrossSet");
#endif

               }break;
           case ENUM_crossover_index:
               {
#if 1
                   if (i % 2 == 0)
                   {
                        CrossSet(i,Xover_Index,current[i].dsp[j]);
                        LOGOUT("CrossSet gain:%d,%d",i,current[i].dsp[j]);
                   }
                   else
                   {
                       CrossSet(i,Xover_Index,current[i - 1].dsp[j]);
                       LOGOUT("CrossSet index:%d,%d",i,current[i - 1].dsp[j]);
                   }
#else
                   CrossSet(i,Xover_Index,current[i].dsp[j]);
                   LOGOUT("CrossSet");
#endif
               }break;
           case ENUM_crossover_gain:
               {
#if 1
                   if (i % 2 == 0)
                   {
                        CrossSet(i,Xover_Gain,current[i].dsp[j]);
                        LOGOUT("CrossSet gain:%d,%d",i,current[i].dsp[j]);
                   }
                   else
                   {
                       CrossSet(i,Xover_Gain,current[i - 1].dsp[j]);
                       LOGOUT("CrossSet gain:%d,%d",i,current[i - 1].dsp[j]);
                   }
#else
                   CrossSet(i,Xover_Gain,current[i].dsp[j]);
                   LOGOUT("CrossSet gain:%d,%d",i,current[i].dsp[j]);
#endif
               }break;
           }
           LOGOUT("UpdateDsp channel:%d,index:%d",i,j);
           sysdata::getInstance()->UpdateDsp(i,j,current[i].dsp[j]);
          }
        }

        for(k=0;k<2;k++)
        {
            int change=0;
            for(j=k*ENUM_SHELF_N;j<(k+1)*ENUM_SHELF_N;j++)
            {
              if(current[i].dspshelf[j]!=sysdata::getInstance()->dspdata[i].dspshelf[j])
              {
                  current[i].dspshelf[j]=sysdata::getInstance()->dspdata[i].dspshelf[j];
                  sysdata::getInstance()->UpdateDspShelf(i,j,current[i].dspshelf[j]);
                  LOGOUT("SHELF--channel:%d,k:%d,type:%x,data:0x%x",i,k,j,current[i].dspshelf[j]);
                  change=1;
                  if (index_backup_flag != i)
                  {
                      index_backup_flag = i;
                      Mute(i,1);
                      if (dsp_init_flag == 1)
                      {
                         usleep(1000*500);
                      }
                  }

                  if (EQ_change_flag == 0)
                  {
                      if (dsp_init_flag == 1)
                      {
                          LineMute(1);
                      }
                      EQ_change_flag = 1;
                  }
              }
            }
            if(change)
            {
                ShelfSet(i,Shelf_Index,k);
                ShelfSet(i,Shelf_Freq,current[i].dspshelf[ENUM_SHELF_N*k+ENUM_shelf_freq]);
                ShelfSet(i,Shelf_Gain,current[i].dspshelf[ENUM_SHELF_N*k+ENUM_shelf_gain]);
                ShelfSet(i,Shelf_Q,current[i].dspshelf[ENUM_SHELF_N*k+ENUM_shelf_q]);
                LOGOUT("SHELF--channel:Qdata:0x%x",current[i].dspshelf[ENUM_SHELF_N*k+ENUM_shelf_q]);
                if (current[i].dsp[ENUM_dspmute] == 0)
                {
                    Mute(i,current[i].dsp[ENUM_dspmute]);
                }
            }
        }
        for(k=0;k<12;k++)
        {
            int change=0;
            for(j=k*ENUM_PEQ_N;j<(k+1)*ENUM_PEQ_N;j++)
            {
              if(current[i].dsppeq[j]!=sysdata::getInstance()->dspdata[i].dsppeq[j])
              {
                 current[i].dsppeq[j]=sysdata::getInstance()->dspdata[i].dsppeq[j];
                 sysdata::getInstance()->UpdateDspPEQ(i,j,current[i].dsppeq[j]);
                 LOGOUT("PEQ--channel:%d,k:%d,type:%x,data:0x%x",i,k,j,current[i].dsppeq[j]);
                 change=1;
                 if (index_backup_flag != i)
                 {
                     index_backup_flag = i;
                     Mute(i,1);
                     if (dsp_init_flag == 1)
                     {
                        usleep(1000*500);
                     }
                 }
                 if (EQ_change_flag == 0)
                 {
                     if (dsp_init_flag == 1)
                     {
                         LineMute(1);
                     }
                     EQ_change_flag = 1;
                 }
              }
            }
            if(change)
            {
                PeqSet(i,PEQ_Index,k);
                PeqSet(i,PEQ_Freq,current[i].dsppeq[ENUM_PEQ_N*k+ENUM_PEQ_Freq]);
                PeqSet(i,PEQ_Gain,current[i].dsppeq[ENUM_PEQ_N*k+ENUM_PEQ_Gain]);
                PeqSet(i,PEQ_Q,current[i].dsppeq[ENUM_PEQ_N*k+ENUM_PEQ_Q]);
                PeqSet(i,PEQ_SR,current[i].dsppeq[ENUM_PEQ_N*k+ENUM_PEQ_SR]);
                if (current[i].dsp[ENUM_dspmute] == 0)
                {
                    Mute(i,current[i].dsp[ENUM_dspmute]);
                }
            }
        }  
    }
    if (EQ_change_flag == 1)
    {
        EQ_change_flag = 0;
        if (dsp_init_flag == 1)
        {
            usleep(1000*500);
            LineMute(0);
        }
        index_backup_flag = CHANNELS;
    }
}

int stream::SignalDet()
{
  int i, Signal=0;
  static int signal_buf[CHANNELS] = {0};

  for(i=0;i<CHANNELS;i++)
  {
      Signal|=(OutSignal(i)?1:0)<<i;
      if (signal_buf[i] != (OutSignal(i)?1:0))
      {
        signal_buf[i] = (OutSignal(i)?1:0);
        if ((sysdata::getInstance()->devicedata.audiosens & (0x01<<i)) != 0)
        {
            SocketServer::getInstance()->report_Signal_detect(i);
        }
      }
  }
  //DEBUG_LOG("outsig:%d :0X%x",i,Signal);
  LEDMISC::getInstance()->SetOutActive(Signal);
  return Signal;
}

void stream::SpdifOrRCA()
{
  int i;
  static unsigned char SpdifEn[CHANNELS/2]={0};
   //memset(SpdifEn,1,CHANNELS/2);
  if(powerc!=1)
  {
      for(i=0;i<CHANNELS/2;i++)
      {
         SpdifEn[i]=0;
      }
      return;
  }
  for(i=0;i<CHANNELS/2;i++)
  {
      int Spdiflo;
      Spdiflo=Spdiflock(i);
    //  LOGOUT("[%d]Spdiflo:%d",i,Spdiflo);

      if(SpdifEn[i]==0)
      {
          if(Spdiflo)
          {
              SpdifEn[i]=1;
              SpdifUmute(i);
              usleep(1000*100);
              Optical(i,1);
              LOGOUT("[%d]Spdif1",i);
          }

      }
      else
      {
          if(!Spdiflo)
          {
              Optical(i,0);
              LOGOUT("[%d]Spdif0",i);
              SpdifEn[i]=0;
          }
      }
  }
}

int stream::sem_timedwait_millsecs(long msecs)
{
    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    long secs = msecs/1000;
    msecs = msecs%1000;

    long add = 0;
    msecs = msecs*1000*1000 + ts.tv_nsec;
    add = msecs / (1000*1000*1000);
    ts.tv_sec += (add + secs);
    ts.tv_nsec = msecs%(1000*1000*1000);

    return sem_timedwait(&sysdatasem, &ts);
}

void stream::run()
{
    //struct timespec ts;
    int timercount=0;
    if(sysdata::getInstance()->devicedata.power==1)
    {
        power(1);
    }
    while(1)
    {
        //clock_gettime(CLOCK_REALTIME, &ts);
        //ts.tv_sec += 1; //2
        //if(sem_timedwait(&sysdatasem,&ts)<0)
        if (sem_timedwait_millsecs(500) < 0)
        {
            int i;
            if(powerc==1)
            {
                SpdifOrRCA();
                for(i=0;i<CHANNELS;i++) ADCSignal(sysdata::getInstance()->devicedata.audiosens&(0x01<<i),i);
                if(SignalDet())
                {
                    timercount=0;
                    if((sysdata::getInstance()->devicedata.autostandby)&&(!powerc))
                    {
                       // sysdata::getInstance()->dspdata.power=1;//wake up
                        continue;
                    }
                    else continue;
                }
                else
                {
                    if(timercount>=0)timercount+=1; //2
                    if(sysdata::getInstance()->devicedata.autostandby)
                    {
                        if(timercount>60*20*2) //60*20
                        {
                            sysdata::getInstance()->devicedata.power=0;
                            timercount=0;
                        }
                        else
                        {
//                         DEBUG_LOG("power off after:%d",60*20-timercount);
                         continue;
                        }
                    }
                    else
                    {
                        if(timercount)timercount=0;
                        continue;
                    }

                }
            }
        }

        if(powerc!=sysdata::getInstance()->devicedata.power)
        {
            powerc=sysdata::getInstance()->devicedata.power;
            if(powerc==1)
            {
               DEBUG_LOG("poweron");
                power(1);
            }
            else
            {
                DEBUG_LOG("poweroff");
                LOGOUT("poweroff");
                power(0);
                SpdifOrRCA();
            }
        }
        if(powerc!=1)continue;
        UpdataPara();
    }
}

