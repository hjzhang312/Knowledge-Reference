#ifndef SNAPAV_FIVEONE

#ifndef EQPAGEHANDLE_H
#define EQPAGEHANDLE_H

#include "comhandleapi.h"
#include "tools/sqlite3base.h"
#include "cJSON.h"

#define ROOM_EQ_EXPORT_ALL "/tmp/all_room_eq_presets.eqs"
#define SPEAKER_EXPORT_ALL "/tmp/all_speaker_presets.eqs"

class EqPageHandle : public ComHandleApi
{
public:
    static EqPageHandle *getInstance() {
        static EqPageHandle s;
        return &s;
    }
    enum class CHECK_TYPE {
        INVALID_TYPE = 0x0,
        INT_TYPE,
        DOUBLE_TYPE
    };
    enum class SELECT_ITEM {
        INVALID_ITEM = 0x0,
        EQ_ITEM,
        DELAY_ITEM_SEC,
        DELAY_ITEM_FEET,
        DELAY_ITEM_METERS
    };
private:
    EqPageHandle();
    string doubleToString(double tmp);
    void chechValue(const string id,string &v,SELECT_ITEM item = SELECT_ITEM::INVALID_ITEM,CHECK_TYPE type = CHECK_TYPE::INVALID_TYPE);
    //void setDspInfo(dspPresetItemType type, string index);

    S_ret writeBinary(std::ofstream &fout,string &md5,const string value);
    S_ret readBinary(string &value,string &md5,char **p);

public:
    void getEqConfigureAll(cJSON *retJson);
    void getEqPreConfigureAll(cJSON *retJson);

    S_ret getOutputDspSingleInfo(cJSON *outputDspInfo, string index);
    S_ret getSubDspSingleInfo(cJSON *subDspInfo, string index);
    S_ret getRoomEqSingleInfo(cJSON *eqInfo, string index);
    S_ret getSpeakerEqSingleInfo(cJSON *eqInfo, string index);

    S_ret setEqPageInfo(cJSON *root, cJSON *retJson);

    string eqExportAllHandleFun(bool room = true);
    string eqExportSingleHandleFun(string index,bool room = true);
    S_ret eqImportAllHandleFun(string fileName,string md5Value,bool room);
    S_ret eqImportSingleHandleFun(string index,string fileName,string md5Value,bool room);

    S_ret setOutputRoomEQLockFunc(int index, string v);
};

#endif // EQPAGEHANDLE_H
#endif
