#ifndef COMHANDLEAPI_H
#define COMHANDLEAPI_H

#include "tools/sqlite3base.h"
#include "cJSON.h"
#include <mutex>
#include "types.h"

#define BACKUP_ALL "/tmp/TriadAMS.gen"

enum ConfigureStrValue {
    evNotDefined,

    evDeviceName,
    evBackUp,
    evRestore,
    evSshEnable,

    evDhcpEnabled,
    evIpAddress,
    evGateWay,
    evSubnetMask,
    evDnsServer,
    evUserName,
    evPasswd,

    evInputName,
    evInputGain,
    evInputDelay,
    evInputAudioSence,

    evOutputName,
    evOutputSource,
    evOutputDelay,
    evOutputStereo,
    evOutputMute,
    evOutputVol,
    evOutputMaxVol,
    evOutputBalance,
    evOutputAssignTrigger,
    evOutputTestSignal,
    evOutputTestSignalVolume,

    evDspOutputIndex,
    evDspOutputLock,
    evDspToneBass,
    evDspToneTreble,
    evDspLoudnessEn,
    evDspToneBassEN,
    evDspToneBassFreq,
    evDspToneBassQ,
    evDspToneTrebleEN,
    evDspToneTrebleFreq,
    evDspToneTrebleQ,


    evSubOutputIndex,
    evSubEnable,
    evSubVolOffset,
    evCrossoverType,
    evCrossoverSlop,
    evCrossoverFreq,

    evEqImportAll,
    evEqExportAll,
    evEqImportSingle,
    evEqExportSingle,
    evEqCopyDsp,
    evEqEditDsp,
    evEqResetDsp,

    evEqRoomIndex,
    evEqSpeakerIndex,
    evEqEnable,
    evEqFreq,
    evEqQratio,
    evEqGain,

    evEqCustomIndex,
    evSpeakerEqEnable,
    evSpeakerEqFreq,
    evSpeakerEqQratio,
    evSpeakerEqGain,
    evEqAddEq,
    evEqDelEq,
    evEqSavePreset,
    evEqDelPreset,

    evEnd
};

enum ApiStatus {
    API_STATUS_SUCCESS = 200,
    API_STATUS_REPEAT_OPERATION = 300,
    API_STATUS_LOGIN_ERROR = 400,
    API_STATUS_ILLEGAL_REQ = 401,
    API_STATUS_UNLOGIN = 402,
    API_STATUS_PWD_DEFAULT = 403,
    API_STATUS_SIGN_OUT = 405,
    API_STATUS_PWD_LOCK = 406,
    API_STATUS_PWD_SAME = 407,
    API_STATUS_PWD_SET_SUCCESS = 408,

    API_STATUS_INVALID_RANGE = 410,
    API_STATUS_PARAM_ERROR = 411,
    API_STATUS_UNKNOWN_ERROR = 500,
    API_STATUS_FILE_NOT_EXIST = 600,
    API_STATUS_FILE_MD5_ERROR = 601,
    API_STATUS_FILE_TYPE_ERROR = 602,

    API_STATUS_STANDBY_MODE = 700,
    API_STATUS_TRIGGER_MODE = 701,
    API_STATUS_AUDIO_MODE = 702,

    API_STATUS_UPDATE_SUCCESS = 800,
    API_STATUS_UPDATE_FAIL = 801
};

enum OvrcUpdate
{
    DEVICE_NAME_INFO,
    DEVICE_NET_INFO,
    OVRC_ENABLE_INFO,
    OVRC_URL_INFO,
    OVRC_FREQ_INFO
};

enum dspPresetItemType {
    Room_EQ_Type = 0,
    Speaker_EQ_Type,
    Tilt_Type,
    Crossover_Type,
    Delay_Type,
    Limiter_Type,
    Dsp_Type
};

struct observer
{
    virtual ~observer() {};
    virtual void ovrcUpdate(OvrcUpdate info) = 0;
};
class subject{
public:
       static subject& GetInstance();
       void Attach(observer* listener);
       void Notify(OvrcUpdate info);
   private:
       subject() : listener(nullptr) {}

       observer* listener;
};

class ComHandleApi
{
public:
    ComHandleApi();

public:
    string getValueToKey(ConfigureStrValue value);

    virtual ApiStatus setInputName(int index, std::string value_s);
    virtual ApiStatus setInputGainVol(int index, std::string value_s);
    virtual ApiStatus setInputDelay(int index, std::string value_s);
    virtual ApiStatus setInputAudioSense(int index, std::string enable_s);

    virtual ApiStatus setOutputName(int index, std::string value_s);
    virtual ApiStatus setOutputSource(int index, std::string value_s);
    virtual ApiStatus setOutputDelay(int index, std::string value_s);
    virtual ApiStatus setOutputStereo(int index, std::string enable_s);
    virtual ApiStatus setOutputMute(int index, std::string enable_s);
    virtual ApiStatus setOutputVol(int index, std::string value_s);
    virtual ApiStatus setOutputMaxVol(int index, std::string value_s);
    virtual ApiStatus setOutputBalance(int index, std::string value_s);
    virtual ApiStatus setOutputAssignTrigger(int index, std::string enable_s);

    virtual ApiStatus setIpAddress(_networkinfo ip, bool send = false); //true : web change
    virtual ApiStatus setOvrcInfo(_cloudinfo info);

    virtual ApiStatus setDspLoudnessEn(int index, std::string enable_s);
    virtual ApiStatus setOutputToneBass(int index, std::string value_s);
    virtual ApiStatus setOutputToneTreble(int index, std::string value_s);
    virtual ApiStatus setOutputRoomDspPreset(int index, std::string value_s);
    virtual ApiStatus setOutputSpeakerDspPreset(int index, std::string value_s);
    // Tone Control
    virtual ApiStatus setOutputToneBassEN(int index, std::string enable_s);
    virtual ApiStatus setOutputToneBassFreq(int index, std::string value_s);
    virtual ApiStatus setOutputToneBassQ(int index, std::string value_s);
    virtual ApiStatus setOutputToneTrebleEN(int index, std::string enable_s);
    virtual ApiStatus setOutputToneTrebleFreq(int index, std::string value_s);
    virtual ApiStatus setOutputToneTrebleQ(int index, std::string value_s);
    // room eq lock
    virtual ApiStatus setOutputRoomEQLock(int index, std::string value_s);


    virtual ApiStatus setSubEnable(int index, std::string enable_s);
    virtual ApiStatus setSubVolOffset(int index, std::string value_s);
    virtual ApiStatus setSubCrossoverType(int index, std::string value_s);
    virtual ApiStatus setSubCrossoverSlop(int index, std::string value_s);
    virtual ApiStatus setSubCrossoverFreq(int index, std::string value_s);

    virtual ApiStatus setEqEnable(int index, string uuid_s, std::string enable_s);
    virtual ApiStatus setEqFreq(int index, string uuid_s, std::string value_s);
    virtual ApiStatus setEqQratio(int index, string uuid_s, std::string value_s);
    virtual ApiStatus setEqGain(int index, string uuid_s, std::string value_s);

    virtual ApiStatus setSpeakerEqEnable(int index, string uuid_s, std::string enable_s);
    virtual ApiStatus setSpeakerEqFreq(int index, string uuid_s, std::string value_s);
    virtual ApiStatus setSpeakerEqQratio(int index, string uuid_s, std::string value_s);
    virtual ApiStatus setSpeakerEqGain(int index, string uuid_s, std::string value_s);

    virtual ApiStatus setCopyDsp(string from, string to,bool room = true);

    void setDspInfo(string dsp_index, dspPresetItemType type);

public:
    virtual ApiStatus getInputSetting(cJSON *retJson,vector<int> index,bool apiNote=false);
    virtual ApiStatus getOutputSetting(cJSON *retJson,vector<int> getIndex,bool apiNote=false);
    virtual ApiStatus getSystemSetting(cJSON *retJson,bool apiNote=false);

    virtual ApiStatus getIpAddress(cJSON *retJson,bool apiNote=false);

    virtual ApiStatus getPowerStatus(cJSON *retJson,bool apiNote=false);


    virtual int getIpChange() {
        int status = mIPChange;
        mIPChange = -1;
        return status;}


public:
    void setSourceConfigure(int index);
    bool isNum(string str) ;
private:
    string doubleToString_one(double tmp);
    string doubleToString(double tmp);
    bool isIPAddressValid(std::string &str);
    bool filtStr(std::string &s);
    void setOutSpeakSizeFun(int index,int item);
    void setOutCrossOverFun(int index,int item);
    void setOutSlopeFun(int index,int item);
    int mIPChange; // -1: no status 0: web ip change 1:api ip change

private:
    std::mutex mMutexLock;

public:
    std::map<std::string, ConfigureStrValue> s_mapConfigStrVal;

    vector<string> m_inputGainRange;
    vector<string> m_inputDelayRange;
    vector<string> m_outputDelayRange;
    vector<string> m_outputVolRange;
    vector<string> m_outputMaxVolRange;
    vector<string> m_outputBalanceRange;

    vector<string> m_dspToneBassRange;
    vector<string> m_dspToneTrebleRange;
    vector<string> m_SubVolOffsetRange;
    vector<string> m_CrossoverFreqRange;
    vector<string> m_CrossoverTypeItem;
    vector<string> m_CrossoverSlopItem;

    string mCurrentDspOutputIndex;
    string mCurrentSubOutputIndex;
    string mCurrentRoomEqIndex;
    string mCurrentSpeakerEqIndex;
    string mCurrentCustomSpeakerEqIndex;

};

#endif // COMHANDLEAPI_H
