#ifndef INOUTPUTHANDLE_H
#define INOUTPUTHANDLE_H

#include "tools/sqlite3base.h"
#include "cJSON.h"
#include "comhandleapi.h"

class InOutPutHandle: public ComHandleApi
{
public:
    static InOutPutHandle *getInstance() {
        static InOutPutHandle s;
        return &s;
    }
private:
    InOutPutHandle();
    //void checkMutexValue(string index,string v,string item);

public:
    S_ret setInOutPutPageInfo(cJSON *root,cJSON *retJson);
    void getInOutPutPageInfo(cJSON *retJson);

};

#endif // INOUTPUTHANDLE_H
