#ifndef SNAPAV_FIVEONE

#include "eqpagehandle.h"

#include <stdio.h>
#include <string>
#include <string.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <cstdio>
#include "md5.h"

#include <iostream>
#include <sstream>

#include "types.h"
#include "sysdata.h"
#include "websocket_client.h"
#include "log.h"

EqPageHandle::EqPageHandle()
{

}

string EqPageHandle::doubleToString(double tmp)
{
    tmp*=100;
    tmp=(int)tmp;
    tmp/=100.0;


    stringstream oss;
    oss << tmp;
    return oss.str();
}

S_ret EqPageHandle::writeBinary(ofstream &fout, string &md5, const string value)
{
    char endMark = 0;
    fout.write(value.c_str(), sizeof(char) * (value.size()));
    md5 += value;
    fout.write(&endMark,sizeof(char));
    return SUCESS;
}

S_ret EqPageHandle::readBinary(string &value,string &md5, char **p)
{
    value.clear();
    value = *p;
    md5 +=value;
    *p = *p + strlen(*p) + 1;
    return SUCESS;
}

string EqPageHandle::eqExportAllHandleFun(bool room)
{
    if(room)
    {
        if(0 == (access(ROOM_EQ_EXPORT_ALL,F_OK)))
            return string(ROOM_EQ_EXPORT_ALL);

        string head = "Control4_8_Room";
        if(CHANNELS > 8)
            head = "Control4_16_Room";

        char endMark = 0;
        std::ofstream fout(ROOM_EQ_EXPORT_ALL, std::ios::binary);
        fout.write(head.c_str(), sizeof(char) * (head.size()));
        fout.write(&endMark,sizeof(char));
        string md5Str;

        //dsp size
        int roomSize = sysdata::getInstance()->mRoomDspVecInfo.size();
        writeBinary(fout,md5Str,to_string(roomSize));

        //dsp item
        for(int n = 0; n < sysdata::getInstance()->mRoomDspVecInfo.size(); n++)
        {
            _roomDspPresetItemInfo tmp = sysdata::getInstance()->mRoomDspVecInfo[n];
            writeBinary(fout,md5Str,tmp.mRoomDspIndex);
            writeBinary(fout,md5Str,tmp.mRoomDspName);

            for(int i = 0; i< MAX_EQ_NUM;i++)
            {
                writeBinary(fout,md5Str,tmp.mRoomEqIndex[i]);
                writeBinary(fout,md5Str,tmp.mRoomEqEnable[i]);
                writeBinary(fout,md5Str,tmp.mRoomEqFreq[i]);
                writeBinary(fout,md5Str,tmp.mRoomEqQratio[i]);
                writeBinary(fout,md5Str,tmp.mRoomEqGain[i]);
            }
        }

        char md5Value[64]={0};
        Md5String((unsigned char*)(md5Str.c_str()),md5Str.size(),md5Value);
        string md5_value = md5Value;
        writeBinary(fout,md5Str,md5_value);

        fout.close();

        return string(ROOM_EQ_EXPORT_ALL);
    }
    else
    {
        if(0 == (access(SPEAKER_EXPORT_ALL,F_OK)))
            return string(SPEAKER_EXPORT_ALL);

        string head = "Control4_8_Speaker";
        if(CHANNELS > 8)
            head = "Control4_16_Speaker";

        char endMark = 0;
        std::ofstream fout(SPEAKER_EXPORT_ALL, std::ios::binary);
        fout.write(head.c_str(), sizeof(char) * (head.size()));
        fout.write(&endMark,sizeof(char));
        string md5Str;

        //dsp size
        int speakerSize = sysdata::getInstance()->mSpeakerDspMapInfo.size();
        writeBinary(fout,md5Str,to_string(speakerSize));

        //dsp item
        SPEAKER_PRESET_MAP::iterator it;
        for(it=sysdata::getInstance()->mSpeakerDspMapInfo.begin();it !=sysdata::getInstance()->mSpeakerDspMapInfo.end();it++)
        {
            _speakerDspPresetItemInfo tmp = it->second;
            writeBinary(fout,md5Str,tmp.mSpeakerDspIndex);
            writeBinary(fout,md5Str,tmp.mSpeakerDspName);

            for(int i = 0; i< MAX_EQ_NUM;i++)
            {
                writeBinary(fout,md5Str,tmp.mSpeakerEqIndex[i]);
                writeBinary(fout,md5Str,tmp.mSpeakerEqEnable[i]);
                writeBinary(fout,md5Str,tmp.mSpeakerEqFreq[i]);
                writeBinary(fout,md5Str,tmp.mSpeakerEqQratio[i]);
                writeBinary(fout,md5Str,tmp.mSpeakerEqGain[i]);
            }
        }

        char md5Value[64]={0};
        Md5String((unsigned char*)(md5Str.c_str()),md5Str.size(),md5Value);
        string md5_value = md5Value;
        writeBinary(fout,md5Str,md5_value);

        fout.close();

        return string(SPEAKER_EXPORT_ALL);
    }
}

string EqPageHandle::eqExportSingleHandleFun(string index, bool room)
{
#if 1
    string mFileName;
    unsigned long long iIndex = stoull(index);

    if(room)
    {
        if(iIndex >= sysdata::getInstance()->mRoomDspVecInfo.size())
        {
            string str;
            str.clear();
            return  str;
        }

        mFileName = "/tmp/"+sysdata::getInstance()->mRoomDspVecInfo[iIndex].mRoomDspName + ".eqs";
        if(0 == (access(mFileName.c_str(),F_OK)))
            return mFileName;

        string head = "Control4_8_Room";
        if(CHANNELS > 8)
            head = "Control4_16_Room";

        char endMark = 0;
        std::ofstream fout(mFileName.c_str(), std::ios::binary);
        fout.write(head.c_str(), sizeof(char) * (head.size()));
        fout.write(&endMark,sizeof(char));
        string md5Str;

        //dsp item
        _roomDspPresetItemInfo tmp = sysdata::getInstance()->mRoomDspVecInfo[iIndex];
        writeBinary(fout,md5Str,tmp.mRoomDspIndex);
        writeBinary(fout,md5Str,tmp.mRoomDspName);

        for(int i = 0; i< MAX_EQ_NUM;i++)
        {
            writeBinary(fout,md5Str,tmp.mRoomEqIndex[i]);
            writeBinary(fout,md5Str,tmp.mRoomEqEnable[i]);
            writeBinary(fout,md5Str,tmp.mRoomEqFreq[i]);
            writeBinary(fout,md5Str,tmp.mRoomEqQratio[i]);
            writeBinary(fout,md5Str,tmp.mRoomEqGain[i]);
        }

        char md5Value[64]={0};
        Md5String((unsigned char*)(md5Str.c_str()),md5Str.size(),md5Value);
        string md5_value = md5Value;
        fout.write(md5_value.c_str(),sizeof(char) * (md5_value.size()));

        md5Str += md5_value;
        fout.write(&endMark,sizeof(char));

        fout.close();
    }
    else
    {
        if(iIndex > sysdata::getInstance()->mSpeakerDspMapInfo.rbegin()->first)
        {
            string str;
            str.clear();
            return  str;
        }

        mFileName = "/tmp/"+sysdata::getInstance()->mSpeakerDspMapInfo[iIndex].mSpeakerDspName + ".eqs";
        if(0 == (access(mFileName.c_str(),F_OK)))
            return mFileName;

        string head = "Control4_8_Speaker";
        if(CHANNELS > 8)
            head = "Control4_16_Speaker";

        char endMark = 0;
        std::ofstream fout(mFileName.c_str(), std::ios::binary);
        fout.write(head.c_str(), sizeof(char) * (head.size()));
        fout.write(&endMark,sizeof(char));
        string md5Str;

        //dsp item
        _speakerDspPresetItemInfo tmp = sysdata::getInstance()->mSpeakerDspMapInfo[iIndex];
        writeBinary(fout,md5Str,tmp.mSpeakerDspIndex);
        writeBinary(fout,md5Str,tmp.mSpeakerDspName);

        for(int i = 0; i< MAX_EQ_NUM;i++)
        {
            writeBinary(fout,md5Str,tmp.mSpeakerEqIndex[i]);
            writeBinary(fout,md5Str,tmp.mSpeakerEqEnable[i]);
            writeBinary(fout,md5Str,tmp.mSpeakerEqFreq[i]);
            writeBinary(fout,md5Str,tmp.mSpeakerEqQratio[i]);
            writeBinary(fout,md5Str,tmp.mSpeakerEqGain[i]);
        }

        char md5Value[64]={0};
        Md5String((unsigned char*)(md5Str.c_str()),md5Str.size(),md5Value);
        string md5_value = md5Value;
        fout.write(md5_value.c_str(),sizeof(char) * (md5_value.size()));

        md5Str += md5_value;
        fout.write(&endMark,sizeof(char));

        fout.close();
    }

    return string(mFileName);
#endif
}

S_ret EqPageHandle::eqImportAllHandleFun(string fileName, string md5FileValue, bool room)
{
    string mFileName = "/tmp/" + fileName;
    if(-1 == (access(mFileName.c_str(),F_OK)))
        return IMPORT_FILE_NOT_EXIST;
#if 1
    char md5File[64]={0};
    if(0 == Md5File(mFileName.c_str(),md5File))
    {
        LOGOUT("md5File: %s",md5File);
        if(md5FileValue != string(md5File))
        {
            remove(mFileName.c_str());
            return IMPORT_MD5_FILE_ERROR;
        }
    }
    char *readBuf,*p;

    unsigned int nfileSize = 0;
    std::ifstream fin(mFileName.c_str(), std::ios::binary);
    fin.seekg(0, ios::end);
    nfileSize = fin.tellg();
    printf("len: %d\n",nfileSize);
    fin.seekg(ios::beg);
    readBuf = (char*)malloc(nfileSize);
//    memset(readBuf,0,nfileSize);
    fin.read(readBuf, sizeof(char) * nfileSize);
    p = readBuf;
    string head = p+1;
    LOGOUT("head: %s ",head.c_str());

    if(room)
    {
        string strCmp = "Control4_8_Room";
        if(CHANNELS > 8)
            strCmp = "Control4_16_Room";

//        if(0 != head.compare(strCmp))
//        {
//            free(readBuf);
//            remove(mFileName.c_str());
//            return IMPORT_TYPE_ERROR;
//        }
        string::size_type idx;
        idx = head.find(strCmp);
        if(idx == string::npos){
            DEBUG_LOG("eqImportAllHandleFun error!!!");
            free(readBuf);
            remove(mFileName.c_str());
            return IMPORT_TYPE_ERROR;
        }

        string md5Preset;
        p = p + strlen(p) + 1;
        string roomSize;
        readBinary(roomSize,md5Preset,&p);


        vector<_roomDspPresetItemInfo> tmpVec;
        for(int i = 0; i < stoi(roomSize); i++)
        {
            tmpVec.push_back(sysdata::getInstance()->mRoomDspVecInfo[i]);
            _roomDspPresetItemInfo tmp;

            readBinary(tmp.mRoomDspIndex,md5Preset,&p);
            readBinary(tmp.mRoomDspName,md5Preset,&p);

            for(int i = 0;i < MAX_EQ_NUM; i++)
            {
                readBinary(tmp.mRoomEqIndex[i],md5Preset,&p);
                readBinary(tmp.mRoomEqEnable[i],md5Preset,&p);
                readBinary(tmp.mRoomEqFreq[i],md5Preset,&p);
                readBinary(tmp.mRoomEqQratio[i],md5Preset,&p);
                readBinary(tmp.mRoomEqGain[i],md5Preset,&p);
            }
            tmpVec[i] = tmp;
        }

        string md5V;
        md5V = p;
        // p = p + strlen(p) + 1;

        char md5Str_value[64]={0};
        Md5String((unsigned char*)(md5Preset.c_str()),md5Preset.size(),md5Str_value);
        LOGOUT("Import Md5Value: %s ",md5Str_value);
        if(md5V == string(md5Str_value))
        {
            for(int i = 0; i < tmpVec.size(); i++)
            {
                sysdata::getInstance()->mRoomDspVecInfo[i] = tmpVec[i];
                sysdata::getInstance()->updateDataBasePresetInfoTable(to_string(i),room);
            }
        }
        else
        {
            free(readBuf);
            remove(mFileName.c_str());
            return IMPORT_MD5_STRING_ERROR;
        }
    }
    else
    {
        string strCmp = "Control4_8_Speaker";
        if(CHANNELS > 8)
            strCmp = "Control4_16_Speaker";

//        if(0 != head.compare(strCmp))
//        {
//            free(readBuf);
//            remove(mFileName.c_str());
//            return IMPORT_TYPE_ERROR;
//        }
        string::size_type idx;
        idx = head.find(strCmp);
        if(idx == string::npos){
            DEBUG_LOG("eqImportAllHandleFun error!!!");
            free(readBuf);
            remove(mFileName.c_str());
            return IMPORT_TYPE_ERROR;
        }

        string md5Preset;
        p = p + strlen(p) + 1;
        string speakerSize;
        readBinary(speakerSize,md5Preset,&p);


        SPEAKER_PRESET_MAP tmpSpeaker;
        for(int i = 0; i < stoi(speakerSize); i++)
        {
            _speakerDspPresetItemInfo tmp;
            readBinary(tmp.mSpeakerDspIndex,md5Preset,&p);
            readBinary(tmp.mSpeakerDspName,md5Preset,&p);

            for(int i = 0;i < MAX_EQ_NUM; i++)
            {
                readBinary(tmp.mSpeakerEqIndex[i],md5Preset,&p);
                readBinary(tmp.mSpeakerEqEnable[i],md5Preset,&p);
                readBinary(tmp.mSpeakerEqFreq[i],md5Preset,&p);
                readBinary(tmp.mSpeakerEqQratio[i],md5Preset,&p);
                readBinary(tmp.mSpeakerEqGain[i],md5Preset,&p);
            }
            tmpSpeaker[i+1] = tmp;
        }

        string md5V;
        md5V = p;
        // p = p + strlen(p) + 1;

        char md5Str_value[64]={0};
        Md5String((unsigned char*)(md5Preset.c_str()),md5Preset.size(),md5Str_value);
        DEBUG_LOG("Import Md5Value: %s old:%s",md5Str_value,md5V.c_str());
        if(md5V == string(md5Str_value))
        {
            sysdata::getInstance()->mSpeakerDspMapInfo.erase(sysdata::getInstance()->mSpeakerDspMapInfo.begin(),sysdata::getInstance()->mSpeakerDspMapInfo.end());
            for(int n = 0; n < tmpSpeaker.size(); n++)
            {
                sysdata::getInstance()->mSpeakerDspMapInfo[n+1] = tmpSpeaker[n+1];
            }

            sysdata::getInstance()->importAllSpeakerPresetInfoTable();
        }
        else
        {
            free(readBuf);
            remove(mFileName.c_str());
            return IMPORT_MD5_STRING_ERROR;
        }
    }

    free(readBuf);
    remove(mFileName.c_str());
#endif
    return SUCESS;
}

S_ret EqPageHandle::eqImportSingleHandleFun(string index, string fileName, string md5FileValue, bool room)
{
    string mFileName = "/tmp/" + fileName;
    if(-1 == (access(mFileName.c_str(),F_OK)))
    {
        DEBUG_LOG("File not exist");
        return IMPORT_FILE_NOT_EXIST;
    }

    char md5File[64]={0};
    if(0 == Md5File(mFileName.c_str(),md5File))
    {
        if(md5FileValue != string(md5File))
        {
            remove(mFileName.c_str());
            return IMPORT_MD5_FILE_ERROR;
        }
    }

    char *readBuf=NULL,*p=NULL;

    unsigned int nfileSize = 0;
    std::ifstream fin(mFileName.c_str(), std::ios::binary);
    fin.seekg(0, ios::end);
    nfileSize = fin.tellg();
    printf("len: %d\n",nfileSize);
    fin.seekg(ios::beg);
    readBuf = (char*)malloc(nfileSize);
    fin.read(readBuf, sizeof(char) * nfileSize);
    p = readBuf;
    string head = p+1;
//    DEBUG_LOG("======head:%s =====,size:%d",head.c_str(),head.size());
    if(room)
    {
        string strCmp = "Control4_8_Room";
        if(CHANNELS > 8)
            strCmp = "Control4_16_Room";

//        if(0 != head.compare(strCmp))
//        {
//            DEBUG_LOG("0000000000000000000");
//            free(readBuf);
//            remove(mFileName.c_str());
//            return IMPORT_TYPE_ERROR;
//        }
        string::size_type idx;
        idx = head.find(strCmp);
        if(idx == string::npos){
            DEBUG_LOG("eqImportSingleHandleFun error!!!");
            free(readBuf);
            remove(mFileName.c_str());
            return IMPORT_TYPE_ERROR;
        }

        string md5Preset;
        p = p + strlen(p) + 1;


        _roomDspPresetItemInfo tmp;

        readBinary(tmp.mRoomDspIndex,md5Preset,&p);
        readBinary(tmp.mRoomDspName,md5Preset,&p);


        for(int i = 0;i < MAX_EQ_NUM; i++)
        {
            readBinary(tmp.mRoomEqIndex[i],md5Preset,&p);
            readBinary(tmp.mRoomEqEnable[i],md5Preset,&p);
            readBinary(tmp.mRoomEqFreq[i],md5Preset,&p);
            readBinary(tmp.mRoomEqQratio[i],md5Preset,&p);
            readBinary(tmp.mRoomEqGain[i],md5Preset,&p);
        }
        tmp.mRoomDspIndex = index;

        string md5V;
        md5V = p;
        //p = p + strlen(p) + 1;

        char md5Str_value[64]={0};
        Md5String((unsigned char*)(md5Preset.c_str()),md5Preset.size(),md5Str_value);

        if(md5V == string(md5Str_value))
        {
            sysdata::getInstance()->mRoomDspVecInfo[stoi(index)] = tmp;
            sysdata::getInstance()->updateDataBasePresetInfoTable(tmp.mRoomDspIndex,room);
        }
        else
        {
            free(readBuf);
            remove(mFileName.c_str());
            return IMPORT_MD5_STRING_ERROR;
        }

        free(readBuf);
        remove(mFileName.c_str());
    }
    else
    {
        string strCmp = "Control4_8_Speaker";
        if(CHANNELS > 8)
            strCmp = "Control4_16_Speaker";
//        if(0 != head.compare(strCmp))
//        {
//            free(readBuf);
//            remove(mFileName.c_str());
//            return IMPORT_TYPE_ERROR;
//        }
        string::size_type idx;
        idx = head.find(strCmp);
        if(idx == string::npos){
            DEBUG_LOG("eqImportSingleHandleFun error!!!");
            free(readBuf);
            remove(mFileName.c_str());
            return IMPORT_TYPE_ERROR;
        }

        string md5Preset;
        p = p + strlen(p) + 1;

        _speakerDspPresetItemInfo tmp;

        readBinary(tmp.mSpeakerDspIndex,md5Preset,&p);
        readBinary(tmp.mSpeakerDspName,md5Preset,&p);


        for(int i = 0;i < MAX_EQ_NUM; i++)
        {
            readBinary(tmp.mSpeakerEqIndex[i],md5Preset,&p);
            readBinary(tmp.mSpeakerEqEnable[i],md5Preset,&p);
            readBinary(tmp.mSpeakerEqFreq[i],md5Preset,&p);
            readBinary(tmp.mSpeakerEqQratio[i],md5Preset,&p);
            readBinary(tmp.mSpeakerEqGain[i],md5Preset,&p);
        }

        string md5V;
        md5V = p;

        char md5Str_value[64]={0};
        Md5String((unsigned char*)(md5Preset.c_str()),md5Preset.size(),md5Str_value);

        if(md5V == string(md5Str_value))
        {
            tmp.mSpeakerDspIndex = index;
            sysdata::getInstance()->mSpeakerDspMapInfo[stoull(tmp.mSpeakerDspIndex)] = tmp;
            sysdata::getInstance()->updateDataBasePresetInfoTable(tmp.mSpeakerDspIndex,room);
        }
        else
        {
            free(readBuf);
            remove(mFileName.c_str());
            return IMPORT_MD5_STRING_ERROR;
        }

        free(readBuf);
        remove(mFileName.c_str());
    }

    return SUCESS;
}

S_ret EqPageHandle::setOutputRoomEQLockFunc(int index, string v)
{
    setOutputRoomEQLock(index, v);
}

void EqPageHandle:: getEqConfigureAll(cJSON *retJson)
{
    int ovrcStatus = WBS_STATE_INVALID;

    cJSON_AddItemToObject(retJson, "type", cJSON_CreateString("dsp_settings"));

    //    if(NULL != wbsConnection)
    //    {
    //        ovrcStatus = wbsConnection->connectionState;
    //    }
    cJSON_AddItemToObject(retJson, "ovrc", cJSON_CreateString(to_string(ovrcStatus).c_str()));

    if(NULL ==cJSON_GetObjectItem(retJson,"status"))
    {
        if(0 == sysdata::getInstance()->mLoginInfo.mStatus)
        {
            cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(402));
        }
        else if(0 == sysdata::getInstance()->devicedata.power)
        {
            cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(700));
        }
        else
        {
            cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(200));
        }
    }

    cJSON_AddItemToObject(retJson, "deviceName", cJSON_CreateString(sysdata::getInstance()->deviceinfo.devicename.c_str()));
    getEqPreConfigureAll(retJson);
}

void EqPageHandle::getEqPreConfigureAll(cJSON *retJson)
{
    cJSON *outputName = cJSON_CreateArray();
    cJSON *speakerDspItem = cJSON_CreateObject();
    cJSON *roomDspItem = cJSON_CreateArray();

    cJSON *outputDspInfo = cJSON_CreateObject();
    cJSON *subDspInfo = cJSON_CreateObject();
    cJSON *roomEqInfo = cJSON_CreateObject();
    cJSON *speakerEqInfo = cJSON_CreateObject();

    for(int i = 0; i < CHANNELS; i++)
    {
        cJSON_AddItemToArray(outputName, cJSON_CreateString(sysdata::getInstance()->mWebInfo.outputname[i].c_str()));
    }

    SPEAKER_PRESET_MAP::iterator it;
    for(it=sysdata::getInstance()->mSpeakerDspMapInfo.begin();it !=sysdata::getInstance()->mSpeakerDspMapInfo.end();it++)
    {
        _speakerDspPresetItemInfo tmp = it->second;
        cJSON_AddItemToObject(speakerDspItem,tmp.mSpeakerDspIndex.c_str(),cJSON_CreateString(tmp.mSpeakerDspName.c_str()));
    }

    for(int i = 0; i < sysdata::getInstance()->mRoomDspVecInfo.size(); i++)
    {
        cJSON_AddItemToArray(roomDspItem, cJSON_CreateString(sysdata::getInstance()->mRoomDspVecInfo[i].mRoomDspName.c_str()));
    }

    getOutputDspSingleInfo(outputDspInfo, mCurrentDspOutputIndex);
    getSubDspSingleInfo(subDspInfo, mCurrentSubOutputIndex);
    getRoomEqSingleInfo(roomEqInfo, mCurrentRoomEqIndex);
    getSpeakerEqSingleInfo(speakerEqInfo,mCurrentCustomSpeakerEqIndex);

    cJSON_AddItemToObject(retJson, "output_name", outputName);
    cJSON_AddItemToObject(retJson, "room_preset_item", roomDspItem);
    cJSON_AddItemToObject(retJson, "speaker_preset_item", speakerDspItem);

    cJSON_AddItemToObject(retJson, "output_dsp_info", outputDspInfo);
    cJSON_AddItemToObject(retJson, "sub_info", subDspInfo);

    cJSON_AddItemToObject(retJson, "room_dsp_info", roomEqInfo);
    cJSON_AddItemToObject(retJson, "speaker_dsp_info", speakerEqInfo);
    setDspInfo(mCurrentRoomEqIndex, Room_EQ_Type);

}

S_ret EqPageHandle::getOutputDspSingleInfo(cJSON *outputDspInfo, string index)
{
    int nIndex = stoi(index);

    if(nIndex < 0 || nIndex >= CHANNELS)
        return FAILED;

    cJSON *toneBassRange = cJSON_CreateArray();
    cJSON *toneTrebleRange = cJSON_CreateArray();
    cJSON *outPutDspSelect = cJSON_CreateArray();
    cJSON *outPutSubList = cJSON_CreateArray();
    cJSON *outPutSubEnable = cJSON_CreateArray();

    for(int i = 0; i < m_dspToneBassRange.size(); i++)
    {
        cJSON_AddItemToArray(toneBassRange, cJSON_CreateString(m_dspToneBassRange.at(i).c_str()));
    }

    for(int i = 0; i < m_dspToneTrebleRange.size(); i++)
    {
        cJSON_AddItemToArray(toneTrebleRange, cJSON_CreateString(m_dspToneTrebleRange.at(i).c_str()));
    }

    for(int i = 0; i < CHANNELS; i++)
    {
        cJSON_AddItemToArray(outPutDspSelect, cJSON_CreateString(to_string(i).c_str()));
    }

    for(int i = 1; i < CHANNELS; i = i + 2)
    {
        cJSON_AddItemToArray(outPutSubList, cJSON_CreateString(to_string(i).c_str()));
        cJSON_AddItemToArray(outPutSubEnable, cJSON_CreateString(sysdata::getInstance()->mSubDspInfo[i].mSubDspEnable.c_str()));
    }

    cJSON_AddItemToObject(outputDspInfo,"output_value",outPutDspSelect);

    cJSON_AddItemToObject(outputDspInfo, "output_index", cJSON_CreateString(index.c_str()));
    cJSON_AddItemToObject(outputDspInfo, "tone_bass_range", toneBassRange);
    cJSON_AddItemToObject(outputDspInfo, "tone_bass", cJSON_CreateString(sysdata::getInstance()->mOutputDspInfo[nIndex].mOutputToneBass.c_str()));
    cJSON_AddItemToObject(outputDspInfo, "tone_treble_range", toneTrebleRange);
    cJSON_AddItemToObject(outputDspInfo, "tone_treble", cJSON_CreateString(sysdata::getInstance()->mOutputDspInfo[nIndex].mOutputToneTreble.c_str()));
    cJSON_AddItemToObject(outputDspInfo, "tone_loudness_enable", cJSON_CreateString(sysdata::getInstance()->mOutputDspInfo[nIndex].mOutputLoudnessEN.c_str()));
    cJSON_AddItemToObject(outputDspInfo, "room_dsp_preset", cJSON_CreateString(sysdata::getInstance()->mOutputDspInfo[nIndex].mOutputRoomDspPreset.c_str()));
    cJSON_AddItemToObject(outputDspInfo, "speaker_dsp_preset", cJSON_CreateString(sysdata::getInstance()->mOutputDspInfo[nIndex].mOutputSpeakerDspPreset.c_str()));
    // 2020/11/11 tone control
    cJSON_AddItemToObject(outputDspInfo, "tone_bass_enable", cJSON_CreateString(sysdata::getInstance()->mOutputDspInfo[nIndex].mOutputToneBassEN.c_str()));
    cJSON_AddItemToObject(outputDspInfo, "tone_bass_freq", cJSON_CreateString(sysdata::getInstance()->mOutputDspInfo[nIndex].mOutputToneBassFreq.c_str()));
    cJSON_AddItemToObject(outputDspInfo, "tone_bass_q", cJSON_CreateString(sysdata::getInstance()->mOutputDspInfo[nIndex].mOutputToneBassQ.c_str()));
    cJSON_AddItemToObject(outputDspInfo, "tone_treble_enable", cJSON_CreateString(sysdata::getInstance()->mOutputDspInfo[nIndex].mOutputToneTrebleEN.c_str()));
    cJSON_AddItemToObject(outputDspInfo, "tone_treble_freq", cJSON_CreateString(sysdata::getInstance()->mOutputDspInfo[nIndex].mOutputToneTrebleFreq.c_str()));
    cJSON_AddItemToObject(outputDspInfo, "tone_treble_q", cJSON_CreateString(sysdata::getInstance()->mOutputDspInfo[nIndex].mOutputToneTrebleQ.c_str()));
    // add sub_index and sub_enable
    cJSON_AddItemToObject(outputDspInfo, "sub_output", outPutSubList);
    cJSON_AddItemToObject(outputDspInfo, "sub_enable", outPutSubEnable);

    return SUCESS;
}

S_ret EqPageHandle::getSubDspSingleInfo(cJSON *subDspInfo, string index)
{
    int nIndex = stoi(index);

    if(nIndex < 0 || nIndex >= CHANNELS)
        return FAILED;

    cJSON *outPutSubSelect = cJSON_CreateArray();
    cJSON *subVolOffsetRange = cJSON_CreateArray();
    cJSON *crossoverTypeItem = cJSON_CreateArray();
    cJSON *crossoverSlopItem = cJSON_CreateArray();
    cJSON *crossoverFreqRange = cJSON_CreateArray();

    for(int i = 1; i < CHANNELS; i = i + 2)
    {
        cJSON_AddItemToArray(outPutSubSelect, cJSON_CreateString(to_string(i).c_str()));
    }

    for(int i = 0; i < m_SubVolOffsetRange.size(); i++)
    {
        cJSON_AddItemToArray(subVolOffsetRange, cJSON_CreateString(m_SubVolOffsetRange.at(i).c_str()));
    }

    for(int i = 0; i < m_CrossoverTypeItem.size(); i++)
    {
        cJSON_AddItemToArray(crossoverTypeItem, cJSON_CreateString(m_CrossoverTypeItem.at(i).c_str()));
    }

    for(int i = 0; i < m_CrossoverSlopItem.size(); i++)
    {
        cJSON_AddItemToArray(crossoverSlopItem, cJSON_CreateString(m_CrossoverSlopItem.at(i).c_str()));
    }

    for(int i = 0; i < m_CrossoverFreqRange.size(); i++)
    {
        cJSON_AddItemToArray(crossoverFreqRange, cJSON_CreateString(m_CrossoverFreqRange.at(i).c_str()));
    }

    cJSON_AddItemToObject(subDspInfo, "sub_value", outPutSubSelect);
    cJSON_AddItemToObject(subDspInfo, "sub_enable", cJSON_CreateString(sysdata::getInstance()->mSubDspInfo[nIndex].mSubDspEnable.c_str()));
    cJSON_AddItemToObject(subDspInfo, "sub_output_index", cJSON_CreateString(index.c_str()));
    cJSON_AddItemToObject(subDspInfo, "sub_volume_offset_range", subVolOffsetRange);
    cJSON_AddItemToObject(subDspInfo, "sub_volume_offset", cJSON_CreateString(sysdata::getInstance()->mSubDspInfo[nIndex].mSubVolOffset.c_str()));
    cJSON_AddItemToObject(subDspInfo, "crossover_type_item", crossoverTypeItem);
    cJSON_AddItemToObject(subDspInfo, "crossover_type", cJSON_CreateString(sysdata::getInstance()->mSubDspInfo[nIndex].mSubCrossoverType.c_str()));
    cJSON_AddItemToObject(subDspInfo, "crossover_slop_item", crossoverSlopItem);
    cJSON_AddItemToObject(subDspInfo, "crossover_slop", cJSON_CreateString(sysdata::getInstance()->mSubDspInfo[nIndex].mSubCrossoverSlop.c_str()));
    cJSON_AddItemToObject(subDspInfo, "crossover_freq_range", crossoverFreqRange);
    cJSON_AddItemToObject(subDspInfo, "crossover_freq", cJSON_CreateString(sysdata::getInstance()->mSubDspInfo[nIndex].mSubCrossoverFreq.c_str()));

    return SUCESS;
}

S_ret EqPageHandle::getSpeakerEqSingleInfo(cJSON *eqInfo, string index)
{
    int nIndex = stoull(index);

    if(nIndex < 0 || nIndex > sysdata::getInstance()->mSpeakerDspMapInfo.rbegin()->first)
        return FAILED;

    cJSON *eq = cJSON_CreateArray();
    cJSON *preset = cJSON_CreateArray();

    SPEAKER_PRESET_MAP::iterator iter = sysdata::getInstance()->mSpeakerDspMapInfo.find(sysdata::getInstance()->mDefaultSpeakerPresetName.size());
    iter++;
    for (;iter!=sysdata::getInstance()->mSpeakerDspMapInfo.end(); iter++)
    {
        cJSON_AddItemToArray(preset,cJSON_CreateString(iter->second.mSpeakerDspIndex.c_str()));
    }

    if(0 != nIndex )
    {
        for(int i = 0; i < MAX_EQ_NUM; i++)
        {
            cJSON *item = cJSON_CreateObject();
            cJSON_AddItemToObject(item, "uuid", cJSON_CreateString(sysdata::getInstance()->mSpeakerDspMapInfo[nIndex].mSpeakerEqIndex[i].c_str()));
            cJSON_AddItemToObject(item, "eq_enable", cJSON_CreateString(sysdata::getInstance()->mSpeakerDspMapInfo[nIndex].mSpeakerEqEnable[i].c_str()));
            cJSON_AddItemToObject(item, "eq_freq", cJSON_CreateString(sysdata::getInstance()->mSpeakerDspMapInfo[nIndex].mSpeakerEqFreq[i].c_str()));
            cJSON_AddItemToObject(item, "eq_qratio", cJSON_CreateString(sysdata::getInstance()->mSpeakerDspMapInfo[nIndex].mSpeakerEqQratio[i].c_str()));
            cJSON_AddItemToObject(item, "eq_gain", cJSON_CreateString(sysdata::getInstance()->mSpeakerDspMapInfo[nIndex].mSpeakerEqGain[i].c_str()));
            cJSON_AddItemToArray(eq, item);
        }
    }
    cJSON_AddItemToObject(eqInfo, "custom_eq_item", preset);
    cJSON_AddItemToObject(eqInfo, "current_eq_speaker", cJSON_CreateString(index.c_str()));
    cJSON_AddItemToObject(eqInfo, "parametric_eq", eq);

    return SUCESS;
}

S_ret EqPageHandle::getRoomEqSingleInfo(cJSON *eqInfo, string index)
{
    int nIndex = stoi(index);

    if(nIndex < 0 || nIndex >= sysdata::getInstance()->mRoomDspVecInfo.size())
        return FAILED;

    cJSON *eq = cJSON_CreateArray();

    for(int i = 0; i < MAX_EQ_NUM; i++)
    {
        cJSON *item = cJSON_CreateObject();
        cJSON_AddItemToObject(item, "uuid", cJSON_CreateString(sysdata::getInstance()->mRoomDspVecInfo[nIndex].mRoomEqIndex[i].c_str()));
        cJSON_AddItemToObject(item, "eq_enable", cJSON_CreateString(sysdata::getInstance()->mRoomDspVecInfo[nIndex].mRoomEqEnable[i].c_str()));
        cJSON_AddItemToObject(item, "eq_freq", cJSON_CreateString(sysdata::getInstance()->mRoomDspVecInfo[nIndex].mRoomEqFreq[i].c_str()));
        cJSON_AddItemToObject(item, "eq_qratio", cJSON_CreateString(sysdata::getInstance()->mRoomDspVecInfo[nIndex].mRoomEqQratio[i].c_str()));
        cJSON_AddItemToObject(item, "eq_gain", cJSON_CreateString(sysdata::getInstance()->mRoomDspVecInfo[nIndex].mRoomEqGain[i].c_str()));
        cJSON_AddItemToArray(eq, item);
    }

    cJSON_AddItemToObject(eqInfo, "current_eq_room", cJSON_CreateString(index.c_str()));
    cJSON_AddItemToObject(eqInfo, "parametric_eq", eq);
    // add output_lock
    cJSON_AddItemToObject(eqInfo, "output_lock", cJSON_CreateString(sysdata::getInstance()->mOutputDspInfo[stoi(mCurrentDspOutputIndex)].mOutputLock.c_str()));

    return SUCESS;
}

S_ret EqPageHandle::setEqPageInfo(cJSON *root, cJSON *retJson)
{
    cJSON *items = cJSON_GetObjectItem(root,"changed_item");
    if(NULL ==items)
        return FAILED;

    int sizes = cJSON_GetArraySize(items);
    if(sizes > 0)
    {
        cJSON *itemRoot = cJSON_GetObjectItem(root,"items");

        for(int i = 0; i < sizes; i++)
        {
            char *itemV = cJSON_GetArrayItem(items, i)->valuestring;
            LOGOUT("KEY: %s, %d", itemV, s_mapConfigStrVal[itemV]);
            switch (s_mapConfigStrVal[itemV])
            {
            case evDspOutputIndex:
            {
                cJSON *tItem = cJSON_GetObjectItem(itemRoot, itemV);
                string val = tItem->valuestring;

                if(stoi(val) < 0 || stoi(val) >= CHANNELS)
                {
                    DEBUG_LOG("index out of range");
                    break;
                }
                mCurrentDspOutputIndex = val;

                mCurrentRoomEqIndex = sysdata::getInstance()->mOutputDspInfo[stoi(val)].mOutputRoomDspPreset;
                mCurrentSpeakerEqIndex = sysdata::getInstance()->mOutputDspInfo[stoi(val)].mOutputSpeakerDspPreset;
                mCurrentCustomSpeakerEqIndex = "1";
                if(stoi(val) > 0 || stoi(val) < CHANNELS){
                    mCurrentSubOutputIndex = to_string(stoi(val)+1);
                }

                break;
            }
            case evDspOutputLock:
            {
                cJSON *tItem = cJSON_GetObjectItem(itemRoot, itemV);
                string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                setOutputRoomEQLock(stoi(id), v);
                break;
            }
            case evDspLoudnessEn:
            {
                cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                setDspLoudnessEn(stoi(id),v);

                //                    vector<int> getIndex(1,stoi(id));
                //                    getDspLoudnessEn(NULL,getIndex,true);
                break;
            }
            case evDspToneBass:
            {
                cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                setOutputToneBass(stoi(id),v);

                //vector<int> getIndex(1,stoi(id));
                //getInputSetting(NULL,getIndex,true);
                break;
            }
            case evDspToneTreble:
            {
                cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                setOutputToneTreble(stoi(id),v);

                //vector<int> getIndex(1,stoi(id));
                //getInputSetting(NULL,getIndex,true);
                break;
            }
            case evDspToneBassEN:
            {
                cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                setOutputToneBassEN(stoi(id),v);

                //vector<int> getIndex(1,stoi(id));
                //getInputSetting(NULL,getIndex,true);
                break;
            }
            case evDspToneBassFreq:
            {
                cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                setOutputToneBassFreq(stoi(id),v);

                //vector<int> getIndex(1,stoi(id));
                //getInputSetting(NULL,getIndex,true);
                break;
            }
            case evDspToneBassQ:
            {
                cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                setOutputToneBassQ(stoi(id),v);

                //vector<int> getIndex(1,stoi(id));
                //getInputSetting(NULL,getIndex,true);
                break;
            }
            case evDspToneTrebleEN:
            {
                cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                setOutputToneTrebleEN(stoi(id),v);

                //vector<int> getIndex(1,stoi(id));
                //getInputSetting(NULL,getIndex,true);
                break;
            }
            case evDspToneTrebleFreq:
            {
                cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                setOutputToneTrebleFreq(stoi(id),v);

                //vector<int> getIndex(1,stoi(id));
                //getInputSetting(NULL,getIndex,true);
                break;
            }
            case evDspToneTrebleQ:
            {
                cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                setOutputToneTrebleQ(stoi(id),v);

                //vector<int> getIndex(1,stoi(id));
                //getInputSetting(NULL,getIndex,true);
                break;
            }
            case evSubOutputIndex:
            {
                cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                string val = tItem->valuestring;

                if(stoi(val) < 0 || stoi(val) >= CHANNELS)
                {
                    DEBUG_LOG("sub index out of range");
                    break;
                }
                mCurrentSubOutputIndex = val;
                break;
            }
            case evSubEnable:
            {
                cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                mCurrentSubOutputIndex = id;
                setSubEnable(stoi(id),v);

                //vector<int> getIndex(1,stoi(id));
                //getOutputSetting(NULL,getIndex,true);
                break;
            }
            case evSubVolOffset:
            {
                cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                mCurrentSubOutputIndex = id;
                setSubVolOffset(stoi(id),v);

                //vector<int> getIndex(1,stoi(id));
                //getOutputSetting(NULL,getIndex,true);
                break;
            }
            case evCrossoverType:
            {
                cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                mCurrentSubOutputIndex = id;
                setSubCrossoverType(stoi(id),v);

                break;
            }
            case evCrossoverSlop:
            {
                cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                mCurrentSubOutputIndex = id;
                setSubCrossoverSlop(stoi(id),v);

                break;
            }
            case evCrossoverFreq:
            {
                cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                mCurrentSubOutputIndex = id;
                setSubCrossoverFreq(stoi(id),v);

                break;
            }
            case evEqRoomIndex:
            {
                cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                string v = cJSON_GetObjectItem(tItem,"value")->valuestring;

                if(stoi(v) < 0 || stoi(v) >= sysdata::getInstance()->mRoomDspVecInfo.size())
                {
                    DEBUG_LOG("room dsp index out of range");
                    break;
                }
                mCurrentRoomEqIndex = v;
                setOutputRoomDspPreset(stoi(id),v);

                //vector<int> getIndex(1,stoi(id));
                //getOutputSetting(NULL,getIndex,true);
                break;
            }
            case evEqSpeakerIndex:
            {
                cJSON *tItem = cJSON_GetObjectItem(itemRoot,itemV);
                string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                string v = cJSON_GetObjectItem(tItem,"value")->valuestring;

                if(stoull(v) < 0)
                {
                    DEBUG_LOG("speaker dsp index out of range");
                    break;
                }
                mCurrentSpeakerEqIndex = v;
                setOutputSpeakerDspPreset(stoi(id),v);

                break;
            }
            case evEqEnable:
            {
                cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                string uuid = cJSON_GetObjectItem(tItem,"uuid")->valuestring;
                string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                setEqEnable(stoi(id), uuid, v);

                break;
            }
            case evEqFreq:
            {
                cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                string uuid = cJSON_GetObjectItem(tItem,"uuid")->valuestring;
                string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                setEqFreq(stoi(id), uuid, v);

                break;
            }
            case evEqQratio:
            {
                cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                string uuid = cJSON_GetObjectItem(tItem,"uuid")->valuestring;
                string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                setEqQratio(stoi(id), uuid, v);

                break;
            }
            case evEqGain:
            {
                cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                string uuid = cJSON_GetObjectItem(tItem,"uuid")->valuestring;
                string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                setEqGain(stoi(id), uuid, v);

                break;
            }
            case evEqImportAll:
            {
                cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                string fileName = cJSON_GetObjectItem(tItem, "value")->valuestring;
                string md5 = cJSON_GetObjectItem(tItem,"md5")->valuestring;
                string type = cJSON_GetObjectItem(tItem, "type")->valuestring;
                bool room = true;
                if("1" == type)
                {
                    room = false;
                }
                int ret = eqImportAllHandleFun(fileName,md5,room);
                if(ret == IMPORT_FILE_NOT_EXIST)
                {
                    cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(600));
                }
                else if((ret == IMPORT_MD5_FILE_ERROR) || (ret == IMPORT_MD5_STRING_ERROR))
                {
                    cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(601));
                }
                else if(ret == IMPORT_TYPE_ERROR)
                {
                    cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(602));
                }
                else if( SUCESS == ret)
                {
                    //TODO
                    //if(SystemControl::getInstance()->getHardwareRWEnable())
                    //    ConfigPageHandle::getInstance()->initDspPreset();
                    setDspInfo(mCurrentRoomEqIndex, Room_EQ_Type);
                    if(mCurrentSpeakerEqIndex != "1"){
                        setDspInfo(mCurrentSpeakerEqIndex, Speaker_EQ_Type);
                    }
                }

                break;
            }
            case evEqExportAll:
            {
                cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                string type = cJSON_GetObjectItem(tItem, "type")->valuestring;
                bool room = true;
                if("1" == type)
                {
                    room = false;
                }
                string url = eqExportAllHandleFun(room);
                url = url.substr(url.find('/', 1)+1, url.size());
                cJSON_AddItemToObject(retJson, "url", cJSON_CreateString(url.c_str()));

                break;
            }
            case evEqImportSingle:
            {
                cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                string index = cJSON_GetObjectItem(tItem, "index")->valuestring;
                string fileName = cJSON_GetObjectItem(tItem, "value")->valuestring;
                string md5 = cJSON_GetObjectItem(tItem,"md5")->valuestring;
                string type = cJSON_GetObjectItem(tItem, "type")->valuestring;
                bool room = true;
                if("1" == type)
                {
                    room = false;
                }

                int ret = eqImportSingleHandleFun(index, fileName, md5,room);
                if(ret == IMPORT_FILE_NOT_EXIST)
                {
                    cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(600));
                }
                else if((ret == IMPORT_MD5_FILE_ERROR) || (ret == IMPORT_MD5_STRING_ERROR))
                {
                    cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(601));
                }
                else if(ret == IMPORT_TYPE_ERROR)
                {
                    cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(602));
                }
                else if(ret == SUCESS)
                {
                    //TODO
                    setDspInfo(mCurrentRoomEqIndex, Room_EQ_Type);
                    if(mCurrentSpeakerEqIndex != "1"){
                        setDspInfo(mCurrentSpeakerEqIndex, Speaker_EQ_Type);
                    }
                }

                break;
            }
            case evEqExportSingle:
            {
                cJSON *tItem = cJSON_GetObjectItem(itemRoot,itemV);
                string index = cJSON_GetObjectItem(tItem, "index")->valuestring;
                string type = cJSON_GetObjectItem(tItem, "type")->valuestring;
                bool room = true;
                if("1" == type)
                {
                    room = false;
                }
                string url = eqExportSingleHandleFun(index,room);
                if(url.empty())
                {
                    cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(401));
                }else
                {
                    url = url.substr(url.find('/',1)+1,url.size());
                    cJSON_AddItemToObject(retJson, "url", cJSON_CreateString(url.c_str()));
                }

                break;
            }
            case evEqCopyDsp:
            {
                cJSON *tItem = cJSON_GetObjectItem(itemRoot,itemV);
                string from = cJSON_GetObjectItem(tItem, "from")->valuestring;
                string to = cJSON_GetObjectItem(tItem,"to")->valuestring;
                string type = cJSON_GetObjectItem(tItem,"type")->valuestring;
                bool room = true;
                if("1" == type)
                {
                    room = false;
                }
                setCopyDsp(from, to,room);

                break;
            }
            case evEqEditDsp:
            {
                cJSON *tItem = cJSON_GetObjectItem(itemRoot,itemV);
                string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                string v = cJSON_GetObjectItem(tItem,"value")->valuestring;

                //TODO
                //updateDataBaseTable(DSPPRESET_DB_TABLE,"dsp_preset_item",v,id);
                sysdata::getInstance()->mRoomDspVecInfo[stoi(id)].mRoomDspName = v;
                sysdata::getInstance()->updateDataBaseTable("t_room_Dsp_Preset_Info", "room_dsp_preset_name", v, id);
                break;
            }
            case evEqResetDsp:
            {
                cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                string id = cJSON_GetObjectItem(tItem, "index")->valuestring;

                //TODO
                //resetDspPresetDbTable(id);

                break;
            }
            case evEqCustomIndex:
            {
                cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                string v = tItem->valuestring;
                mCurrentCustomSpeakerEqIndex = v;

                break;
            }
            case evSpeakerEqEnable:
            {
                cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                string uuid = cJSON_GetObjectItem(tItem,"uuid")->valuestring;
                string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                setSpeakerEqEnable(stoi(id), uuid, v);

                break;
            }
            case evSpeakerEqFreq:
            {
                cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                string uuid = cJSON_GetObjectItem(tItem,"uuid")->valuestring;
                string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                setSpeakerEqFreq(stoi(id), uuid, v);

                break;
            }
            case evSpeakerEqQratio:
            {
                cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                string uuid = cJSON_GetObjectItem(tItem,"uuid")->valuestring;
                string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                setSpeakerEqQratio(stoi(id), uuid, v);

                break;
            }
            case evSpeakerEqGain:
            {
                cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                string uuid = cJSON_GetObjectItem(tItem,"uuid")->valuestring;
                string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                setSpeakerEqGain(stoi(id), uuid, v);

                break;
            }
            case evEqSavePreset:
            {
                cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                string id = cJSON_GetObjectItem(tItem, "index")->valuestring;

                _speakerDspPresetItemInfo tmp;
                tmp.mSpeakerDspIndex = id;
                tmp.mSpeakerDspName = cJSON_GetObjectItem(tItem, "presetName")->valuestring;
                cJSON *eqItems = cJSON_GetObjectItem(tItem,"parametric_eq");
                int size =  cJSON_GetArraySize(eqItems);
                for(int i = 0 ; i < size; i++)
                {
                    cJSON *t = cJSON_GetArrayItem(eqItems, i);
                    tmp.mSpeakerEqIndex[i] = cJSON_GetObjectItem(t,"uuid")->valuestring;
                    tmp.mSpeakerEqEnable[i] = cJSON_GetObjectItem(t,"eq_enable")->valuestring;
                    tmp.mSpeakerEqFreq[i] = cJSON_GetObjectItem(t,"eq_freq")->valuestring;
                    tmp.mSpeakerEqQratio[i] = cJSON_GetObjectItem(t,"eq_qratio")->valuestring;
                    tmp.mSpeakerEqGain[i] = cJSON_GetObjectItem(t,"eq_gain")->valuestring;
                }

                if("1" == id)
                {
                    SPEAKER_PRESET_MAP::iterator it = sysdata::getInstance()->mSpeakerDspMapInfo.end();
                    it--;
                    tmp.mSpeakerDspIndex = to_string(it->first+1);
                    sysdata::getInstance()->mSpeakerDspMapInfo[stoull(tmp.mSpeakerDspIndex)] = tmp;
                    sysdata::getInstance()->insertSpeakerPresetInfoTable();
                }
                else
                {
                    sysdata::getInstance()->mSpeakerDspMapInfo[stoull(tmp.mSpeakerDspIndex)] = tmp;
                    sysdata::getInstance()->updateDataBasePresetInfoTable(tmp.mSpeakerDspIndex,false);
                    setDspInfo(tmp.mSpeakerDspIndex, Speaker_EQ_Type);
                }

                break;
            }
            case evEqDelPreset:
            {
                string v = cJSON_GetObjectItem(itemRoot, itemV)->valuestring;

                sysdata::getInstance()->deleteSpeakerPresetInfoTable(v);
                mCurrentCustomSpeakerEqIndex = "1";
                if(mCurrentSpeakerEqIndex == v)
                {
                    mCurrentSpeakerEqIndex = "2";
                    sysdata::getInstance()->mOutputDspInfo[stoi(mCurrentDspOutputIndex)].mOutputSpeakerDspPreset = mCurrentSpeakerEqIndex;
//                    setDspInfo(mCurrentSpeakerEqIndex, Speaker_EQ_Type);
                    setDspInfo(mCurrentSpeakerEqIndex, Speaker_EQ_Type);
                }

                break;
            }

            default:
                DEBUG_LOG("unknow data...");
                break;
            }
        }
    }

    getEqConfigureAll(retJson);
    return SUCESS;
}


#endif
