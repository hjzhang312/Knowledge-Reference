#include "inoutputhandle.h"

#include "sysdata.h"
#include "log.h"
#include "wshandle.h"
#define InOutputNameLength 15

InOutPutHandle::InOutPutHandle()
{

}

S_ret InOutPutHandle::setInOutPutPageInfo(cJSON *root, cJSON *retJson)
{

    cJSON *items = cJSON_GetObjectItem(root,"changed_item");
    if(NULL ==items)
        return -1;
    int sizes = cJSON_GetArraySize(items);
    if(sizes > 0)
    {
        cJSON *itemRoot = cJSON_GetObjectItem(root,"items");

        for(int i = 0; i < sizes; i++)
        {
            char *itemV = cJSON_GetArrayItem(items,i)->valuestring;
            //LOGOUT("KEY: %s, %d", itemV, s_mapConfigStrVal[itemV]);
            switch (s_mapConfigStrVal[itemV])
            {
                case evInputName:
                {
                    cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                    string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                    string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                    v[0] = toupper(v[0]);
                    if(v.length() > InOutputNameLength){
                        v = v.substr(0, InOutputNameLength);
                    }
                    setInputName(stoi(id),v);

                    vector<int> getIndex(1,stoi(id));
                    getInputSetting(NULL,getIndex,true);
                    break;
                }
                case evInputGain:
                {
                    cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                    string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                    string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                    setInputGainVol(stoi(id),v);

                    vector<int> getIndex(1,stoi(id));
                    getInputSetting(NULL,getIndex,true);
                    break;
                }
                case evInputDelay:
                {
                    cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                    string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                    string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                    setInputDelay(stoi(id),v);

                    vector<int> getIndex(1,stoi(id));
                    getInputSetting(NULL,getIndex,true);
                    break;
                }
                case evInputAudioSence:
                {
                    cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                    string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                    string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                    setInputAudioSense(stoi(id),v);

                    vector<int> getIndex(1,stoi(id));
                    getInputSetting(NULL,getIndex,true);
                    break;
                }

                case evOutputName:
                {
                    cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                    string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                    string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                    v[0] = toupper(v[0]);
                    if(v.length() > InOutputNameLength){
                        v = v.substr(0, InOutputNameLength);
                    }
                    setOutputName(stoi(id),v);

                    vector<int> getIndex(1,stoi(id));
                    getOutputSetting(NULL,getIndex,true);
                    break;
                }

                case evOutputSource:
                {
                    cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                    string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                    string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                    setOutputSource(stoi(id),v);

                    vector<int> getIndex(1,stoi(id));
                    getOutputSetting(NULL,getIndex,true);
                    break;
                }
                case evOutputDelay:
                {
                    cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                    string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                    string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                    setOutputDelay(stoi(id),v);

                    vector<int> getIndex(1,stoi(id));
                    getOutputSetting(NULL,getIndex,true);
                    break;
                }
                case evOutputStereo:
                {
                    cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                    string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                    string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                    setOutputStereo(stoi(id),v);

                    vector<int> getIndex(1,stoi(id));
                    getOutputSetting(NULL,getIndex,true);
                    break;
                }
                case evOutputMute:
                {
                    cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                    string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                    string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                    setOutputMute(stoi(id),v);

                    vector<int> getIndex(1,stoi(id));
                    getOutputSetting(NULL,getIndex,true);
                    break;
                }
                case evOutputVol:
                {
                    cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                    string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                    string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                    setOutputVol(stoi(id),v);

                    vector<int> getIndex(1,stoi(id));
                    getOutputSetting(NULL,getIndex,true);
                    break;
                }
                case evOutputMaxVol:
                {
                    cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                    string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                    string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                    setOutputMaxVol(stoi(id),v);

                    vector<int> getIndex(1,stoi(id));
                    getOutputSetting(NULL,getIndex,true);
                    break;
                }
                case evOutputBalance:
                {
                    cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                    string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                    string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                    setOutputBalance(stoi(id),v);

                    vector<int> getIndex(1,stoi(id));
                    getOutputSetting(NULL,getIndex,true);
                    break;
                }
                case evOutputAssignTrigger:
                {
                    cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                    string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                    string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                    setOutputAssignTrigger(stoi(id),v);

                    vector<int> getIndex(1,stoi(id));
                    getOutputSetting(NULL,getIndex,true);
                    break;
                }
                case evOutputTestSignal:
                {
                    cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                    string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                    string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                    sysdata::getInstance()->TestSignal(stoi(id), stoi(v));
                    sysdata::getInstance()->ExeSet();
                    break;
                }
                case evOutputTestSignalVolume:
                {
                    cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                    string id = cJSON_GetObjectItem(tItem, "index")->valuestring;
                    string v = cJSON_GetObjectItem(tItem,"value")->valuestring;
                    float nVal = stof(v);
                    if(-24 > nVal){
                        nVal = -24;
                    }else if(0 < nVal) {
                        nVal = 0;
                    }
                    int signalVolume = (nVal+24)*2;
                    sysdata::getInstance()->SetOscGain(stoi(id),signalVolume);
                    sysdata::getInstance()->ExeSet();
                    break;
                }


            default:
                DEBUG_LOG("unknow data...");
                break;
            }
        }
    }

    getInOutPutPageInfo(retJson);
    return SUCESS;
}

void InOutPutHandle::getInOutPutPageInfo(cJSON *retJson)
{
    char str[16] = { 0 };
    cJSON *settingInfo =  cJSON_CreateObject();
    cJSON *inPutInfo = cJSON_CreateObject();
    cJSON *outPutinfo = cJSON_CreateObject();

    cJSON *inName = cJSON_CreateArray();
    cJSON *inGainRange = cJSON_CreateArray();
    cJSON *inGain = cJSON_CreateArray();
    cJSON *inDelayRange = cJSON_CreateArray();
    cJSON *inDelay = cJSON_CreateArray();
    cJSON *inAudioSense = cJSON_CreateArray();

    cJSON *outName = cJSON_CreateArray();
    cJSON *outSource = cJSON_CreateArray();
    cJSON *outDealyRange = cJSON_CreateArray();
    cJSON *outDelay = cJSON_CreateArray();
    cJSON *outStereoEnable = cJSON_CreateArray();
    cJSON *outMute = cJSON_CreateArray();
    cJSON *outVolRange = cJSON_CreateArray();
    cJSON *outVol = cJSON_CreateArray();
    cJSON *outMaxVolRange = cJSON_CreateArray();
    cJSON *outMaxVol = cJSON_CreateArray();
    cJSON *outBalanceRange = cJSON_CreateArray();
    cJSON *outBalance = cJSON_CreateArray();
    cJSON *outAssignTrigger = cJSON_CreateArray();
    cJSON *testSignal = cJSON_CreateArray();
    cJSON *testSignalVolume = cJSON_CreateArray();
    cJSON *outPutSubSelect = cJSON_CreateArray();
    cJSON *outPutSubSelectEnable = cJSON_CreateArray();

    //default range and item
    for(int i = 0; i < m_inputGainRange.size(); i++)
    {
        cJSON_AddItemToArray(inGainRange, cJSON_CreateString(m_inputGainRange.at(i).c_str()));
    }

    for(int i = 0; i < m_inputDelayRange.size(); i++)
    {
        cJSON_AddItemToArray(inDelayRange, cJSON_CreateString(m_inputDelayRange.at(i).c_str()));
    }

    for(int i = 0; i < m_outputDelayRange.size(); i++)
    {
        cJSON_AddItemToArray(outDealyRange, cJSON_CreateString(m_outputDelayRange.at(i).c_str()));
    }

//    for(int i = 0; i < m_outputVolRange.size(); i++)
//    {
//        cJSON_AddItemToArray(outVolRange, cJSON_CreateString(m_outputVolRange.at(i).c_str()));
//    }

    for(int i = 0; i < m_outputMaxVolRange.size(); i++)
    {
        cJSON_AddItemToArray(outMaxVolRange, cJSON_CreateString(m_outputMaxVolRange.at(i).c_str()));
    }

    for(int i = 0; i < m_outputBalanceRange.size(); i++)
    {
        cJSON_AddItemToArray(outBalanceRange, cJSON_CreateString(m_outputBalanceRange.at(i).c_str()));
    }

    //real parameter
    for(int i = 0; i < CHANNELS; i++)
    {
        //input
        cJSON_AddItemToArray(inName, cJSON_CreateString(sysdata::getInstance()->mWebInfo.inputname[i].c_str()));
        float fVol = sysdata::getInstance()->dspdata[i].dsp[ENUM_Inputvolume] / 2.0 - 12;
        snprintf(str, 16, "%.1f", fVol);
        cJSON_AddItemToArray(inGain, cJSON_CreateString(str));
        cJSON_AddItemToArray(inDelay, cJSON_CreateString(std::to_string(sysdata::getInstance()->dspdata[i].dsp[ENUM_Inputdelay]).c_str()));
        cJSON_AddItemToArray(inAudioSense, cJSON_CreateString(std::to_string(((sysdata::getInstance()->devicedata.audiosens & (0x01<<i)) >> i)).c_str()));

        //ouput
        cJSON_AddItemToArray(outName, cJSON_CreateString(sysdata::getInstance()->mWebInfo.outputname[i].c_str()));
        cJSON_AddItemToArray(outSource, cJSON_CreateString(std::to_string(sysdata::getInstance()->dspdata[i].dsp[ENUM_Outputsource]).c_str()));
        cJSON_AddItemToArray(outDelay, cJSON_CreateString(std::to_string(sysdata::getInstance()->dspdata[i].dsp[ENUM_outputdelay]).c_str()));

        int stereoIndex = sysdata::getInstance()->dspdata[i].dsp[ENUM_merge];
        if(stereoIndex != Switch_stereo)
        {
            stereoIndex = 0;
        }

        int testSignalToggle = sysdata::getInstance()->dspdata[i].dsp[ENUM_merge];
        if(testSignalToggle == Switch_test)
        {
            testSignalToggle = 1;
        }
        else
        {
            testSignalToggle = 0;
        }

        int signalVolume = sysdata::getInstance()->dspdata[i].dsp[ENUM_oscgain];
        float FsignalVolume = -24 + 0.5*(signalVolume);
        char signalVolume_s[12] = {0};
        sprintf(signalVolume_s,"%.1f",FsignalVolume);

        cJSON_AddItemToArray(testSignal, cJSON_CreateString(std::to_string(testSignalToggle).c_str()));
        cJSON_AddItemToArray(testSignalVolume, cJSON_CreateString(signalVolume_s));
        cJSON_AddItemToArray(outStereoEnable, cJSON_CreateString(std::to_string(stereoIndex).c_str()));
        cJSON_AddItemToArray(outMute, cJSON_CreateString(std::to_string(sysdata::getInstance()->dspdata[i].dsp[ENUM_dspmute]).c_str()));
        cJSON_AddItemToArray(outVol, cJSON_CreateString(std::to_string(sysdata::getInstance()->dspdata[i].dsp[ENUM_volume]).c_str()));
        cJSON_AddItemToArray(outMaxVol, cJSON_CreateString(std::to_string(sysdata::getInstance()->dspdata[i].dsp[ENUM_maxvolume]).c_str()));

        float fBalance = sysdata::getInstance()->dspdata[i].dsp[ENUM_balance] / 2.0 - 12;
        snprintf(str, 16, "%.1f", fBalance);
        cJSON_AddItemToArray(outBalance, cJSON_CreateString(str));
        cJSON_AddItemToArray(outAssignTrigger, cJSON_CreateString(sysdata::getInstance()->mWebInfo.assigntrigger[i].c_str()));
    }

    for(int i = 1; i < CHANNELS; i = i + 2)
    {
        cJSON_AddItemToArray(outPutSubSelect, cJSON_CreateString(to_string(i).c_str()));
        cJSON_AddItemToArray(outPutSubSelectEnable, cJSON_CreateString(sysdata::getInstance()->mSubDspInfo[i].mSubDspEnable.c_str()));
    }

    cJSON_AddItemToObject(inPutInfo, "input_name", inName);
    cJSON_AddItemToObject(inPutInfo, "input_gain_range", inGainRange);
    cJSON_AddItemToObject(inPutInfo, "input_gain", inGain);
    cJSON_AddItemToObject(inPutInfo, "input_delay_range", inDelayRange);
    cJSON_AddItemToObject(inPutInfo, "input_delay", inDelay);
    cJSON_AddItemToObject(inPutInfo, "signal_sense_enable", inAudioSense);

    cJSON_AddItemToObject(outPutinfo, "output_name", outName);
    cJSON_AddItemToObject(outPutinfo, "output_source", outSource);
    cJSON_AddItemToObject(outPutinfo, "output_delay_range", outDealyRange);
    cJSON_AddItemToObject(outPutinfo, "output_delay", outDelay);
    cJSON_AddItemToObject(outPutinfo, "stereo_enable", outStereoEnable);
    cJSON_AddItemToObject(outPutinfo, "output_mute", outMute);
    cJSON_AddItemToObject(outPutinfo, "output_volume_range", outVolRange);
    cJSON_AddItemToObject(outPutinfo, "output_volume", outVol);
    cJSON_AddItemToObject(outPutinfo, "output_max_volume_range", outMaxVolRange);
    cJSON_AddItemToObject(outPutinfo, "output_max_volume", outMaxVol);
    cJSON_AddItemToObject(outPutinfo, "output_balance_range", outBalanceRange);
    cJSON_AddItemToObject(outPutinfo, "output_balance", outBalance);
    cJSON_AddItemToObject(outPutinfo, "assign_trigger", outAssignTrigger);
    cJSON_AddItemToObject(outPutinfo, "sub_output", outPutSubSelect);
    cJSON_AddItemToObject(outPutinfo, "sub_enable", outPutSubSelectEnable);

    cJSON_AddItemToObject(outPutinfo, "test_signal", testSignal);
    cJSON_AddItemToObject(outPutinfo, "test_signal_volume", testSignalVolume);

    cJSON_AddItemToObject(settingInfo, "inputInfo", inPutInfo);
    cJSON_AddItemToObject(settingInfo, "outputInfo", outPutinfo);

    cJSON_AddItemToObject(retJson, "deviceName", cJSON_CreateString(sysdata::getInstance()->deviceinfo.devicename.c_str()));
    cJSON_AddItemToObject(retJson, "settingInfo", settingInfo);
}

