#ifndef LOG_H
#define LOG_H

//#define LOG_ENABLE

#include <stdio.h>
#include <time.h>
#include <string.h>
#include <stdarg.h>

void DEBUG_LOG(const char *msg, ...);

class Log {
private:
    Log();
    ~Log();
    void create_log_file();
public:
    static Log *log();
    void write_log(const char *msg);
private:
    static Log *m_log;
    time_t tim;
    struct tm *t;
    FILE *fp;
    char filepath[32];
};
#endif // LOG_H
