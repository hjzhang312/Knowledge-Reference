#include "comhandleapi.h"
#include "sysdata.h"
#include <sstream>
#include "log.h"

#include "tools.h"
//#include "apicontrol.h"

#define bind(a,b,c)  ((a)[(b)] = (c))

subject &subject::GetInstance()
{
    static subject s;
    return s;
}

void subject::Attach(observer *listener)
{
    this->listener = listener;
}

void subject::Notify(OvrcUpdate info)
{
    if (listener != nullptr) {
        listener->ovrcUpdate(info);
    }
}

ComHandleApi::ComHandleApi()
{
    mIPChange = -1;

    //default
    m_inputGainRange = {"-12","12"};
    m_inputDelayRange = {"0", "80"};

    m_outputDelayRange = {"0", "80"};
    m_outputVolRange = {"0", "100"};
    m_outputMaxVolRange = {"0", "100"};
    m_outputBalanceRange = {"-12", "12"};

    m_dspToneBassRange = {"-12", "12"};
    m_dspToneTrebleRange = {"-12", "12"};
    m_SubVolOffsetRange = {"-12", "12"};
    m_CrossoverFreqRange = {"20", "20000"};
    m_CrossoverTypeItem = {"Butterworth", "Linkwitz-Riley"};
    m_CrossoverSlopItem = {"12dB", "24dB", "48dB"};

    mCurrentDspOutputIndex = "0";
    mCurrentSubOutputIndex = "1";
    mCurrentRoomEqIndex = sysdata::getInstance()->mOutputDspInfo[stoi(mCurrentDspOutputIndex)].mOutputRoomDspPreset;
    mCurrentSpeakerEqIndex = sysdata::getInstance()->mOutputDspInfo[stoi(mCurrentDspOutputIndex)].mOutputSpeakerDspPreset;
    mCurrentCustomSpeakerEqIndex = "1";

    //bind
    bind(s_mapConfigStrVal, "deviceName",           evDeviceName);
    bind(s_mapConfigStrVal, "backup",               evBackUp);
    bind(s_mapConfigStrVal, "restore",              evRestore);

    bind(s_mapConfigStrVal, "dhcp_enable",          evDhcpEnabled);
    bind(s_mapConfigStrVal, "ipAddress",            evIpAddress);
    bind(s_mapConfigStrVal, "gateway",              evGateWay);
    bind(s_mapConfigStrVal, "subnetMask",           evSubnetMask);
    bind(s_mapConfigStrVal, "dnsServer",            evDnsServer);
    bind(s_mapConfigStrVal, "username",             evUserName);
    bind(s_mapConfigStrVal, "password",             evPasswd);
    bind(s_mapConfigStrVal, "sshEnable",            evSshEnable);

    bind(s_mapConfigStrVal, "input_name",           evInputName);
    bind(s_mapConfigStrVal, "input_gain",           evInputGain);
    bind(s_mapConfigStrVal, "input_delay",          evInputDelay);
    bind(s_mapConfigStrVal, "signal_sense_enable",  evInputAudioSence);

    bind(s_mapConfigStrVal, "output_name",          evOutputName);
    bind(s_mapConfigStrVal, "output_source",        evOutputSource);
    bind(s_mapConfigStrVal, "output_delay",         evOutputDelay);
    bind(s_mapConfigStrVal, "stereo_enable",        evOutputStereo);
    bind(s_mapConfigStrVal, "output_mute",          evOutputMute);
    bind(s_mapConfigStrVal, "output_volume",        evOutputVol);
    bind(s_mapConfigStrVal, "output_max_volume",    evOutputMaxVol);
    bind(s_mapConfigStrVal, "output_balance",       evOutputBalance);
    bind(s_mapConfigStrVal, "assign_trigger",       evOutputAssignTrigger);
    bind(s_mapConfigStrVal, "test_signal",          evOutputTestSignal);
    bind(s_mapConfigStrVal, "test_signal_volume",   evOutputTestSignalVolume);

    //dsp settings
    bind(s_mapConfigStrVal, "output_index",         evDspOutputIndex);
    bind(s_mapConfigStrVal, "tone_bass",            evDspToneBass);
    bind(s_mapConfigStrVal, "tone_treble",          evDspToneTreble);
    bind(s_mapConfigStrVal, "tone_loudness_enable", evDspLoudnessEn);
    bind(s_mapConfigStrVal, "tone_bass_enable",     evDspToneBassEN);
    bind(s_mapConfigStrVal, "tone_bass_freq",       evDspToneBassFreq);
    bind(s_mapConfigStrVal, "tone_bass_q",          evDspToneBassQ);
    bind(s_mapConfigStrVal, "tone_treble_enable",   evDspToneTrebleEN);
    bind(s_mapConfigStrVal, "tone_treble_freq",     evDspToneTrebleFreq);
    bind(s_mapConfigStrVal, "tone_treble_q",        evDspToneTrebleQ);
    // output lock
    bind(s_mapConfigStrVal, "output_lock",          evDspOutputLock);

    bind(s_mapConfigStrVal, "sub_enable",           evSubEnable);
    bind(s_mapConfigStrVal, "sub_output_index",     evSubOutputIndex);
    bind(s_mapConfigStrVal, "sub_volume_offset",    evSubVolOffset);
    bind(s_mapConfigStrVal, "crossover_type",       evCrossoverType);
    bind(s_mapConfigStrVal, "crossover_slop",       evCrossoverSlop);
    bind(s_mapConfigStrVal, "crossover_freq",       evCrossoverFreq);

    bind(s_mapConfigStrVal, "import_all",           evEqImportAll);
    bind(s_mapConfigStrVal, "export_all",           evEqExportAll);
    bind(s_mapConfigStrVal, "import_single",        evEqImportSingle);
    bind(s_mapConfigStrVal, "export_single",        evEqExportSingle);
    bind(s_mapConfigStrVal, "copy_dsp",             evEqCopyDsp);
    bind(s_mapConfigStrVal, "edit_dsp_name",        evEqEditDsp);
    bind(s_mapConfigStrVal, "reset_dsp",            evEqResetDsp);

    bind(s_mapConfigStrVal, "room_dsp_preset",      evEqRoomIndex);
    bind(s_mapConfigStrVal, "speaker_dsp_preset",   evEqSpeakerIndex);
    bind(s_mapConfigStrVal, "eq_enable",            evEqEnable);
    bind(s_mapConfigStrVal, "eq_freq",              evEqFreq);
    bind(s_mapConfigStrVal, "eq_qratio",            evEqQratio);
    bind(s_mapConfigStrVal, "eq_gain",              evEqGain);

    bind(s_mapConfigStrVal, "custom_preset_index",  evEqCustomIndex);
    bind(s_mapConfigStrVal, "speaker_eq_enable",    evSpeakerEqEnable);
    bind(s_mapConfigStrVal, "speaker_eq_freq",      evSpeakerEqFreq);
    bind(s_mapConfigStrVal, "speaker_eq_qratio",    evSpeakerEqQratio);
    bind(s_mapConfigStrVal, "speaker_eq_gain",      evSpeakerEqGain);
    bind(s_mapConfigStrVal, "add_eq",               evEqAddEq);
    bind(s_mapConfigStrVal, "del_eq",               evEqDelEq);
    bind(s_mapConfigStrVal, "save_preset",          evEqSavePreset);
    bind(s_mapConfigStrVal, "del_preset",           evEqDelPreset);

}

string ComHandleApi::getValueToKey(ConfigureStrValue value)
{
    map<std::string,ConfigureStrValue>::iterator it;
    for(it = s_mapConfigStrVal.begin(); it != s_mapConfigStrVal.end();it++)
    {
        if(it->second == value)
            return it->first;
    }
}

ApiStatus ComHandleApi::setInputName(int index, string value_s)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    if(index < 0 || index >= CHANNELS)
    {
        return ret;
    }

    if(value_s.empty())
    {
        return ret;
    }

    ret = API_STATUS_SUCCESS;

    mMutexLock.lock();
    sysdata::getInstance()->mWebInfo.inputname[index] = value_s;
    sysdata::getInstance()->updateDataBaseTable("webInfoTab", "inputname", value_s, to_string(index));
    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::setInputGainVol(int index, std::string value_s)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    if(!isNum(value_s))
    {
        ret = API_STATUS_ILLEGAL_REQ;
        return ret;
    }

    float fVal = stof(value_s);
    if(index < 0 || index >= CHANNELS)
    {
        return ret;
    }

    int minV = stoi(m_inputGainRange.at(0));
    int maxV = stoi(m_inputGainRange.at(1));

    if(fVal < minV)
    {
        return ret;
    }
    else if(fVal > maxV)
    {
        return ret;
    }

    ret = API_STATUS_SUCCESS;
    mMutexLock.lock();
    LOGOUT("setInputGainVol: %d, %f", index, fVal);
    //sysdata::getInstance()->dspdata.inputvolume[index] = vol;
    fVal = (fVal + 12) * 2;
    sysdata::getInstance()->SetinputVolme(index, (unsigned int)fVal);
    sysdata::getInstance()->ExeSet();

    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::setInputDelay(int index, std::string value_s)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    if(!isNum(value_s))
    {
        ret = API_STATUS_ILLEGAL_REQ;
        return ret;
    }

    if(index < 0 || index >= CHANNELS)
    {
        return ret;
    }

    int minV = stoi(m_inputDelayRange.at(0));
    int maxV = stoi(m_inputDelayRange.at(1));

    int delay = stoi(value_s);
    if(delay < minV)
    {
        return ret;
    }
    else if(delay > maxV)
    {
        return ret;
    }

    ret = API_STATUS_SUCCESS;
    mMutexLock.lock();
    sysdata::getInstance()->Setinputdelay(index, delay);
    sysdata::getInstance()->ExeSet();

    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::setInputAudioSense(int index, std::string enable_s)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    if(!isNum(enable_s))
    {
        ret = API_STATUS_ILLEGAL_REQ;
        return ret;
    }

    if(index < 0 || index >= CHANNELS)
    {
        return ret;
    }

    int en = stoi(enable_s);
    if(en != 0 && en != 1)
    {
        return ret;
    }

    ret = API_STATUS_SUCCESS;
    mMutexLock.lock();
    int v = sysdata::getInstance()->devicedata.audiosens;
    if(0 == en)
    {
        v&= ~(1 << index);
    }
    else
    {
        v |= (en<<index);
    }
    sysdata::getInstance()->SetAutoSense(v);
    sysdata::getInstance()->ExeSet();
    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::setOutputName(int index, string value_s)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    if(index < 0 || index >= CHANNELS)
    {
        return ret;
    }

    if(value_s.empty())
    {
        return ret;
    }

    ret = API_STATUS_SUCCESS;

    mMutexLock.lock();
    sysdata::getInstance()->mWebInfo.outputname[index] = value_s;
    sysdata::getInstance()->updateDataBaseTable("webInfoTab", "outputname", value_s, to_string(index));
    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::setOutputSource(int index, std::string value_s)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    if(!isNum(value_s))
    {
        ret = API_STATUS_ILLEGAL_REQ;
        return ret;
    }

    if(index < 0 || index >= CHANNELS)
    {
        return ret;
    }

    int val = stoi(value_s);
    if(val < 0 || val > CHANNELS)
    {
        return ret;
    }

    ret = API_STATUS_SUCCESS;
    mMutexLock.lock();
    sysdata::getInstance()->Setoutputsource(index, val);
    sysdata::getInstance()->ExeSet();

    mMutexLock.unlock();
}

ApiStatus ComHandleApi::setOutputDelay(int index, std::string value_s)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    if(!isNum(value_s))
    {
        ret = API_STATUS_ILLEGAL_REQ;
        return ret;
    }

    if(index < 0 || index >= CHANNELS)
    {
        return ret;
    }

    int minV = stoi(m_outputDelayRange.at(0));
    int maxV = stoi(m_outputDelayRange.at(1));

    int delay = stoi(value_s);
    if(delay < minV)
    {
        return ret;
    }
    else if(delay > maxV)
    {
        return ret;
    }

    ret = API_STATUS_SUCCESS;
    mMutexLock.lock();
    sysdata::getInstance()->Setoutputdelay(index, delay);
    sysdata::getInstance()->ExeSet();

    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::setOutputStereo(int index, std::string enable_s)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    if(!isNum(enable_s))
    {
        ret = API_STATUS_ILLEGAL_REQ;
        return ret;
    }

    if(index < 0 || index >= CHANNELS)
    {
        return ret;
    }

    int en = stoi(enable_s);
    if(en != 0 && en != 1)
    {
        return ret;
    }

    ret = API_STATUS_SUCCESS;
    mMutexLock.lock();
    //TODO
    //updateDataBaseTable(INPUT_DB_TABLE,sysdata::getInstance()->getValueToKey(evInputGain),to_string(vol),to_string(index));
    if(1 == en)
    {
        //sysdata::getInstance()->dspdata.merge[index] = 1;
        sysdata::getInstance()->Mon(index, Switch_stereo);
    }
    else
    {
        //sysdata::getInstance()->dspdata.merge[index] = 0;
        sysdata::getInstance()->Mon(index, Switch_mono);
    }
    sysdata::getInstance()->ExeSet();

    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::setOutputMute(int index, std::string enable_s)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    if(!isNum(enable_s))
    {
        ret = API_STATUS_ILLEGAL_REQ;
        return ret;
    }

    if(index < 0 || index >= CHANNELS)
    {
        return ret;
    }

    int en = stoi(enable_s);
    if(en != 0 && en != 1)
    {
        return ret;
    }

    ret = API_STATUS_SUCCESS;
    mMutexLock.lock();
    sysdata::getInstance()->SetDspmute(index, en);
    if((CHANNELS-1) > index){
        if(sysdata::getInstance()->mSubDspInfo[index+1].mSubDspEnable == "1"){
            sysdata::getInstance()->SetDspmute(index+1, en);
        }
    }
    sysdata::getInstance()->ExeSet();

    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::setOutputVol(int index, std::string value_s)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    if(!isNum(value_s))
    {
        ret = API_STATUS_ILLEGAL_REQ;
        return ret;
    }

    if(index < 0 || index >= CHANNELS)
    {
        return ret;
    }

    int minV = stoi(m_outputVolRange.at(0));
    int maxV = stoi(m_outputVolRange.at(1));
    maxV = maxV > sysdata::getInstance()->dspdata[index].dsp[ENUM_maxvolume] ?
                maxV : sysdata::getInstance()->dspdata[index].dsp[ENUM_maxvolume];

    int val = stoi(value_s);
    if(val < minV)
    {
        return ret;
    }
    else if(val > maxV)
    {
        return ret;
    }

    ret = API_STATUS_SUCCESS;
    mMutexLock.lock();
    sysdata::getInstance()->Setvolume(index, val);
    sysdata::getInstance()->ExeSet();

    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::setOutputMaxVol(int index, std::string value_s)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    if(!isNum(value_s))
    {
        ret = API_STATUS_ILLEGAL_REQ;
        return ret;
    }

    if(index < 0 || index >= CHANNELS)
    {
        return ret;
    }

    int minV = stoi(m_outputVolRange.at(0));
    int maxV = stoi(m_outputVolRange.at(1));

    int val = stoi(value_s);
    if(val < minV)
    {
        return ret;
    }
    else if(val > maxV)
    {
        return ret;
    }

    ret = API_STATUS_SUCCESS;
    mMutexLock.lock();
    if(val < sysdata::getInstance()->dspdata[index].dsp[ENUM_volume])
    {
        sysdata::getInstance()->Setvolume(index, val);
    }
    sysdata::getInstance()->SetmaxVolume(index, val);
    sysdata::getInstance()->ExeSet();

    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::setOutputBalance(int index, std::string value_s)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    if(!isNum(value_s))
    {
        ret = API_STATUS_ILLEGAL_REQ;
        return ret;
    }

    if(index < 0 || index >= CHANNELS)
    {
        return ret;
    }

    int minV = stoi(m_outputBalanceRange.at(0));
    int maxV = stoi(m_outputBalanceRange.at(1));

    float fVal = stof(value_s);
    if(fVal < minV)
    {
        return ret;
    }
    else if(fVal > maxV)
    {
        return ret;
    }

    ret = API_STATUS_SUCCESS;
    mMutexLock.lock();
    LOGOUT("=============%s, %f ==============", value_s.c_str(), fVal);
    fVal = (fVal + 12) * 2;
    sysdata::getInstance()->SetBalance(index, (unsigned int)fVal);
    sysdata::getInstance()->ExeSet();

    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::setOutputAssignTrigger(int index, std::string enable_s)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    if(!isNum(enable_s))
    {
        ret = API_STATUS_ILLEGAL_REQ;
        return ret;
    }

    if(index < 0 || index >= CHANNELS)
    {
        return ret;
    }

    int en = stoi(enable_s);
    if(en != 0 && en != 1)
    {
        return ret;
    }

    ret = API_STATUS_SUCCESS;
    mMutexLock.lock();
    sysdata::getInstance()->mWebInfo.assigntrigger[index] = enable_s;
    sysdata::getInstance()->updateDataBaseTable("webInfoTab", "assigntrigger", enable_s, to_string(index));

    int asg_enable = 0;
    for(int channelIndex=0; channelIndex<CHANNELS; channelIndex++){
        string asg_value = sysdata::getInstance()->mWebInfo.assigntrigger[channelIndex];
        asg_enable = asg_enable || stoi(asg_value);
    }

    if(asg_enable == 1){
        sysdata::getInstance()->SetAsg(1);
    }else {
        sysdata::getInstance()->SetAsg(0);
    }

    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::setIpAddress(_networkinfo ip, bool send)
{
    ApiStatus ret = API_STATUS_ILLEGAL_REQ;

    if(!isNum(ip.dhcpEnabled))
    {
        return ret;
    }
    int enable = stoi(ip.dhcpEnabled);

    if((0 != enable) && (1 != enable))
    {
        return ret;
    }
    if(0 == enable)
    {
        if(!isIPAddressValid(ip.ip) || !isIPAddressValid(ip.gateway)|| !isIPAddressValid(ip.netmask)
                || !isIPAddressValid(ip.dnsServer1))
        {
            return ret;
        }
    }

    ret = API_STATUS_SUCCESS;
    mMutexLock.lock();

    mIPChange = 1;
    if(send)
    {
        mIPChange = -1;
        //ApiControl::getInstance()->clearApiMap();
    }
    sysdata::getInstance()->netinfo = ip;
    if("0" == sysdata::getInstance()->netinfo.dhcpEnabled)
    {
        char cmd[1024];
        sprintf(cmd, "snapav_network_config.sh static %s %s %s %s ",sysdata::getInstance()->netinfo.ip.c_str(),
                sysdata::getInstance()->netinfo.gateway.c_str(),sysdata::getInstance()->netinfo.netmask.c_str(),
                sysdata::getInstance()->netinfo.dnsServer1.c_str());
        DEBUG_LOG("modify network info[%s]" , cmd );
        system(cmd);
    }else
    {
        char cmd[1024];
        sprintf(cmd, "snapav_network_config.sh dhcp");
        DEBUG_LOG("modify network info[%s]" , cmd );
        system(cmd);
    }
    //sysdata::getInstance()->updateNetWorkInfo();
    Tools::getInstanc()->getNetStatus(sysdata::getInstance()->netinfo, "eth0");
    subject::GetInstance().Notify(DEVICE_NET_INFO);

    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::setOvrcInfo(_cloudinfo info)
{
#if 0
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    OvrcUpdate ovrc = OVRC_URL_INFO;
    if(!isNum(info.enable))
    {
        ret = API_STATUS_ILLEGAL_REQ;
        return ret;
    }
    int enable = stoi(info.enable);

    if((0 != enable) && (1 != enable))
    {
        return ret;
    }

    if(1 == enable)
    {
        if(!isNum(info.port))
        {
            ret = API_STATUS_ILLEGAL_REQ;
            return ret;
        }
        if(!isNum(info.updatefrequency))
        {
            ret = API_STATUS_ILLEGAL_REQ;
            return ret;
        }

        if(info.updatefrequency != sysdata::getInstance()->mOvrcInfo.updatefrequency)
        {
            ovrc = OVRC_FREQ_INFO;
        }

        sysdata::getInstance()->mOvrcInfo.url = info.url;
        sysdata::getInstance()->mOvrcInfo.port = info.port;
        sysdata::getInstance()->mOvrcInfo.updatefrequency = info.updatefrequency;
    }
    else
    {
        ovrc = OVRC_ENABLE_INFO;
    }
    sysdata::getInstance()->mOvrcInfo.enable = info.enable;

    ret = API_STATUS_SUCCESS;
    mMutexLock.lock();

    updateOvrcNetInfo(sysdata::getInstance()->mOvrcInfo);
    subject::GetInstance().Notify(ovrc);

    mMutexLock.unlock();
    return ret;
#endif
}

ApiStatus ComHandleApi::getInputSetting(cJSON *retJson, vector<int> getIndex, bool apiNote)
{
    char str[16] = { 0 };
    ApiStatus ret = API_STATUS_ILLEGAL_REQ;
    if(getIndex.empty())
    {
        return ret;
    }

    for(int j = 0;j < getIndex.size(); j++)
    {
        if(0 > getIndex[j])
        {
            return ret;
        }
        else if(getIndex[j] >= CHANNELS)
        {
            return ret;
        }
    }
    ret = API_STATUS_SUCCESS;

    mMutexLock.lock();
    if(apiNote)
    {
        retJson = cJSON_CreateObject();
        cJSON_AddItemToObject(retJson, "type", cJSON_CreateString("get_inputsetting"));
        cJSON_AddItemToObject(retJson, "status",cJSON_CreateNumber(API_STATUS_SUCCESS));
    }

    cJSON *arry = cJSON_CreateArray();


    for(int i = 0;i < getIndex.size();i++)
    {
        cJSON *info =  cJSON_CreateObject();
        cJSON_AddItemToObject(info, "index", cJSON_CreateNumber(getIndex[i]));
        cJSON_AddItemToObject(info, "inputName", cJSON_CreateString(sysdata::getInstance()->mWebInfo.inputname[getIndex.at(i)].c_str()));

        float fGain = (sysdata::getInstance()->dspdata[i].dsp[ENUM_Inputvolume] / 2.0) - 12;
        snprintf(str, 16, "%.1f", fGain);
        cJSON_AddItemToObject(info, "inputGain", cJSON_CreateString(str));
        cJSON_AddItemToObject(info, "inputDelay", cJSON_CreateString(to_string(sysdata::getInstance()->dspdata[getIndex.at(i)].dsp[ENUM_Inputdelay]).c_str()));
        cJSON_AddItemToObject(info, "inputAudioSense", cJSON_CreateString(to_string(sysdata::getInstance()->devicedata.audiosens).c_str()));    //TODO
        cJSON_AddItemToArray(arry, info);
    }

    cJSON_AddItemToObject(retJson, "value",arry);

//    if(apiNote)
//        ApiControl::getInstance()->reportApiInfo(retJson);


    mMutexLock.unlock();
    return ret;

}

ApiStatus ComHandleApi::getOutputSetting(cJSON *retJson, vector<int> getIndex, bool apiNote)
{
    char str[16] = { 0 };
    ApiStatus ret = API_STATUS_ILLEGAL_REQ;
    if(getIndex.empty())
    {
        return ret;
    }

    for(int j = 0;j < getIndex.size();j++)
    {
        if(0 > getIndex[j])
        {
            return ret;
        }
        else if(getIndex[j] > CHANNELS)
        {
            return ret;
        }
    }
    ret = API_STATUS_SUCCESS;

    mMutexLock.lock();
    if(apiNote)
    {
        retJson = cJSON_CreateObject();
        cJSON_AddItemToObject(retJson, "type", cJSON_CreateString("get_outputsetting"));
        cJSON_AddItemToObject(retJson, "status",cJSON_CreateNumber(API_STATUS_SUCCESS));
    }

    cJSON *arry = cJSON_CreateArray();


    for(int i = 0;i < getIndex.size();i++)
    {
        cJSON *info =  cJSON_CreateObject();
        cJSON_AddItemToObject(info, "index", cJSON_CreateNumber(getIndex[i]));
        cJSON_AddItemToObject(info, "outputName", cJSON_CreateString(sysdata::getInstance()->mWebInfo.outputname[getIndex.at(i)].c_str())); //TODO
        cJSON_AddItemToObject(info, "outputSource", cJSON_CreateString(to_string(sysdata::getInstance()->dspdata[getIndex.at(i)].dsp[ENUM_Outputsource] - 1).c_str()));
        cJSON_AddItemToObject(info, "outputDelay", cJSON_CreateString(to_string(sysdata::getInstance()->dspdata[getIndex.at(i)].dsp[ENUM_outputdelay]).c_str()));

        int stereoIndex = sysdata::getInstance()->dspdata[getIndex.at(i)].dsp[ENUM_merge];
        if(stereoIndex != 1)
        {
            stereoIndex = 0;
        }
        cJSON_AddItemToObject(info, "outputStereo", cJSON_CreateString(to_string(stereoIndex).c_str()));
        cJSON_AddItemToObject(info, "outputMute", cJSON_CreateString(to_string(sysdata::getInstance()->dspdata[getIndex.at(i)].dsp[ENUM_dspmute]).c_str()));
        cJSON_AddItemToObject(info, "outputVol", cJSON_CreateString(to_string(sysdata::getInstance()->dspdata[getIndex.at(i)].dsp[ENUM_volume]).c_str()));
        cJSON_AddItemToObject(info, "outputMaxVol", cJSON_CreateString(to_string(sysdata::getInstance()->dspdata[getIndex.at(i)].dsp[ENUM_maxvolume]).c_str()));

        float fBalance = (sysdata::getInstance()->dspdata[getIndex.at(i)].dsp[ENUM_balance] / 2.0) - 12;
        snprintf(str, 16, "%.1f", fBalance);
        cJSON_AddItemToObject(info, "outputBalance", cJSON_CreateString(str));
        cJSON_AddItemToObject(info, "outputAssignTrigger", cJSON_CreateString(sysdata::getInstance()->mWebInfo.assigntrigger[getIndex.at(i)].c_str()));    //TODO
        cJSON_AddItemToArray(arry, info);
    }

    cJSON_AddItemToObject(retJson, "value",arry);

//    if(apiNote)
//        ApiControl::getInstance()->reportApiInfo(retJson);


    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::getSystemSetting(cJSON *retJson, bool apiNote)
{
    ApiStatus ret = API_STATUS_SUCCESS;

    mMutexLock.lock();
    if(apiNote)
    {
        retJson = cJSON_CreateObject();
        cJSON_AddItemToObject(retJson, "type", cJSON_CreateString("get_systemsetting"));
        cJSON_AddItemToObject(retJson, "status",cJSON_CreateNumber(API_STATUS_SUCCESS));
    }

    cJSON *info = cJSON_CreateObject();
    cJSON_AddItemToObject(info, "ampName", cJSON_CreateString(sysdata::getInstance()->deviceinfo.devicename.c_str()));
    cJSON_AddItemToObject(info, "model", cJSON_CreateString(sysdata::getInstance()->deviceinfo.devicemodel.c_str()));
    cJSON_AddItemToObject(info, "macAddress", cJSON_CreateString(sysdata::getInstance()->netinfo.mac.c_str()));
    cJSON_AddItemToObject(info, "firmwareVersion", cJSON_CreateString(sysdata::getInstance()->deviceinfo.firmware.c_str()));
    cJSON_AddItemToObject(info, "serviceTag", cJSON_CreateString(sysdata::getInstance()->deviceinfo.serialnumber.c_str()));

    cJSON_AddItemToObject(retJson, "value",info);
    //TODO
//    if(apiNote)
//        ApiControl::getInstance()->reportApiInfo(retJson);


    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::getIpAddress(cJSON *retJson, bool apiNote)
{
    ApiStatus ret = API_STATUS_SUCCESS;

    mMutexLock.lock();
    if(apiNote)
    {
        retJson = cJSON_CreateObject();
        cJSON_AddItemToObject(retJson, "type", cJSON_CreateString("get_ip"));
        cJSON_AddItemToObject(retJson, "status",cJSON_CreateNumber(API_STATUS_SUCCESS));
    }

    cJSON *info = cJSON_CreateObject();
    cJSON_AddItemToObject(info, "dhcp", cJSON_CreateString(sysdata::getInstance()->netinfo.dhcpEnabled.c_str()));
    cJSON_AddItemToObject(info, "ipaddress", cJSON_CreateString(sysdata::getInstance()->netinfo.ip.c_str()));
    cJSON_AddItemToObject(info, "gateway", cJSON_CreateString(sysdata::getInstance()->netinfo.gateway.c_str()));
    cJSON_AddItemToObject(info, "subnetmask", cJSON_CreateString(sysdata::getInstance()->netinfo.netmask.c_str()));
    cJSON_AddItemToObject(info, "dnsserver", cJSON_CreateString(sysdata::getInstance()->netinfo.dnsServer1.c_str()));

    cJSON_AddItemToObject(retJson, "value",info);
    //TODO
//    if(apiNote)
//        ApiControl::getInstance()->reportApiInfo(retJson);


    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::getPowerStatus(cJSON *retJson, bool apiNote)
{
    ApiStatus ret = API_STATUS_SUCCESS;

    mMutexLock.lock();
    if(apiNote)
    {
        retJson = cJSON_CreateObject();
        cJSON_AddItemToObject(retJson, "type", cJSON_CreateString("get_powerstatus"));
        cJSON_AddItemToObject(retJson, "status",cJSON_CreateNumber(API_STATUS_SUCCESS));
    }

    string powerStr = (1 == sysdata::getInstance()->devicedata.power) ? "1" : "0";
    cJSON_AddItemToObject(retJson, "value",cJSON_CreateString(powerStr.c_str()));
    //TODO
//    if(apiNote)
//        ApiControl::getInstance()->reportApiInfo(retJson);


    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::setOutputRoomEQLock(int index, std::string enable_s){
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    int en = stoi(enable_s);
    if(en != 0 && en != 1)
    {
        return ret;
    }
    ret = API_STATUS_SUCCESS;
    sysdata::getInstance()->mOutputDspInfo[index].mOutputLock = enable_s;
    sysdata::getInstance()->updateDataBaseTable("outputDspInfo", "output_lock", enable_s, to_string(index));
    sysdata::getInstance()->ExeSet();
    return ret;
}

ApiStatus ComHandleApi::setDspLoudnessEn(int index, std::string enable_s)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    if(!isNum(enable_s))
    {
        ret = API_STATUS_ILLEGAL_REQ;
        return ret;
    }

    if(index < 0 || index >= CHANNELS)
    {
        return ret;
    }

    int en = stoi(enable_s);
    if(en != 0 && en != 1)
    {
        return ret;
    }

    ret = API_STATUS_SUCCESS;
    mMutexLock.lock();
    sysdata::getInstance()->mOutputDspInfo[index].mOutputLoudnessEN = enable_s;
    sysdata::getInstance()->updateDataBaseTable("outputDspInfo", "output_loudness_enable", enable_s, to_string(index));
    sysdata::getInstance()->SetLoudness(index, en);
    sysdata::getInstance()->ExeSet();

    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::setOutputToneBassEN(int index, std::string enable_s)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    if(!isNum(enable_s)){
        ret = API_STATUS_ILLEGAL_REQ;
        return ret;
    }

    if(index < 0 || index >= CHANNELS){
        return ret;
    }

    int en = stoi(enable_s);
    if(en != 0 && en != 1){
        return ret;
    }

    int nVal = stoi(sysdata::getInstance()->mOutputDspInfo[index].mOutputToneBass);
    int minV = stoi(m_dspToneBassRange.at(0));
    int maxV = stoi(m_dspToneBassRange.at(1));
    float fVal = nVal;
    if(fVal < minV){
        return ret;
    }else if(fVal > maxV){
        return ret;
    }
//    if(fVal > 0.0){
//        nVal = fVal * 100;
//    }else{
//        nVal = abs((int)(fVal * 100)) | 0x80000000;
//    }

    nVal = fVal * 100;
    ret = API_STATUS_SUCCESS;
    mMutexLock.lock();
    sysdata::getInstance()->mOutputDspInfo[index].mOutputToneBassEN = enable_s;
    sysdata::getInstance()->updateDataBaseTable("outputDspInfo", "output_tone_bass_enable", enable_s, to_string(index));
    if(en == 0)
    {
        sysdata::getInstance()->SetShelf(index, Shelf_Gain, 0, 0);
    }else
    {
        sysdata::getInstance()->SetShelf(index, Shelf_Gain, 0, nVal);
    }
    sysdata::getInstance()->ExeSet();
    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::setOutputToneBass(int index, std::string value_s)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    if(!isNum(value_s))
    {
        ret = API_STATUS_ILLEGAL_REQ;
        return ret;
    }

    if(index < 0 || index >= CHANNELS)
    {
        return ret;
    }

    int minV = stoi(m_dspToneBassRange.at(0));
    int maxV = stoi(m_dspToneBassRange.at(1));

    float fVal = stof(value_s);
    if(fVal < minV)
    {
        return ret;
    }
    else if(fVal > maxV)
    {
        return ret;
    }

    ret = API_STATUS_SUCCESS;
    mMutexLock.lock();
    LOGOUT("=============%s, %f ==============", value_s.c_str(), fVal);
    sysdata::getInstance()->mOutputDspInfo[index].mOutputToneBass = value_s;
    sysdata::getInstance()->updateDataBaseTable("outputDspInfo", "output_tone_bass", value_s, to_string(index));

    signed int nVal = 0;
//    if(fVal > 0.0)
//    {
//        nVal = fVal * 1000;
//    }
//    else
//    {
//        nVal = abs((int)(fVal * 1000)) | 0x80000000;
//    }
    nVal = fVal * 100;
    sysdata::getInstance()->SetShelf(index, Shelf_Gain, 0, nVal);
    sysdata::getInstance()->ExeSet();

    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::setOutputToneBassFreq(int index, std::string value_s)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    if(!isNum(value_s))
    {
        ret = API_STATUS_ILLEGAL_REQ;
        return ret;
    }

    if(index < 0 || index >= CHANNELS)
    {
        return ret;
    }

    int nVal = stoi(value_s);

    if(nVal<20){
        nVal = 20;
    }else if(nVal>20000){
        nVal = 20000;
    }

    ret = API_STATUS_SUCCESS;
    mMutexLock.lock();
    sysdata::getInstance()->mOutputDspInfo[index].mOutputToneBassFreq = to_string(nVal);
    sysdata::getInstance()->updateDataBaseTable("outputDspInfo", "output_tone_bass_freq", to_string(nVal), to_string(index));

    sysdata::getInstance()->SetShelf(index, Shelf_Freq, 0, nVal);
    sysdata::getInstance()->ExeSet();

    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::setOutputToneBassQ(int index, std::string value_s)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    if(!isNum(value_s))
    {
        ret = API_STATUS_ILLEGAL_REQ;
        return ret;
    }

    if(index < 0 || index >= CHANNELS)
    {
        return ret;
    }  

    if(stof(value_s) < 0.5)
    {
        value_s = "0.5";
    }else if(stof(value_s) > 3.0)
    {
        value_s = "3";
    }

    ret = API_STATUS_SUCCESS;
    mMutexLock.lock();
    sysdata::getInstance()->mOutputDspInfo[index].mOutputToneBassQ = value_s;
    sysdata::getInstance()->updateDataBaseTable("outputDspInfo", "output_tone_bass_q", value_s, to_string(index));

    sysdata::getInstance()->SetShelf(index, Shelf_Q, 0, stof(value_s)*100);
    sysdata::getInstance()->ExeSet();

    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::setOutputToneTrebleEN(int index, std::string enable_s)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    if(!isNum(enable_s)){
        ret = API_STATUS_ILLEGAL_REQ;
        return ret;
    }
    if(index < 0 || index >= CHANNELS){
        return ret;
    }
    int en = stoi(enable_s);
    if(en != 0 && en != 1){
        return ret;
    }

    ret = API_STATUS_SUCCESS;
    int nVal = stoi(sysdata::getInstance()->mOutputDspInfo[index].mOutputToneTreble);
    int minV = stoi(m_dspToneTrebleRange.at(0));
    int maxV = stoi(m_dspToneTrebleRange.at(1));
    float fVal = nVal;
//    if(fVal < minV){
//        return ret;
//    }else if(fVal > maxV){
//        return ret;
//    }
//    if(fVal > 0.0){
//        nVal = fVal * 1000;
//    }else{
//        nVal = abs((int)(fVal * 1000)) | 0x80000000;
//    }
    nVal = fVal * 100;
    mMutexLock.lock();
    sysdata::getInstance()->mOutputDspInfo[index].mOutputToneTrebleEN = enable_s;
    sysdata::getInstance()->updateDataBaseTable("outputDspInfo", "output_tone_treble_enable", enable_s, to_string(index));
    if(en == 0)
    {
        sysdata::getInstance()->SetShelf(index, Shelf_Gain, 1, 0);
    }else
    {
        sysdata::getInstance()->SetShelf(index, Shelf_Gain, 1, nVal);
    }
    sysdata::getInstance()->ExeSet();
    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::setOutputToneTrebleFreq(int index, string value_s)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    if(!isNum(value_s))
    {
        ret = API_STATUS_ILLEGAL_REQ;
        return ret;
    }

    if(index < 0 || index >= CHANNELS)
    {
        return ret;
    }

    int nVal = stoi(value_s);

    if(nVal<20){
        nVal = 20;
    }else if(nVal>20000){
        nVal = 20000;
    }

    ret = API_STATUS_SUCCESS;
    mMutexLock.lock();
    LOGOUT("=============%s, %d ==============", value_s.c_str(), nVal);
    sysdata::getInstance()->mOutputDspInfo[index].mOutputToneTrebleFreq = value_s;
    sysdata::getInstance()->updateDataBaseTable("outputDspInfo", "output_tone_treble_freq", value_s, to_string(index));

    sysdata::getInstance()->SetShelf(index, Shelf_Freq, 1, nVal);
    sysdata::getInstance()->ExeSet();

    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::setOutputToneTrebleQ(int index, string value_s)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    if(!isNum(value_s))
    {
        ret = API_STATUS_ILLEGAL_REQ;
        return ret;
    }

    if(index < 0 || index >= CHANNELS)
    {
        return ret;
    }

    if(stof(value_s) < 0.5)
    {
        value_s = "0.5";
    }else if(stof(value_s) > 3.0)
    {
        value_s = "3";
    }

    ret = API_STATUS_SUCCESS;
    mMutexLock.lock();
    sysdata::getInstance()->mOutputDspInfo[index].mOutputToneTrebleQ = value_s;
    sysdata::getInstance()->updateDataBaseTable("outputDspInfo", "output_tone_treble_q", value_s, to_string(index));

    sysdata::getInstance()->SetShelf(index, Shelf_Q, 0, stof(value_s)*100);
    sysdata::getInstance()->ExeSet();

    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::setOutputToneTreble(int index, std::string value_s)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    if(!isNum(value_s))
    {
        ret = API_STATUS_ILLEGAL_REQ;
        return ret;
    }

    if(index < 0 || index >= CHANNELS)
    {
        return ret;
    }

    int minV = stoi(m_dspToneTrebleRange.at(0));
    int maxV = stoi(m_dspToneTrebleRange.at(1));

    float fVal = stof(value_s);
    if(fVal < minV)
    {
        return ret;
    }
    else if(fVal > maxV)
    {
        return ret;
    }

    ret = API_STATUS_SUCCESS;
    mMutexLock.lock();
    LOGOUT("=============%s, %f ==============", value_s.c_str(), fVal);
    sysdata::getInstance()->mOutputDspInfo[index].mOutputToneTreble = value_s;
    sysdata::getInstance()->updateDataBaseTable("outputDspInfo", "output_tone_treble", value_s, to_string(index));

    signed int nVal = 0;
//    if(fVal > 0.0)
//    {
//        nVal = fVal * 1000;
//    }
//    else
//    {
//        nVal = abs((int)(fVal * 1000)) | 0x80000000;
//    }
    nVal = fVal * 100;
    sysdata::getInstance()->SetShelf(index, Shelf_Gain, 1, nVal);
    sysdata::getInstance()->ExeSet();

    mMutexLock.unlock();
    return ret;
}


ApiStatus ComHandleApi::setOutputRoomDspPreset(int index, std::string value_s)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    if(!isNum(value_s))
    {
        ret = API_STATUS_ILLEGAL_REQ;
        return ret;
    }

    if(index < 0 || index >= CHANNELS)
    {
        return ret;
    }

    int nVal = stoi(value_s);
    if(nVal < 0 || nVal >= sysdata::getInstance()->mRoomDspVecInfo.size())
    {
        return ret;
    }

    ret = API_STATUS_SUCCESS;
    mMutexLock.lock();
    sysdata::getInstance()->mOutputDspInfo[index].mOutputRoomDspPreset = value_s;
    sysdata::getInstance()->updateDataBaseTable("outputDspInfo", "output_room_dsp_preset", value_s, to_string(index));
    setDspInfo(value_s, Room_EQ_Type);
    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::setOutputSpeakerDspPreset(int index, string value_s)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    if(!isNum(value_s))
    {
        ret = API_STATUS_ILLEGAL_REQ;
        return ret;
    }

    if(index < 0 || index >= CHANNELS)
    {
        return ret;
    }

    unsigned long long nVal = stoull(value_s);
    if(nVal < 0)
    {
        return ret;
    }

    ret = API_STATUS_SUCCESS;
    mMutexLock.lock();
    sysdata::getInstance()->mOutputDspInfo[index].mOutputSpeakerDspPreset = value_s;
    sysdata::getInstance()->updateDataBaseTable("outputDspInfo", "output_speaker_dsp_preset", value_s, to_string(index));
    setDspInfo(value_s, Speaker_EQ_Type);
    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::setSubEnable(int index, std::string enable_s)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    if(!isNum(enable_s))
    {
        ret = API_STATUS_ILLEGAL_REQ;
        return ret;
    }

    if(index < 0 || index >= CHANNELS)
    {
        return ret;
    }

    int en = stoi(enable_s);
    if(en != 0 && en != 1)
    {
        return ret;
    }

    ret = API_STATUS_SUCCESS;
    mMutexLock.lock();
    sysdata::getInstance()->mSubDspInfo[index].mSubDspEnable = enable_s;
    sysdata::getInstance()->updateDataBaseTable("subDspInfo", "sub_enable", enable_s, to_string(index));

    if(1 == en)
        sysdata::getInstance()->Mon(index, Switch_StereoHP);
    else
        sysdata::getInstance()->Mon(index, Switch_stereo);

    sysdata::getInstance()->ExeSet();

    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::setSubVolOffset(int index, std::string value_s)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    if(!isNum(value_s))
    {
        ret = API_STATUS_ILLEGAL_REQ;
        return ret;
    }

    if(index < 0 || index >= CHANNELS)
    {
        return ret;
    }

    int minV = stoi(m_SubVolOffsetRange.at(0));
    int maxV = stoi(m_SubVolOffsetRange.at(1));

    float fVal = stof(value_s);
    if(fVal < minV)
    {
        return ret;
    }
    else if(fVal > maxV)
    {
        return ret;
    }

    ret = API_STATUS_SUCCESS;
    mMutexLock.lock();
    sysdata::getInstance()->mSubDspInfo[index].mSubVolOffset = value_s;
    sysdata::getInstance()->updateDataBaseTable("subDspInfo", "sub_volume_offset", value_s, to_string(index));
    sysdata::getInstance()->SetSubVolume(index-1, (fVal+12)*2);
    sysdata::getInstance()->ExeSet();
    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::setSubCrossoverType(int index, std::string value_s)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    if(!isNum(value_s))
    {
        ret = API_STATUS_ILLEGAL_REQ;
        return ret;
    }

    if(index < 0 || index >= CHANNELS)
    {
        return ret;
    }

    int nVal = stoi(value_s);
    if(nVal < 0 || nVal >= m_CrossoverTypeItem.size())
    {
        return ret;
    }

    ret = API_STATUS_SUCCESS;
    mMutexLock.lock();
    sysdata::getInstance()->mSubDspInfo[index].mSubCrossoverType = value_s;
    sysdata::getInstance()->updateDataBaseTable("subDspInfo", "sub_crossover_type", value_s, to_string(index));

    //see dsp pdf
    nVal = nVal * 3 + stoi(sysdata::getInstance()->mSubDspInfo[index].mSubCrossoverSlop);
    nVal = nVal > 6 ? 6 : nVal;
    sysdata::getInstance()->SetXover(index - 1, Xover_Index, nVal);
    sysdata::getInstance()->ExeSet();

    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::setSubCrossoverSlop(int index, std::string value_s)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    if(!isNum(value_s))
    {
        ret = API_STATUS_ILLEGAL_REQ;
        return ret;
    }

    if(index < 0 || index >= CHANNELS)
    {
        return ret;
    }

    int nVal = stoi(value_s);
    if(nVal < 0 || nVal >= m_CrossoverSlopItem.size())
    {
        return ret;
    }

    ret = API_STATUS_SUCCESS;
    mMutexLock.lock();
    sysdata::getInstance()->mSubDspInfo[index].mSubCrossoverSlop = value_s;
    sysdata::getInstance()->updateDataBaseTable("subDspInfo", "sub_crossover_slop", value_s, to_string(index));

    //see dsp pdf
    nVal += stoi(sysdata::getInstance()->mSubDspInfo[index].mSubCrossoverType) * 3;
    nVal = nVal > 6 ? 6 : nVal;
    sysdata::getInstance()->SetXover(index - 1, Xover_Index, nVal);
    sysdata::getInstance()->ExeSet();

    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::setSubCrossoverFreq(int index, std::string value_s)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    if(!isNum(value_s))
    {
        ret = API_STATUS_ILLEGAL_REQ;
        return ret;
    }

    if(index < 0 || index >= CHANNELS)
    {
        return ret;
    }

    int minV = stoi(m_CrossoverFreqRange.at(0));
    int maxV = stoi(m_CrossoverFreqRange.at(1));

    float fVal = stof(value_s);
    if(fVal < minV)
    {
        return ret;
    }
    else if(fVal > maxV)
    {
        return ret;
    }

    ret = API_STATUS_SUCCESS;
    mMutexLock.lock();
    sysdata::getInstance()->mSubDspInfo[index].mSubCrossoverFreq = value_s;
    sysdata::getInstance()->updateDataBaseTable("subDspInfo", "sub_crossover_freq", value_s, to_string(index));

    sysdata::getInstance()->SetXover(index - 1, Xover_Freq, stoi(value_s));
    sysdata::getInstance()->ExeSet();

    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::setEqEnable(int index, string uuid_s, std::string enable_s)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    if(!isNum(enable_s))
    {
        ret = API_STATUS_ILLEGAL_REQ;
        return ret;
    }

    if(index < 0 || index >= sysdata::getInstance()->mRoomDspVecInfo.size())
    {
        return ret;
    }

    int  uuid = stoi(uuid_s);
    if(uuid < 0 || uuid >= MAX_EQ_NUM)
    {
        return ret;
    }

    int en = stoi(enable_s);
    if(en != 0 && en != 1)
    {
        return ret;
    }

    ret = API_STATUS_SUCCESS;
    mMutexLock.lock();

#if 0
    for(int i = 0; i < sysdata::getInstance()->mRoomDspVecInfo.size(); i++)
    {
        if(index == stoi(sysdata::getInstance()->mRoomDspVecInfo.at(i).mRoomDspIndex)
            && (uuid == sysdata::getInstance()->mRoomDspVecInfo.at(i).mRoomEqIndex))
        {
            sysdata::getInstance()->mRoomDspVecInfo.at(i).mRoomEqEnable = enable_s;
            sysdata::getInstance()->updateDataBaseEqInfoTable("eq_enable", enable_s, to_string(index), uuid);
            break;
        }
    }
#endif
    sysdata::getInstance()->mRoomDspVecInfo[index].mRoomEqEnable[uuid] = enable_s;
    sysdata::getInstance()->updateDataBaseEqInfoTable("eq_enable", enable_s, to_string(index), uuid_s);
    setDspInfo(to_string(index), Room_EQ_Type);
    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::setSpeakerEqEnable(int index, string uuid_s, std::string enable_s)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    if(!isNum(enable_s))
    {
        ret = API_STATUS_ILLEGAL_REQ;
        return ret;
    }

    if(index < 0 || index > sysdata::getInstance()->mSpeakerDspMapInfo.rbegin()->first)
    {
        return ret;
    }

    int  uuid = stoi(uuid_s);
    if(uuid < 0 || uuid >= MAX_EQ_NUM)
    {
        return ret;
    }

    int en = stoi(enable_s);
    if(en != 0 && en != 1)
    {
        return ret;
    }

    ret = API_STATUS_SUCCESS;
    mMutexLock.lock();
    sysdata::getInstance()->mSpeakerDspMapInfo[index].mSpeakerEqEnable[uuid] = enable_s;
    sysdata::getInstance()->updateDataBaseEqInfoTable("eq_enable", enable_s, to_string(index), uuid_s, false);
    setDspInfo(to_string(index), Speaker_EQ_Type);
    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::setEqFreq(int index, string uuid_s, std::string value_s)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    if(!isNum(value_s))
    {
        ret = API_STATUS_ILLEGAL_REQ;
        return ret;
    }

    if(index < 0 || index >= sysdata::getInstance()->mRoomDspVecInfo.size())
    {
        return ret;
    }

    int  uuid = stoi(uuid_s);
    if(uuid < 0 || uuid >= MAX_EQ_NUM)
    {
        return ret;
    }

    int val = stoi(value_s);
    if(val < 20 && val > 20000)
    {
        return ret;
    }

    ret = API_STATUS_SUCCESS;
    mMutexLock.lock();
#if 0
    for(int i = 0; i < sysdata::getInstance()->mEQItemInfo.size(); i++)
    {
        if(index == stoi(sysdata::getInstance()->mEQItemInfo.at(i).mDspPresetIndex)
            && uuid == sysdata::getInstance()->mEQItemInfo.at(i).mDspEqUuid)
        {
            sysdata::getInstance()->mEQItemInfo.at(i).mDspEqFreq = value_s;
            sysdata::getInstance()->updateDataBaseEqInfoTable("eq_freq", value_s, to_string(index), uuid);
            break;
        }
    }
#endif
    sysdata::getInstance()->mRoomDspVecInfo[index].mRoomEqFreq[uuid] = value_s;
    sysdata::getInstance()->updateDataBaseEqInfoTable("eq_freq", value_s, to_string(index), uuid_s);

    setDspInfo(to_string(index), Room_EQ_Type);
    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::setSpeakerEqFreq(int index, string uuid_s, std::string value_s)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    if(!isNum(value_s))
    {
        ret = API_STATUS_ILLEGAL_REQ;
        return ret;
    }

    if(index < 0 || index > sysdata::getInstance()->mSpeakerDspMapInfo.rbegin()->first)
    {
        return ret;
    }

    int  uuid = stoi(uuid_s);
    if(uuid < 0 || uuid >= MAX_EQ_NUM)
    {
        return ret;
    }

    int val = stoi(value_s);
    if(val < 20 && val > 20000)
    {
        return ret;
    }

    ret = API_STATUS_SUCCESS;
    mMutexLock.lock();

    sysdata::getInstance()->mSpeakerDspMapInfo[index].mSpeakerEqFreq[uuid] = value_s;
    sysdata::getInstance()->updateDataBaseEqInfoTable("eq_freq", value_s, to_string(index), uuid_s, false);

    setDspInfo(to_string(index), Speaker_EQ_Type);
    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::setEqQratio(int index, string uuid_s, std::string value_s)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    if(!isNum(value_s))
    {
        ret = API_STATUS_ILLEGAL_REQ;
        return ret;
    }

    if(index < 0 || index >= sysdata::getInstance()->mRoomDspVecInfo.size())
    {
        return ret;
    }

    int  uuid = stoi(uuid_s);
    if(uuid < 0 || uuid >= MAX_EQ_NUM)
    {
        return ret;
    }

    double val = stod(value_s);
    if(val < 0.3 && val > 3.0)
    {
        return ret;
    }

    ret = API_STATUS_SUCCESS;
    mMutexLock.lock();
#if 0
    for(int i = 0; i < sysdata::getInstance()->mEQItemInfo.size(); i++)
    {
        if(index == stoi(sysdata::getInstance()->mEQItemInfo.at(i).mDspPresetIndex)
            && uuid == sysdata::getInstance()->mEQItemInfo.at(i).mDspEqUuid)
        {
            sysdata::getInstance()->mEQItemInfo.at(i).mDspEqQratio = doubleToString_one(val);
            sysdata::getInstance()->updateDataBaseEqInfoTable("eq_qratio", value_s, to_string(index), uuid);
            break;
        }
    }
#endif
    sysdata::getInstance()->mRoomDspVecInfo[index].mRoomEqQratio[uuid] = doubleToString_one(val);
    sysdata::getInstance()->updateDataBaseEqInfoTable("eq_qratio", value_s, to_string(index), uuid_s);

    setDspInfo(to_string(index), Room_EQ_Type);
    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::setSpeakerEqQratio(int index, string uuid_s, std::string value_s)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    if(!isNum(value_s))
    {
        ret = API_STATUS_ILLEGAL_REQ;
        return ret;
    }

    if(index < 0 || index > sysdata::getInstance()->mSpeakerDspMapInfo.rbegin()->first)
    {
        return ret;
    }

    int  uuid = stoi(uuid_s);
    if(uuid < 0 || uuid >= MAX_EQ_NUM)
    {
        return ret;
    }

    double val = stod(value_s);
    if(val < 0.3 && val > 3.0)
    {
        return ret;
    }

    ret = API_STATUS_SUCCESS;
    mMutexLock.lock();

    sysdata::getInstance()->mSpeakerDspMapInfo[index].mSpeakerEqQratio[uuid] = doubleToString_one(val);
    sysdata::getInstance()->updateDataBaseEqInfoTable("eq_qratio", value_s, to_string(index), uuid_s, false);

    setDspInfo(to_string(index), Speaker_EQ_Type);
    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::setEqGain(int index, string uuid_s, std::string value_s)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    if(!isNum(value_s))
    {
        ret = API_STATUS_ILLEGAL_REQ;
        return ret;
    }

    if(index < 0 || index >= sysdata::getInstance()->mRoomDspVecInfo.size())
    {
        return ret;
    }

    int  uuid = stoi(uuid_s);
    if(uuid < 0 || uuid >= MAX_EQ_NUM)
    {
        return ret;
    }

    double val = stod(value_s);
    if(val < -12.0 && val > 12.0)
    {
        return ret;
    }

    LOGOUT("gain: %f, %s", val, doubleToString_one(val).c_str());
    ret = API_STATUS_SUCCESS;
    mMutexLock.lock();

#if 0
    for(int i = 0; i < sysdata::getInstance()->mEQItemInfo.size(); i++)
    {
        if(index == stoi(sysdata::getInstance()->mEQItemInfo.at(i).mDspPresetIndex)
            && uuid_s == sysdata::getInstance()->mEQItemInfo.at(i).mDspEqUuid)
        {
            sysdata::getInstance()->mEQItemInfo.at(i).mDspEqGain = doubleToString_one(val);
            sysdata::getInstance()->updateDataBaseEqInfoTable("eq_gain", value_s, to_string(index), uuid_s);
            break;
        }
    }
#endif
    sysdata::getInstance()->mRoomDspVecInfo[index].mRoomEqGain[uuid] = doubleToString_one(val);
    sysdata::getInstance()->updateDataBaseEqInfoTable("eq_gain", value_s, to_string(index), uuid_s);

    setDspInfo(to_string(index), Room_EQ_Type);
    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::setSpeakerEqGain(int index, string uuid_s, std::string value_s)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;
    if(!isNum(value_s))
    {
        ret = API_STATUS_ILLEGAL_REQ;
        return ret;
    }

    if(index < 0 || index > sysdata::getInstance()->mSpeakerDspMapInfo.rbegin()->first)
    {
        return ret;
    }

    int  uuid = stoi(uuid_s);
    if(uuid < 0 || uuid >= MAX_EQ_NUM)
    {
        return ret;
    }

    double val = stod(value_s);
    if(val < -12.0 && val > 12.0)
    {
        return ret;
    }

    LOGOUT("gain: %f, %s", val, doubleToString_one(val).c_str());
    ret = API_STATUS_SUCCESS;
    mMutexLock.lock();

    sysdata::getInstance()->mSpeakerDspMapInfo[index].mSpeakerEqGain[uuid] = doubleToString_one(val);
    sysdata::getInstance()->updateDataBaseEqInfoTable("eq_gain", value_s, to_string(index), uuid_s, false);

    setDspInfo(to_string(index), Speaker_EQ_Type);
    mMutexLock.unlock();
    return ret;
}

ApiStatus ComHandleApi::setCopyDsp(string from, string to, bool room)
{
    ApiStatus ret = API_STATUS_INVALID_RANGE;

    if(!isNum(from) || !isNum(to))
    {
        ret = API_STATUS_ILLEGAL_REQ;
        return ret;
    }

    if(room)
    {
        if(to == from)
            return API_STATUS_ILLEGAL_REQ;

        if(stoi(from) < 0 || stoi(from) >= sysdata::getInstance()->mRoomDspVecInfo.size())
        {
            return ret;
        }

        if(stoi(to) < 0 || stoi(to) >= sysdata::getInstance()->mRoomDspVecInfo.size())
        {
            return ret;
        }

        mMutexLock.lock();

        string oldToName = sysdata::getInstance()->mRoomDspVecInfo[stoull(to)].mRoomDspName;
        sysdata::getInstance()->mRoomDspVecInfo[stoi(to)] = sysdata::getInstance()->mRoomDspVecInfo[stoi(from)];
        sysdata::getInstance()->mRoomDspVecInfo[stoi(to)].mRoomDspIndex = to;
        // Keep the name unchanged
        sysdata::getInstance()->mRoomDspVecInfo[stoull(to)].mRoomDspName = oldToName;

        sysdata::getInstance()->updateDataBasePresetInfoTable(to,room);

        setDspInfo(to, Room_EQ_Type);
        mMutexLock.unlock();
    }
    else
    {
        if(to == from)
            return API_STATUS_ILLEGAL_REQ;

        if(stoull(from) < 0 || stoull(from) > sysdata::getInstance()->mSpeakerDspMapInfo.rbegin()->first)
        {
            return ret;
        }

        if(stoull(to) < 0 || stoull(to) > sysdata::getInstance()->mSpeakerDspMapInfo.rbegin()->first)
        {
            return ret;
        }

        mMutexLock.lock();

        string oldToName = sysdata::getInstance()->mSpeakerDspMapInfo[stoull(to)].mSpeakerDspName;
        sysdata::getInstance()->mSpeakerDspMapInfo[stoull(to)] = sysdata::getInstance()->mSpeakerDspMapInfo[stoull(from)];
        sysdata::getInstance()->mSpeakerDspMapInfo[stoull(to)].mSpeakerDspIndex = to;
        // Keep the name unchanged
        sysdata::getInstance()->mSpeakerDspMapInfo[stoull(to)].mSpeakerDspName = oldToName;

        sysdata::getInstance()->updateDataBasePresetInfoTable(to,room);

        setDspInfo(to, Speaker_EQ_Type);
        mMutexLock.unlock();
    }


    return API_STATUS_SUCCESS;
}

void ComHandleApi::setDspInfo(string dsp_index, dspPresetItemType type)
{
    switch (type) {
    case Room_EQ_Type:
        for(int i = 0; i < CHANNELS; i++)
        {
            int nEqIndex = 5;    //DSP 目前只支持3组EQ，且底层设计时三组EQ的名称不一样
            if(dsp_index == sysdata::getInstance()->mOutputDspInfo[i].mOutputRoomDspPreset)
            {
                //mute
                //sysdata::getInstance()->SetDspmute(i, 1);
                //sysdata::getInstance()->ExeSet();
                for(int j = 0; j < MAX_EQ_NUM; j++)
                {
                    nEqIndex++;
                    int dspIndex = stoi(dsp_index);
                    if("0" == sysdata::getInstance()->mRoomDspVecInfo[dspIndex].mRoomEqEnable[j])
                    {
                        sysdata::getInstance()->SetPEQ(i, PEQ_Gain, nEqIndex, 0);
                        continue;
                    }


                    sysdata::getInstance()->SetPEQ(i, PEQ_Freq, nEqIndex, stoi(sysdata::getInstance()->mRoomDspVecInfo[dspIndex].mRoomEqFreq[j]));
                    sysdata::getInstance()->SetPEQ(i, PEQ_Q, nEqIndex, (signed int)(stod(sysdata::getInstance()->mRoomDspVecInfo[dspIndex].mRoomEqQratio[j])*100));

                    signed int nVal = 0;
                    float fVal = stof(sysdata::getInstance()->mRoomDspVecInfo[dspIndex].mRoomEqGain[j]);
//                    if(fVal > 0.0)
//                    {
//                        nVal = fVal * 1000;
//                    }
//                    else
//                    {
//                        nVal = abs((int)(fVal * 1000)) | 0x80000000;
//                    }
                    nVal = fVal * 100;
                    sysdata::getInstance()->SetPEQ(i, PEQ_Gain, nEqIndex, nVal);
                 }

                //unmute
                //sysdata::getInstance()->SetDspmute(i, 0);
                sysdata::getInstance()->ExeSet();
             }
        }
        break;
    case Speaker_EQ_Type:
        for(int i = 0; i < CHANNELS; i++)
        {
            int nEqIndex = -1;    //DSP 目前只支持3组EQ，且底层设计时三组EQ的名称不一样
            if(dsp_index == sysdata::getInstance()->mOutputDspInfo[i].mOutputSpeakerDspPreset)
            {
                //mute
                //sysdata::getInstance()->SetDspmute(i, 1);
                //sysdata::getInstance()->ExeSet();
                for(int j = 0; j < MAX_EQ_NUM; j++)
                {
                    nEqIndex++;
                    unsigned long long dspIndex = stoull(dsp_index);
                    if("0" == sysdata::getInstance()->mSpeakerDspMapInfo[dspIndex].mSpeakerEqEnable[j])
                    {
                        sysdata::getInstance()->SetPEQ(i, PEQ_Gain, nEqIndex, 0);
                        continue;
                    }

                    sysdata::getInstance()->SetPEQ(i, PEQ_Freq, nEqIndex, stoi(sysdata::getInstance()->mSpeakerDspMapInfo[dspIndex].mSpeakerEqFreq[j]));
                    sysdata::getInstance()->SetPEQ(i, PEQ_Q, nEqIndex, (signed int)(stod(sysdata::getInstance()->mSpeakerDspMapInfo[dspIndex].mSpeakerEqQratio[j])*100));

                    signed int nVal = 0;
                    float fVal = stof(sysdata::getInstance()->mSpeakerDspMapInfo[dspIndex].mSpeakerEqGain[j]);
//                    if(fVal > 0.0)
//                    {
//                        nVal = fVal * 1000;
//                    }
//                    else
//                    {
//                        nVal = abs((int)(fVal * 1000)) | 0x80000000;
//                    }
                    nVal = fVal * 100;
                    sysdata::getInstance()->SetPEQ(i, PEQ_Gain, nEqIndex, nVal);
                 }

                //unmute
                //sysdata::getInstance()->SetDspmute(i, 0);
                sysdata::getInstance()->ExeSet();
             }
        }
        break;
    default:
        break;
    }

}

string ComHandleApi::doubleToString_one(double tmp)
{
    string v = to_string(tmp);

    int pos = v.find(".");
    if(v.npos != pos)
    {
        string str;
        str =v.substr(pos+1,1);
        if("0" == str)
        {
            v= v.substr(0,pos);
        }
        else
        {
            v = v.substr(0,pos+2);
        }
    }
    return v;
}

string ComHandleApi::doubleToString(double tmp)
{
    tmp*=100;
    tmp=(int)tmp;
    tmp/=100.0;


    std::stringstream oss;
    oss << tmp;
    return oss.str();
}
bool ComHandleApi::isIPAddressValid(std::string &str)
{
    std::vector<std::string> resVec;
    bool res = true;

    if ("" == str)
    {
       res = false;
        return res;
    }
    string strs = str + ".";

    size_t pos = strs.find(".");
    size_t size = strs.size();

    while (pos != std::string::npos)
    {
       std::string x = strs.substr(0,pos);
       if(!isNum(x) || !filtStr(x))
       {
           res = false;
           break;
       }
        resVec.push_back(x);

        strs = strs.substr(pos+1,size);
        pos = strs.find(".");
    }
    if(4 !=resVec.size())
        res = false;
     if(res)
     {
        str.clear();
        for(int i = 0; i< resVec.size(); i++)
         {
            str += resVec.at(i) +".";
         }
         str.erase(str.end() - 1);
     }

    return res;
}

bool ComHandleApi::filtStr(string &s)
{
    while(1)
    {
        size_t pos = s.find(" ");
        if(pos == string::npos)
        {
            break;
        }

        s.erase(pos, 1);
    }

    for(int i = 0;(s.size() > 1)&& (i < s.size()); i++)
    {
        if(s.at(0) == 48)
        {
            s.erase(0, 1);
        }
    }

    int v = stoi(s);
    if(v < 0 || v > 255)
        return false;

    return true;
}

bool ComHandleApi::isNum(string str)
{
    stringstream sin(str);
    double d;
    char c;
    if(!(sin >> d))
    {
        return false;
    }
    if (sin >> c)
    {
        return false;
    }
    return true;
}


