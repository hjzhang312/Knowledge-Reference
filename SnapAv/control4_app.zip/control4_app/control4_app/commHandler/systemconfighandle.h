#ifndef SYSTEMCONFIGHANDLE_H
#define SYSTEMCONFIGHANDLE_H

#include "tools/sqlite3base.h"
#include <cJSON.h>
#include "comhandleapi.h"

#if 0
struct observer
{
    virtual ~observer() {};
    virtual void ovrcUpdate() = 0;
};
class subject{
public:
       static subject& GetInstance();
       void Attach(observer* listener);
       void Notify();
   private:
       subject() : listener(nullptr) {}

       observer* listener;
};
#endif
class SystemConfigHandle : public ComHandleApi
{
public:
    static SystemConfigHandle *getInstance() {
        static SystemConfigHandle s;
        return &s;
    }
private:
    SystemConfigHandle();
public:
    void setAmpName(std::string name);
    S_ret setSystemConfigPageInfo(cJSON *root,cJSON *retJson);
    string backUpHandleFun();
    S_ret restoreHandleFun(string fileName,string md5FileValue);
    void setNetWorkDhcpEnable();
    void getSystemConfigPageInfo(cJSON *retJson);
    void initDevicePreset();
    void restartSSHservice();
};

#endif // SYSTEMCONFIGHANDLE_H
