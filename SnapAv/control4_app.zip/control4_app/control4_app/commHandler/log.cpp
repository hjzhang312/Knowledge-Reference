#include "log.h"

#include <stdarg.h>
#include <pthread.h>
#include <sys/time.h>
#include <unistd.h>

pthread_mutex_t log_mutex = PTHREAD_MUTEX_INITIALIZER;
#define LOG_ENABLE

void DEBUG_LOG(const char *msg, ...) {

    char message[8192] = {0};
    va_list args;
    va_start(args, msg);
    int n = vsnprintf(message, 8192, msg, args);
    va_end(args);

    Log::log()->write_log(message);
}

Log *Log::m_log = NULL;

Log::Log():
    tim(0),
    t(NULL),
    fp(NULL),
    filepath()
{
#ifdef LOG_ENABLE
    create_log_file();
#endif
}

Log::~Log(){
#ifdef LOG_ENABLE
    fclose(fp);
#endif
}

void Log::create_log_file(){
    if(fp != NULL)
        fclose(fp);

    sprintf(filepath, "/media/userdata/debuglog.log");
    time(&tim);
    t = localtime(&tim);
    //sprintf(filepath + 17, "%02d_%02d",t->tm_mon + 1, t->tm_mday);
    fp = fopen(filepath, "a+");
}

Log *Log::log(){
    if(m_log == NULL){
        m_log = new Log();
    }
    return m_log;
}

void Log::write_log(const char *msg){
    time(&tim);
    t = localtime(&tim);
    char message[8192] ={0};
    snprintf(message, 8192, "[%02d-%02d-%02d %02d:%02d:%02d] %s\n",t->tm_year + 1900,t->tm_mon + 1, t->tm_mday, t->tm_hour, t->tm_min, t->tm_sec, msg);
#ifdef LOG_ENABLE

    long size = ftell(fp);
    if(size > 10*1024*1024)
    {
        remove("/media/userdata/debuglog.log");
        create_log_file();
    }
    fwrite(message, strlen(message), 1, fp);
    fflush(fp);
#else
    printf("\n%s\n", message);
    fflush(stdout);
#endif
}
