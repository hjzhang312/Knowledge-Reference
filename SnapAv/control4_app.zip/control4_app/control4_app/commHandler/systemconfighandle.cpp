#include "systemconfighandle.h"
#include <log.h>
#include "sysdata.h"
#include "md5.h"
#include "wshandle.h"
#include "tools.h"

SystemConfigHandle::SystemConfigHandle()
{

}


void writeBinary(ofstream &fout, string &md5, const string value)
{
    char endMark = 0;
    fout.write(value.c_str(), sizeof(char) * (value.size()));
    md5 += value;
    fout.write(&endMark,sizeof(char));
}

void readBinary(string &value,string &md5, char **p)
{
    value.clear();
    value = *p;
    md5 +=value;
    *p = *p + strlen(*p) + 1;
}

void SystemConfigHandle::restartSSHservice(){
    system("/etc/init.d/S50sshd restart");
}

void SystemConfigHandle::initDevicePreset(){
    setDspInfo(mCurrentRoomEqIndex, Room_EQ_Type);
}

void SystemConfigHandle::setAmpName(string name)
{
    sysdata::getInstance()->deviceinfo.devicename = name;
    sysdata::getInstance()->updateDataBaseTable("Devicetab", "devicename", name);
    subject::GetInstance().Notify(DEVICE_NAME_INFO);
}

S_ret SystemConfigHandle::setSystemConfigPageInfo(cJSON *root, cJSON *retJson)
{
    cJSON *items = cJSON_GetObjectItem(root,"changed_item");
    if(NULL ==items)
        return -1;
    int sizes = cJSON_GetArraySize(items);
    if(sizes > 0)
    {
        cJSON *itemRoot = cJSON_GetObjectItem(root,"items");

        for(int i = 0; i < sizes; i++)
        {
            char *itemV = cJSON_GetArrayItem(items,i)->valuestring;
            switch (s_mapConfigStrVal[itemV]) {
            case evDeviceName:
            {
                string value = cJSON_GetObjectItem(itemRoot,itemV)->valuestring;
                if(!value.empty())
                    setAmpName(value);
                getSystemSetting(NULL,true);
                break;
            }
            case evSshEnable:
            {
                restartSSHservice();
                DEBUG_LOG("The ssh is open!!!");
                break;
            }
            case evBackUp:
            {
                string url = backUpHandleFun();
                url = url.substr(url.find('/', 1)+1,url.size());
                cJSON_AddItemToObject(retJson, "url", cJSON_CreateString(url.c_str()));
                break;
            }
            case evRestore:
            {
#if 1
                cJSON *tItem=cJSON_GetObjectItem(itemRoot,itemV);
                string fileName = cJSON_GetObjectItem(tItem, "value")->valuestring;
                string md5 = cJSON_GetObjectItem(tItem,"md5")->valuestring;

                int ret = restoreHandleFun(fileName,md5);
                if(ret == IMPORT_FILE_NOT_EXIST)
                {
                    cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(600));
                }
                else if((ret == IMPORT_MD5_FILE_ERROR) || (ret == IMPORT_MD5_STRING_ERROR))
                {
                    cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(601));
                }
                else if(ret == IMPORT_TYPE_ERROR)
                {
                    cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(602));
                }else if( SUCESS == ret)
                {
                    setDspInfo(mCurrentRoomEqIndex, Room_EQ_Type);
                }
#endif
                break;
            }
            case evDhcpEnabled:
            {
                string v = cJSON_GetObjectItem(itemRoot,itemV)->valuestring;
                sysdata::getInstance()->netinfo.dhcpEnabled = v;
                break;
            }
            case evIpAddress:
            {
                if("0" == sysdata::getInstance()->netinfo.dhcpEnabled)
                {
                    string v = cJSON_GetObjectItem(itemRoot,itemV)->valuestring;
                    sysdata::getInstance()->netinfo.ip = v;
                }
                break;
            }
            case evGateWay:
            {
                if("0" == sysdata::getInstance()->netinfo.dhcpEnabled)
                {
                    string v = cJSON_GetObjectItem(itemRoot,itemV)->valuestring;
                    sysdata::getInstance()->netinfo.gateway = v;
                }
                break;
            }
            case evSubnetMask:
            {
                if("0" == sysdata::getInstance()->netinfo.dhcpEnabled)
                {
                    string v = cJSON_GetObjectItem(itemRoot,itemV)->valuestring;
                    sysdata::getInstance()->netinfo.netmask = v;
                }
                break;
            }
            case evDnsServer:
            {
                if("0" == sysdata::getInstance()->netinfo.dhcpEnabled)
                {
                    string v = cJSON_GetObjectItem(itemRoot,itemV)->valuestring;
                    sysdata::getInstance()->netinfo.dnsServer1 = v;
                }
                _networkinfo ip = sysdata::getInstance()->netinfo;
                setIpAddress(ip, true);
                getIpAddress(NULL, true);
                break;
            }
            case evUserName:
            {
                string v = cJSON_GetObjectItem(itemRoot,itemV)->valuestring;
                if((1==sysdata::getInstance()->mLoginInfo.mStatus))
                {
                    if(v != sysdata::getInstance()->mLoginInfo.mUserName)
                    {
//                        cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(400));
                        sysdata::getInstance()->mLoginInfo.mUserName = v;
//                        cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(408));
//                        sysdata::getInstance()->updateLoginInfo(sysdata::getInstance()->mLoginInfo);
//                        sysdata::getInstance()->mToken = Tools::getInstanc()->getRandom();
                    }
                }
            }break;
            case evPasswd:
            {
                string v = cJSON_GetObjectItem(itemRoot,itemV)->valuestring;
                if(NULL == cJSON_GetObjectItem(retJson,"status"))
                {
                    if( v == sysdata::getInstance()->mLoginInfo.mUserPasswd)
                    {
                        cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(407));
                    }
                    else if(0 != v.size())
                    {
                        sysdata::getInstance()->mLoginInfo.mUserPasswd = v;
                        cJSON_AddItemToObject(retJson, "status", cJSON_CreateNumber(408));
                        sysdata::getInstance()->updateLoginInfo(sysdata::getInstance()->mLoginInfo);
                        sysdata::getInstance()->mToken = Tools::getInstanc()->getRandom();
                    }
                }
            }
                break;

            default:
                DEBUG_LOG("unknow data...");
                break;
            }
        }
    }

    WSHandle::getInstance()->sendSystemConfigPageInfo(retJson);
}

string SystemConfigHandle::backUpHandleFun()
{
    if(0 == (access(BACKUP_ALL,F_OK)))
        return string(BACKUP_ALL);

    string head = (8 == CHANNELS)?"NJHSCONTROL4_BACKUP8":"NJHSCONTROL4_BACKUP16";
    char endMark = 0;
    std::ofstream fout(BACKUP_ALL, std::ios::binary);
    fout.write(head.c_str(), sizeof(char) * (head.size()));
    fout.write(&endMark, sizeof(char));
    string md5Str;

    //input
    writeBinary(fout,md5Str,to_string(CHANNELS));
    for(int i = 0; i< CHANNELS;i++)
    {
        writeBinary(fout, md5Str, to_string(i));
        //writeBinary(fout, md5Str, sysdata::getInstance()->mWebInfo.inputname[i].c_str());
        writeBinary(fout, md5Str, to_string(sysdata::getInstance()->dspdata[i].dsp[ENUM_Inputvolume]));
        writeBinary(fout, md5Str, to_string(sysdata::getInstance()->dspdata[i].dsp[ENUM_Inputdelay]));
        //writeBinary(fout, md5Str, "0"); //Signal sence
    }
    writeBinary(fout, md5Str,to_string(sysdata::getInstance()->devicedata.audiosens));

    //output
    writeBinary(fout,md5Str,to_string(CHANNELS));
    for(int i = 0; i< CHANNELS;i++)
    {
        writeBinary(fout, md5Str, to_string(i));
        //writeBinary(fout, md5Str, sysdata::getInstance()->mWebInfo.outputname[i].c_str());
        writeBinary(fout, md5Str, to_string(sysdata::getInstance()->dspdata[i].dsp[ENUM_Outputsource]));
        writeBinary(fout, md5Str, to_string(sysdata::getInstance()->dspdata[i].dsp[ENUM_outputdelay]));

        if(1 == sysdata::getInstance()->dspdata[i].dsp[ENUM_merge])
            writeBinary(fout, md5Str, "1");
        else
            writeBinary(fout, md5Str, "0");

        writeBinary(fout, md5Str, to_string(sysdata::getInstance()->dspdata[i].dsp[ENUM_dspmute]));
        writeBinary(fout, md5Str, to_string(sysdata::getInstance()->dspdata[i].dsp[ENUM_volume]));
        writeBinary(fout, md5Str, to_string(sysdata::getInstance()->dspdata[i].dsp[ENUM_maxvolume]));
        writeBinary(fout, md5Str, to_string(sysdata::getInstance()->dspdata[i].dsp[ENUM_balance]));
        writeBinary(fout, md5Str, to_string(sysdata::getInstance()->dspdata[i].dsp[ENUM_oscgain]));// testSingal volume
        writeBinary(fout, md5Str, sysdata::getInstance()->mWebInfo.assigntrigger[i].c_str());     //Assign Trigger

        //Tone Control
        writeBinary(fout, md5Str, sysdata::getInstance()->mOutputDspInfo[i].mOutputToneBass);
        writeBinary(fout, md5Str, sysdata::getInstance()->mOutputDspInfo[i].mOutputToneTreble);
        writeBinary(fout, md5Str, sysdata::getInstance()->mOutputDspInfo[i].mOutputLoudnessEN);
        writeBinary(fout, md5Str, sysdata::getInstance()->mOutputDspInfo[i].mOutputToneBassEN);
        writeBinary(fout, md5Str, sysdata::getInstance()->mOutputDspInfo[i].mOutputToneBassFreq);
        writeBinary(fout, md5Str, sysdata::getInstance()->mOutputDspInfo[i].mOutputToneBassQ);
        writeBinary(fout, md5Str, sysdata::getInstance()->mOutputDspInfo[i].mOutputToneTrebleEN);
        writeBinary(fout, md5Str, sysdata::getInstance()->mOutputDspInfo[i].mOutputToneTrebleFreq);
        writeBinary(fout, md5Str, sysdata::getInstance()->mOutputDspInfo[i].mOutputToneTrebleQ);

        if(1 ==(i%2))
        {
            writeBinary(fout,md5Str, sysdata::getInstance()->mSubDspInfo[i].mSubDspEnable);
            writeBinary(fout,md5Str, sysdata::getInstance()->mSubDspInfo[i].mSubVolOffset);
            writeBinary(fout,md5Str, sysdata::getInstance()->mSubDspInfo[i].mSubCrossoverType);
            writeBinary(fout,md5Str, sysdata::getInstance()->mSubDspInfo[i].mSubCrossoverSlop);
            writeBinary(fout,md5Str, sysdata::getInstance()->mSubDspInfo[i].mSubCrossoverFreq);
        }

        writeBinary(fout,md5Str,sysdata::getInstance()->mOutputDspInfo[i].mOutputRoomDspPreset);
        writeBinary(fout,md5Str,sysdata::getInstance()->mOutputDspInfo[i].mOutputSpeakerDspPreset);
    }


    //Room Dsp size
    int roomSize = sysdata::getInstance()->mRoomDspVecInfo.size();
    writeBinary(fout,md5Str,to_string(roomSize));

    for(int n = 0; n < sysdata::getInstance()->mRoomDspVecInfo.size(); n++)
    {
        _roomDspPresetItemInfo tmp = sysdata::getInstance()->mRoomDspVecInfo[n];
        writeBinary(fout,md5Str,tmp.mRoomDspIndex);
        writeBinary(fout,md5Str,tmp.mRoomDspName);

        for(int i = 0; i< MAX_EQ_NUM;i++)
        {
            writeBinary(fout,md5Str,tmp.mRoomEqIndex[i]);
            writeBinary(fout,md5Str,tmp.mRoomEqEnable[i]);
            writeBinary(fout,md5Str,tmp.mRoomEqFreq[i]);
            writeBinary(fout,md5Str,tmp.mRoomEqQratio[i]);
            writeBinary(fout,md5Str,tmp.mRoomEqGain[i]);
        }
    }

    //Speaker Dsp size
    int speakerSize = sysdata::getInstance()->mSpeakerDspMapInfo.size();
    writeBinary(fout,md5Str,to_string(speakerSize));

    SPEAKER_PRESET_MAP::iterator it;
    for(it=sysdata::getInstance()->mSpeakerDspMapInfo.begin();it !=sysdata::getInstance()->mSpeakerDspMapInfo.end();it++)
    {
        _speakerDspPresetItemInfo tmp = it->second;
        writeBinary(fout,md5Str,tmp.mSpeakerDspIndex);
        writeBinary(fout,md5Str,tmp.mSpeakerDspName);

        for(int i = 0; i< MAX_EQ_NUM;i++)
        {
            writeBinary(fout,md5Str,tmp.mSpeakerEqIndex[i]);
            writeBinary(fout,md5Str,tmp.mSpeakerEqEnable[i]);
            writeBinary(fout,md5Str,tmp.mSpeakerEqFreq[i]);
            writeBinary(fout,md5Str,tmp.mSpeakerEqQratio[i]);
            writeBinary(fout,md5Str,tmp.mSpeakerEqGain[i]);
        }
    }


    char md5Value[64]={0};
    Md5String((unsigned char*)(md5Str.c_str()), md5Str.size(), md5Value);
    string md5_value = md5Value;
    writeBinary(fout, md5Str, md5_value);

    fout.close();

    return string(BACKUP_ALL);

}

S_ret SystemConfigHandle::restoreHandleFun(string fileName, string md5FileValue)
{
    string mFileName = "/tmp/" + fileName;
    if(-1 == (access(mFileName.c_str(),F_OK)))
    {
        return IMPORT_FILE_NOT_EXIST;
    }

    char md5File[64]={0};
    if(0 == Md5File(mFileName.c_str(),md5File))
    {
        if(md5FileValue != string(md5File))
        {
            remove(mFileName.c_str());
            return IMPORT_MD5_FILE_ERROR;
        }
    }
    char *readBuf,*p;

    unsigned int nfileSize = 0;
    std::ifstream fin(mFileName.c_str(), std::ios::binary);
    fin.seekg(0, ios::end);
    nfileSize = fin.tellg();
    fin.seekg(ios::beg);
    readBuf = (char*)malloc(nfileSize);
    fin.read(readBuf, sizeof(char) * nfileSize);
    p = readBuf;
    string head = p+1;
    p = p + strlen(p) + 1;
//    if(0 != head.compare((8 == CHANNELS)?"NJHSCONTROL4_BACKUP8":"NJHSCONTROL4_BACKUP16"))
//    {
//        free(readBuf);
//        remove(mFileName.c_str());
//        return IMPORT_TYPE_ERROR;
//    }
    string backName = "NJHSCONTROL4_BACKUP8";
    if(8 < CHANNELS){
        backName = "NJHSCONTROL4_BACKUP16";
    }
    string::size_type idx;
    idx = head.find(backName);
    if(idx == string::npos){
        DEBUG_LOG("restoreHandleFun error!!!");
        free(readBuf);
        remove(mFileName.c_str());
        return IMPORT_TYPE_ERROR;
    }

    string md5Check;

    //input info
    string tChannels;
    readBinary(tChannels,md5Check,&p);

    string tindex;

    DSPstreaming dspdataTmp[CHANNELS];
    for(int i = 0; i < stoi(tChannels); i++)
    {
        string inputVol,inputDelay;
        readBinary(tindex, md5Check, &p);
        //readBinary(sysdata::getInstance()->mWebInfo.inputname[i], md5Check, &p);
        readBinary(inputVol, md5Check, &p);
        dspdataTmp[i].dsp[ENUM_Inputvolume] = stoi(inputVol);
        readBinary(inputDelay, md5Check, &p);
        dspdataTmp[i].dsp[ENUM_Inputdelay] = stoi(inputDelay);
    }

    string signalSense;
    readBinary(signalSense, md5Check,&p);
    //sysdata::getInstance()->devicedata.audiosens = stoi(signalSense);

    //output info
    _outputDspInfo outputDspInfoTmp[CHANNELS];
    _subDspInfo subDspInfoTmp[CHANNELS];
    readBinary(tChannels,md5Check,&p);
    for(int i = 0; i < stoi(tChannels); i++)
    {
        readBinary(tindex, md5Check, &p);
        //readBinary(sysdata::getInstance()->mWebInfo.outputname[i], md5Check, &p);readBinary(sysdata::getInstance()->mWebInfo.inputname[i], md5Check, &p);

        string outputsource,outputDelay;
        readBinary(outputsource, md5Check,&p);
        dspdataTmp[i].dsp[ENUM_Outputsource] = stoi(outputsource);
        readBinary(outputDelay, md5Check,&p);
        dspdataTmp[i].dsp[ENUM_outputdelay] = stoi(outputDelay);

        string outputmerge;
        readBinary(outputmerge, md5Check,&p);
        dspdataTmp[i].dsp[ENUM_merge] = stoi(outputmerge);

        string outputmute;
        readBinary(outputmute, md5Check,&p);
        dspdataTmp[i].dsp[ENUM_dspmute] = stoi(outputmute);

        string outputvol;
        readBinary(outputvol, md5Check,&p);
        dspdataTmp[i].dsp[ENUM_volume] = stoi(outputvol);

        string outputmaxvol;
        readBinary(outputmaxvol, md5Check,&p);
        dspdataTmp[i].dsp[ENUM_maxvolume] = stoi(outputmaxvol);

        string outputbalance;
        readBinary(outputbalance, md5Check,&p);
        dspdataTmp[i].dsp[ENUM_balance] = stoi(outputbalance);

        string outputTestSignalVolume;
        readBinary(outputTestSignalVolume, md5Check,&p);
        dspdataTmp[i].dsp[ENUM_oscgain] = stoi(outputTestSignalVolume);

        readBinary(sysdata::getInstance()->mWebInfo.assigntrigger[i], md5Check, &p);


        //Tone Control
        readBinary(outputDspInfoTmp[i].mOutputToneBass, md5Check, &p);
        readBinary(outputDspInfoTmp[i].mOutputToneTreble, md5Check, &p);
        readBinary(outputDspInfoTmp[i].mOutputLoudnessEN, md5Check, &p);
        readBinary(outputDspInfoTmp[i].mOutputToneBassEN, md5Check, &p);
        readBinary(outputDspInfoTmp[i].mOutputToneBassFreq, md5Check, &p);
        readBinary(outputDspInfoTmp[i].mOutputToneBassQ, md5Check, &p);
        readBinary(outputDspInfoTmp[i].mOutputToneTrebleEN, md5Check, &p);
        readBinary(outputDspInfoTmp[i].mOutputToneTrebleFreq, md5Check, &p);
        readBinary(outputDspInfoTmp[i].mOutputToneTrebleQ, md5Check, &p);


        if(1 ==(i%2))
        {
            readBinary(subDspInfoTmp[i].mSubDspEnable, md5Check, &p);
            readBinary(subDspInfoTmp[i].mSubVolOffset, md5Check, &p);
            readBinary(subDspInfoTmp[i].mSubCrossoverType, md5Check, &p);
            readBinary(subDspInfoTmp[i].mSubCrossoverSlop, md5Check, &p);
            readBinary(subDspInfoTmp[i].mSubCrossoverFreq, md5Check, &p);
        }

        readBinary(outputDspInfoTmp[i].mOutputRoomDspPreset, md5Check, &p);
        readBinary(outputDspInfoTmp[i].mOutputSpeakerDspPreset, md5Check, &p);
    }

    //Room
    string roomSize;
    readBinary(roomSize,md5Check,&p);

    vector<_roomDspPresetItemInfo> tmpVec;
    for(int i = 0; i < stoi(roomSize); i++)
    {
        tmpVec.push_back(sysdata::getInstance()->mRoomDspVecInfo[i]);
        _roomDspPresetItemInfo tmp;

        readBinary(tmp.mRoomDspIndex,md5Check,&p);
        readBinary(tmp.mRoomDspName,md5Check,&p);

        for(int i = 0;i < MAX_EQ_NUM; i++)
        {
            readBinary(tmp.mRoomEqIndex[i],md5Check,&p);
            readBinary(tmp.mRoomEqEnable[i],md5Check,&p);
            readBinary(tmp.mRoomEqFreq[i],md5Check,&p);
            readBinary(tmp.mRoomEqQratio[i],md5Check,&p);
            readBinary(tmp.mRoomEqGain[i],md5Check,&p);
        }
        tmpVec[i] = tmp;
    }

    //Speaker
    string speakerSize;
    readBinary(speakerSize,md5Check,&p);

    SPEAKER_PRESET_MAP tmpSpeaker;
    for(int i = 0; i < stoi(speakerSize); i++)
    {
        _speakerDspPresetItemInfo tmp;
        readBinary(tmp.mSpeakerDspIndex,md5Check,&p);
        readBinary(tmp.mSpeakerDspName,md5Check,&p);

        for(int i = 0;i < MAX_EQ_NUM; i++)
        {
            readBinary(tmp.mSpeakerEqIndex[i],md5Check,&p);
            readBinary(tmp.mSpeakerEqEnable[i],md5Check,&p);
            readBinary(tmp.mSpeakerEqFreq[i],md5Check,&p);
            readBinary(tmp.mSpeakerEqQratio[i],md5Check,&p);
            readBinary(tmp.mSpeakerEqGain[i],md5Check,&p);
        }
        tmpSpeaker[i+1] = tmp;
    }

    string md5V;
    md5V = p;
    //p = p + strlen(p) + 1;

    char md5Str_value[64]={0};
    Md5String((unsigned char*)(md5Check.c_str()),md5Check.size(),md5Str_value);

    LOGOUT("Import Md5Value: %s ",md5Str_value);
    if(md5V == string(md5Str_value))
    {
        for(int i = 0; i < stoi(tChannels); i++)
        {
            sysdata::getInstance()->dspdata[i].dsp[ENUM_Inputvolume] = dspdataTmp[i].dsp[ENUM_Inputvolume];
            sysdata::getInstance()->dspdata[i].dsp[ENUM_Inputdelay] = dspdataTmp[i].dsp[ENUM_Inputdelay];
        }
        sysdata::getInstance()->devicedata.audiosens = stoi(signalSense);

        //output info
        for(int i = 0; i < stoi(tChannels); i++)
        {
            sysdata::getInstance()->dspdata[i].dsp[ENUM_Outputsource] = dspdataTmp[i].dsp[ENUM_Outputsource];

            sysdata::getInstance()->dspdata[i].dsp[ENUM_outputdelay] = dspdataTmp[i].dsp[ENUM_outputdelay];
            sysdata::getInstance()->dspdata[i].dsp[ENUM_merge] = dspdataTmp[i].dsp[ENUM_merge];
            sysdata::getInstance()->dspdata[i].dsp[ENUM_dspmute] = dspdataTmp[i].dsp[ENUM_dspmute];
            sysdata::getInstance()->dspdata[i].dsp[ENUM_volume] = dspdataTmp[i].dsp[ENUM_volume];
            sysdata::getInstance()->dspdata[i].dsp[ENUM_maxvolume] = dspdataTmp[i].dsp[ENUM_maxvolume];
            sysdata::getInstance()->dspdata[i].dsp[ENUM_balance] = dspdataTmp[i].dsp[ENUM_balance];
            sysdata::getInstance()->dspdata[i].dsp[ENUM_oscgain] = dspdataTmp[i].dsp[ENUM_oscgain];

            //Tone Control
            sysdata::getInstance()->mOutputDspInfo[i].mOutputToneBass = outputDspInfoTmp[i].mOutputToneBass;
            sysdata::getInstance()->updateDataBaseTable("outputDspInfo", "output_tone_bass", outputDspInfoTmp[i].mOutputToneBass, to_string(i));

            sysdata::getInstance()->mOutputDspInfo[i].mOutputToneTreble = outputDspInfoTmp[i].mOutputToneTreble;
            sysdata::getInstance()->updateDataBaseTable("outputDspInfo", "output_tone_treble", outputDspInfoTmp[i].mOutputToneTreble, to_string(i));

            sysdata::getInstance()->mOutputDspInfo[i].mOutputLoudnessEN = outputDspInfoTmp[i].mOutputLoudnessEN;
            sysdata::getInstance()->updateDataBaseTable("outputDspInfo", "output_loudness_enable", outputDspInfoTmp[i].mOutputLoudnessEN, to_string(i));

            sysdata::getInstance()->mOutputDspInfo[i].mOutputToneBassEN = outputDspInfoTmp[i].mOutputToneBassEN;
            sysdata::getInstance()->updateDataBaseTable("outputDspInfo", "output_tone_bass", outputDspInfoTmp[i].mOutputToneBassEN, to_string(i));

            sysdata::getInstance()->mOutputDspInfo[i].mOutputToneBassFreq = outputDspInfoTmp[i].mOutputToneBassFreq;
            sysdata::getInstance()->updateDataBaseTable("outputDspInfo", "output_tone_bass", outputDspInfoTmp[i].mOutputToneBassFreq, to_string(i));

            sysdata::getInstance()->mOutputDspInfo[i].mOutputToneBassQ = outputDspInfoTmp[i].mOutputToneBassQ;
            sysdata::getInstance()->updateDataBaseTable("outputDspInfo", "output_tone_bass", outputDspInfoTmp[i].mOutputToneBassQ, to_string(i));

            sysdata::getInstance()->mOutputDspInfo[i].mOutputToneTrebleEN = outputDspInfoTmp[i].mOutputToneTrebleEN;
            sysdata::getInstance()->updateDataBaseTable("outputDspInfo", "output_tone_treble", outputDspInfoTmp[i].mOutputToneTrebleEN, to_string(i));

            sysdata::getInstance()->mOutputDspInfo[i].mOutputToneTrebleFreq = outputDspInfoTmp[i].mOutputToneTrebleFreq;
            sysdata::getInstance()->updateDataBaseTable("outputDspInfo", "output_tone_treble", outputDspInfoTmp[i].mOutputToneTrebleFreq, to_string(i));

            sysdata::getInstance()->mOutputDspInfo[i].mOutputToneTrebleQ = outputDspInfoTmp[i].mOutputToneTrebleQ;
            sysdata::getInstance()->updateDataBaseTable("outputDspInfo", "output_tone_treble", outputDspInfoTmp[i].mOutputToneTrebleQ, to_string(i));

            if(1 ==(i%2))
            {
                sysdata::getInstance()->mSubDspInfo[i].mSubDspEnable=subDspInfoTmp[i].mSubDspEnable;
                sysdata::getInstance()->updateDataBaseTable("subDspInfo", "sub_enable", subDspInfoTmp[i].mSubDspEnable, to_string(i));

                sysdata::getInstance()->mSubDspInfo[i].mSubVolOffset=subDspInfoTmp[i].mSubVolOffset;
                sysdata::getInstance()->updateDataBaseTable("subDspInfo", "sub_volume_offset", subDspInfoTmp[i].mSubVolOffset, to_string(i));

                sysdata::getInstance()->mSubDspInfo[i].mSubCrossoverType=subDspInfoTmp[i].mSubCrossoverType;
                sysdata::getInstance()->updateDataBaseTable("subDspInfo", "sub_crossover_type", subDspInfoTmp[i].mSubCrossoverType, to_string(i));

                sysdata::getInstance()->mSubDspInfo[i].mSubCrossoverSlop=subDspInfoTmp[i].mSubCrossoverSlop;
                sysdata::getInstance()->updateDataBaseTable("subDspInfo", "sub_crossover_slop", subDspInfoTmp[i].mSubCrossoverSlop, to_string(i));

                sysdata::getInstance()->mSubDspInfo[i].mSubCrossoverFreq=subDspInfoTmp[i].mSubCrossoverFreq;
                sysdata::getInstance()->updateDataBaseTable("subDspInfo", "sub_crossover_freq", subDspInfoTmp[i].mSubCrossoverFreq, to_string(i));

            }

            sysdata::getInstance()->mOutputDspInfo[i].mOutputRoomDspPreset = outputDspInfoTmp[i].mOutputRoomDspPreset;
            sysdata::getInstance()->mOutputDspInfo[i].mOutputSpeakerDspPreset = outputDspInfoTmp[i].mOutputSpeakerDspPreset;
        }

        //Room info
        for(int i = 0; i < tmpVec.size(); i++)
        {
            sysdata::getInstance()->mRoomDspVecInfo[i] = tmpVec[i];
            sysdata::getInstance()->updateDataBasePresetInfoTable(to_string(i),true);
        }

        //Speaker info
        sysdata::getInstance()->mSpeakerDspMapInfo.erase(sysdata::getInstance()->mSpeakerDspMapInfo.begin(),sysdata::getInstance()->mSpeakerDspMapInfo.end());
        for(int n = 0; n < tmpSpeaker.size(); n++)
        {
            sysdata::getInstance()->mSpeakerDspMapInfo[n+1] = tmpSpeaker[n+1];
        }
        sysdata::getInstance()->importAllSpeakerPresetInfoTable();
        sysdata::getInstance()->ExeSet();
    }
    else
    {
        free(readBuf);
        remove(mFileName.c_str());
        return IMPORT_MD5_STRING_ERROR;
    }

    free(readBuf);
    remove(mFileName.c_str());
    return SUCESS;
}

void SystemConfigHandle::setNetWorkDhcpEnable()
{
    if("0" == sysdata::getInstance()->netinfo.dhcpEnabled)
    {
        char cmd[1024];
        sprintf(cmd, "snapav_network_config.sh dhcp");
        DEBUG_LOG("modify network info[%s]" , cmd );
        system(cmd);
        //sysdata::getInstance()->updateNetWorkInfo();
        Tools::getInstanc()->getNetStatus(sysdata::getInstance()->netinfo, "eth0");
        subject::GetInstance().Notify(DEVICE_NET_INFO);

        sysdata::getInstance()->netinfo.dhcpEnabled = "1";
    }
}

void SystemConfigHandle::getSystemConfigPageInfo(cJSON *retJson)
{
    cJSON *configuresInfo =  cJSON_CreateObject();
    cJSON *systemSettingInfo = cJSON_CreateObject();
    cJSON *ipSettingInfo = cJSON_CreateObject();

    //Tools::getInstanc()->getNetStatus(sysdata::getInstance()->netinfo, "eth0");
    cJSON_AddItemToObject(systemSettingInfo,"deviceName",cJSON_CreateString(sysdata::getInstance()->deviceinfo.devicename.c_str()));
    cJSON_AddItemToObject(systemSettingInfo,"modelName",cJSON_CreateString(sysdata::getInstance()->deviceinfo.devicemodel.c_str()));
    cJSON_AddItemToObject(systemSettingInfo,"macAddress",cJSON_CreateString(sysdata::getInstance()->netinfo.mac.c_str()));
    cJSON_AddItemToObject(systemSettingInfo,"firmwareVersion",cJSON_CreateString(sysdata::getInstance()->deviceinfo.firmware.c_str()));
    cJSON_AddItemToObject(systemSettingInfo,"serviceTag",cJSON_CreateString(sysdata::getInstance()->deviceinfo.serialnumber.c_str()));


    cJSON_AddItemToObject(ipSettingInfo,"dhcp_enable",cJSON_CreateString(sysdata::getInstance()->netinfo.dhcpEnabled.c_str()));
    cJSON_AddItemToObject(ipSettingInfo,"ipAddress",cJSON_CreateString(sysdata::getInstance()->netinfo.ip.c_str()));
    cJSON_AddItemToObject(ipSettingInfo,"gateway",cJSON_CreateString(sysdata::getInstance()->netinfo.gateway.c_str()));
    cJSON_AddItemToObject(ipSettingInfo,"subnetMask",cJSON_CreateString(sysdata::getInstance()->netinfo.netmask.c_str()));
    cJSON_AddItemToObject(ipSettingInfo,"dnsServer",cJSON_CreateString(sysdata::getInstance()->netinfo.dnsServer1.c_str()));

    cJSON_AddItemToObject(configuresInfo,"system_settings",systemSettingInfo);
    cJSON_AddItemToObject(configuresInfo,"ip_settings",ipSettingInfo);

    cJSON_AddItemToObject(retJson,"configures",configuresInfo);
}

