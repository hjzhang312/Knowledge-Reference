#include "button.h"
#include <linux/input.h>
#include <sys/epoll.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <fcntl.h>
#include "log.h"
#include <time.h>
#include <signal.h>
#include <sys/reboot.h>
#include "ledmisc.h"
#include "tools.h"
#include "sysdata.h"
#include "systemconfighandle.h"
#define EPOLLSIZE 10
#define TIMEWAIT -1

void sig_alrm(int)
{
 // reboot(RB_AUTOBOOT);
    DEBUG_LOG("System reboot");
    system("reboot");
}

Button::Button()
{
     pidofsddp=0;
     button_fd = open("/dev/input/event0",O_RDONLY);
        if(button_fd < 0 ){
            DEBUG_LOG("failed to open /dev/input/event0");
            return;
        }
        if(signal(SIGALRM,sig_alrm) == SIG_ERR){  //信号注册函数
              DEBUG_LOG("signal error");
             }




      // LOGOUT("Tools::getInstanc()->myexec  : %s ",tmpbuf.at(0).c_str());


         IDkeyPress=0;
         RebootPress=0;
}



void Button::run()
{
   time_t t1= time(NULL);
   time_t t2=time(NULL);
   vector <string> tmpbuf;
    while(true){
        struct input_event t;
        read(button_fd,&t,sizeof t);
        DEBUG_LOG("Button id: 0x%x",t.code);
        if(t.code==0x64)
        {
            if(t.value)
            {
                t1= time(NULL);
                alarm(5);
            }
            else
            {

                if(difftime (time(NULL),t1)<=1)
                {
                     DEBUG_LOG("Id Button:%f",difftime ( time(NULL),t1));//Initiate SDDP identification

                     tmpbuf.clear();
                     Tools::getInstanc()->myexec("pidof sddpd",tmpbuf);
                     if(tmpbuf.size()>0)
                     {
                         pidofsddp=atoi(tmpbuf.at(0).c_str());
                         LOGOUT("sddp pid:%d",pidofsddp);
                         if(pidofsddp)
                         {
                             kill(pidofsddp,SIGUSR1);
                             LEDMISC::getInstance()->SetIdentify(15);
                         }
                     }

                }
//                if(difftime (time(NULL),t1)>5)
//                {
//                     DEBUG_LOG("<2:%f",difftime ( time(NULL),t1));
                  //   system("reboot");//reboot
//                }
                alarm(0);

            }
        }
        else if(t.code==0x65)
        {
#if 0
            if(t.value)
            {
                t2= time(NULL);
            }
            else
            {
                if(difftime (time(NULL),t2)>4)
                {
                    sysdata::getInstance()->FactoryDefault();
                    sysdata::getInstance()->ExeSet();
                    LEDMISC::getInstance()->SetFactory(15);
                }

            }
#endif
            if(1 == t.value)
            {
                t2= time(NULL);
            }
            else
            {
                float tin = difftime(time(NULL),t2);
                DEBUG_LOG("button continue time:%f ",tin);
                if(tin >= 10)
                {
                    sysdata::getInstance()->resetDevice();
                }
                else if(tin >= 5)
                {
                    SystemConfigHandle::getInstance()->setNetWorkDhcpEnable();
                }
                else if(tin <= 2)
                {
                    sysdata::getInstance()->rebootDevice();
                }

            }
        }

       // DEBUG_LOG("read fd: %d event code: 0x%x value: %d",button_fd,t.code,t.value);
    }

}
