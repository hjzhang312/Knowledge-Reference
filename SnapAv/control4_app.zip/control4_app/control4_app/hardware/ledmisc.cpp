#include "ledmisc.h"
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/ioctl.h>
#include "log.h"
#include "common.h"


#define LEDPATH "/dev/led"
#define AnmaPATH "/dev/boot_animation"




#define LEDR        0x1000
#define LEDB        0x1001
#define LEDG        0x1002
#define LEDBlue     0x1003
#define LEDBlueDim  0x1004
#define TrigerASG   0x2000
#define TrigerZoon  0x2001

#define LEDWhite    0x3000


void LEDMISC::ledOpen()
{
    ledfd = open( LEDPATH , O_RDWR );
    if(ledfd<0)
    {
        LOGOUT("ledmisc:failed to open ! please check!!!");
    }
    else
    {
        LOGOUT("ledmisc open");
    }
    animationfd = open( AnmaPATH , O_RDWR );
    if(animationfd<0)
    {
        LOGOUT("animationfd:failed to open ! please check!!!");
    }
    else
    {
        ioctl(animationfd,LEDWhite,0);
        LOGOUT("animationfd open");
    }

}
void LEDMISC::SetPower(int power)
{
  Gled.Power=power;

  if(power)
  {
      Gled.Booting=1;
  }
}

void LEDMISC::LedTest(int test)
{
    Gled.Test=test;
    if(test==0)
    {
        memset(&Currentled, 0, sizeof(struct LedStr));
    }
}

void LEDMISC::SetBoot(int boot)
{
    if(boot==1)
    {
        Gled.Booting=1;
    }
    else
    {
        Gled.Booting=0;
    }
}
void LEDMISC::SetNetWork(int net)
{
    Gled.Iperror=!net;
    if(Gled.Iperror)
    {
       Gled.Connected=0;
    }
}

void LEDMISC::SetUpgrade(int upgrade)
{
    Gled.Upgrade=upgrade;
}

void LEDMISC::SetOutActive(int active)
{
    Gled.Output=active;
}

void LEDMISC::SetConnectd(int con)
{
    Gled.Connected=con;
}

void LEDMISC::SetIdentify(int time)
{
    Gled.SddpId=time;
}

void LEDMISC::SetFactory(int time)
{
    Gled.Restore=time;
}

void LEDMISC::SetZoon(int zoon,int set)
{
    if(zoon<CHANNELS/8)
    {
        ioctl(ledfd,TrigerZoon+zoon,set);
    }
}
void LEDMISC::SetAsg(int set)
{
    ioctl(ledfd,TrigerASG,set);
}
LEDMISC::LEDMISC()
{
  Gled.Power=1;
  Gled.Test=0;
  Gled.System=DeviceBooting;//DeviceBootCompleted;
  Gled.White=DeviceBooting;//DeviceBootCompleted;
  Gled.Booting=1; //0
  Gled.Output=0;
  Gled.Connected=0;
  Gled.SddpId=0;
  Gled.Restore=0;
  Gled.White=1;
  Gled.Iperror=0;
  Currentled.Power=0;
  Currentled.System=0;
  Currentled.Output=0;
  Currentled.Connected=0;
  Currentled.SddpId=0;
  Currentled.Restore=0;
  Currentled.White=0;

  ledOpen();
  //LOGOUT("LED:%x,%d,%d",(unsigned int)&Gled.power,ledfd,animationfd);
}

void LEDMISC::LEDBooting(void)//100ms
{
  static unsigned int count=0;
  count++;
  if(count==5)
  {
      ioctl(animationfd,LEDWhite,1);
      //ioctl(ledfd,LEDB,1);
      //ioctl(ledfd,LEDG,0);
      //ioctl(ledfd,LEDR,0);
  }
  else if(count>=10)
  {
      ioctl(animationfd,LEDWhite,0);
      //ioctl(ledfd,LEDB,0);
      //ioctl(ledfd,LEDG,0);
      //ioctl(ledfd,LEDR,0);
      count=0;
  }
}
void LEDMISC::LEDIpErr()//100ms
{
  static unsigned int count=0;
  count++;
  if(count==10)
  {
      ioctl(ledfd,LEDR,1);
      ioctl(ledfd,LEDG,1);
  }
  else if(count>=20)
  {
      ioctl(ledfd,LEDR,0);
      ioctl(ledfd,LEDG,0);
      count=0;
  }
}
void LEDMISC::LEDupdating()
{
    static unsigned int count=0;
    count++;
    if(count==2)
    {
        ioctl(ledfd,LEDB,1);
    }
    else if(count>=5)
    {
        ioctl(ledfd,LEDB,0);
        count=0;

    }
}
void LEDMISC::LEDupError()
{
    static unsigned int count=0;
    count++;
    if(count==2)
    {
        ioctl(ledfd,LEDR,1);
    }
    else if(count>=5)
    {
        ioctl(ledfd,LEDR,0);
        count=0;
    }
}
void LEDMISC::LEDRestore()//100ms
{
  static unsigned int count=0;
  count++;
  if(count==1)
  {
      ioctl(animationfd,LEDWhite,0);
  }
  else if(count>=2)
  {
      ioctl(animationfd,LEDWhite,1);
      count=0;
  }
}

void LEDMISC::Ledtestblink()
{
    ioctl(ledfd,LEDBlue,0);
    ioctl(ledfd,LEDBlueDim,0);
    ioctl(animationfd,LEDWhite,0);
    ioctl(ledfd,LEDR,0);
    ioctl(ledfd,LEDG,0);
    ioctl(ledfd,LEDB,0);
    usleep(1000*100);if(!Gled.Test) goto exit;
    ioctl(ledfd,LEDBlueDim,1);
    usleep(1000*1000);if(!Gled.Test) goto exit;
    ioctl(ledfd,LEDBlueDim,0);
    ioctl(ledfd,LEDBlue,1);
    usleep(1000*1000);if(!Gled.Test) goto exit;
    ioctl(ledfd,LEDBlue,0);
    ioctl(animationfd,LEDWhite,1);
    usleep(1000*1000);if(!Gled.Test) goto exit;
    ioctl(animationfd,LEDWhite,0);
    ioctl(ledfd,LEDR,1);
    usleep(1000*1000);if(!Gled.Test) goto exit;
    ioctl(ledfd,LEDR,0);
    ioctl(ledfd,LEDG,1);
    usleep(1000*1000);if(!Gled.Test) goto exit;
    ioctl(ledfd,LEDG,0);
    ioctl(ledfd,LEDB,1);
    usleep(1000*1000);if(!Gled.Test) goto exit;
    return;
exit:
    ioctl(ledfd,LEDBlue,0);
    ioctl(ledfd,LEDBlueDim,0);
    ioctl(animationfd,LEDWhite,0);
    ioctl(ledfd,LEDR,0);
    ioctl(ledfd,LEDG,0);
    ioctl(ledfd,LEDB,0);
}

void LEDMISC::PowerLedTask()
{
    if(Currentled.Power!=Gled.Power)
    {
        Currentled.Power=Gled.Power;
        LOGOUT("Power:%d",Currentled.Power);
        if(Currentled.Power)
        {
            ioctl(ledfd,LEDBlue,1);
            ioctl(ledfd,LEDBlueDim,0);
        }
        else
        {
            ioctl(ledfd,LEDBlueDim,1);
            ioctl(ledfd,LEDBlue,0);
        }
    }
}
void LEDMISC::WhiteLedTask()
{
    if(Currentled.White==DeviceBooting)
    {
       LEDBooting();
    }
    else if(Currentled.White==RestoreFactory)
    {
       LEDRestore();
    }
    if(Currentled.White!=Gled.White)
    {
        LOGOUT("White:current->%d, set->%d",Currentled.White, Gled.White);
        Currentled.White=Gled.White;
        if(Currentled.White==DeviceConnected)
        {
            ioctl(animationfd,LEDWhite,0);
            ioctl(ledfd,LEDR,0);
            ioctl(ledfd,LEDG,0);
            ioctl(ledfd,LEDB,1);
        }
        else if(Currentled.White==DeviceBootCompleted)
        {
            ioctl(animationfd,LEDWhite,0);
        }
        else if(Currentled.White==DeviceOutputactive)
        {
            ioctl(ledfd,LEDR,0);
            ioctl(ledfd,LEDG,0);
            ioctl(ledfd,LEDB,0);
            ioctl(animationfd,LEDWhite,1);
        }
        else
        {
            ioctl(animationfd,LEDWhite,0);
        }

    }
}

void LEDMISC::SystemLedTask()
{
    if(Currentled.System==IPError)
    {
       LEDIpErr();
    }
    else if(Currentled.System==FirmwareUpdating)
    {
       LEDupdating();
    }
    else if(Currentled.System==FirmwareUpdatError)
    {
       LEDupError();
    }
    ////////////////////////////////////////////////////////////
    if(Currentled.System!=Gled.System)
    {
        LOGOUT("System:current->%d, set->%d",Currentled.System, Gled.System);
        Currentled.System=Gled.System;
        if(Currentled.System==DeviceBootCompleted)
        {
            ioctl(ledfd,LEDR,0);
            ioctl(ledfd,LEDG,1);
            ioctl(ledfd,LEDB,0);
        }
#if 1
        else if(Currentled.System==DeviceOutputactive)
        {
            ioctl(ledfd,LEDR,0); //0
            ioctl(ledfd,LEDG,0); //0
            ioctl(ledfd,LEDB,0); //0
        }
#endif
        else if(Currentled.System==SDDPIdentify)
        {
            ioctl(ledfd,LEDR,0);
            ioctl(ledfd,LEDG,1);
            ioctl(ledfd,LEDB,1);
        }
        else if(Currentled.System==DeviceConnected)
        {
            ioctl(ledfd,LEDR,0);
            ioctl(ledfd,LEDG,0);
            ioctl(ledfd,LEDB,1);
        }
        else
        {
            ioctl(ledfd,LEDR,0);
            ioctl(ledfd,LEDG,0);
            ioctl(ledfd,LEDB,0);
        }
    }
}
void LEDMISC::run()
{
    while(1)
    {
        PowerLedTask();
        SystemLedTask();
        WhiteLedTask();

if(Gled.Test)
{
    Ledtestblink();
}
else
{
        if(Gled.Power==0)
        {
            Gled.System=DeviceNull;
        }
        else if(Gled.Upgrade)
        {
            Gled.System=FirmwareUpdating;
        }
        else if(Gled.Booting)
        {
            Gled.System=DeviceBooting;
        }
        else if(Gled.Restore)
        {
            Gled.System=RestoreFactory;
        }
        else if(Gled.Iperror)
        {
            Gled.System=IPError;
            Gled.White=IPError;
        }
        else if(Gled.SddpId)//100
        {
            Gled.System=SDDPIdentify;
            Gled.SddpId--;
        }
        else if(Gled.Output)
        {
           if(Gled.Iperror == 0)
           {
               Gled.System=DeviceOutputactive;
               Gled.White=DeviceOutputactive;
           }
        }
        else if(Gled.Connected)
        {
            if(Gled.Output == 0)
            {
                Gled.System=DeviceConnected;
            }
        }
        else
        {
            Gled.System=DeviceBootCompleted;
        }
        if(Gled.Power==0)
        {
            Gled.White=DeviceNull;
        }
        else if(Gled.Booting)
        {
            Gled.White=DeviceBooting;
        }
        else if (Gled.Restore)
        {
            Gled.White=RestoreFactory;
            Gled.Restore--;
        }
        else if(Gled.Connected)
        {
            if(Gled.Output == 0)
            {
                Gled.White=DeviceConnected;
            }
        }
        else if(Gled.Output)
        {
            if(Gled.Iperror == 0)
            {
                Gled.White=DeviceOutputactive;
            }
        }
        else
        {
            Gled.White=DeviceBootCompleted;
        }
}
        usleep(1000*100);
    }


}
