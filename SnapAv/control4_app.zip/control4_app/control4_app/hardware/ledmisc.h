#ifndef _LEDMISC_H
#define _LEDMISC_H

#include "tinythread.h"


enum DEViceLeds {

    DeviceNull=0,
    DeviceBooting=1,
    DeviceBootCompleted,
    DeviceConnected,
    DeviceOutputactive,
    IPError,
    FirmwareUpdating,
    FirmwareUpdatError,
    SDDPIdentify,
    NetworkReset,
    RestoreFactory,
};
struct LedStr
{
    int Power;
    int System;
    int White;
    int Test;

    ///////////////////////
    int Connected;
    int Output;
    int SddpId;
    int Restore;
    int Iperror;
    int Booting;
    int Upgrade;

};

class LEDMISC : public TinyThread
{
public:
    static LEDMISC *getInstance() {
        static LEDMISC ledT;
        return &ledT;
    }
    void SetPower(int power);
    void SetBoot(int boot);
    void SetIdentify(int time);
    void SetNetWork(int net);
    void SetOutActive(int active);
    void SetUpgrade(int upgrade);
    void SetConnectd(int con);
    void SetFactory(int time);
    void SetZoon(int zoon,int set);
    void SetAsg(int set);
    void LedTest(int test);
    void run();
private:
    LEDMISC();
    int ledfd;
    int animationfd;
    LedStr Gled;
    LedStr Currentled;
    void ledOpen();
    void LEDBooting(void);
    void LEDIpErr();
    void LEDupdating();
    void LEDRestore();
    void LEDupError();

    void PowerLedTask();
    void SystemLedTask();
    void WhiteLedTask();
    void Ledtestblink();
};


#endif // LEDHANDLER_H
