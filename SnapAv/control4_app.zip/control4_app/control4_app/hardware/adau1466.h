#ifndef _ADAU1466_H
#define _ADAU1466_H

#include "common.h"

enum DspFunction {

    funSourceSwitch=0,
    funVolume,
    funDelay,
    funPEQ,
    funShelf,
    funCrossover,
    funMute,
    funMonoSwitch,
    funBalance,
    funLoudness,
    funmaxvolume,
    funoscgain,
    funSignalPresence,
};

enum DSPIOCTL
{
    Back_samplerate=0xa0010000,
    Back_version,
    Back_AudioDetect1,
    Back_AudioDetect2,
    Back_AudioDetectdig,
};

class ADAU1466
{
public:

    ADAU1466();
    void DspInit();
    void DspDeinit();
    unsigned int Signal(int index);
    void Write(unsigned int path,unsigned int fun,unsigned int index,unsigned int *data,unsigned int datalen);
    void Optical(int index,int optical);
    void Loudness(int index,int loud);
    void scgain(int index,int gain);
    void Oscgain(int index,int gain);
    void Inputvolume(int index,unsigned int volume);
    void Outputvolume(int index,unsigned int volume);
    void Outputmaxvolume(int index,unsigned int volume);
    void Inputdelay(int index,unsigned int delay);
    void Outputdelay(int index,unsigned int delay);
    void Mono(int index,unsigned int mon);
    void Mute(int index,unsigned int mute);
    void PeqSet(int index,int type,unsigned int vol);
    void ShelfSet(int index,int type,unsigned int vol);
    void CrossSet(int index,int type,unsigned int vol);
    void BalanceSet(int index, unsigned int gain);
    int  OutSignal(int index);
    int  ReadBack(int index,int page,unsigned int addr);
    int  Spdiflock(int index);
    int  Spdiflockloss(int index);
    void SpdifUmute(int index);
    void DacMute(int index,int mute);
    void LineMute(int mute);
    int  DSPSampleRate(unsigned int index);
    int  DSPVersion(unsigned int index);
    void SetSignalPresence(int index,int threshold,unsigned int releasetime);
private:

    int fd[CHANNELS];
    unsigned int Sigma_8_24(float db);
    void ParamatricEQCalculation(float freq, float q, float boost, unsigned int *data);
    void ToneControlCalculation(float freqT, float boostT, float freqB, float boostB, unsigned int *data);
    void LowPassCalculation(float freq, float gain, unsigned int *data);
    void HighPassCalculation(float freq, float gain, unsigned int *data);
};

#endif // ADAU1466_H
