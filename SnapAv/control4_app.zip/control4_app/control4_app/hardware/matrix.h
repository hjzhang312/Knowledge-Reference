#ifndef _matrix_H
#define _matrix_H

#include "common.h"


class matrix
{
public:
//    static matrix *getInstance() {
//        static matrix s;
//        return &s;
//    }
    void matrixInit();
    void matrixDenit();
    void MatrixSet(int outsource,int insource);
    matrix();
private:

    int fd;

};

#endif // matrix_H
