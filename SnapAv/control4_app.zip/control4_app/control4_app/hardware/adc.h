#ifndef _ADC_H
#define _ADC_H

#include "common.h"


class PCM1863
{
public:
    PCM1863();
    void ADCInit();
    void ADCDeinit();
    void Set(int value);
    void ADCSignal(int autoen,int index);
    int workstat[CHANNELS];
private:
    int pfd[CHANNELS];
    int signal[CHANNELS];
};

#endif // PCM1863_H
