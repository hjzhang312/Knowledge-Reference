#include "adau1466.h"
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/ioctl.h>
#include <math.h>
#include "log.h"
#include "types.h"
#include "sysdata.h"

#define DevADAU1466 "/dev/adau1466_%d"	  //PI11

ADAU1466::ADAU1466()
{
    int i;
    for(i=0;i<(CHANNELS/2);i++)
    {
        char devname[20];
        sprintf(devname,DevADAU1466,i+1);
       // sleep(1);
        fd[i] = open( devname , O_RDWR );
        if ( fd[i] < 0 ) {
            LOGOUT("ADAU1466:failed to open ! please check!!!");
        }
        else
        {
           // LOGOUT("ADAU1466-%d-%d open",i,fd[i]);
        }
    }
}

#define DSPPower 0X8000
#define DSPReset 0x8001
void ADAU1466::DspInit()
{
    int i;
    ioctl(fd[0],DSPPower,1);

    ioctl(fd[0],0x8001,0);//reset
    usleep(1000*100);

    ioctl(fd[0],0x8001,1);//reset
    LOGOUT("ADAreset onnit");
    usleep(1000*100);
    for(i=0;i<(CHANNELS/2);i++)
    {
        if(fd[i])
        {
            ioctl(fd[i],0x1000,0);
            LOGOUT("ADAU1466_%d init",i);
        }
    }
}
void ADAU1466::DspDeinit()
{
    ioctl(fd[0],0x8001,0);
    ioctl(fd[0],0x8000,0);
}

unsigned int toFixvalue(unsigned int value)
{
  int valueabs;
  unsigned int high8;
  unsigned int low24;
  valueabs=(int)value;
  if (value & 0x80000000)
  {
      high8=valueabs/100;
      if (-valueabs%100 > 0)
      {
        high8--;
        low24=(100 + (valueabs%100))*167772.15;
      }
      else
      {
          low24=(valueabs%100)*167772.15;
      }
      //LOGOUT("toFixvalue:valueabs%100: %d,%x",valueabs%100,low24);
  }
  else
  {
      high8=valueabs/100;
      low24=(valueabs%100)*167772.15;
  }
  //LOGOUT("toFixvalue:%x,%x",value,(high8<<24)|low24);
  return (high8<<24)|low24;
  /*
  if(valueabs<0)
  {

  }
  else
  {

  }
  int pn=value&0x80000000?-1:1;
  valueabs=0x7fffffff&value;
  high8=valueabs/100;
  if(high8>128)return 0;
  low24=(valueabs%100)*16777.215;


  if(pn>0)return (high8<<24)|low24;
  else return (0-((high8<<24)|low24));
*/
}

void ADAU1466::Write(unsigned int path,unsigned int fun,unsigned int index,unsigned int *data,unsigned int datalen)
{
  if(path>(CHANNELS/2))return;
  unsigned char Dat[datalen*4+8];
  memcpy(Dat,&fun,4);
  memcpy(Dat+4,&index,4);
  memcpy(Dat+8,data,datalen*4);
  write(fd[path],Dat,datalen*4+8);
}

void ADAU1466::Optical(int index,int optical)//0-4
{
    unsigned int Switch[2];//
    Switch[0]=optical?0:0x01000000;
    Switch[1]=optical?0x01000000:0;
    Write(index,funSourceSwitch,0,Switch,2);
}

void ADAU1466::Loudness(int index,int loud)
{
    unsigned int Switch[2];//
    Switch[0]=loud?0:0x01000000;
    Switch[1]=loud?0x01000000:0;
    Write(index/2,funLoudness,(index%2),Switch,2);
}
void ADAU1466::Oscgain(int index,int gain)
{
    Write(index/2,funoscgain,0,(unsigned int *)&gain,1);
}
#if(CHANNELS==8)
const unsigned int path[CHANNELS]={0,2,4,6,1,3,5,7};
#elif (CHANNELS==16)
const unsigned int path[CHANNELS]={0,2,4,6,8,10,12,14,1,3,5,7,9,11,13,15};
#endif

void ADAU1466:: SetSignalPresence(int index, int threshold,unsigned int releasetime)
{
    unsigned int dat[2] = {0, 0};
    index=path[index];

    dat[0] = Sigma_8_24((float)threshold);
    dat[1] = releasetime * 96000;

    Write(index/2,funSignalPresence,index%2,dat,2);
}

void ADAU1466:: Inputvolume(int index,unsigned int volume)
{
    index=path[index];
    Write(index/2,funVolume,index%2,&volume,1);
}

void ADAU1466:: Outputvolume(int index,unsigned int volume)
{
    Write(index/2,funVolume,2+(index%2),&volume,1);
}

void ADAU1466:: Outputmaxvolume(int index,unsigned int volume)
{
    Write(index/2,funmaxvolume,(index%2),&volume,1);
}

void ADAU1466:: Inputdelay(int index,unsigned int delay)
{
    index=path[index];
    Write(index/2,funDelay,index%2,&delay,1);
}

void ADAU1466:: Outputdelay(int index,unsigned int delay)
{
    Write(index/2,funDelay,2+(index%2),&delay,1);
}
void ADAU1466:: PeqSet(int index,int type,unsigned int vol)
{
    if((type==PEQ_Gain)|(type==PEQ_Q))
    {
       vol=toFixvalue(vol);
    }
    Write(index/2,funPEQ,(index%2)?100+type:type,&vol,1);
}

void ADAU1466:: ShelfSet(int index,int type,unsigned int vol)
{
    if((type==Shelf_Gain)|(type==Shelf_Q))
    {
       vol=toFixvalue(vol);
    }
    Write(index/2,funShelf,(index%2)?100+type:type,&vol,1);
}

void ADAU1466:: CrossSet(int index,int type,unsigned int vol)
{
    Write(index/2,funCrossover,type,&vol,1);
}
void ADAU1466:: Mono(int index,unsigned int mon)
{
    unsigned int Switch[XSwitch_N];//
    memset(Switch,0,sizeof(Switch));
    if(mon<XSwitch_N)
    {
        Switch[mon]=0x01000000;
    }
    else
    {
        LOGOUT("ADAU1466 mon error-%d",mon);
        return ;
    }
    Write(index/2,funMonoSwitch,index%2,Switch,XSwitch_N);
}
void ADAU1466:: Mute(int index,unsigned int mute)
{
    unsigned int muu=0x01000000;
    if(mute) muu=0x00000000;
    Write(index/2,funMute,index%2,&muu,1);
}


void ADAU1466:: BalanceSet(int index, unsigned int gain)
{
    Write(index/2,funBalance,(index%2),&gain,1);
}

int ADAU1466:: OutSignal(int index)
{
    int tempindex;
    tempindex=index>=(CHANNELS/2)?index-(CHANNELS/2):index;
    if(fd[tempindex])
    {
        if(index>=(CHANNELS/2))
        {
            return (ioctl(fd[tempindex],0x5000,1)  || ioctl(fd[tempindex],0x5000,2)) ;//ioctl(fd[index],0x5000,1)  ||
        }
        else
        {
            return ioctl(fd[index],0x5000,0);
        }
    }
    else return -1;
}
int ADAU1466:: DSPSampleRate(unsigned int index)
{
    if(fd[index/2])
    {
       return ioctl(fd[index/2],0xa0000000,Back_samplerate);
    }
    else return -1;
}
int ADAU1466:: DSPVersion(unsigned int index)
{
    if(fd[index/2])
    {
       return ioctl(fd[index/2],0xa0000000,Back_version);
    }
    else return -1;
}

int ADAU1466:: ReadBack(int index,int page,unsigned int addr)
{
    if(index>=CHANNELS)return -1;
    if(fd[index/2])
    {
      return ioctl(fd[index/2],page?0x5005:0x5004,addr)   ;//ioctl(fd[index],0x5000,1)  ||
    }
    else return -1;
}
int ADAU1466:: Spdiflock(int index)
{
    if(fd[index])
      return  ioctl(fd[index],0x5001,NULL);
    else return -1;
}
int ADAU1466:: Spdiflockloss(int index)
{
    if(fd[index])
      return  ioctl(fd[index],0x5002,NULL);
    else return -1;
}
void ADAU1466:: SpdifUmute(int index)
{
    if(fd[index])
       ioctl(fd[index],0x4004,0x0400);

}

void ADAU1466:: DacMute(int index,int mute)
{
    if(fd[index/2])
        ioctl(fd[index/2],index%2?0x4001:0x4002,mute);
}

void ADAU1466:: LineMute(int mute)
{
  ioctl(fd[0],0x4000,mute);
}


unsigned int ADAU1466:: Signal(int index)
{
    unsigned int sig;
    if(fd[index])
    {
            if(read(fd[index],(void*)&sig,4)>0)
        return sig;
    }
    return -1;
}

unsigned int ADAU1466:: Sigma_8_24(float db)
{
    unsigned int out;
    //if (db > 24)db = 24.0;
    if (db > 42)db = 42.0;
    out=powf(10,(db/20))* 0x01000000;//floatn=24
    return out;
}
