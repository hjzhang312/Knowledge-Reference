#include "adc.h"
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/ioctl.h>

#define DevPCM1863 "/dev/pcm1863_%d"	  //PI11



#define AutoSense 0x3000
#define ReadBack  0x3001
#define WriteByte 0x3002


#define POWERCON 0x8000
#define PCMINIT  0x1000
PCM1863::PCM1863()
{
    int i;
    for(i=0;i<CHANNELS;i++)
    {

        char devname[20];
        sprintf(devname,DevPCM1863,i+1);
       // LOGOUT("PCM1863 :%s",devname);
        pfd[i] = open( devname , O_WRONLY );
        if ( pfd[i] < 0 ) {
            LOGOUT("PCM1863:failed to open :pcm_%d! please check!!!",i);
        }
        else
        {
           // LOGOUT("PCM1863-%d open-%d",i,pfd[i]);
        }
    }
}

//int PCM1863Init();
//int PCM1863Svalue(int value);

void PCM1863::ADCInit()
{
    int i;
    LOGOUT("PCM1863 init");
    ioctl(pfd[0],POWERCON,1);
    usleep(1000*100);
    for(i=0;i<CHANNELS;i++)
    {
        signal[i]=0;
        workstat[i]=0; //0
        if(pfd[i])
        {
            ioctl(pfd[i],PCMINIT,0);
            ioctl(pfd[i],AutoSense,0);
            ioctl(pfd[i],WriteByte,0x7072);
            //ioctl(pfd[i],WriteByte,0x7070);
          //  LOGOUT("PCM1863-[%d-%d]",i,pfd[i]);
        }
    }
}
void PCM1863::ADCDeinit()
{
    int i;
    ioctl(pfd[0],POWERCON,0);
    LOGOUT("PCM1863 deinit");
    for(i=0;i<CHANNELS;i++)
    {
        signal[i]=0;
    }
}
void PCM1863::Set(int value)
{
    int i;
    for(i=0;i<CHANNELS;i++)
    {
        if(pfd[i])
            ioctl(pfd[i],WriteByte,value);
    }
}
#define SLEEP_COUNT_MINUTE_TIMEOUT 300

void PCM1863::ADCSignal(int autoen,int index)
{
    static uint16 sleep_count_timeout[CHANNELS];
    int temp;

    if(index>=CHANNELS)return;
#if 0
    if(!autoen)
    {
       if(workstat[index]==0)
       {
           ioctl(pfd[index],WriteByte,0x7070);
           workstat[index]=1;
           LOGOUT("[%d]workstat:0x%x",index,workstat[index]);
       }
    }
    else
    {
        temp=ioctl(pfd[index],ReadBack,0x32);
        if (index == 0)
            LOGOUT("ADCSignale:%d, %d, %d, %d", index, temp, signal[index], workstat[index]);
        if (temp == 0)
        {
            if ((signal[index] == 1) || (workstat[index] == 1))
            {
                sleep_count_timeout[index]++;
                if (sleep_count_timeout[index] == SLEEP_COUNT_MINUTE_TIMEOUT)
                {
                    workstat[index] = 0;
                    signal[index] = 0;
                    ioctl(pfd[index],WriteByte,0x7072);//kaiji
                    LOGOUT("[%d]workstat off:0x%x",index,workstat[index]);
                }
            }
            else
            {
                sleep_count_timeout[index] = 0;
            }

        }
        else
        {
            sleep_count_timeout[index] = 0;
            if (workstat[index] == 0)
            {
                workstat[index] = 1;
                signal[index] = 1;
                ioctl(pfd[index],WriteByte,0x7070);//kaiji
                LOGOUT("[%d]workstat on:0x%x",index,workstat[index]);
            }
        }

#if 0
        if(temp>=0)
        {
            signal[index]=((!!temp)^(!!workstat[index]));

            if(signal[index]!=workstat[index])
            {

                ioctl(pfd[index],WriteByte,signal[index]?0x7070:0x7072);//kaiji
                workstat[index]=signal[index];
                LOGOUT("[%d]workstat:0x%x",index,workstat[index]);
            }
        }
#endif

    }
#else
    temp=ioctl(pfd[index],ReadBack,0x32);
    if (index == 0)
        LOGOUT("ADCSignale:%d, %d, %d, %d", index, temp, signal[index], workstat[index]);
    if (temp > 0)
    {
        if (signal[index] == 1)
        {
            if(autoen)
            {
                sleep_count_timeout[index]++;
                if (sleep_count_timeout[index] == SLEEP_COUNT_MINUTE_TIMEOUT)
                {
                    workstat[index] = 0;
                    signal[index] = 0;
                    ioctl(pfd[index],WriteByte,0x7072);//kaiji
                    LOGOUT("[%d]workstat off:0x%x",index,workstat[index]);
                }
            }
            else
            {
                sleep_count_timeout[index] = 0;
            }
        }
        else
        {
            workstat[index] = 1;
            signal[index] = 1;
            ioctl(pfd[index],WriteByte,0x7070);//kaiji
            LOGOUT("[%d]workstat on:0x%x",index,workstat[index]);
        }
    }
    else if (signal[index] == 1)
    {
        sleep_count_timeout[index] = 0;
    }
#endif
}

