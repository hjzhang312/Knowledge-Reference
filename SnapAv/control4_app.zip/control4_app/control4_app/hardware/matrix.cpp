#include "matrix.h"
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/ioctl.h>

#define Devmatrix "/dev/cpld"	  //PI11


matrix::matrix()
{
        fd = open( Devmatrix , O_WRONLY );
        if ( fd < 0 ) {
            LOGOUT("matrix:failed to open ! please check!!!");
        }
        else
        {
            LOGOUT("matrix open");
        }

}

//int matrixInit();
//int matrixSvalue(int value);
#if(CHANNELS==8)
unsigned int path[CHANNELS+1]={1,3,5,7,2,4,6,8,0};
#elif (CHANNELS==16)

unsigned int path[CHANNELS+1]={1,3,5,7,9,11,13,15,2,4,6,8,10,12,14,16,0};
#endif
//unsigned int path[8]={1,2,3,4,5,6,7,8};
void matrix::matrixInit()
{
    int i;
    for(i=0;i<CHANNELS;i++)
    {
       ioctl(fd,0x1001+i,path[i]);
    }
    LOGOUT("matrix init");
}

void matrix::matrixDenit()
{
    ioctl(fd,0x1000,0);
    LOGOUT("matrix init");
}

void matrix::MatrixSet(int outsource,int insource)
{
    if(insource>=0&&insource<=CHANNELS)

    ioctl(fd,outsource+0x1000+1,path[insource]);
}

