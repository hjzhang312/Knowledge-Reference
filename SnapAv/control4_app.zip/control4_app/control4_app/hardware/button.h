#ifndef BUTTONEVENTHANDLE_H
#define BUTTONEVENTHANDLE_H

#include "tinythread.h"


class Button:public TinyThread
{
public:
    static Button *getInstance() {
        static Button sc;
        return &sc;
    }
public:

    void run();
private:
    int pidofsddp;
    Button();

    int IDkeyPress;
    int RebootPress;
    int mEpollFd;
    int button_fd;
    //ButtonEventHandle();
};

#endif // BUTTONEVENTHANDLE_H
