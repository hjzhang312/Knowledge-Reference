#ifndef COMMON_H
#define COMMON_H
#include <iostream>
#include <unistd.h>
#include <time.h>
#include<fstream>



enum S_ret_status {
    ERROR=-2,
    FAILED=-1,
    SUCESS=0,
    I_SUCESS,
    I_FAILED,
    NOTFIND,
    FOUND,
    TIMEOUT,
    NEEDUPGRADE,
    NOTNEEDUPGRADE,

    IMPORT_FILE_NOT_EXIST = 0x1010,
    IMPORT_MD5_FILE_ERROR,
    IMPORT_MD5_STRING_ERROR,
    IMPORT_TYPE_ERROR

};


typedef  int S_ret;
typedef  unsigned char uchar;
typedef  unsigned int uint;
typedef  unsigned short uint16;




//static std::ofstream logd(LOGTMPPATH);
#if 1
#define LOGOUT(format , ...)  { \
                                time_t tt=time(0); struct tm   time;\
                                /*char buf[1024];*/ \
                                localtime_r(&tt,&time);\
                                printf("%02d-%02d-%02d %02d:%02d:%02d" \
                                        " [%s]=> "\
                                        format "\n",time.tm_year + 1900,\
                                time.tm_mon + 1,time.tm_mday,time.tm_hour,\
                                time.tm_min,time.tm_sec,\
                                __func__,##__VA_ARGS__);\
                                /*logd << buf<<std::endl; */ \
                              }
#else

#define LOGOUT(format , ...) //printf(format "\n" , ##__VA_ARGS__)

#endif

#define ARRYSIZE(arry) (sizeof arry /sizeof arry[0])


#endif // COMMON_H

