#ifndef FIFO_H
#define FIFO_H

#include "tinythread.h"
#include "common.h"
using namespace std;
class Fifo:public TinyThread
{
public:
    void FifoSend(string message );
    static Fifo *getInstance() {
        static Fifo s;
        return &s;
    }
    void run();
private:
    int Fifofd;
    Fifo();
    ~Fifo();

};

#endif //
