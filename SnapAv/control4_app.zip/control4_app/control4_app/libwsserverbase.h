#ifndef LIBWSSERVERBASE_H
#define LIBWSSERVERBASE_H

#include <libwebsockets.h>
#include "common.h"


class LibWSServerBase
{
public:
    LibWSServerBase();

    static LibWSServerBase *getInstance() {
        static LibWSServerBase s;
        return &s;
    }
    int run_server(int port);

    void sendBoardData(std::string data);

};

#endif // LIBWSSERVERBASE_H
