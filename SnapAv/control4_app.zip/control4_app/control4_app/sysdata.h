#ifndef SYSTEMDATA_H
#define SYSTEMDATA_H

#include "common.h"
#include "tools/sqlite3base.h"
#include "tools/types.h"
#include <sys/types.h>
#include <sys/wait.h>

using namespace std;



class sysdata:public Sqlite3Base
{
public:
            static sysdata *getInstance() {
                static sysdata sc;
                return &sc;
            }

            void init();

            int SetinputVolme(unsigned int index,unsigned int volume);
            void SetVolumeAdd(unsigned int index,int volume);
            int ZoonGet(int index);

            void SetPEQ(unsigned int index,unsigned int type,unsigned int peqindex,unsigned int vol);
            void SetShelf(unsigned int index,unsigned int type,unsigned int trbass,unsigned int vol);
            void SetXover(unsigned int index,unsigned int type,unsigned int vol);

            void SetLoudness(unsigned int index,unsigned int loudness);

            void SetBalance(unsigned int index,unsigned int balance);
            void SetGroup(int index,int group);
            int SetSubVolume(unsigned int index,unsigned int volume);
            int SetGroupVolumeAdd(int group,int volume);
            int GetGroupVolume(int group);
            int SetGroupVolume(int group,float volume);
            int SetGroupSource(int group,int source);
            int GetGroupSource(int group);
            int SetGroupMute(int group,int mute);
            int GetGroupMute(int group);
            void Setinputdelay(unsigned int index,unsigned int delay);
            void Setoutputdelay(unsigned int index,unsigned int delay);
            void Setoutputsource(unsigned int index,unsigned int source);
            void Setvolume(unsigned int index,unsigned int volume);
            void SetmaxVolume(unsigned int index,unsigned int volume);
            void Setturnonvolume(unsigned int index,unsigned int volume);
            void SetDspmute(unsigned int index,int mute);
            int SetOscGain(unsigned int index,int Gain);
            void SetOptical(unsigned int index,bool enable);
            void Power(int power);
            void SetAsg(int set);
            void SetAutoStandby(int set);
            int  SetZoon(int set,int on);
            void SetAutoSense(int set);
            void Mon(int index,unsigned int enable);
            void MonStereo(int index,unsigned int stereo);
            void TestSignal(int index,unsigned int on);
            void SetAll(DSPstreaming dspset);
            void ExeSet(void);
            void FactoryDefault();
            void SetSPReleasetime(unsigned int index,unsigned int data);
            void SetSPThreshold(unsigned int index,int data);
            void autoUpgradeDatabase();

public:
            static pthread_mutex_t Lock ;
            DSPstreaming dspdata[CHANNELS];
            DeviceSet    devicedata;
            _deviceinfo  deviceinfo;
            _networkinfo netinfo;
            _logininfo mLoginInfo;
            _webextrainfo mWebInfo;
            std::string mToken;

            //vector<_dspPresetItemInfo> mDspPresetInfo;
            //vector<_dspEqItemInfo> mEQItemInfo;
            _outputDspInfo mOutputDspInfo[CHANNELS];
            _subDspInfo mSubDspInfo[CHANNELS];

            SPEAKER_PRESET_MAP mSpeakerDspMapInfo;
            vector<_roomDspPresetItemInfo> mRoomDspVecInfo;


            vector<string> mDefaultRoomPresetName;
            vector<vector<string>> mEqDefaultFreq;
            vector<vector<string>> mEqDefaultGain;
            vector<vector<string>> mEqDefaultQRatio;

            vector<vector<string>> mSpeakerEqDefaultFreq;
            vector<vector<string>> mSpeakerEqDefaultGain;
            vector<vector<string>> mSpeakerEqDefaultQRatio;

            vector<string> mDefaultSpeakerPresetName;

public:
            S_ret updateDataBaseTable(string dbname, string key, string value, string row = "0");
            S_ret updateDataBaseEqInfoTable(string key, string value,string dspIndex,string uuid,bool room = true);

            S_ret updateDataBasePresetInfoTable(string index_s, bool room = true);
            S_ret insertSpeakerPresetInfoTable();
            S_ret deleteSpeakerPresetInfoTable(string id_s);

            S_ret importAllSpeakerPresetInfoTable();

            S_ret resetDevice();
            S_ret rebootDevice();
            S_ret firmwareUpdate(std::string  path);


private:
sysdata();

};

#endif // SYSTEMCONTROL_H
