#ifndef OVRCHANDLE_H
#define OVRCHANDLE_H
#include <iostream>
#include "ovrc/ovrc_sdk.h"
#include "tinythread.h"
//#include "observer.h"
//#include "systemcontrol.h"
//#include "configpagehandle.h"
#include "types.h"
#define CLIENT_PORT     80
#define CLIENT_PROTOCOL "http"


//enum OvrcUpdate
//{
//    DEVICE_NAME_INFO,
//    DEVICE_NET_INFO,
//    OVRC_ENABLE_INFO,
//    OVRC_URL_INFO,
//    OVRC_FREQ_INFO
//};

/* structure for the device's time settings */
typedef struct TIME_SETTINGS {
    char timeZone[7];
    char currentTime[64];
    char daylightSavings[10];
} TIME_SETTINGS;

class OvrcHandle :public TinyThread
{
public:
   // OvrcHandle();
    ~OvrcHandle()
    {

    }
    std::string getmacaddress() {
        //return this->macaddr;
        return netinfo.mac;
    }

    friend class Notifier;


protected:
    void run();
    int ovrcmain();
    /* Initialize the device's variables */
    void initDeviceVars(void);
    /* Set the cloud server url */
    void
    setCloudServerUrl(
        IN char *serverUrl
        );

    /* Initialize connection with cloud server */
    void
    initCloudServerConnection();

    /* Close connection with cloud server */
    void
    deleteCloudServerConnection();

    /* Generic handler for all commands received from server */
    void genericCommandHandler( IN JSON_PARSER_OBJ *root );



    /* Method to send event notifications. */
    void
    eventNotifier(
        IN char *event,
        IN char *eventType
        );


    /*
     * API Handlers for the methods of the Base Specification
     */

    /* Handler for the dxGetAbout method */
    void
    dxGetAboutHandler(
        IN JSON_PARSER_OBJ *rootIP
        );

    /* Handler for the dxGetNetworkSettings method */
    void
    dxGetNetworkSettingsHandler(
        IN JSON_PARSER_OBJ *rootIP
        );

    /* Handler for the dxSetNetworkSettings method */
    void
    dxSetNetworkSettingsHandler(
        IN JSON_PARSER_OBJ *rootIP
        );

    /* Handler for the dxGetTimeSettings method */
    void
    dxGetTimeSettingsHandler(
        IN JSON_PARSER_OBJ *rootIP
        );

    /* Handler for the dxSetTimeSettings method */
    void
    dxSetTimeSettingsHandler(
        IN JSON_PARSER_OBJ *rootIP
        );

    /* Handler for the dxResetDevice method */
    void
    dxResetDeviceHandler(
        IN JSON_PARSER_OBJ *rootIP
        );

    /* Handler for the dxUpdateFirmware method */
    void
    dxUpdateFirmwareHandler(
        IN JSON_PARSER_OBJ *rootIP
        );

    /* The callback for the ftp downloading functionality provided by OvrC SDK.*/
    static void
    ovrcClientFtpDownloader(
        IN void *buffer,
        IN size_t size
        );

    /* Handler for the dxEnableRemoteWebUiAccess method. */
    void
    dxEnableRemoteWebUiAccessHandler(
        IN JSON_PARSER_OBJ *rootIP
        );

    /* Handler for the dxDisableRemoteWebUiAccess method. */
    void
    dxDisableRemoteWebUiAccessHandler(
        IN JSON_PARSER_OBJ *rootIP
        );

    /* Handler for dxStreamSystemLogs method. */
    void
    dxStreamSystemLogsHandler(
        IN JSON_PARSER_OBJ *rootIP
        );

    /* Handler for dxSetLoggingMode method. */
    void
    dxSetLoggingModeHandler(
        IN JSON_PARSER_OBJ *rootIP
        );

    /* Handler for dxGetStatusUpdateFrequency method. */
    void
    dxGetStatusUpdateFrequencyHandler(
        IN JSON_PARSER_OBJ *rootIP
        );

    /* Handler for dxSetStatusUpdateFrequency method. */
    void
    dxSetStatusUpdateFrequencyHandler(
        IN JSON_PARSER_OBJ *rootIP
        );

    /* Handler for dxSetCloudServerUrl method. */
    void
    dxSetCloudServerUrlHandler(
        IN JSON_PARSER_OBJ *rootIP
        );

    /* Handler for dxEnableWebConnect method. */
    void
    dxEnableWebConnectHandler(
        IN JSON_PARSER_OBJ *rootIP
        );

    /* Handler for dxDisableWebConnect method. */
    void
    dxDisableWebConnectHandler(
            IN JSON_PARSER_OBJ *rootIP
            );

    /* Send an error code in response to a received method */
    void
    sendError(
        IN JSON_PARSER_OBJ *root,
        IN int errorCode
        );

    BOOL
    timeZoneValidator(
        IN char *timeZone
        );

    bool getBoolValue(string v);
public:
    BYTE getWebSocketStatus();
    virtual void ovrcUpdate(OvrcUpdate type);
private:
    _networkinfo netinfo;
    _deviceinfo devinfo;

    _cloudinfo cloudinfo;

    TIME_SETTINGS timeSettings;

    OvrCConnector connector;
    Thread statusUpdateThread;
    BOOL changeCloudServer;
    BOOL mOvrcEnable;

    bool needdevnotify;
    bool neednetnotify;
    bool needwebportnotify;
    bool needresetnotify;
    bool needupdatefirmware;
    bool needupdatecloudurl;
    //Argument notifyarg;
    std::string firmware;
};




#endif // OVRCHANDLE_H
