#include <socket.h>

unsigned int Float2DSPnow(float fl)
{
    int ret=(int)(fl*100);

    return (unsigned int)ret;
}

//unsigned int Float2DSP(float fl)
//{
//    unsigned int ret=0;
//    if(fl>0)
//    {
//        ret=(unsigned int)((fl)*1000);

//    }
//    else
//    {
//      ret=(unsigned int)(-(fl)*1000);
//    }

//    if(fl<0) ret|=0x80000000;
//    return ret;
//}
float DSP2Float(unsigned int intt)
{
    int ret=(int) intt;
    return ((float)ret)/100;
}

struct freqstr
{
    const char *frechar;
    int freq;
};



const char *XoverType[]=
{
    "12dB/Oct Butterworth",
    "24dB/Oct Butterworth",
    "48dB/Oct Butterworth",
    "12dB/Oct Linkwitz-Riley",
    "24dB/Oct Linkwitz-Riley",
    "48dB/Oct Linkwitz-Riley"
};

float SocketServer::DataToGainFloat(unsigned int data)
{
    int tmp=(int)data;
    float vol=(float)tmp;
    vol/=100;
    return vol;
}

const char* SocketServer::SocketXoverType(unsigned char type)
{

    if(type<6)
    {
        return XoverType[type];
    }
    return "None";
}
const char *Musictypeodd[]= // "Mono HP",
{
    "DSP Bypass Stereo",
    "DSP Stereo",
    "Mono Sum",
    "Stereo HP",
    "Mono Sum HP",
    "Test Signal",
};
const char *Musictypeeven[]= // "Mono HP",
{
    "DSP Bypass Stereo",
    "DSP Stereo",
    "Mono Sum",
    "Stereo LP",
    "Mono Sum LP",
    "Test Signal",
};
const char* SocketServer::SocketMusicType(unsigned char odd,unsigned char type)
{

    if(type<6)
    {
        if(odd)
        return Musictypeodd[type];
        else {

            return Musictypeeven[type];
        }
    }
    return "None";
}
struct freqstr freqtable[31]=
{
    {"20 Hz"    ,20},
    {"25 Hz"    ,25},
    {"31.5 Hz"  ,31},
    {"40 Hz"    ,40},
    {"50 Hz"    ,50},
    {"63 Hz"    ,63},
    {"80 Hz"    ,80},
    {"100 Hz"   ,100},
    {"125 Hz"   ,125},
    {"160 Hz"   ,160},
    {"200 Hz"   ,200},
    {"250 Hz"   ,250},
    {"315 Hz"   ,315},
    {"400 Hz"   ,400},
    {"500 Hz"   ,500},
    {"630 Hz"   ,630},
    {"800 Hz"   ,800},
    {"1 kHz"    ,1000},
    {"1.25 kHz" ,1250},
    {"1.6 kHz"  ,1600},
    {"2 kHz"    ,2000},
    {"2.5 kHz"  ,2500},
    {"3.15 kHz" ,3150},
    {"4 kHz"    ,4000},
    {"5 kHz"    ,5000},
    {"6.3 kHz"  ,6300},
    {"8 kHz"    ,8000},
    {"10 kHz"   ,10000},
    {"12.5 kHz" ,12500},
    {"16 kHz"   ,16000},
    {"20 kHz"   ,20000},
};


const float GAIN[]=
{
      -12,
      -11.5,
      -11,
      -10.5,
      -10,
      -9.5,
      -9,
      -8.5,
      -8,
      -7.5,
      -7,
      -6.5,
      -6,
      -5.5,
      -5,
      -4.5,
      -4,
      -3.5,
      -3,
      -2.5,
      -2,
      -1.5,
      -1,
      -0.5,
      0,
      0.5,
      1,
      1.5,
      2,
      2.5,
      3,
      3.5,
      4,
      4.5,
      5,
      5.5,
      6,
      6.5,
      7,
      7.5,
      8,
      8.5,
      9,
      9.5,
      10,
      10.5,
      11,
      11.5,
      12,
};
const float Q[]=
{
    0.5,
    0.6,
    0.7,
    0.8,
    0.9,
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
};
const float TrebleBass[]=
{
      -12,
      -11.5,
      -11,
      -10.5,
      -10,
      -9.5,
      -9,
      -8.5,
      -8,
      -7.5,
      -7,
      -6.5,
      -6,
      -5.5,
      -5,
      -4.5,
      -4,
      -3.5,
      -3,
      -2.5,
      -2,
      -1.5,
      -1,
      -0.5,
      0,
      0.5,
      1,
      1.5,
      2,
      2.5,
      3,
      3.5,
      4,
      4.5,
      5,
      5.5,
      6,
      6.5,
      7,
      7.5,
      8,
      8.5,
      9,
      9.5,
      10,
      10.5,
      11,
      11.5,
      12,
};
const float  InputLevelTrim[] = {
    -12,
    -11.5,
    -11,
    -10.5,
    -10,
    -9.5,
    -9,
    -8.5,
    -8,
    -7.5,
    -7,
    -6.5,
    -6,
    -5.5,
    -5,
    -4.5,
    -4,
    -3.5,
    -3,
    -2.5,
    -2,
    -1.5,
    -1,
    -0.5,
    0,
    0.5,
    1,
    1.5,
    2,
    2.5,
    3,
    3.5,
    4,
    4.5,
    5,
    5.5,
    6,
    6.5,
    7,
    7.5,
    8,
    8.5,
    9,
    9.5,
    10,
    10.5,
    11,
    11.5,
    12,
};
const float VolumeControl[101] = {
    -108.5,
    -100.3,
    -92.7,
    -85.8,
    -79.5,
    -73.9,
    -69.0,
    -64.6,
    -61.0,
    -58.0,
    -55.6,
    -53.9,
    -52,
    -50.5,
    -49.6,
    -48.7,
    -47.7,
    -46.8,
    -45.9,
    -45.0,
    -44.1,
    -43.2,
    -42.3,
    -41.4,
    -40.6,
    -39.7,
    -38.9,
    -38.0,
    -37.2,
    -36.4,
    -35.6,
    -34.8,
    -34.0,
    -33.2,
    -32.4,
    -31.7,
    -30.9,
    -30.2,
    -29.4,
    -28.7,
    -28.0,
    -27.2,
    -26.5,
    -25.8,
    -25.1,
    -24.5,
    -23.8,
    -23.1,
    -22.5,
    -21.8,
    -21.2,
    -20.5,
    -19.9,
    -19.3,
    -18.7,
    -18.1,
    -17.5,
    -16.9,
    -16.4,
    -15.8,
    -15.3,
    -14.7,
    -14.2,
    -13.7,
    -13.1,
    -12.6,
    -12.1,
    -11.6,
    -11.1,
    -10.7,
    -10.2,
    -9.7,
    -9.3,
    -8.9,
    -8.4,
    -8.0,
    -7.6,
    -7.2,
    -6.8,
    -6.4,
    -6.0,
    -5.6,
    -5.3,
    -4.9,
    -4.6,
    -4.2,
    -3.9,
    -3.6,
    -3.3,
    -3.0,
    -2.7,
    -2.4,
    -2.1,
    -1.8,
    -1.6,
    -1.3,
    -1.1,
    -0.9,
    -0.6,
    -0.4,
    0
};
unsigned int SocketServer::SocketFrequency(unsigned char fre)
{

    if(fre<31)
    {
        return freqtable[fre].freq;
    }
    return 0;

}

unsigned int SocketServer::SocketGain(unsigned char gain)
{

    if(gain<(sizeof(GAIN)/4))
    {
        return Float2DSPnow(GAIN[gain]);
    }
    return 0;

}

unsigned int SocketServer::SocketQ(unsigned char q)
{

    if(q<(sizeof(Q)/4))
    {
        return Float2DSPnow(Q[q]);
    }
    return 0;
}
unsigned int SocketServer::SocketBasstreble(unsigned char a)
{

    if(a<(sizeof(TrebleBass)/4))
    {
        return Float2DSPnow(TrebleBass[a]);
    }
    return 0;
}













float SocketServer::SocketOutPutLeve(unsigned char leve)
{
    if(leve<sizeof(VolumeControl)/sizeof(VolumeControl[0]))
    {
        return VolumeControl[leve];
    }
    return 0;
}
float SocketServer::SocketInputLeve(unsigned char leve)
{
    if(leve<sizeof(InputLevelTrim)/sizeof(InputLevelTrim[0]))
    {
        return InputLevelTrim[leve];
    }
    return 0;
}

float SocketServer::SocketGainf(unsigned char gain)
{

    if(gain<(sizeof(GAIN)/4))
    {
        return GAIN[gain];
    }
    return 0;

}

float SocketServer::Gainfneg24to0(unsigned char gain)
{

    if(gain<(sizeof(GAIN)/4))
    {
        return GAIN[gain]-12.0;
    }
    return 0;

}

float SocketServer::dsp2float(int gainq)
{
    return DSP2Float(gainq);
}
float SocketServer::SocketQf(unsigned char q)
{

    if(q<(sizeof(Q)/4))
    {
        return (Q[q]);
    }
    return 0;
}

float SocketServer::SocketBasstreblef(unsigned char a)
{

    if(a<(sizeof(TrebleBass)/4))
    {
        return (TrebleBass[a]);
    }
    return 0;
}



const char * Grp_String[8+1]={
        "A",
        "B",
        "C",
        "D",
        "E",
        "F",
        "G",
        "H",
        "None"
};

const char * Balance_Gain_Str[49]={
    "Bal L 12",
    "Bal L 11.5",
    "Bal L 11",
    "Bal L 10.5",
    "Bal L 10",
    "Bal L 9.5",
    "Bal L 9",
    "Bal L 8.5",
    "Bal L 8",
    "Bal L 7.5",
    "Bal L 7",
    "Bal L 6.5",
    "Bal L 6",
    "Bal L 5.5",
    "Bal L 5",
    "Bal L 4.5",
    "Bal L 4",
    "Bal L 3.5",
    "Bal L 3",
    "Bal L 2.5",
    "Bal L 2",
    "Bal L 1.5",
    "Bal L 1",
    "Bal L 0.5",
    "Bal Center",
    "Bal R 0.5",
    "Bal R 1",
    "Bal R 1.5",
    "Bal R 2",
    "Bal R 2.5",
    "Bal R 3",
    "Bal R 3.5",
    "Bal R 4",
    "Bal R 4.5",
    "Bal R 5",
    "Bal R 5.5",
    "Bal R 6",
    "Bal R 6.5",
    "Bal R 7",
    "Bal R 7.5",
    "Bal R 8",
    "Bal R 8.5",
    "Bal R 9",
    "Bal R 9.5",
    "Bal R 10",
    "Bal R 10.5",
    "Bal R 11",
    "Bal R 11.5",
    "Bal R 12",
};
const char *PowerStatus[4]={

    "Standby",
    "Working",
    "Poweroff",
    "Poweron",
};
const char *SelectStatus[5]={

    "bypass",
    "stereo",
    "mono",
    "stereo hp",
    "test signal",
};
const char *SocketServer::FreqChar(unsigned char leve)
{
    if(leve<31)
    {
        return freqtable[leve].frechar;
    }
    return "null";
}
const char *SocketServer::FreqChar(int fre)
{
    if((fre>=20)&&(fre<=20000))
    {
        int i;
        for(i=0;i<31;i++)
        {
            if(freqtable[i].freq==fre)return freqtable[i].frechar;
            else if(freqtable[i].freq>fre)return freqtable[i-1].frechar;
        }
    }
    return "null";
}
const char *SocketServer::GroupChar(unsigned int group)
{
    if(group>=0x100)group-=0x100;
    else return "None";
    if(group<8)
    {
        return Grp_String[group];
    }
    else
    {
       // printf("group:%d\r\n",group);
    }
    return "None";
}
const char *SocketServer::BalanceChar(unsigned char balance)
{
    if(balance<49)
    {
        return Balance_Gain_Str[balance];
    }
    return "null";
}
const char *SocketServer::PowerChar(unsigned char power)
{
    if(power<4)
    {
        return PowerStatus[power];
    }
    return "null";
}
const char *SocketServer::SelectChar(unsigned char Select)
{
    if(Select<4)
    {
        return SelectStatus[Select];
    }
    return "null";
}
//const char *SocketServer::SelectChar(unsigned char Select)
//{
//    if(Select<4)
//    {
//        return SelectStatus[Select];
//    }
//    return "null";
//}freqtable
