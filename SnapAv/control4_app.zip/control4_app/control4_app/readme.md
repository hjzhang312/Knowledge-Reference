# build steps
## download src code git clone url
## build env
### use ubuntu 16.04 atlest
### install qt5creator
```
sudo apt install qt5 qt5-sdk qtcreator
```
### downlad crosscompile toolcain
download toolchian 
```
//10.10.6.91:90/snapav/host.tar.gz
```

### install toolchian
zecompress host.tar.gz
```
$tar -zxf host.tar.gz
```
Copy host directory to the snapav5.1 src sibling directory

## build project
```
cd project_src/
qmake
make
``` 
