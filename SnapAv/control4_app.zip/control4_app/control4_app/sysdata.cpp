﻿#include "sysdata.h"
#include "tools.h"
#include <signal.h>
#include <semaphore.h>
#include "log.h"
#include "ledmisc.h"
#include <signal.h>

#if(CHANNELS==8)
#define DBPATH "/media/userdata/control4x8.db"
#elif (CHANNELS==16)
#define DBPATH "/media/userdata/control4x16.db"
#endif

#define MYSIGNAL1  __SIGRTMIN + 4
#define MYSIGNAL2  __SIGRTMIN + 5


pthread_mutex_t sysdata::Lock = PTHREAD_MUTEX_INITIALIZER;
sem_t sysdatasem;



float eqfremap[6]={50,100,500,1000,10000,15000};
sysdata::sysdata():
    Sqlite3Base(DBPATH)
{
    int i,j,k;
    sem_init(&sysdatasem, 0, 0);
    for(i=0;i<CHANNELS;i++)
    {
        for(j=0;j<DSP_N;j++)
        {
           dspdata[i].dsp[j]=0;
        }

        for(k=0;k<2;k++)
        {
            if(k==BASS)dspdata[i].dspshelf[ENUM_SHELF_N*k+ENUM_shelf_freq]=200;
            else dspdata[i].dspshelf[ENUM_SHELF_N*k+ENUM_shelf_freq]=2000;
            dspdata[i].dspshelf[ENUM_SHELF_N*k+ENUM_shelf_gain]=0;
            dspdata[i].dspshelf[ENUM_SHELF_N*k+ENUM_shelf_q]=58;
            dspdata[i].dspshelf[ENUM_SHELF_N*k+ENUM_shelf_sr]=96000;
        }

        for(k=0;k<12;k++)
        {
            dspdata[i].dsppeq[ENUM_PEQ_N*k+ENUM_PEQ_Freq]=1000;
            dspdata[i].dsppeq[ENUM_PEQ_N*k+ENUM_PEQ_Gain]=0;
            dspdata[i].dsppeq[ENUM_PEQ_N*k+ENUM_PEQ_Q]=600;
            dspdata[i].dsppeq[ENUM_PEQ_N*k+ENUM_PEQ_SR]=96000;
        }

        dspdata[i].dsp[ENUM_Inputvolume]=24;
        dspdata[i].dsp[ENUM_Outputsource]=CHANNELS;
        dspdata[i].dsp[ENUM_startvolume]=20;
        dspdata[i].dsp[ENUM_maxvolume]=100;
        dspdata[i].dsp[ENUM_volume]=20;
        dspdata[i].dsp[ENUM_balance]=24;
        dspdata[i].dsp[ENUM_merge]=Switch_stereo;
        dspdata[i].dsp[ENUM_oscgain]=10;
        dspdata[i].dsp[ENUM_crossover_gain]=3;
        dspdata[i].dsp[ENUM_signalpresence_threshold]=-30;
        dspdata[i].dsp[ENUM_signalpresence_releasetime]=5;
     }
      devicedata.power=1;
   DEBUG_LOG("db CreateDsp start.....");
   CreateDsp();
   DEBUG_LOG("db CreateDsp.....");
  if(InsertDsp(dspdata)>=0)
   {
     UpdateDsp(dspdata);
   }
   DEBUG_LOG("db UpdateDsp.....");
//   else
//   {
//     SelectDsp(dspdata);
//   }

   getDSPStreamingInfo(dspdata);

   for(i=0;i<CHANNELS;i++)
   {
       dspdata[i].dsp[ENUM_volume]=dspdata[i].dsp[ENUM_startvolume];
   }

   devicedata.asg=0;
   devicedata.audiosens=0;
   devicedata.autostandby=1;
   for(i=0;i<CHANNELS/8;i++)
   {
       devicedata.zoon[i]=0;

   }

   //deviceinfo.devicename=CHANNELS==8?"control4-8":"control4-16";
   // change the device name
   deviceinfo.devicename=CHANNELS==8?"TRIAD AMS8":"TRIAD AMS16";
   deviceinfo.devicemodel=CHANNELS==8?"TS-AMS8":"TS-AMS16";
   deviceinfo.serialnumber=Tools::getInstanc()->getSerialNumber();

   CreatDevice();
   DEBUG_LOG("db CreatDevice.....");
   InsertDevice(devicedata);
   DEBUG_LOG("db InsertDevice.....");
   SelectDevice(devicedata, deviceinfo);
   DEBUG_LOG("db SelectDevice.....");

   char buftemp[10];
   sprintf(buftemp, "%.4f",((float)AppVersion)/10000);
   deviceinfo.firmware=buftemp;

    LOGOUT("init sysdata ok\r\n");
  // LOGOUT("init sysdata:%d\r\n",dspdata.power);
}
void mySignalhandler(int sig)
{
    switch(sig)
    {
        case MYSIGNAL1:
            DEBUG_LOG("eth0 running :)");
            LEDMISC::getInstance()->SetNetWork(1);
            Tools::getInstanc()->getNetStatus(sysdata::getInstance()->netinfo, "eth0");
            DEBUG_LOG("dhcp:%s ip:%s",sysdata::getInstance()->netinfo.dhcpEnabled.c_str(),sysdata::getInstance()->netinfo.ip.c_str());
        break;
        case MYSIGNAL2:
            DEBUG_LOG("eth0 disconnect running :)");
            LEDMISC::getInstance()->SetNetWork(0);
        break;
    default:
        DEBUG_LOG("unsupport signal:%d ",sig);
        break;

    }
}

void sysdata::init()
{
    signal(MYSIGNAL1,mySignalhandler);
    signal(MYSIGNAL2,mySignalhandler);
    //login info defualt
    // mLoginInfo.mUserName = "episode";
    mLoginInfo.mUserName = "triad";
    mLoginInfo.mUserPasswd = "triad";
    mLoginInfo.mStatus = 0;
    mLoginInfo.mFailNumber = 0;
    mLoginInfo.mChangeType = 0;

    CreateLogin();
    initLoginInfo();
    getLoginInfo(mLoginInfo);
    DEBUG_LOG("db getLoginInfo.....");
    //web info
    for(int i = 0; i < CHANNELS; i++)
    {
        mWebInfo.inputname[i] = "Input" + to_string(i + 1);
        mWebInfo.outputname[i] = "Output" + to_string(i + 1);
        mWebInfo.assigntrigger[i] = "0";
    }
    CreateWebExtraInfo();
    initWebExtraInfo();
    getWebExtraInfo(mWebInfo);
    DEBUG_LOG("db getWebExtraInfo.....");

    //output&sub dsp info
    for(int i = 0; i < CHANNELS; i++)
    {
        mOutputDspInfo[i].mOutputToneBassEN = "0"; // "0" not enabled, "1" endbled
        mOutputDspInfo[i].mOutputLoudnessEN = "0";//to_string(dspdata.loudness[i]);//"1";
        mOutputDspInfo[i].mOutputToneBass = "0";
        mOutputDspInfo[i].mOutputToneBassFreq = "200";
        mOutputDspInfo[i].mOutputToneBassQ = "0.58";
        mOutputDspInfo[i].mOutputToneTrebleEN = "0";
        mOutputDspInfo[i].mOutputToneTrebleFreq = "2000";
        mOutputDspInfo[i].mOutputToneTrebleQ = "0.58";
        mOutputDspInfo[i].mOutputToneTreble = "0";

        mOutputDspInfo[i].mOutputRoomDspPreset = "0";
        mOutputDspInfo[i].mOutputSpeakerDspPreset = "2";
        mSubDspInfo[i].mSubDspEnable = "0";
        mSubDspInfo[i].mSubVolOffset = "0";
        mSubDspInfo[i].mSubCrossoverType = "0";
        mSubDspInfo[i].mSubCrossoverSlop = "0";
        mSubDspInfo[i].mSubCrossoverFreq = "80";
        // add lock
        mOutputDspInfo[i].mOutputLock = "1"; // "0" is locked, "1" is unlocked
    }

    CreateOutputDspTab();
    initOutputDspTab();
    getOutputDspFromTab();

    CreateSubDspTab();
    initSubDspTab();
    getSubDspFromTab();

    //preset info
    mDefaultRoomPresetName = {"FLAT", "CLASSICAL", "POP", "ROCK", "JAZZ", "CUSTOM 1", "CUSTOM 2", "CUSTOM 3", "CUSTOM 4", "CUSTOM 5"};
//    mDefaultSpeakerPresetName = {"FLAT", "CLASSICAL", "POP", "ROCK", "JAZZ", "New Speaker Preset"};
    mDefaultSpeakerPresetName = {"New Speaker Preset", "FLAT", "InCeiling R25 OR", "InCeiling R26 OR", "InCeiling R28 OR", "InCeiling R28 DT OR",
                                "InCeiling Mini OR", "InCeiling Mini SR", "InCeiling Bronze OR", "InCeiling Bronze SR", "InCeiling Silver OR",
                                "InCeiling Silver SR", "InCeiling Silver DT OR", "InCeiling Silver DT SR", "OnWall Micro Sat 2.0", "OnWall Micro LCR 2.0",
                                "OnWall Mini Sat 2.0", "OnWall Mini LCR 2.0", "OnWall Mini LCR 2.0 SE", "InWall Mini/4 Sat", "InWall Bronze/4 Sat",
                                "InCeiling Bronze/8 Sat", "InWall Silver/4 Sat", "InCeiling Silver/6 Sat", "InCeiling R06 OR", "InCeiling R15 OR",
                                "InCeiling R16 OR", "InCeiling R18 OR", "InCeiling R18DT OR", "OnWall Micro Sat 1.0", "OnWall Micro Sat 3.0",
                                "OnWall Micro LCR 1.0", "OnWall Micro LCR 3.0", "InCeiling Mini LCR", "OnWall Mini LCR 1.0", "OnWall Mini LCR 3.0",
                                "OnWall Mini LCR 1.0 SE", "OnWall Mini LCR 3.0 SE", "InRoom Mini Sat", "InRoom Bronze Sat", "InRoom Bronze LCR",
                                "InRoom Bronze Center", "InCeiling Silver/8 Sat Omni SE", "InCeiling Silver Monitor", "InCeiling Silver MiniMonitor",
                                "InWall Silver/4 Sat Omni SE", "InWall Silver/4 Monitor", "InWall Silver/6 Monitor", "InWall Silver MiniMonitor",
                                "InRoom Silver Sat", "InRoom Silver Monitor", "InRoom Silver MiniMonitor", "InRoom Silver LCR", "InRoom Silver Center",
                                "InCeiling Gold/8 Sat Omni SE", "InCeiling Gold/8 MiniMonitor", "InWall Gold/4 Sat Omni SE 125", "InWall Gold/6 MiniMonitor",
                                "InRoom Gold MiniMonitor", "InCeiling Designer Series DS4 FR", "Outdoor OD25", "Outdoor OD26", "IC32SD", "IC33SD",
                                "IC52", "IC53", "IC61", "IC62", "IC63", "IC82", "IC83", "IC82DT", "IC83DT", "IW61", "IW62", "IW63", "IW82", "IW83"};

    mEqDefaultFreq = {
        {"32", "125", "750", "3000", "8000", "16000"},
        {"32", "125", "750", "3000", "8000", "16000"},
        {"32", "125", "750", "3000", "8000", "16000"},
        {"32", "125", "750", "3000", "8000", "16000"},
        {"32", "125", "750", "3000", "8000", "16000"},
        {"32", "125", "750", "3000", "8000", "16000"},
        {"32", "125", "750", "3000", "8000", "16000"},
        {"32", "125", "750", "3000", "8000", "16000"},
        {"32", "125", "750", "3000", "8000", "16000"},
        {"32", "125", "750", "3000", "8000", "16000"}
    };
    mEqDefaultQRatio = {
        {"0.7", "0.7", "0.7", "0.7", "0.7", "0.7"},
        {"0.7", "0.7", "0.7", "0.7", "0.7", "0.7"},
        {"0.7", "0.7", "0.7", "0.7", "0.7", "0.7"},
        {"0.7", "0.7", "0.7", "0.7", "0.7", "0.7"},
        {"0.7", "0.7", "0.7", "0.7", "0.7", "0.7"},
        {"0.7", "0.7", "0.7", "0.7", "0.7", "0.7"},
        {"0.7", "0.7", "0.7", "0.7", "0.7", "0.7"},
        {"0.7", "0.7", "0.7", "0.7", "0.7", "0.7"},
        {"0.7", "0.7", "0.7", "0.7", "0.7", "0.7"},
        {"0.7", "0.7", "0.7", "0.7", "0.7", "0.7"}
    };
    mEqDefaultGain = {
        {"0", "0", "0", "0", "0", "0"},         //FLAT
        {"5", "3", "-2", "1", "3", "4"},        //CLASSICAL
        {"-2", "0", "3", "2", "-1", "-2"},     //POP
        {"5", "3", "-1", "2", "4", "5"},       //ROCK
        {"4", "3", "-1", "1", "3", "4"},        //JAZZ
        {"0", "0", "0", "0", "0", "0"},         // CUSTOM 1
        {"0", "0", "0", "0", "0", "0"},         // CUSTOM 2
        {"0", "0", "0", "0", "0", "0"},         // CUSTOM 3
        {"0", "0", "0", "0", "0", "0"},         // CUSTOM 4
        {"0", "0", "0", "0", "0", "0"}          // CUSTOM 5
    };


    for(int i = 0; i < mDefaultRoomPresetName.size(); i++)
    {
        _roomDspPresetItemInfo roomPresetItem;
        roomPresetItem.mRoomDspIndex = to_string(i);
        roomPresetItem.mRoomDspName = mDefaultRoomPresetName.at(i);

        for(int j = 0; j < 6; j++)
        {
            roomPresetItem.mRoomEqIndex[j] = to_string(j);
            roomPresetItem.mRoomEqEnable[j] = "1";
            roomPresetItem.mRoomEqFreq[j] = mEqDefaultFreq[i].at(j);
            roomPresetItem.mRoomEqQratio[j] = mEqDefaultQRatio[i].at(j);
            roomPresetItem.mRoomEqGain[j] = mEqDefaultGain[i].at(j);
        }
        mRoomDspVecInfo.push_back(roomPresetItem);
    }

    mSpeakerEqDefaultFreq = {
        {"63", "125", "315", "800", "12500", "16000"},
        {"63", "125", "315", "800", "12500", "16000"},
        {"80", "200", "1250", "2500", "5000", "16000"},
        {"63", "200", "800", "1600", "2500", "16000"},
        {"50", "200", "1250", "4000", "6300", "16000"},
        {"63", "200", "500", "1250", "12500", "16000"},
        {"80", "200", "630", "1250", "6300", "16000"},
        {"80", "200", "1250", "3150", "6300", "16000"},
        {"80", "200", "630", "5000", "16000", "16000"},
        {"50", "160", "1600", "5000", "16000", "16000"},
        {"63", "200", "800", "2000", "4000", "16000"},
        {"80", "200", "1250", "3150", "10000", "16000"},
        {"63", "200", "1600", "4000", "16000", "16000"},
        {"80", "200", "2500", "6300", "16000", "16000"},
        {"125", "250", "4000", "16000", "16000", "16000"},
        {"100", "200", "1600", "4000", "12500", "16000"},
        {"100", "200", "1250", "6300", "16000", "16000"},
        {"80", "200", "1250", "4000", "16000", "16000"},
        {"100", "250", "800", "1000", "2500", "16000"},
        {"125", "200", "630", "1250", "2500", "16000"},
        {"100", "200", "1250", "16000", "16000", "16000"},
        {"100", "200", "400", "2500", "6300", "16000"},
        {"80", "250", "1000", "16000", "16000", "16000"},
        {"80", "315", "2000", "5000", "16000", "16000"},
        {"80", "200", "500", "1600", "4000", "16000"},
        {"100", "160", "315", "1250", "5000", "16000"},
        {"80", "200", "800", "4000", "8000", "16000"},
        {"63", "125", "160", "250", "500", "16000"},
        {"80", "200", "1250", "2500", "6300", "16000"},
        {"125", "250", "4000", "16000", "16000", "16000"},
        {"125", "250", "4000", "16000", "16000", "16000"},
        {"100", "200", "1600", "4000", "12500", "16000"},
        {"100", "200", "1600", "4000", "12500", "16000"},
        {"100", "200", "400", "800", "4000", "16000"},
        {"80", "200", "1250", "4000", "16000", "16000"},
        {"80", "200", "1250", "4000", "16000", "16000"},
        {"100", "250", "800", "1000", "2500", "16000"},
        {"100", "250", "800", "1000", "2500", "16000"},
        {"125", "160", "1250", "3150", "10000", "16000"},
        {"100", "200", "800", "1250", "4000", "16000"},
        {"125", "200", "1250", "3150", "5000", "16000"},
        {"80", "100", "200", "1600", "5000", "16000"},
        {"125", "200", "400", "800", "2500", "16000"},
        {"80", "200", "400", "1600", "16000", "16000"},
        {"100", "125", "250", "630", "4000", "16000"},
        {"125", "200", "1000", "3150", "6300", "16000"},
        {"80", "200", "500", "1600", "2500", "16000"},
        {"100", "200", "1600", "2500", "16000", "16000"},
        {"125", "200", "400", "2500", "10000", "16000"},
        {"100", "200", "1250", "4000", "20000", "16000"},
        {"100", "200", "800", "2500", "5000", "16000"},
        {"100", "800", "16000", "16000", "16000", "16000"},
        {"125", "200", "2000", "5000", "16000", "16000"},
        {"125", "200", "2000", "5000", "16000", "16000"},
        {"125", "200", "1250", "2500", "6300", "16000"},
        {"80", "400", "800", "1000", "8000", "16000"},
        {"2.5", "50", "2500", "4000", "16000", "16000"},
        {"80", "250", "800", "1250", "6300", "16000"},
        {"63", "80", "200", "5000", "12500", "16000"},
        {"80", "250", "800", "2500", "10000", "16000"},
        {"100", "160", "630", "2000", "4000", "16000"},
        {"80", "160", "315", "1600", "2500", "16000"},
        {"63", "125", "315", "800", "12500", "16000"},
        {"63", "125", "315", "800", "10000", "16000"},
        {"80", "160", "500", "1250", "5000", "16000"},
        {"80", "160", "1000", "2500", "5000", "16000"},
        {"80", "160", "500", "5000", "8000", "16000"},
        {"63", "200", "400", "1250", "6300", "16000"},
        {"80", "160", "315", "1250", "8000", "16000"},
        {"63", "200", "500", "2500", "6300", "16000"},
        {"63", "160", "315", "5000", "16000", "16000"},
        {"63", "160", "400", "1250", "6300", "16000"},
        {"63", "315", "1000", "2000", "4000", "16000"},
        {"80", "125", "200", "4000", "16000", "16000"},
        {"80", "125", "160", "5000", "16000", "16000"},
        {"80", "125", "200", "800", "4000", "16000"},
        {"63", "160", "250", "400", "16000", "16000"},
        {"63", "80", "125", "200", "500", "16000"}
    };

    mSpeakerEqDefaultGain = {
        {"0", "0", "0", "0", "0", "0"},
        {"0", "0", "0", "0", "0", "0"},
        {"3", "-4", "-6", "2", "-2", "0"},
        {"3", "-3.5", "-1.5", "-4", "1.5", "0"},
        {"2.5", "-3", "-3", "-3.5", "-3", "0"},
        {"3", "-2.5", "2.5", "-6", "4", "0"},
        {"3", "-4", "-3", "-4", "-6", "0"},
        {"3", "-6", "-3", "3", "-4", "0"},
        {"2", "-4", "-1", "-6", "0", "0"},
        {"4", "-5", "-4", "-4", "0", "0"},
        {"2.5", "-5.5", "-1.5", "-2", "-1.5", "0"},
        {"3", "-5", "1.5", "-3.5", "2", "0"},
        {"3", "-2.5", "-4", "-4", "2", "0"},
        {"4", "-4", "-5", "-5", "3", "0"},
        {"3", "-7", "-6", "0", "0", "0"},
        {"3", "-5.5", "-2", "-3", "-2", "0"},
        {"4", "-5", "-3", "-1", "0", "0"},
        {"3", "-7", "-1", "-2", "0", "0"},
        {"3", "-6", "-1", "-1.5", "-1", "0"},
        {"2", "-5", "1", "-5", "-1.5", "0"},
        {"3", "-4", "-2", "0", "0", "0"},
        {"3.5", "-6", "-2", "-2", "1", "0"},
        {"3", "-4", "-2", "0", "0", "0"},
        {"4", "-7", "-4", "-3", "0", "0"},
        {"3", "-4", "2", "-3", "-4", "0"},
        {"3", "-6", "-2", "-2", "-4", "0"},
        {"2", "-4", "2", "-5", "-7", "0"},
        {"2", "2", "-5", "-2.5", "1", "0"},
        {"2", "-2", "-3", "3", "-2", "0"},
        {"3", "-7", "-6", "0", "0", "0"},
        {"3", "-7", "-6", "0", "0", "0"},
        {"3", "-5.5", "-2", "-3", "-2", "0"},
        {"3", "-5.5", "-2", "-3", "-2", "0"},
        {"2", "-6", "-7.5", "3", "-2", "0"},
        {"3", "-7", "-1", "-2", "0", "0"},
        {"3", "-7", "-1", "-2", "0", "0"},
        {"3", "-6", "-1", "-1.5", "-1", "0"},
        {"3", "-6", "-1", "-1.5", "-1", "0"},
        {"2", "-1", "-4", "-2.5", "-3", "0"},
        {"2.5", "-1.5", "1", "-2", "-3", "0"},
        {"2", "-2.5", "-1.5", "-2", "-1.5", "0"},
        {"1", "2.5", "-2", "-2", "-2.5", "0"},
        {"2", "-2", "-5.5", "2.5", "-2.5", "0"},
        {"1.5", "-2", "-2.5", "3", "1", "0"},
        {"1.5", "1.5", "-4.5", "-2.5", "-3", "0"},
        {"2.5", "-6", "-2", "-4", "-2.5", "0"},
        {"1.5", "-3", "1", "4", "-3.5", "0"},
        {"1.5", "-3", "4", "-5", "0", "0"},
        {"1.5", "-4", "1.5", "-1", "2", "0"},
        {"2.5", "-1.5", "-1.5", "-1", "-2", "0"},
        {"2", "-1.5", "-1.5", "-1.5", "-1", "0"},
        {"1", "-1", "0", "0", "0", "0"},
        {"2", "-1.5", "-2", "1", "0", "0"},
        {"2", "-1.5", "-2", "1", "0", "0"},
        {"2", "-1.5", "2", "2.5", "-2", "0"},
        {"1.5", "-5", "4", "2", "1.5", "0"},
        {"3", "-5", "-2.5", "-2.5", "0", "0"},
        {"1.5", "-3", "4", "2", "3", "0"},
        {"1.5", "1", "-1", "1.5", "-1.5", "0"},
        {"2.5", "1", "-2.5", "-3.5", "-4", "0"},
        {"2", "-2", "3", "2.5", "-2", "0"},
        {"1.5", "-1.5", "1.5", "3", "-2", "0"},
        {"-3", "3", "-4", "-3", "-8", "0"},
        {"-3", "3", "-4", "-3", "-6", "0"},
        {"2", "-2", "2", "-3", "-5", "0"},
        {"2.5", "-2.5", "-1", "2.5", "-4", "0"},
        {"2", "-1", "2.5", "-5", "-5", "0"},
        {"2.5", "-3", "2.5", "-1", "-3", "0"},
        {"2", "-2", "2.5", "-1.5", "2", "0"},
        {"1.5", "-1", "3", "2", "-3", "0"},
        {"1.5", "-1.5", "1.5", "-2", "0", "0"},
        {"1.5", "-2", "3.5", "-5", "-1", "0"},
        {"2.5", "2", "-2", "3", "-5", "0"},
        {"2", "1.5", "-2", "-3", "-2", "0"},
        {"2", "2", "-3", "-3", "0", "0"},
        {"3", "1", "-4", "-2.5", "-1", "0"},
        {"2.5", "-3", "-2", "3", "0", "0"},
        {"2", "2.5", "-2.5", "-4", "2", "0"}
    };

    mSpeakerEqDefaultQRatio = {
        {"1", "1", "1", "1", "1", "0"},
        {"1", "1", "1", "1", "1", "0"},
        {"3", "2", "3", "3", "3", "0"},
        {"3", "2", "3", "3", "3", "0"},
        {"3", "2", "2", "3", "3", "0"},
        {"2", "2", "2", "2", "3", "0"},
        {"3", "2", "2", "3", "2", "0"},
        {"3", "2", "1", "3", "3", "0"},
        {"3", "2", "3", "3", "0.7", "0"},
        {"1", "1", "3", "3", "0.7", "0"},
        {"2", "3", "3", "2", "3", "0"},
        {"3", "2", "2", "1", "1", "0"},
        {"2", "2", "2", "0.8", "3", "0"},
        {"2", "1", "1", "2", "1", "0"},
        {"3", "3", "2", "0.7", "0.7", "0"},
        {"3", "2", "1", "2", "3", "0"},
        {"3", "1", "3", "0.5", "0.7", "0"},
        {"3", "2", "2", "3", "0.7", "0"},
        {"3", "2", "2", "3", "3", "0"},
        {"3", "2", "0.7", "2", "3", "0"},
        {"2", "2", "3", "0.7", "0.7", "0"},
        {"2", "3", "3", "2", "3", "0"},
        {"2", "2", "1", "0.7", "0.7", "0"},
        {"1", "1", "3", "3", "0.7", "0"},
        {"2", "2", "1", "2", "2", "0"},
        {"3", "2", "1", "3", "3", "0"},
        {"2", "2", "0.8", "3", "3", "0"},
        {"2", "3", "3", "3", "3", "0"},
        {"2", "2", "1", "1", "1", "0"},
        {"3", "3", "2", "0.7", "0.7", "0"},
        {"3", "3", "2", "0.7", "0.7", "0"},
        {"3", "2", "1", "2", "3", "0"},
        {"3", "2", "1", "2", "3", "0"},
        {"3", "3", "2", "3", "3", "0"},
        {"3", "2", "2", "3", "0.7", "0"},
        {"3", "2", "2", "3", "0.7", "0"},
        {"3", "2", "2", "3", "3", "0"},
        {"3", "2", "2", "3", "3", "0"},
        {"3", "3", "2", "1", "3", "0"},
        {"3", "3", "2", "2", "0.7", "0"},
        {"2", "3", "1", "0.8", "3", "0"},
        {"3", "3", "3", "0.7", "3", "0"},
        {"3", "3", "3", "2", "0.5", "0"},
        {"2", "2", "2", "0.6", "2", "0"},
        {"3", "3", "3", "2", "3", "0"},
        {"3", "2", "1", "2", "0.6", "0"},
        {"3", "2", "1", "1", "3", "0"},
        {"3", "2", "3", "3", "0.7", "0"},
        {"3", "2", "3", "2", "1", "0"},
        {"3", "3", "0.5", "1", "3", "0"},
        {"2", "3", "3", "0.8", "3", "0"},
        {"3", "2", "0.7", "0.7", "0.7", "0"},
        {"2", "2", "0.7", "0.7", "0.7", "0"},
        {"2", "2", "0.7", "0.7", "0.7", "0"},
        {"3", "3", "2", "3", "1", "0"},
        {"3", "3", "2", "3", "2", "0"},
        {"2", "3", "3", "3", "0.7", "0"},
        {"3", "2", "1", "3", "1", "0"},
        {"2", "3", "3", "1", "1", "0"},
        {"2", "3", "2", "1", "1", "0"},
        {"3", "2", "2", "3", "2", "0"},
        {"2", "2", "1", "3", "0.9", "0"},
        {"3", "3", "2", "2", "2", "0"},
        {"3", "3", "2", "2", "3", "0"},
        {"3", "3", "1", "3", "3", "0"},
        {"2", "3", "2", "2", "2", "0"},
        {"3", "1", "0.8", "3", "3", "0"},
        {"3", "3", "1", "2", "3", "0"},
        {"3", "2", "2", "1", "2", "0"},
        {"3", "3", "0.7", "0.7", "3", "0"},
        {"3", "2", "2", "1", "0.7", "0"},
        {"3", "2", "2", "2", "2", "0"},
        {"3", "3", "2", "3", "1", "0"},
        {"3", "3", "2", "3", "3", "0"},
        {"3", "3", "2", "2", "0.7", "0"},
        {"3", "2", "2", "1", "1", "0"},
        {"3", "2", "2", "1", "0.7", "0"},
        {"3", "2", "3", "2", "1", "0"}
    };

    for(int i = 0; i < mDefaultSpeakerPresetName.size(); i++)
    {
        _speakerDspPresetItemInfo speakerPresetItem;
        speakerPresetItem.mSpeakerDspIndex = to_string(i+1);
        speakerPresetItem.mSpeakerDspName = mDefaultSpeakerPresetName.at(i);
        for(int j = 0; j < 6; j ++)
        {
            speakerPresetItem.mSpeakerEqIndex[j] = to_string(j);
            speakerPresetItem.mSpeakerEqEnable[j] = "1";
            if(j == 5){
                speakerPresetItem.mSpeakerEqEnable[j] = "0";
            }
            speakerPresetItem.mSpeakerEqFreq[j] = mSpeakerEqDefaultFreq[i].at(j);
            speakerPresetItem.mSpeakerEqQratio[j] = mSpeakerEqDefaultQRatio[i].at(j);
            speakerPresetItem.mSpeakerEqGain[j] = mSpeakerEqDefaultGain[i].at(j);
        }
        mSpeakerDspMapInfo[i+1] = speakerPresetItem;
    }
    DEBUG_LOG("mSpeakerDspMapInfo size: %d",mSpeakerDspMapInfo.size());
    DEBUG_LOG("mRoomDspVecInfo size: %d",mRoomDspVecInfo.size());
    CreateRoomDspPresetInfoTab();
    initRoomDspPresetInfoTab();
    getRoomDspPresetInfoFromTab(mRoomDspVecInfo);

    CreateSpeakerDspPresetInfoTab();
    initSpeakerDspPresetInfoTab();
    getSpeakerDspPresetInfoFromTab(mSpeakerDspMapInfo);
#if 0
    CreateDspInfoTab();
    initDspInfoTab();
    getDspInfoFromTab(mDspPresetInfo);

    CreateEqItemTab();
    initEqItemTab();
    getEqItemFromTab(mEQItemInfo);
#endif
    Tools::getInstanc()->getNetStatus(sysdata::getInstance()->netinfo, "eth0");
    if(sysdata::getInstance()->netinfo.ip.empty())
    {
        LEDMISC::getInstance()->SetNetWork(0);
    }
    else
    {
        LEDMISC::getInstance()->SetNetWork(1);
    }

    mToken = Tools::getInstanc()->getRandom();

    create_tables();
    autoUpgradeDatabase();

}

void sysdata:: FactoryDefault()
{
     int i,j,k;
     pthread_mutex_lock(&Lock);
     for(i=0;i<CHANNELS;i++)
     {
         for(j=0;j<DSP_N;j++)
         {
            dspdata[i].dsp[j]=0;
         }
         for(k=0;k<2;k++)
         {
             if(k==BASS)dspdata[i].dspshelf[ENUM_SHELF_N*k+ENUM_shelf_freq]=200;
             else dspdata[i].dspshelf[ENUM_SHELF_N*k+ENUM_shelf_freq]=2000;
             dspdata[i].dspshelf[ENUM_SHELF_N*k+ENUM_shelf_gain]=0;
             dspdata[i].dspshelf[ENUM_SHELF_N*k+ENUM_shelf_q]=58;
             dspdata[i].dspshelf[ENUM_SHELF_N*k+ENUM_shelf_sr]=96000;
         }

         for(k=0;k<12;k++)
         {
             dspdata[i].dsppeq[ENUM_PEQ_N*k+ENUM_PEQ_Freq]=1000;
             dspdata[i].dsppeq[ENUM_PEQ_N*k+ENUM_PEQ_Gain]=0;
             dspdata[i].dsppeq[ENUM_PEQ_N*k+ENUM_PEQ_Q]=600;
             dspdata[i].dsppeq[ENUM_PEQ_N*k+ENUM_PEQ_SR]=96000;
         }

         dspdata[i].dsp[ENUM_Inputvolume]=24;
         dspdata[i].dsp[ENUM_Outputsource]=CHANNELS;
         dspdata[i].dsp[ENUM_startvolume]=20;
         dspdata[i].dsp[ENUM_maxvolume]=100;
         dspdata[i].dsp[ENUM_volume]=20;
         dspdata[i].dsp[ENUM_balance]=24;
         dspdata[i].dsp[ENUM_merge]=Switch_stereo;
         dspdata[i].dsp[ENUM_oscgain]=10;
         dspdata[i].dsp[ENUM_crossover_gain]=3;
         dspdata[i].dsp[ENUM_signalpresence_threshold]=-30;
         dspdata[i].dsp[ENUM_signalpresence_releasetime]=5;
      }
       devicedata.power=1;

    // UpdateDsp(dspdata);



     devicedata.asg=0;
     devicedata.audiosens=0;
     devicedata.autostandby=1;
     for(i=0;i<CHANNELS/8;i++)
     {
         devicedata.zoon[i]=0;

     }
     UpdateDevice(devicedata);
     pthread_mutex_unlock(&Lock);
}


int sysdata:: SetinputVolme(unsigned int index,unsigned int volume)
{
 if(index>=CHANNELS || volume>48)return -1;
 pthread_mutex_lock(&Lock);
 dspdata[index].dsp[ENUM_Inputvolume]=volume;
 pthread_mutex_unlock(&Lock);
 return 1;
}

void sysdata:: SetVolumeAdd(unsigned int index,int volume)
{
    if(index>=CHANNELS)return;
    pthread_mutex_lock(&Lock);
    dspdata[index].dsp[ENUM_volume]+=volume;
    if(dspdata[index].dsp[ENUM_volume]>100)
    {
     dspdata[index].dsp[ENUM_volume]=100;
    }
    if(dspdata[index].dsp[ENUM_volume]<0)
    {
     dspdata[index].dsp[ENUM_volume]=0;
    }
    pthread_mutex_unlock(&Lock);
}

void sysdata::SetSPThreshold(unsigned int index,int data)
{
    if((index>=CHANNELS) || (data > 0) || (data < -150))return;
    pthread_mutex_lock(&Lock);
    dspdata[index].dsp[ENUM_signalpresence_threshold]=data;
    pthread_mutex_unlock(&Lock);
}

void sysdata::SetSPReleasetime(unsigned int index,unsigned int data)
{
    if((index>=CHANNELS) || (data < 2) || (data > 200))return;
    pthread_mutex_lock(&Lock);
    dspdata[index].dsp[ENUM_signalpresence_releasetime]=data;
    pthread_mutex_unlock(&Lock);
}

void sysdata::Setinputdelay(unsigned int index,unsigned int delay)
{
    if(index>=CHANNELS || delay>80)return;
    pthread_mutex_lock(&Lock);
    dspdata[index].dsp[ENUM_Inputdelay]=delay;
    pthread_mutex_unlock(&Lock);
}
void sysdata::Setoutputdelay(unsigned int index,unsigned int delay)
{
    if(index>=CHANNELS || delay>80)return;
    pthread_mutex_lock(&Lock);
    dspdata[index].dsp[ENUM_outputdelay]=delay;
    pthread_mutex_unlock(&Lock);
}
void sysdata::Setoutputsource(unsigned int index,unsigned int source)
{
    if(index>=CHANNELS || source>CHANNELS)return;
    pthread_mutex_lock(&Lock);
    dspdata[index].dsp[ENUM_Outputsource]=source;
    pthread_mutex_unlock(&Lock);
}

void sysdata:: Setvolume(unsigned int index,unsigned int volume)
{
     if(index>=CHANNELS)return;
     pthread_mutex_lock(&Lock);
     dspdata[index].dsp[ENUM_volume]=volume>100?100:volume;
     pthread_mutex_unlock(&Lock);
}

void sysdata:: SetmaxVolume(unsigned int index,unsigned int volume)
{
     if(index>=CHANNELS || volume>101)return;
     pthread_mutex_lock(&Lock);
     dspdata[index].dsp[ENUM_maxvolume]=volume;
     pthread_mutex_unlock(&Lock);
}
void sysdata:: Setturnonvolume(unsigned int index,unsigned int volume)
{
     if(index>=CHANNELS || volume>101)return;
     pthread_mutex_lock(&Lock);
     dspdata[index].dsp[ENUM_startvolume]=volume;
     pthread_mutex_unlock(&Lock);
}

void sysdata:: SetPEQ(unsigned int index,unsigned int type,unsigned int peqindex,unsigned int vol)
{
     if(index>=CHANNELS || type>ENUM_PEQ_N || (peqindex>11))return;
     pthread_mutex_lock(&Lock);
     dspdata[index].dsppeq[peqindex*ENUM_PEQ_N+type]=vol;
     pthread_mutex_unlock(&Lock);
}
//0 bass,1 treble
void sysdata:: SetShelf(unsigned int index,unsigned int type,unsigned int trbass,unsigned int vol)
{
    printf("index:%d,type:%d,trbass:%d,vol:%x\r\n",index,type,trbass,vol);
    if(index>=CHANNELS || type>ENUM_SHELF_N)return;
    pthread_mutex_lock(&Lock);
    dspdata[index].dspshelf[trbass*ENUM_SHELF_N+type]=vol;
   // printf("sss channel:%d,data:%x,%d\r\n",index,dspdata[index].dspshelf[trbass*ENUM_SHELF_N+type],trbass*ENUM_SHELF_N+type);
    pthread_mutex_unlock(&Lock);
}
//0 ENUM_crossover_freq,1 ENUM_crossover_sr,2 ENUM_crossover_index
void sysdata:: SetXover(unsigned int index,unsigned int type,unsigned int vol)
{
    //printf("1index:%d,type:%d,vol:%x\r\n",index,type,vol);
    if(index>=CHANNELS || type>Xover_N)return;
    pthread_mutex_lock(&Lock);
    dspdata[index].dsp[ENUM_crossover_freq+type]=vol;//
    pthread_mutex_unlock(&Lock);
    //printf("2index:%d,type:%d,vol:%x\r\n",index,type,vol);
}

void sysdata:: SetLoudness(unsigned int index,unsigned int loudness)
{
     if(index>=CHANNELS)return;
     pthread_mutex_lock(&Lock);
     if(loudness==2)
     {
       dspdata[index].dsp[ENUM_loudness] =!dspdata[index].dsp[ENUM_loudness];
     }
     else
     dspdata[index].dsp[ENUM_loudness]=!!loudness;
     pthread_mutex_unlock(&Lock);
}
void sysdata:: SetBalance(unsigned int index,unsigned int balance)
{
   // LOGOUT("unsigned int");
     if(index>=CHANNELS || balance>48)return;
     pthread_mutex_lock(&Lock);
     dspdata[index].dsp[ENUM_balance]=balance;
     pthread_mutex_unlock(&Lock);
}
int sysdata:: SetSubVolume(unsigned int index,unsigned int volume)
{
    //LOGOUT("unsigned int");
     if(index>=CHANNELS || volume>48)return -1;
     pthread_mutex_lock(&Lock);
     dspdata[index].dsp[ENUM_crossover_gain]=volume;
     pthread_mutex_unlock(&Lock);
     return 0;
}

int sysdata:: GetGroupVolume(int group)
{
    int i,ret=0;
    if(group>=8)return -1;
    for(i=0;i<CHANNELS;i++)
    {
        if((dspdata[i].dsp[ENUM_group]==0x100+group)||((dspdata[i].dsp[ENUM_group]>0x10)&&(group==-1)))
        {
            return dspdata[i].dsp[ENUM_volume];
        }
    }

    return -1;
}
int sysdata:: SetGroupVolumeAdd(int group,int volume)
{
     int i,ret=0;
     if(group>=8)return 0;
     pthread_mutex_lock(&Lock);
     for(i=0;i<CHANNELS;i++)
     {
         if((dspdata[i].dsp[ENUM_group]==0x100+group)||((dspdata[i].dsp[ENUM_group]>0x10)&&(group==-1)))
         {
             dspdata[i].dsp[ENUM_volume]+=volume;
             if(dspdata[i].dsp[ENUM_volume]>100)dspdata[i].dsp[ENUM_volume]=100;
             if(dspdata[i].dsp[ENUM_volume]<0)dspdata[i].dsp[ENUM_volume]=0;
             ret=1;
         }
     }
     pthread_mutex_unlock(&Lock);
     return ret;
}
int sysdata:: SetGroupVolume(int group,float volume)
{
 int i,ret=0;
 if((group>=8)||(volume>100))return 0;
 pthread_mutex_lock(&Lock);
 for(i=0;i<CHANNELS;i++)
 {
     if((dspdata[i].dsp[ENUM_group]==0x100+group)||((dspdata[i].dsp[ENUM_group]>0x10)&&(group==-1)))
     {
        dspdata[i].dsp[ENUM_volume]=volume;
        ret=1;
     }
 }
 pthread_mutex_unlock(&Lock);
 return ret;
}

int sysdata:: GetGroupSource(int group)
{
    int i,ret=0;
    if(group>=8)return -1;
    for(i=0;i<CHANNELS;i++)
    {
        if((dspdata[i].dsp[ENUM_group]==0x100+group)||((dspdata[i].dsp[ENUM_group]>0x10)&&(group==-1)))
        {
            return dspdata[i].dsp[ENUM_Outputsource];
        }
    }
    return -1;
}

int sysdata:: SetGroupSource(int group,int source)
{
 int i,ret=0;
 if((group>=8)||(source>CHANNELS))return 0;
 pthread_mutex_lock(&Lock);
 for(i=0;i<CHANNELS;i++)
 {
     if((dspdata[i].dsp[ENUM_group]==0x100+group)||((dspdata[i].dsp[ENUM_group]>0x10)&&(group==-1)))
     {
        dspdata[i].dsp[ENUM_Outputsource]=source;
        ret= 1;
     }
 }
 pthread_mutex_unlock(&Lock);
 return ret;
}
int sysdata:: GetGroupMute(int group)
{
    int i,ret=0;
    if(group>=8)return -1;
    for(i=0;i<CHANNELS;i++)
    {
        if((dspdata[i].dsp[ENUM_group]==0x100+group)||((dspdata[i].dsp[ENUM_group]>0x10)&&(group==-1)))
        {
            return dspdata[i].dsp[ENUM_dspmute];
        }
    }
    return -1;
}
int sysdata:: SetGroupMute(int group,int mute)
{
     int i,ret=0;
     if(group>=8)return 0;
     pthread_mutex_lock(&Lock);
     for(i=0;i<CHANNELS;i++)
     {
         if((dspdata[i].dsp[ENUM_group]==0x100+group)||((dspdata[i].dsp[ENUM_group]>0x10)&&(group==-1)))
         {
             if(mute==2)dspdata[i].dsp[ENUM_dspmute]=!dspdata[i].dsp[ENUM_dspmute];
             else dspdata[i].dsp[ENUM_dspmute]=mute;
             ret=1;
         }
     }
     pthread_mutex_unlock(&Lock);
     return ret;
}

void sysdata:: SetGroup(int index,int group)
{
     if((index>=CHANNELS)||(group>=9))return;
     pthread_mutex_lock(&Lock);
     if(group>=8)dspdata[index].dsp[ENUM_group]=0;
     else dspdata[index].dsp[ENUM_group]=0x100+group;
     pthread_mutex_unlock(&Lock);
}

void sysdata::SetDspmute(unsigned int index,int mute)
{
    if(index>=CHANNELS)return;
    pthread_mutex_lock(&Lock);
    if(mute==2)dspdata[index].dsp[ENUM_dspmute]=!dspdata[index].dsp[ENUM_dspmute];
    else dspdata[index].dsp[ENUM_dspmute]=mute;
    pthread_mutex_unlock(&Lock);
}

int sysdata::SetOscGain(unsigned int index,int Gain)
{
    if(index>=CHANNELS || Gain>48)return -1;
    pthread_mutex_lock(&Lock);
    dspdata[index].dsp[ENUM_oscgain]=Gain;
    pthread_mutex_unlock(&Lock);
    return 0;
}

void sysdata::Power(int power)
{
    pthread_mutex_lock(&Lock);
    if(power==2)devicedata.power=!devicedata.power;
    else devicedata.power=!!power;
    pthread_mutex_unlock(&Lock);
}

void sysdata::SetAsg(int set)
{
    devicedata.asg=set;
    LEDMISC::getInstance()->SetAsg(devicedata.asg);
    UpdateDevice(devicedata);
}

void sysdata::SetAutoStandby(int set)
{
    devicedata.autostandby=set;
    UpdateDevice(devicedata);
}

int sysdata::SetZoon(int set,int on)
{
    if(set<CHANNELS/8)
    {
        if(on==2)devicedata.zoon[set]=!devicedata.zoon[set];
        else devicedata.zoon[set]=!!on;
        LEDMISC::getInstance()->SetZoon(set,devicedata.zoon[set]);
        UpdateDevice(devicedata);
        return 1;
    }
    else return -1;
}
int sysdata::ZoonGet(int index)
{
    if(index<CHANNELS)
    {
      return devicedata.zoon[index/2];
    }
    return -1;
}

void sysdata::SetAutoSense(int set)
{
  devicedata.audiosens=set;
  UpdateDevice(devicedata);
}


void sysdata::Mon(int index,unsigned int swi)
{
    if(index>=CHANNELS)return;
    pthread_mutex_lock(&Lock);
    if(swi<XSwitch_N)dspdata[index].dsp[ENUM_merge]=swi;
    else
    {
        if(dspdata[index].dsp[ENUM_merge]!=Switch_mono)
        {
            dspdata[index].dsp[ENUM_merge]=Switch_mono;
        }
        else
        {
            dspdata[index].dsp[ENUM_merge]=Switch_stereo;
        }
    }
    pthread_mutex_unlock(&Lock);
}
void sysdata::TestSignal(int index,unsigned int on)
{
    if(index>=CHANNELS)return;
    pthread_mutex_lock(&Lock);
    if(on)
    {
        if(dspdata[index].dsp[ENUM_merge]!=Switch_test)
        {
            dspdata[index].dsp[Enum_mergeBefore]=dspdata[index].dsp[ENUM_merge];
        }
        dspdata[index].dsp[ENUM_merge]=Switch_test;
    }
    else
    {
        if(dspdata[index].dsp[ENUM_merge]==Switch_test)
        {
            dspdata[index].dsp[ENUM_merge]=(dspdata[index].dsp[Enum_mergeBefore]==Switch_test)?Switch_stereo:dspdata[index].dsp[Enum_mergeBefore];
        }

    }
    pthread_mutex_unlock(&Lock);
}
void sysdata::MonStereo(int index,unsigned int stereo)
{
    if(index>=CHANNELS)return;
    pthread_mutex_lock(&Lock);

    if(stereo==1)
    {
        dspdata[index].dsp[ENUM_merge]=Switch_stereo;
    }
    else if(stereo==0)
    {
        dspdata[index].dsp[ENUM_merge]=Switch_mono;
    }
    else
    {
        if(dspdata[index].dsp[ENUM_merge]==Switch_mono)
        {
            dspdata[index].dsp[ENUM_merge]=Switch_stereo;
        }
        else
        {
            dspdata[index].dsp[ENUM_merge]=Switch_mono;
        }
    }
    pthread_mutex_unlock(&Lock);
}

void sysdata::SetAll(DSPstreaming dspset)
{
    pthread_mutex_lock(&Lock);
    //dspdata=dspset;
    //UpdateDsp(dspdata);
    pthread_mutex_unlock(&Lock);
}

void sysdata::ExeSet(void)
{
    sem_post(&sysdatasem);
}

////////////////////////////////////////////////////////
//mike
////////////////////////////////////////////////////////
S_ret sysdata::updateDataBaseTable(string dbname,string key, string value,string row)
{
    char * sql;
    char * zErrMsg = NULL;
    int nrow = stoi(row);

    sql = sqlite3_mprintf("update '%s' set '%s' = '%s' where id = %d",
                          dbname.c_str(), key.c_str(), value.c_str(), nrow);
    sqlite3_exec(getDB(), sql, 0,0, &zErrMsg);
    sqlite3_free(sql);
    return SUCESS;
}

S_ret sysdata::updateDataBaseEqInfoTable(string key, string value, string dspIndex, string uuid, bool room)
{
    char * sql;
    char * zErrMsg = NULL;

    string::size_type idx;

    idx=key.find("eq_");
    if(idx != string::npos )
    {
        key = key+ "_" + uuid;
    }

    if(room)
    {
        sql = sqlite3_mprintf("update t_room_Dsp_Preset_Info set '%s' = '%s' where id = %d",
                              key.c_str(), value.c_str(), stoull(dspIndex), uuid.c_str());
    }
    else
    {
        sql = sqlite3_mprintf("update t_speaker_Dsp_Preset_Info set '%s' = '%s' where id = %d",
                              key.c_str(), value.c_str(), stoull(dspIndex), uuid.c_str());
    }
    sqlite3_exec(getDB(), sql, 0,0, &zErrMsg);

    sqlite3_free(sql);
    return SUCESS;
}

S_ret sysdata::updateDataBasePresetInfoTable(string index_s, bool room)
{
    char * zErrMsg = NULL;

    string table,cmd;
    unsigned long index = stoul(index_s);
    if(room)
    {
       table  = "update t_room_Dsp_Preset_Info set room_dsp_preset_name = ";
       cmd = table + mRoomDspVecInfo[index].mRoomDspName + ",";

       for(int i = 0 ; i < MAX_EQ_NUM;i++)
       {
           cmd += "uuid_" + to_string(i) + "=";
           cmd += mRoomDspVecInfo[index].mRoomEqIndex[i] +",";
           cmd += "eq_enable_" + to_string(i) + "=";
           cmd += mRoomDspVecInfo[index].mRoomEqEnable[i] +",";
           cmd += "eq_freq_" + to_string(i) + "=";
           cmd += mRoomDspVecInfo[index].mRoomEqFreq[i] +",";
           cmd += "eq_qratio_" + to_string(i) + "=";
           cmd += mRoomDspVecInfo[index].mRoomEqQratio[i] +",";
           cmd += "eq_gain_" + to_string(i) + "=";
           if((MAX_EQ_NUM -1) == i)
               cmd += mRoomDspVecInfo[index].mRoomEqGain[i] +" ";
           else
               cmd += mRoomDspVecInfo[index].mRoomEqGain[i] +",";
       }
    }
    else
    {
       table  = "update t_speaker_Dsp_Preset_Info set speaker_dsp_preset_name = ";
       cmd = table + mSpeakerDspMapInfo[index].mSpeakerDspName + ",";

       for(int i = 0 ; i < MAX_EQ_NUM;i++)
       {
           cmd += "uuid_" + to_string(i) + "=";
           cmd += mSpeakerDspMapInfo[index].mSpeakerEqIndex[i] +",";
           cmd += "eq_enable_" + to_string(i) + "=";
           cmd += mSpeakerDspMapInfo[index].mSpeakerEqEnable[i] +",";
           cmd += "eq_freq_" + to_string(i) + "=";
           cmd += mSpeakerDspMapInfo[index].mSpeakerEqFreq[i] +",";
           cmd += "eq_qratio_" + to_string(i) + "=";
           cmd += mSpeakerDspMapInfo[index].mSpeakerEqQratio[i] +",";
           cmd += "eq_gain_" + to_string(i) + "=";
           if((MAX_EQ_NUM -1) == i)
               cmd += mSpeakerDspMapInfo[index].mSpeakerEqGain[i] +" ";
           else
               cmd += mSpeakerDspMapInfo[index].mSpeakerEqGain[i] +",";
       }
    }

    cmd += " where id = "+ index_s ; // id
    //LOGOUT("cmd: %s",cmd.c_str());
    sqlite3_exec(getDB(), cmd.c_str(), 0,0, &zErrMsg);

    return SUCESS;
}

S_ret sysdata::insertSpeakerPresetInfoTable()
{
    char * zErrMsg = NULL;
    SPEAKER_PRESET_MAP::iterator it = sysdata::getInstance()->mSpeakerDspMapInfo.end();
    --it;
    _speakerDspPresetItemInfo tmp = it->second;

    string cmd  = "INSERT INTO t_speaker_Dsp_Preset_Info VALUES(" + tmp.mSpeakerDspIndex +",'";
    cmd += tmp.mSpeakerDspName +"','" ; // Name
    for(int n = 0 ; n < MAX_EQ_NUM;n++)
    {
        cmd += tmp.mSpeakerEqIndex[n] +"','";
        cmd += tmp.mSpeakerEqEnable[n] +"','";
        cmd += tmp.mSpeakerEqFreq[n] +"','";
        cmd += tmp.mSpeakerEqQratio[n] +"','";
        if(MAX_EQ_NUM == (n+1))
            cmd += tmp.mSpeakerEqGain[n] +"');";
        else
            cmd += tmp.mSpeakerEqGain[n] +"','";
    }
    DEBUG_LOG("insert speaker cmd:%s",cmd.c_str());
    sqlite3_exec(getDB(),cmd.c_str(), 0, 0, &zErrMsg);
    return SUCESS;
}

S_ret sysdata::deleteSpeakerPresetInfoTable(string id_s)
{
    char * zErrMsg = NULL;
    unsigned long long id = stoull(id_s);
    sysdata::getInstance()->mSpeakerDspMapInfo.erase(id);
    string cmd = "DELETE from t_speaker_Dsp_Preset_Info where id = " + id_s + ";";

    DEBUG_LOG("delete speaker cmd:%s",cmd.c_str());
    sqlite3_exec(getDB(),cmd.c_str(), 0, 0, &zErrMsg);
    return SUCESS;
}

S_ret sysdata::importAllSpeakerPresetInfoTable()
{
    if(isrecordexist("select * from t_speaker_Dsp_Preset_Info"))
    {
        return FAILED;
    }

    string cmd;
    char * zErrMsg = NULL;
    cmd = "DELETE FROM t_speaker_Dsp_Preset_Info;";
    sqlite3_exec(getDB(),cmd.c_str(), 0, 0, &zErrMsg);

    cmd = "DELETE FROM sqlite_sequence;";
    sqlite3_exec(getDB(),cmd.c_str(), 0, 0, &zErrMsg);

    for(int i = 0; i < sysdata::getInstance()->mSpeakerDspMapInfo.size(); i++)
    {
        cmd = "INSERT INTO t_speaker_Dsp_Preset_Info VALUES(?,'";
        cmd += sysdata::getInstance()->mSpeakerDspMapInfo[i+1].mSpeakerDspName +"','" ; // Name
        for(int n = 0 ; n < MAX_EQ_NUM;n++)
        {
            cmd += sysdata::getInstance()->mSpeakerDspMapInfo[i+1].mSpeakerEqIndex[n] +"','";
            cmd += sysdata::getInstance()->mSpeakerDspMapInfo[i+1].mSpeakerEqEnable[n] +"','";
            cmd += sysdata::getInstance()->mSpeakerDspMapInfo[i+1].mSpeakerEqFreq[n] +"','";
            cmd += sysdata::getInstance()->mSpeakerDspMapInfo[i+1].mSpeakerEqQratio[n] +"','";
            if(MAX_EQ_NUM == (n+1))
                cmd += sysdata::getInstance()->mSpeakerDspMapInfo[i+1].mSpeakerEqGain[n] +"');";
            else
                cmd += sysdata::getInstance()->mSpeakerDspMapInfo[i+1].mSpeakerEqGain[n] +"','";

        }
        sqlite3_exec(getDB(),cmd.c_str(), 0, 0, &zErrMsg);
    }
    return SUCESS;
}

S_ret sysdata::resetDevice( )
{
    DEBUG_LOG("resetDevice");
    sysdata::getInstance()->Power(0);

    deleteDatabase();
    system("rm -rf /media/userdata/*");
    system("sleep 2 && reboot&");
    return SUCESS;
}

S_ret sysdata::rebootDevice()
{
    DEBUG_LOG("rebootDevice");
    //SystemControl::getInstance()->powerControlInterface(false);
    //system("touch /media/userdata/reboot.lock");

    system("reboot");
}

S_ret sysdata::firmwareUpdate(std::string  path)
{
    char cmd[1024] ={0};

    char *scriptname = "/usr/bin/triggerota.sh"; //脚本中返回值请不要使用0,success: 1 fail: 2,3....

    if (::access(scriptname, R_OK) == 0)
    {
        LOGOUT("New platform code");
        snprintf(cmd, sizeof(cmd),
                 "triggerota.sh /tmp/%s || echo $?", path.c_str());

        std::vector<std::string> retStr;
        Tools::getInstanc()->myexec(string(cmd),retStr);
        if(retStr.size() > 0)
        {
            return stoi(retStr.back());
        }
    }
    else
    {
        sprintf(cmd, "snapav_fw_upgrade.sh /tmp/%s ",path.c_str());
        DEBUG_LOG("firmwareUpdate [%s]" , cmd );
        system(cmd);
    }

    return SUCESS;
}


void sysdata::autoUpgradeDatabase(){
    string sqlcmd;
    int version = get_database_version();
    if(version >= DATABASE_VERSION || version <= 0)
    {
        return;
    }

//    if(DATABASE_VERSION >= 2 && version < 2){
//        sqlcmd.clear();
//        sqlcmd = "alter table Devicetab add column zoon_4 INT DEFAULT \"0\";";
//        runsqlcmd(sqlcmd);
//    }

//    updateVersionInfo("version_info", "version", DATABASE_VERSION);

}
