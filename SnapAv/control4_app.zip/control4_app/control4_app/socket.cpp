
/*
*   socket简单编程 服务端
 */
#include "sysdata.h"
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <socket.h>
#include "log.h"
#include "stream.h"
#include "ledmisc.h"
#include "tools.h"
#include "stdio.h"
#include "fifo.h"
#include "eqpagehandle.h"
#define  FD_SIZE_LEN  1024

void Writemac( char * mac)
{
    FILE *fp;
    fp = fopen("/tmp/mac.bin", "w+");
    fwrite(mac, 6, 1, fp);
    fclose(fp);
}
unsigned int BigToLittle(unsigned int Bigend)
{
    unsigned int tmp;
    tmp=(Bigend>>24)&0xff;
    tmp|=(Bigend>>8)&0xff00;
    tmp|=(Bigend<<24)&0xff000000;
    tmp|=(Bigend<<8)&0xff0000;
    return tmp;
}

int BigToLittleint(unsigned int Bigend)
{
    int tmp;
    tmp=(Bigend>>24)&0xff;
    tmp|=(Bigend>>8)&0xff00;
    tmp|=(Bigend<<24)&0xff000000;
    tmp|=(Bigend<<8)&0xff0000;
    return tmp;
}

struct control4pack data;
void SocketServer::Commhandle_Input_New(struct control4pack data)
{
    switch(data.optSecond)
    {
        case MSG_Input_Delay:
        {
            sysdata::getInstance()->Setinputdelay(data.Set.channel,data.Set.value);
            sysdata::getInstance()->ExeSet();
            sprintf(bufSend, "Set Input[%d] Delay %d",data.Set.channel+1,data.Set.value);
         }break;
        case MSG_Input_SPThreshold:
        {
            sysdata::getInstance()->SetSPThreshold(data.Set.channel,data.Setint.value);
            sysdata::getInstance()->ExeSet();
            sprintf(bufSend, "Set Input[%d] SPThreshold %d",data.Set.channel+1,data.Setint.value);
         }break;
         case MSG_Input_SPReleaseTime:
         {
             sysdata::getInstance()->SetSPReleasetime(data.Set.channel,data.Set.value);
             sysdata::getInstance()->ExeSet();
             sprintf(bufSend, "Set Input[%d] SPRleaseTime %d",data.Set.channel+1,data.Set.value);
         }break;
        default:break;
    }
}
void SocketServer::Commhandle_EQ(struct control4pack data)
{
    unsigned int eqnumber=data.optSecond>>4;
    if(eqnumber>11)return;
    if(eqnumber>5)
    {
        if(stoi(sysdata::getInstance()->mOutputDspInfo[data.Set.channel].mOutputLock))
        {
            sprintf(bufSend, "Out[%d] Room EQ locked",data.Set.channel+1);
            return;
        }
    }
    switch(data.optSecond&0x0f)
    {
        case MSG_EqFreq:
        {
           if((BigToLittleint(data.Setint.value)>=20) && (BigToLittleint(data.Setint.value)<=20000))
           {
               sysdata::getInstance()->SetPEQ(data.Set.channel,ENUM_PEQ_Freq,eqnumber,BigToLittle(data.Setint.value));
               sysdata::getInstance()->ExeSet();
               sprintf(bufSend, "Set Out[%d] Band %d Freq to %d Hz",data.Set.channel+1,eqnumber+1,BigToLittle(data.Setint.value));
           }
        }break;
        case MSG_EqGain:
        {
           if((BigToLittleint(data.Setint.value)>=-100*12) && (BigToLittleint(data.Setint.value)<=100*12))
           {
            sysdata::getInstance()->SetPEQ(data.Set.channel,ENUM_PEQ_Gain,eqnumber,BigToLittle(data.Setint.value));
            sysdata::getInstance()->ExeSet();
            sprintf(bufSend, "Set Out[%d] Band %d Gain to %g",data.Set.channel+1,eqnumber+1,((int)(BigToLittle(data.Setint.value)))/100.0);
           }

        }break;
        case MSG_EqQ:
        {
            if((BigToLittleint(data.Setint.value)>=0)&& (BigToLittleint(data.Setint.value)<=15*100))
            {
                sysdata::getInstance()->SetPEQ(data.Set.channel,ENUM_PEQ_Q,eqnumber,BigToLittle(data.Setint.value));
                sysdata::getInstance()->ExeSet();
                sprintf(bufSend, "Set Out[%d] Band %d Q to %g",data.Set.channel+1,eqnumber+1,((int)(BigToLittle(data.Setint.value)))/100.0);
            }
        }break;
    default:break;
    }
}
void SocketServer::Commhandle_Output_New(struct control4pack data)
{


        switch(data.optSecond)
        {
            case MSG_Output_HighSf:
            case MSG_Output_LowSf:
            case MSG_Output_Cf:
                if((BigToLittleint(data.Setint.value)<20) || (BigToLittleint(data.Setint.value)>20000))
                {
                    return ;
                }
            break;
            case MSG_Output_HighSq:
            case MSG_Output_LowSq:
                if((BigToLittleint(data.Setint.value)<0)|| (BigToLittleint(data.Setint.value)>15*100))
                {
                    return ;
                }
            break;
            case MSG_Output_HighSgain:
            case MSG_Output_LowSgain:
                if((BigToLittleint(data.Setint.value)<-12*100) || (BigToLittleint(data.Setint.value)>12*100))
                {
                    return ;
                }
                break;

        }

    switch(data.optSecond)
    {

    case MSG_Output_Delay:
    {
        sysdata::getInstance()->Setoutputdelay(data.Set.channel,data.Set.value);
        sysdata::getInstance()->ExeSet();
        sprintf(bufSend, "Set Output[%d] Delay %d",data.Set.channel+1,data.Set.value);
    }break;
    case MSG_Output_HighSf:
    {
        sysdata::getInstance()->SetShelf(data.Set.channel,ENUM_shelf_freq,TREBLE,BigToLittle(data.Setint.value));
        sysdata::getInstance()->ExeSet();
        sprintf(bufSend, "Set Out[%d] High Shelf Frequency to %d Hz",data.Set.channel+1,BigToLittle(data.Setint.value));
    }break;
    case MSG_Output_HighSq:
    {
        sysdata::getInstance()->SetShelf(data.Set.channel,ENUM_shelf_q,TREBLE,BigToLittle(data.Setint.value));
        sysdata::getInstance()->ExeSet();
        sprintf(bufSend, "Set Out[%d] High Shelf Q to %g",data.Set.channel+1,((int)(BigToLittle(data.Setint.value)))/100.0);
    }break;

    case MSG_Output_HighSgain:
    {
        sysdata::getInstance()->SetShelf(data.Set.channel,ENUM_shelf_gain,TREBLE,BigToLittle(data.Setint.value));
        sysdata::getInstance()->ExeSet();
        sprintf(bufSend, "Set Out[%d] High Shelf gain to %g",data.Set.channel+1,((int)(BigToLittle(data.Setint.value)))/100.0);
    }break;
    case MSG_Output_LowSgain:
    {
        sysdata::getInstance()->SetShelf(data.Set.channel,ENUM_shelf_gain,BASS,BigToLittle(data.Setint.value));
        sysdata::getInstance()->ExeSet();
        sprintf(bufSend, "Set Out[%d] Low Shelf gain to %g",data.Set.channel+1,((int)(BigToLittle(data.Setint.value)))/100.0);
    }break;

    case MSG_Output_LowSf:
    {
        sysdata::getInstance()->SetShelf(data.Set.channel,ENUM_shelf_freq,BASS,BigToLittle(data.Setint.value));
        sysdata::getInstance()->ExeSet();
        sprintf(bufSend, "Set Out[%d] Low Shelf Frequency to %d Hz",data.Set.channel+1,BigToLittle(data.Setint.value));
    }break;
    case MSG_Output_LowSq:
    {
        sysdata::getInstance()->SetShelf(data.Set.channel,ENUM_shelf_q,BASS,BigToLittle(data.Setint.value));
        sysdata::getInstance()->ExeSet();
        sprintf(bufSend, "Set Out[%d] Low Shelf Q to %g",data.Set.channel+1,((int)BigToLittle(data.Setint.value))/100.0);
    }break;
    case MSG_Output_Cf:
    {
        sysdata::getInstance()->SetXover(data.Set.channel,Xover_Freq,BigToLittle(data.Setint.value));
        sysdata::getInstance()->ExeSet();
        sprintf(bufSend, "Set Out[%d] Crossover Frequency to %d Hz",data.Set.channel+1,BigToLittle(data.Setint.value));
    }break;
    case MSG_Output_Ct:
    {
        sysdata::getInstance()->SetXover(data.Set.channel,Xover_Index,data.Set.value);
        sysdata::getInstance()->ExeSet();
        sprintf(bufSend, "Set Out[%d] Crossover Type to %s",data.Set.channel+1,SocketXoverType(data.Set.value));
    }break;
    case MSG_Output_LowPassGain:
    {
        if(sysdata::getInstance()->SetSubVolume(data.Set.channel,data.Set.value)>=0)
        {
            sysdata::getInstance()->ExeSet();
            sprintf(bufSend, "Set Out[%d] Low Pass Gain Offset to %g",data.Set.channel+1,SocketGainf(data.Set.value));
        }

    }break;

    case MSG_Output_RoomLock:
    {
        EqPageHandle::getInstance()->setOutputRoomEQLockFunc(data.Set.channel,data.Set.value?"1":"0");
        sprintf(bufSend, "Set Out[%d] Lock Room EQ %s",data.Set.channel+1,data.Set.value?"On":"Off");

    }break;
    case MSG_Output_Trigger:
    {
        sysdata::getInstance()->SetZoon(data.Set.channel/8,data.Set.value);
        sysdata::getInstance()->ExeSet();
        sprintf(bufSend, "Set Out[%d] Tigger %s",data.Set.channel+1,data.Set.value?"On":"Off");
    }break;
    case MSG_Output_MusicType:
    {
        if(data.Set.value<XSwitch_N)
        {
            sysdata::getInstance()->Mon(data.Set.channel,data.Set.value);
            sysdata::getInstance()->ExeSet();
            sprintf(bufSend, "Set Out[%d] Select:%s",data.Set.channel+1,SocketMusicType(!(data.Set.channel%2),data.Set.value));
        }

    }break;
    case MSG_Output_LineoutMute:
    {
        lineout_mute = data.Set.value;
        LineMute(lineout_mute);
        sprintf(bufSend, "Set lineout %s", data.Set.value?"Mute":"unMute");
    }break;
    default:break;
    }
}
void SocketServer::Commhandle_Misc_New(struct control4pack data)
{
    switch(data.optSecond)
    {
        case MSG_Misc_TestGain:
        {
            if(sysdata::getInstance()->SetOscGain(data.Set.channel,data.Set.value)>=0)
            {
                sysdata::getInstance()->ExeSet();
                sprintf(bufSend, "Set Out[%d] Test Gain %g",data.Set.channel+1,Gainfneg24to0(data.Set.value));
            }

        }break;
        case MSG_Set_Allvolume:
        {
            if(data.Set.channel == 0xff)
            {
                if(data.Set.value<=100)
                {
                    char i = 0;
                    for (i = 0; i < CHANNELS; i++)
                    {
                        sysdata::getInstance()->Setvolume(i,data.Set.value);
                        sysdata::getInstance()->Setoutputsource(i,i);
                    }
                    sysdata::getInstance()->ExeSet();
                    if(SocketOutPutLeve(data.Set.value)!=0)sprintf(bufSend, "Set Out[%02x] set all channel volume to %0.1f",data.Set.channel,SocketOutPutLeve(data.Set.value));
                     else sprintf(bufSend, "Set Out[%02x] set all channel volume to 0",data.Set.channel);
                }
            }
        }break;
    default:break;
    }

}
void SocketServer::Commhandle_System(struct control4pack data)
{
    switch(data.optSecond)
    {
        case MSG_Upgrade:
        {
            char command[110];
            memset(command,0,110);
            int ret;
            sprintf(command,"%s %s","apiupgrade.sh",data.Data.url);
          //if(sysdata::getInstance()->SetOscGain(data.Set.channel,data.Set.value)>=0)
            {
                ret=system(command);
                printf("----%d\r\n",ret);
                if((ret==256)||(ret<0))
                {
                    sprintf(bufSend, "Upgrade:fail");
                }
                else {
                    sprintf(bufSend, "Upgrade:success");
                }

            }
        }break;
        case MSG_Credential:
        {
            char username_len = data.credential[0];
            char passwd_len = data.credential[username_len + 1];
            char username[100];
            char passwd[50];
            string v;

            memset(username, 0, sizeof(username));
            memset(passwd, 0, sizeof(passwd));
            memcpy(username, &(data.credential[1]), username_len);
            memcpy(passwd, &(data.credential[username_len + 2]), passwd_len);
            v = username;
            if (0 == v.size())
            {
                sprintf(bufSend, "Username is NULL");
                break;
            }
            if(v != sysdata::getInstance()->mLoginInfo.mUserName)
            {
                sysdata::getInstance()->mLoginInfo.mUserName.clear();
                sysdata::getInstance()->mLoginInfo.mUserName = v;
            }
            v = passwd;
            if(0 != v.size())
            {
                sysdata::getInstance()->mLoginInfo.mUserPasswd.clear();
                sysdata::getInstance()->mLoginInfo.mUserPasswd = v;
                sysdata::getInstance()->updateLoginInfo(sysdata::getInstance()->mLoginInfo);
            }
            else
            {
                sprintf(bufSend, "password is NULL");
                break;
            }
            if((1==sysdata::getInstance()->mLoginInfo.mStatus))
            {
                sysdata::getInstance()->mToken = Tools::getInstanc()->getRandom();
            }
            sprintf(bufSend, "set Credential success");
        }
        break;
        default:break;
    }

}
void SocketServer::Commhandle_Sys_Old(struct control4pack data)
{
    switch(data.optSecond)
    {
        case MSG_SYS_PowerOn:
        {
            sysdata::getInstance()->Power(1);
            sysdata::getInstance()->ExeSet();
            sprintf(bufSend, "PowerOn");

        }break;
        case MSG_SYS_PowerOff:
        {
            sysdata::getInstance()->Power(0);
            sysdata::getInstance()->ExeSet();
            sprintf(bufSend, "PowerOff");
        }break;
        case MSG_SYS_PowerToggle:
        {
            sysdata::getInstance()->Power(2);
            sysdata::getInstance()->ExeSet();
            sprintf(bufSend, "PowerToggle");
        }break;
        default:break;
    }
}
void SocketServer::Commhandle_Input_Old(struct control4pack data)
{
    if(data.optSecond== MSG_Channel_InputLevel_Ctrl)//0-24
    {
        if(sysdata::getInstance()->SetinputVolme(data.Set.channel,data.Set.value)>0)
        {
            sysdata::getInstance()->ExeSet();
            sprintf(bufSend, "Set In[%d] input gain : %g",1+data.Set.channel,SocketInputLeve(data.Set.value));
        }
    }
}
void SocketServer::Commhandle_Output_Old(struct control4pack data)
{
    switch(data.optSecond)
    {
        case MSG_Channel_StereoON://0-4
        {
            sysdata::getInstance()->MonStereo(data.Set.channel,1);
            sysdata::getInstance()->ExeSet();
            if(data.Set.channel<CHANNELS)sprintf(bufSend, "Set Out[%d] %s",1+data.Set.channel,"Stereo");
        }break;
        case MSG_Channel_MonoON:
        {
            sysdata::getInstance()->MonStereo(data.Set.channel,0);
            sysdata::getInstance()->ExeSet();
            if(data.Set.channel<CHANNELS)sprintf(bufSend, "Set Out[%d] %s",1+data.Set.channel,"Mono   ");
        }break;
        case MSG_Channel_StereoMonoToggle:
        {
            sysdata::getInstance()->MonStereo(data.Set.channel,0xff);
            sysdata::getInstance()->ExeSet();
            if(data.Set.channel<CHANNELS)sprintf(bufSend, "Set Out[%d] %s",1+data.Set.channel,"StereoMonoToggle");
        }break;
        case MSG_Channel_VolUp:
        {
            sysdata::getInstance()->SetVolumeAdd(data.Set.channel,1);
            sysdata::getInstance()->ExeSet();
            if(data.Set.channel<CHANNELS)sprintf(bufSend, "Set Out[%d] %s",1+data.Set.channel,"Volume Up " );
        }break;
        case MSG_Channel_VolDown:
        {
            sysdata::getInstance()->SetVolumeAdd(data.Set.channel,-1);
            sysdata::getInstance()->ExeSet();
            if(data.Set.channel<CHANNELS)sprintf(bufSend, "Set Out[%d] %s",1+data.Set.channel,"Volume Down");
        }break;
        case MSG_Channel_VolInc3db:
        {
            sysdata::getInstance()->SetVolumeAdd(data.Set.channel,3);
            sysdata::getInstance()->ExeSet();
            if(data.Set.channel<CHANNELS)sprintf(bufSend, "Set Out[%d] %s",1+data.Set.channel,"Volume +3db" );
        }break;
        case MSG_Channel_VolDec3db:
        {
            sysdata::getInstance()->SetVolumeAdd(data.Set.channel,-3);
            sysdata::getInstance()->ExeSet();
            if(data.Set.channel<CHANNELS)sprintf(bufSend, "Set Out[%d] %s",1+data.Set.channel,"Volume -3db" );
        }break;
        case MSG_Channel_MuteOn:
        {
            sysdata::getInstance()->SetDspmute(data.Set.channel,1);
            sysdata::getInstance()->ExeSet();
            if(data.Set.channel<CHANNELS)sprintf(bufSend, "Set Out[%d] %s",1+data.Set.channel,"Mute" );
        }break;
        case MSG_Channel_MuteOff:
        {
            sysdata::getInstance()->SetDspmute(data.Set.channel,0);
            sysdata::getInstance()->ExeSet();
            if(data.Set.channel<CHANNELS)sprintf(bufSend, "Set Out[%d] %s",1+data.Set.channel,"Unmute" );
        }break;
        case MSG_Channel_MuteToggle:
        {
            sysdata::getInstance()->SetDspmute(data.Set.channel,2);
            sysdata::getInstance()->ExeSet();
            if(data.Set.channel<CHANNELS)sprintf(bufSend, "Set Out[%d] %s",1+data.Set.channel,"Mute Toggle" );
        }break;
        case MSG_Channel_LoundnessOn:
        {
            sysdata::getInstance()->SetLoudness(data.Set.channel,1);
            sysdata::getInstance()->ExeSet();
            if(data.Set.channel<CHANNELS)sprintf(bufSend, "Set Out[%d] %s",1+data.Set.channel,"Loudness On"  );
        }break;
        case MSG_Channel_LoundnessOFF:
        {
            sysdata::getInstance()->SetLoudness(data.Set.channel,0);
            sysdata::getInstance()->ExeSet();
            if(data.Set.channel<CHANNELS)sprintf(bufSend, "Set Out[%d] %s",1+data.Set.channel,"Loudness Off" );
        }break;
        case MSG_Channel_LoundnessTog:
        {
            sysdata::getInstance()->SetLoudness(data.Set.channel,2);
            sysdata::getInstance()->ExeSet();
            if(data.Set.channel<CHANNELS)sprintf(bufSend, "Set Out[%d] %s",1+data.Set.channel,"Loudness Toggle" );
        }break;
        case MSG_Channel_Source1:
        {
            sysdata::getInstance()->Setoutputsource(data.Set.channel,data.Set.value);
            sysdata::getInstance()->ExeSet();
            if(data.Set.value<CHANNELS)sprintf(bufSend, "Set Out[%d] %s to input %d",data.Set.channel+1,"Input Source" ,data.Set.value+1);
            else if(data.Set.value==CHANNELS)sprintf(bufSend, "Set Out[%d] Input Source to Audio Off",data.Set.channel+1);
        }break;
        case MSG_Channel_Vol_Ctrl:
        {
            if(data.Set.value<=100)
            {
                sysdata::getInstance()->Setvolume(data.Set.channel,data.Set.value);
                sysdata::getInstance()->ExeSet();
                if(data.Set.channel<CHANNELS)
                {
                 if(SocketOutPutLeve(data.Set.value)!=0)sprintf(bufSend, "Set Out[%d] Output Volume to %0.1f",data.Set.channel+1,SocketOutPutLeve(data.Set.value));
                 else sprintf(bufSend, "Set Out[%d] Output Volume to 0",data.Set.channel+1);
                }
            }
        }break;
        case MSG_Channel_Vol_max:
        {
            if(data.Set.value<=100)
            {
                sysdata::getInstance()->SetmaxVolume(data.Set.channel,data.Set.value);
                sysdata::getInstance()->ExeSet();
                if(data.Set.channel<CHANNELS)
                {
                    float vol=SocketOutPutLeve(data.Set.value);
                    if(vol!=0)sprintf(bufSend, "Set Out[%d] Max Volume to %0.1f",data.Set.channel+1,vol);
                    else sprintf(bufSend, "Set Out[%d] Max Volume to 0",data.Set.channel+1);
                }
            }

        }break;
        case MSG_Channel_TurnOnVol:
        {
            if(data.Set.value<=100)
            {
                sysdata::getInstance()->Setturnonvolume(data.Set.channel,data.Set.value);
                sysdata::getInstance()->ExeSet();
                if(data.Set.channel<CHANNELS)
                {
                   float vol=SocketOutPutLeve(data.Set.value);
                   if(vol==0)sprintf(bufSend, "Set Out[%d] Turn on Vol to 0",data.Set.channel+1);
                   else sprintf(bufSend, "Set Out[%d] Turn on Vol to %0.1f",data.Set.channel+1,vol);

                }
            }
        }break;
        case MSG_Channel_EQ1_Fre:
        case MSG_Channel_EQ2_Fre:
        case MSG_Channel_EQ3_Fre:
        case MSG_Channel_EQ4_Fre:
        case MSG_Channel_EQ5_Fre:
        {
            sysdata::getInstance()->SetPEQ(data.Set.channel,ENUM_PEQ_Freq,data.optSecond-MSG_Channel_EQ1_Fre,SocketFrequency(data.Set.value));
            sysdata::getInstance()->ExeSet();
            if(data.Set.channel<CHANNELS)sprintf(bufSend, "Set Out[%d] Band %d Freq to %s",data.Set.channel+1,data.optSecond-MSG_Channel_EQ1_Fre+1,FreqChar(data.Set.value));
        }break;

        case MSG_Channel_EQ1_Gain:
        case MSG_Channel_EQ2_Gain:
        case MSG_Channel_EQ3_Gain:
        case MSG_Channel_EQ4_Gain:
        case MSG_Channel_EQ5_Gain:
        {
            sysdata::getInstance()->SetPEQ(data.Set.channel,ENUM_PEQ_Gain,data.optSecond-MSG_Channel_EQ1_Gain,SocketGain(data.Set.value));
            sysdata::getInstance()->ExeSet();
            if(data.Set.channel<CHANNELS)sprintf(bufSend, "Set Out[%d] Band %d Gain to %g",data.Set.channel+1,data.optSecond-MSG_Channel_EQ1_Gain+1,SocketGainf(data.Set.value));
        }break;

        case MSG_Channel_EQ1_Q:
        case MSG_Channel_EQ2_Q:
        case MSG_Channel_EQ3_Q:
        case MSG_Channel_EQ4_Q:
        case MSG_Channel_EQ5_Q:
        {
            sysdata::getInstance()->SetPEQ(data.Set.channel,ENUM_PEQ_Q,data.optSecond-MSG_Channel_EQ1_Q,SocketQ(data.Set.value));
            sysdata::getInstance()->ExeSet();
            if(data.Set.channel<CHANNELS)sprintf(bufSend, "Set Out[%d] Band %d Q to %g",data.Set.channel+1,data.optSecond-MSG_Channel_EQ1_Q+1,SocketQf(data.Set.value));
        }break;

        case MSG_Channel_Bass:
        {
            sysdata::getInstance()->SetShelf(data.Set.channel,ENUM_shelf_gain,BASS,SocketBasstreble(data.Set.value));
            sysdata::getInstance()->ExeSet();
            if(data.Set.channel<CHANNELS)sprintf(bufSend, "Set Out[%d] Bass to %g",data.Set.channel+1,SocketBasstreblef(data.Set.value));
        }break;
        case MSG_Channel_Treble:
        {
            sysdata::getInstance()->SetShelf(data.Set.channel,ENUM_shelf_gain,TREBLE,SocketBasstreble(data.Set.value));
            sysdata::getInstance()->ExeSet();
            if(data.Set.channel<CHANNELS)sprintf(bufSend, "Set Out[%d] Treble to %g",data.Set.channel+1,SocketBasstreblef(data.Set.value));
        }break;

        case MSG_Channel_balance://0-48
        {
            sysdata::getInstance()->SetBalance(data.Set.channel,data.Set.value);
            sysdata::getInstance()->ExeSet();
            if(data.Set.channel<CHANNELS)sprintf(bufSend, "Set Out[%d] Balance to %s",data.Set.channel+1,BalanceChar(data.Set.value));
        }break;
        case MSG_Channel_GROUP:
        {
            sysdata::getInstance()->SetGroup(data.Set.channel,data.Set.value);
            if(data.Set.channel<CHANNELS)sprintf(bufSend, "Set Out[%d] Group to %s",data.Set.channel+1,GroupChar(sysdata::getInstance()->dspdata[data.Set.channel].dsp[ENUM_group]));
        }break;
        default:break;
    }
}
void SocketServer::Commhandle_Group_Old(struct control4pack data)
{
    switch(data.optSecond)
    {
            case MSG_GROUP_VolUp:
            {
                if(sysdata::getInstance()->SetGroupVolumeAdd(data.Set.channel,+1))
                {
                    sysdata::getInstance()->ExeSet();
                   if(data.Set.channel<CHANNELS) sprintf(bufSend, "Set Group[%c] %s ",data.Set.channel+'A',"Volume Up " );
                }
                else sprintf(bufSend, "Group[%c] is empty",data.Set.channel+'A');
            }break;
            case MSG_GROUP_VolDown:
            {
                if(sysdata::getInstance()->SetGroupVolumeAdd(data.Set.channel,-1))
                {
                    sysdata::getInstance()->ExeSet();
                    if(data.Set.channel<CHANNELS)sprintf(bufSend, "Set Group[%c] %s ",data.Set.channel+'A',"Volume Down"  );
                }
                else
                {
                    if(data.Set.channel<CHANNELS)sprintf(bufSend, "Group[%c] is empty",data.Set.channel+'A');
                }

            }break;

            case MSG_GROUP_VolInc3db:
            {
                if(sysdata::getInstance()->SetGroupVolumeAdd(data.Set.channel,+3))
                {
                    sysdata::getInstance()->ExeSet();
                    if(data.Set.channel<CHANNELS)sprintf(bufSend, "Set Group[%c] %s ",data.Set.channel+'A',"Volume +3db"  );
                }
                else if(data.Set.channel<CHANNELS)sprintf(bufSend, "Group[%c] is empty",data.Set.channel+'A');
            }break;

            case MSG_GROUP_VolDec3db:
            {
                if(sysdata::getInstance()->SetGroupVolumeAdd(data.Set.channel,-3))
                {
                    sysdata::getInstance()->ExeSet();
                    if(data.Set.channel<CHANNELS)sprintf(bufSend, "Set Group[%c] %s ",data.Set.channel+'A',"Volume -3db"  );
                }
                else if(data.Set.channel<CHANNELS)sprintf(bufSend, "Group[%c] is empty",data.Set.channel+'A');
            }break;
            case MSG_GROUP_Volset:    //ff,55,4,4,47,0
            {
                if(data.Set.value<=100)
                {
                    if(sysdata::getInstance()->SetGroupVolume(data.Set.channel,data.Set.value))
                    {
                       sysdata::getInstance()->ExeSet();
                       if(data.Set.channel<CHANNELS)sprintf(bufSend, "Set Group[%c] vol to %g",data.Set.channel+'A',SocketOutPutLeve(data.Set.value));
                    }
                    else if(data.Set.channel<CHANNELS)sprintf(bufSend, "Group[%c] is empty",data.Set.channel+'A');
                }
            }break;
            case MSG_GROUP_SOURCE_SET:
            {
                if(sysdata::getInstance()->SetGroupSource(data.Set.channel,data.Set.value+1)>0)
                {
                  sysdata::getInstance()->ExeSet();
                  if(data.Set.channel<CHANNELS)sprintf(bufSend, "Set Group[%c] source to %d",data.Set.channel+'A',data.Set.value+1);
                }
                else sprintf(bufSend, "Group[%c] is empty",data.Set.channel+'A');
            }break;
            case MSG_GROUP_Mute_ON:
            {
                if(sysdata::getInstance()->SetGroupMute(data.Set.channel,1))
                {
                    sysdata::getInstance()->ExeSet();
                    if(data.Set.channel<CHANNELS)sprintf(bufSend, "Set Group[%c] %s ",data.Set.channel+'A',"Mute "  );
                }
                else if(data.Set.channel<CHANNELS)sprintf(bufSend, "Group[%c] is empty",data.Set.channel+'A');
            }break;

            case MSG_GROUP_Mute_OFF:
            {
                if(sysdata::getInstance()->SetGroupMute(data.Set.channel,0))
                {
                    sysdata::getInstance()->ExeSet();
                    if(data.Set.channel<CHANNELS)sprintf(bufSend, "Set Group[%c] %s ",data.Set.channel+'A',"Unmute"  );
                }
                else if(data.Set.channel<CHANNELS)sprintf(bufSend, "Group[%c] is empty",data.Set.channel+'A');
            }break;

            case MSG_GROUP_Mute_Toggle:
            {
                if(sysdata::getInstance()->SetGroupMute(data.Set.channel,2))
                {
                    sysdata::getInstance()->ExeSet();
                    if(data.Set.channel<CHANNELS)sprintf(bufSend, "Set Group[%c] %s ",data.Set.channel+'A',"Mute Toggle"  );
                }
                else if(data.Set.channel<CHANNELS)sprintf(bufSend, "Group[%c] is empty",data.Set.channel+'A');
            }break;

            case MSG_GROUP_ALL_VOLUP:
            {
                sysdata::getInstance()->SetGroupVolumeAdd(-1,+1);
                sysdata::getInstance()->ExeSet();
            }break;
            case MSG_GROUP_ALL_VOLDOWN:
            {
                sysdata::getInstance()->SetGroupVolumeAdd(-1,-1);
                sysdata::getInstance()->ExeSet();
            }break;
            case MSG_GROUP_ALL_VolIn3db:
            {
                sysdata::getInstance()->SetGroupVolumeAdd(-1,+3);
                sysdata::getInstance()->ExeSet();
            }break;
            case MSG_GROUP_ALL_VolDec3db:
            {
                sysdata::getInstance()->SetGroupVolumeAdd(-1,-3);
                sysdata::getInstance()->ExeSet();
            }break;
            case MSG_GROUP_ALL_MUTE:
            {
                sysdata::getInstance()->SetGroupMute(-1,1);
                sysdata::getInstance()->ExeSet();
            }break;
            case MSG_GROUP_ALL_UNMUTE:
            {
                sysdata::getInstance()->SetGroupMute(-1,0);
                sysdata::getInstance()->ExeSet();
            }break;
                //  case MSG_GROUP_ALL_MUTEToggle:
                //  {
                //      sysdata::getInstance()->SetGroupMute(-1,2);
                //      sysdata::getInstance()->ExeSet();
                //  }break;
            case MSG_GROUP_ALL_VOLSET://ff,55,3,7,77,64
            {
                if(data.Set.channel<=100)
                {
                    sysdata::getInstance()->SetGroupVolume(-1,data.Set.channel);
                    sysdata::getInstance()->ExeSet();
                }
            }break;


            case MSG_GROUP_ALL_SOURCE:
            {
                sysdata::getInstance()->SetGroupSource(-1,data.Set.channel+1);
                sysdata::getInstance()->ExeSet();
            }break;
            default:break;
    }

}
void SocketServer::Commhandle_Old(struct control4pack data)
{
    switch(data.optSecond)
    {

        case MSG_FIRMWARE_VERSION:
        {
            sprintf(bufSend, "Fw version : V%.4f",((float)AppVersion)/10000);
        }break;
        case MSG_NETWORK_MAC:
        {
            Writemac((char *)data.mac);
            system("dd if=/tmp/mac.bin of=/dev/mtdblock0 bs=1 seek=1966112 count=6");
        }break;
        case MSG_TRIGGER_ON_ZONE:
        {
            if(data.Set.channel<CHANNELS/8)
            {
                sysdata::getInstance()->SetZoon(data.Set.channel,1);
                sprintf(bufSend, "Set Zone :%s ON",data.Set.channel==0?"1-8":"9-16");
            }
            else if(data.Set.channel==CHANNELS/8)
            {
                sysdata::getInstance()->SetAsg(1);
                sprintf(bufSend, "Set ASG ON");
            }
        }break;
        case MSG_TRIGGER_OFF_ZONE:
        {
            if(data.Set.channel<CHANNELS/8)
            {
                sysdata::getInstance()->SetZoon(data.Set.channel,0);
                sprintf(bufSend, "Set Zone :%s OFF",data.Set.channel==0?"1-8":"9-16");
            }
            else if(data.Set.channel==CHANNELS/8)
            {
                sysdata::getInstance()->SetAsg(0);
                sprintf(bufSend, "Set ASG OFF");
            }
        }break;
        case   MSG_TRIGGER_TOG_ZONE:
        {
           // sysdata::getInstance()->SetZoon(data.Set.channel,2);
            //sprintf(bufSend, "Fw version : V%.4f",((float)AppVersion)/10000);
        }break;

        case MSG_TRIGGER_ASG_CHANNEL:
        {
            //sysdata::getInstance()->SetAsg(data.Set.channel);
        }break;
        case MSG_NETWORK_AUTONETWORKSTANDBY:
        {
            sysdata::getInstance()->SetAutoStandby(data.Set.channel);
            sprintf(bufSend, "Auto Standby %s",data.Set.channel?"On":"Off");
        }break;

        case MSG_AUDIO_SENSE_ENABLE:
        {
            sysdata::getInstance()->SetAutoSense(data.Set.channel?0xffff:0);
            sprintf(bufSend, "Set AUTO SENSE %s",sysdata::getInstance()->devicedata.audiosens?"On":"Off");

        }break;
            //  case MSG_Channel_OSC_Gain:
            //  {
            //      sysdata::getInstance()->SetOscGain(data.Set.channel,data.para[1]);
            //      sysdata::getInstance()->ExeSet();
            //  }break;
        case MSG_FIRMWARE_UPGRADE:
        case MSG_BOOTLOAER_UPDATE:
        {
    #if(CHANNELS==8)
            Fifo::getInstance()->FifoSend("http://dev.hansong-china.com/linux/control4/Config.8c");
    #elif (CHANNELS==16)
            Fifo::getInstance()->FifoSend("http://dev.hansong-china.com/linux/control4/Config.16c");
    #endif
            sprintf(bufSend, "Update...");
        }break;

            /**/
        case MSG_RESET_COMMAD:
        {
            DEBUG_LOG("factoryResetHandle in");
            sysdata::getInstance()->resetDevice();
            sprintf(bufSend, "Factory Reset Command");
        }break;
        case MSG_REBOOT_COMMAD:
        {
            DEBUG_LOG("RebootHandle in");
            system("sleep 2 && reboot&");
            sprintf(bufSend, "Reboot Command");
        }break;
        case MSG_NETWORK_DHCP:
        {
            _networkinfo ip = sysdata::getInstance()->netinfo;
            LOGOUT("DHCP ON:%s",ip.dhcpEnabled.c_str());
            if(ip.dhcpEnabled.find("1")==ip.dhcpEnabled.npos)
            {
                ip.dhcpEnabled="1";
                setIpAddress(ip, true);
            }
            sprintf(bufSend, "DHCP ON");
        }break;
        case MSG_NETWORK_STATIC:
        {
            int i;
            char ipc[16];
            _networkinfo ip = sysdata::getInstance()->netinfo;
            if(ip.dhcpEnabled.find("0")==ip.dhcpEnabled.npos)
            {
                LOGOUT("IP:%s netmask:%s gateway:%s",ip.ip.c_str(),ip.netmask.c_str(),ip.gateway.c_str());
                ip.dhcpEnabled="0";
                sprintf(ipc,"%d.%d.%d.%d",data.Ip.ip[0],data.Ip.ip[1],data.Ip.ip[2],data.Ip.ip[3]);
                ip.ip.assign(ipc);
                sprintf(ipc,"%d.%d.%d.%d",data.Ip.subnet[0],data.Ip.subnet[1],data.Ip.subnet[2],data.Ip.subnet[3]);
                ip.netmask.assign(ipc);
                sprintf(ipc,"%d.%d.%d.%d",data.Ip.gateway[0],data.Ip.gateway[1],data.Ip.gateway[2],data.Ip.gateway[3]);
                ip.gateway.assign(ipc);
                LOGOUT("IP:%s netmask:%s gateway:%s",ip.ip.c_str(),ip.netmask.c_str(),ip.gateway.c_str());
                setIpAddress(ip, true);
                system("reboot");
            }
            sprintf(bufSend, "IP STATIC");
        }break;
        case MSG_BOOTLOAER_VERSION:
        {
            sprintf(bufSend, "Linux version : V3.10");
        }break;
        case MSG_LED_TEST:
        {
            LEDMISC::getInstance()->LedTest(data.Set.channel);
            sprintf(bufSend, "LED test %s",data.Set.channel?"start":"stop");
        }break;
        case 0xfe:
        {
            stream::getInstance()->Set(0x7070);
        }break;
        case 0xff:
        {
            stream::getInstance()->Set(0x7072);
        }break;

        default:break;
    }
}
void SocketServer::Commhandle(struct control4pack packet,int newcom)
{
    if(newcom)
    {
        if(packet.OptMaster==MSG_Input)
        {
            if(packet.Set.channel<CHANNELS)Commhandle_Input_New(packet);
        }
        else if(packet.OptMaster==MSG_Output)
        {
            if(packet.Set.channel<CHANNELS)Commhandle_Output_New(packet);
        }
        else if(packet.OptMaster==MSG_Misc)
        {
            Commhandle_Misc_New(packet);
        }
        else if(packet.OptMaster==MSG_EQ)
        {
            if(packet.Set.channel<CHANNELS)Commhandle_EQ(packet);
        }
        else if(packet.OptMaster==MSG_SYS)
        {
            Commhandle_System(packet);
            printf("yes\r\n");
        }
    }
    else
    {
        if(packet.OptMaster==cmd_type_sys)Commhandle_Sys_Old(packet);
        else if(packet.OptMaster==cmd_type_input)
        {
            if(data.Set.channel<CHANNELS)Commhandle_Input_Old(packet);
        }
        else if(packet.OptMaster==cmd_type_output)
        {
            if(data.Set.channel<CHANNELS)Commhandle_Output_Old(packet);
        }
        else if(packet.OptMaster==cmd_type_group)
        {
            if(data.Set.channel<CHANNELS)Commhandle_Group_Old(packet);
        }
        else
        {
            Commhandle_Old(packet);
        }
    }




}
void SocketServer::QueryBack_Input_New(struct control4pack data)
{
    int ret;
    switch(data.optSecond)
    {
        case MSG_Input_ADetect:
        {
            ret=stream::getInstance()->OutSignal(data.Get.channel);
            sprintf(bufSend, "Get Input[%d] Audio Detect %s",data.Get.channel+1,ret?"Detected":"Undetected");
        }break;
        case MSG_Input_Delay:
        {
            sprintf(bufSend, "Get Input[%d] Delay %d",data.Get.channel+1,sysdata::getInstance()->dspdata[data.Get.channel].dsp[ENUM_Inputdelay]);
         }break;
        case MSG_Input_SPThreshold:
        {
            sprintf(bufSend, "Get Input[%d] SPThreshold %d",data.Get.channel+1,sysdata::getInstance()->dspdata[data.Get.channel].dsp[ENUM_signalpresence_threshold]);
         }break;
        case MSG_Input_SPReleaseTime:
        {
            sprintf(bufSend, "Get Input[%d] SPReleaseTime %d",data.Get.channel+1,sysdata::getInstance()->dspdata[data.Get.channel].dsp[ENUM_signalpresence_releasetime]);
         }break;
        default:break;
    }


}
void SocketServer::QueryBack_EQ(struct control4pack data)
{
    unsigned int eqnumber=data.optSecond>>4;
    if(eqnumber>11)return;

    switch(data.optSecond&0x0f)
    {
        case MSG_EqFreq:
        {
           sprintf(bufSend, "Get Out[%d] Band %d Freq : %d Hz",data.Get.channel+1,eqnumber+1,(sysdata::getInstance()->dspdata[data.Get.channel].dsppeq[ENUM_PEQ_N*eqnumber+ENUM_PEQ_Freq]));
        }break;
        case MSG_EqGain:
        {
            sprintf(bufSend, "Get Out[%d] Band %d Gain : %g",data.Get.channel+1,eqnumber+1,DataToGainFloat(sysdata::getInstance()->dspdata[data.Get.channel].dsppeq[ENUM_PEQ_N*eqnumber+ENUM_PEQ_Gain]));
        }break;
        case MSG_EqQ:
        {
            sprintf(bufSend, "Get Out[%d] Band %d Q : %g",data.Get.channel+1,eqnumber+1,   DataToGainFloat(sysdata::getInstance()->dspdata[data.Get.channel].dsppeq[ENUM_PEQ_N*eqnumber+ENUM_PEQ_Q]));
        }break;
        default:LOGOUT("QueryBack-->master:%x,second:%d\r\n",data.optSecond);
    }


}
void SocketServer::QueryBack_Out_New(struct control4pack data)
{
    switch(data.optSecond)
    {
            case MSG_Output_Delay:
            {
                sprintf(bufSend, "Get Output[%d] Delay %d",data.Get.channel+1,sysdata::getInstance()->dspdata[data.Get.channel].dsp[ENUM_outputdelay]);
            }break;
            case MSG_Output_HighSf:
            {
                sprintf(bufSend, "Get Out[%d] High Shelf Frequency %d Hz",data.Get.channel+1,sysdata::getInstance()->dspdata[data.Get.channel].dspshelf[TREBLE*ENUM_SHELF_N+ENUM_shelf_freq]);
            }break;
            case MSG_Output_HighSq:
            {
                sprintf(bufSend, "Get Out[%d] High Shelf Q %g",data.Get.channel+1,((float)sysdata::getInstance()->dspdata[data.Get.channel].dspshelf[TREBLE*ENUM_SHELF_N+ENUM_shelf_q])/100);
            }break;

            case MSG_Output_HighSgain:
            {
                sprintf(bufSend, "Get Out[%d] High Shelf gain %g",data.Get.channel+1,DataToGainFloat(sysdata::getInstance()->dspdata[data.Get.channel].dspshelf[TREBLE*ENUM_SHELF_N+ENUM_shelf_gain]));
                //printf("channel:%d,data:%x,%d\r\n",data.Get.channel,sysdata::getInstance()->dspdata[data.Get.channel].dspshelf[TREBLE*ENUM_SHELF_N+ENUM_shelf_gain],TREBLE*ENUM_SHELF_N+ENUM_shelf_gain);
            }break;
            case MSG_Output_LowSgain:
            {
                sprintf(bufSend, "Get Out[%d] Low Shelf gain %g" ,data.Get.channel+1,DataToGainFloat(sysdata::getInstance()->dspdata[data.Get.channel].dspshelf[BASS*ENUM_SHELF_N+ENUM_shelf_gain]));
            }break;

            case MSG_Output_LowSf:
            {
                sprintf(bufSend, "Get Out[%d] Low Shelf Frequency %d Hz",data.Get.channel+1,sysdata::getInstance()->dspdata[data.Get.channel].dspshelf[BASS*ENUM_SHELF_N+ENUM_shelf_freq]);
            }break;
            case MSG_Output_LowSq:
            {
                sprintf(bufSend, "Get Out[%d] Low Shelf Q %g",data.Get.channel+1,((float)sysdata::getInstance()->dspdata[data.Get.channel].dspshelf[BASS*ENUM_SHELF_N+ENUM_shelf_q])/100);
            }break;
            case MSG_Output_Cf:
            {
                sprintf(bufSend, "Get Out[%d] Crossover Frequency %d Hz",data.Get.channel+1,sysdata::getInstance()->dspdata[data.Get.channel].dsp[ENUM_crossover_freq]);
            }break;
            case MSG_Output_Ct:
            {
                sprintf(bufSend, "Get Out[%d] Crossover Type %s",data.Get.channel+1,SocketXoverType(sysdata::getInstance()->dspdata[data.Get.channel].dsp[ENUM_crossover_index]));
            }break;
            case MSG_Output_LowPassGain:
            {
                sprintf(bufSend, "Get Out[%d] Low Pass Gain Offset %g",data.Get.channel+1,SocketGainf(sysdata::getInstance()->dspdata[data.Get.channel].dsp[ENUM_crossover_gain]));
            }break;
            case MSG_Output_MusicType:
            {
                sprintf(bufSend, "Get Out[%d] %s",data.Get.channel+1,SocketMusicType(!(data.Get.channel%2),sysdata::getInstance()->dspdata[data.Get.channel].dsp[ENUM_merge]));
            }break;
            case MSG_Output_LineoutMute:
            {
                sprintf(bufSend, "Get lineout %s", lineout_mute?"Mute":"unMute");
            }break;

//    case MSG_Output_TestSignal:
//    {
//        sprintf(bufSend, "Get Out[%d] Test Signal %s",data.Get.channel+1,(sysdata::getInstance()->dspdata[data.Get.channel].dsp[ENUM_merge]==Switch_test)?"On":"Off");
//    }break;

           // case MSG_Output_StereoHp:
          //  {
          //      sprintf(bufSend, "Get Out[%d] StereoHp %s",data.Get.channel+1,sysdata::getInstance()->dspdata[data.Get.channel].dsp[ENUM_merge]==Switch_hp?"On":"Off");
           // }break;







            case MSG_Output_RoomLock:
            {
                sprintf(bufSend, "Get Out[%d] Lock Room EQ %s",data.Get.channel+1,stoi(sysdata::getInstance()->mOutputDspInfo[data.Get.channel].mOutputLock)?"On":"Off");
            }break;
            case MSG_Output_Trigger:
            {
                sprintf(bufSend, "Get Out[%d] Tigger %s",data.Get.channel+1,(sysdata::getInstance()->ZoonGet(data.Get.channel))?"On":"Off");
            }break;
            default:LOGOUT("QueryBack-->master:%x,second:%d\r\n",data.optSecond);

        break;
    }

}
void SocketServer::QueryBack_Misc_New(struct control4pack data)
{
    int ret;
    switch(data.optSecond)
    {
        case MSG_Misc_TestGain:
        {
                sprintf(bufSend, "Get Out[%d] Test Gain %g",
                1+data.Get.channel,Gainfneg24to0(sysdata::getInstance()->dspdata[data.Get.channel].dsp[ENUM_oscgain]));
        }break;
        case MSG_Misc_SampleRate:
        {
                ret=stream::getInstance()->DSPSampleRate(data.Get.channel);
                sprintf(bufSend, "Get Sample %d",ret);
        }break;
        case MSG_Misc_DspVersion:
        {
                ret=stream::getInstance()->DSPVersion(data.Get.channel);
                sprintf(bufSend, "Get DSP firmware %d",ret);
        }break;
        case MSG_SERTAGE:
        {
            string tag=Tools::getInstanc()->getSerialNumber();
            sprintf(bufSend, "Get Service Tag %s",tag.c_str());
        }
        break;
        case MSG_Set_Allvolume:
        {
            float vol =SocketOutPutLeve(sysdata::getInstance()->dspdata[0].dsp[ENUM_volume]);
            if(vol!=0)sprintf(bufSend, "Get all channel volume : %0.1f",vol);
            else sprintf(bufSend, "Get all channel volume : 0");
        }
        break;
        default:break;
    }


}
void SocketServer::QueryBack_Sys_Old(struct control4pack data)
{
    if(data.OptMaster==cmd_type_sys)sprintf(bufSend,"Get Power status : %s",PowerChar(stream::getInstance()->powerc));
}
void SocketServer::QueryBack_Input_Old(struct control4pack data)
{
    switch(data.optSecond)
    {
        case MSG_Channel_InputLevel_Ctrl:
        {
           sprintf(bufSend,"Get In[%d] input gain : %g",1+data.Get.channel,SocketInputLeve(sysdata::getInstance()->dspdata[data.Get.channel].dsp[ENUM_Inputvolume]));
        }break;
        default:break;
    }
}
void SocketServer::QueryBack_Output_Old(struct control4pack data)
{
    switch(data.optSecond)
    {
            case MSG_Channel_StereoON:
            {
                sprintf(bufSend, "Get Out[%d] %s : %s",1+data.Get.channel,"Stereo Mono status",SelectChar(sysdata::getInstance()->dspdata[data.Get.channel].dsp[ENUM_merge]));
            }break;
            case MSG_Channel_Vol_Ctrl:
            {
                float vol =SocketOutPutLeve(sysdata::getInstance()->dspdata[data.Get.channel].dsp[ENUM_volume]);
                if(vol!=0)sprintf(bufSend, "Get Out[%d] %s : %0.1f",1+data.Get.channel,"Volume",vol);
                else sprintf(bufSend, "Get Out[%d] %s : 0",1+data.Get.channel,"Volume");
            }break;
            case MSG_Channel_Vol_max:
            {
                float vol=SocketOutPutLeve(sysdata::getInstance()->dspdata[data.Get.channel].dsp[ENUM_maxvolume]);
                if(vol!=0)sprintf(bufSend, "Get Out[%d] %s : %0.1f",1+data.Get.channel,"Max Volume",vol);
                else sprintf(bufSend, "Get Out[%d] %s : 0",1+data.Get.channel,"Max Volume");
            }break;
            case MSG_Channel_MuteOn:
            {
                sprintf(bufSend, "Get Out[%d] %s : %s",1+data.Get.channel,"Mute status",(sysdata::getInstance()->dspdata[data.Get.channel].dsp[ENUM_dspmute])?"mute":"Unmute");
            }break;
            case MSG_Channel_LoundnessOn:
            {
                sprintf(bufSend, "Get Out[%d] %s : %s",1+data.Get.channel,"Loudness status" ,(sysdata::getInstance()->dspdata[data.Get.channel].dsp[ENUM_loudness])?"On":"Off");
            }break;
            case MSG_Channel_Source1:
            {
                unsigned int output=(sysdata::getInstance()->dspdata[data.Get.channel].dsp[ENUM_Outputsource]);
                if(output<CHANNELS)sprintf(bufSend, "Get Out[%d] %s : input %d",1+data.Get.channel,"Input Source",output+1);
                else sprintf(bufSend, "Get Out[%d] Input Source : Audio Off",data.Get.channel+1);
            }break;
            case MSG_Channel_Bass:
            {
                sprintf(bufSend, "Get Out[%d] %s : %g",
                        1+data.Get.channel,
                        "Bass",
                        dsp2float(sysdata::getInstance()->dspdata[data.Get.channel].dspshelf[ENUM_SHELF_N*BASS+ENUM_shelf_gain]));
            }break;
            case MSG_Channel_Treble:
            {
                sprintf(bufSend, "Get Out[%d] %s : %g",
                        1+data.Get.channel,
                        "Treble",
                        dsp2float(sysdata::getInstance()->dspdata[data.Get.channel].dspshelf[ENUM_SHELF_N*TREBLE+ENUM_shelf_gain]));
            }break;
            case MSG_Channel_balance:
            {
                sprintf(bufSend, "Get Out[%d] %s : %s",
                        1+data.Get.channel,
                        "Balance",
                        BalanceChar(sysdata::getInstance()->dspdata[data.Get.channel].dsp[ENUM_balance]));
            }break;
            case MSG_Channel_GROUP:
            {
                sprintf(bufSend, "Get Out[%d] %s : %s",
                        1+data.Get.channel,
                        "Group",
                        GroupChar(sysdata::getInstance()->dspdata[data.Get.channel].dsp[ENUM_group]));
            }break;
            case MSG_Channel_TurnOnVol:
            {
                float vol=SocketOutPutLeve(sysdata::getInstance()->dspdata[data.Get.channel].dsp[ENUM_startvolume]);
                if(vol==0)sprintf(bufSend, "Get Out[%d] %s : 0",1+data.Get.channel,"Turn on Vol");
                else sprintf(bufSend, "Get Out[%d] %s : %0.1f",1+data.Get.channel,"Turn on Vol",vol);
            }break;
            case MSG_Channel_EQ1_Fre:
            case MSG_Channel_EQ2_Fre:
            case MSG_Channel_EQ3_Fre:
            case MSG_Channel_EQ4_Fre:
            case MSG_Channel_EQ5_Fre:
            {
                sprintf(bufSend, "Get Out[%d] Band %d Freq : %s",
                        1+data.Get.channel,
                        data.optSecond-MSG_Channel_EQ1_Fre+1,
                        FreqChar(sysdata::getInstance()->dspdata[data.Get.channel].dsppeq[ENUM_PEQ_N*(data.optSecond-MSG_Channel_EQ1_Fre)+ENUM_PEQ_Freq])
                );
            }break;

            case MSG_Channel_EQ1_Gain:
            case MSG_Channel_EQ2_Gain:
            case MSG_Channel_EQ3_Gain:
            case MSG_Channel_EQ4_Gain:
            case MSG_Channel_EQ5_Gain:
            {
                sprintf(bufSend, "Get Out[%d] Band %d Gain : %g",
                        1+data.Get.channel,
                        data.optSecond-MSG_Channel_EQ1_Gain+1,
                        dsp2float(sysdata::getInstance()->dspdata[data.Get.channel].dsppeq[ENUM_PEQ_N*(data.optSecond-MSG_Channel_EQ1_Gain)+ENUM_PEQ_Gain])
                );
             }break;
            case MSG_Channel_EQ1_Q:
            case MSG_Channel_EQ2_Q:
            case MSG_Channel_EQ3_Q:
            case MSG_Channel_EQ4_Q:
            case MSG_Channel_EQ5_Q:
            {
                sprintf(bufSend, "Get Out[%d] Band %d Q : %g",
                        1+data.Get.channel,
                        data.optSecond-MSG_Channel_EQ1_Q+1,
                        dsp2float(sysdata::getInstance()->dspdata[data.Get.channel].dsppeq[ENUM_PEQ_N*(data.optSecond-MSG_Channel_EQ1_Q)+ENUM_PEQ_Q])
                );
            }break;
            default:break;
    }

}
void SocketServer::QueryBack_Group_Old(struct control4pack data)
{
    switch(data.optSecond)
    {
        case MSG_GROUP_Volset:
        {
            if(sysdata::getInstance()->GetGroupVolume(data.Get.channel)>=0)
            {                     //Volume : -44.1
                sprintf(bufSend, "Get Group[%c] Volume : %0.1f",data.Get.channel+'A',SocketOutPutLeve(sysdata::getInstance()->GetGroupVolume(data.Get.channel)));
            }
            else {
                sprintf(bufSend, "Group[%c] is empty",data.Get.channel+'A');
            }
        }break;
        case MSG_GROUP_SOURCE_SET:
        {
           if(sysdata::getInstance()->GetGroupSource(data.Get.channel)>=0)
           {
             sprintf(bufSend, "Get Group[%c] Source : %d",data.Get.channel+'A',
                      sysdata::getInstance()->GetGroupSource(data.Get.channel));
           }
           else {
               sprintf(bufSend, "Group[%c] is empty",data.Get.channel+'A');
           }
        }break;
    case MSG_GROUP_Mute_ON:
    {
       if(sysdata::getInstance()->GetGroupMute(data.Get.channel)>=0)
       {
         sprintf(bufSend, "Get Group[%c] %s",data.Get.channel+'A',
                  sysdata::getInstance()->GetGroupMute(data.Get.channel)?"Mute":"Unmute");
       }
       else {
           sprintf(bufSend, "Group[%c] is empty",data.Get.channel+'A');
       }
    }break;

    }
}

void SocketServer::QueryBack_Old(struct control4pack data)
{
    switch(data.OptMaster)
    {
        case cmd_type_trigger:
        {
            if(data.optSecond == MSG_TRIGGER_ON_ZONE)//sysdata::devicedata.zoon[set]
            {
                if(data.Get.channel<CHANNELS/8)
                {
                    sprintf(bufSend, "Get Zone :%s :%s",data.Get.channel==0?"1-8":"9-16",sysdata::getInstance()->devicedata.zoon[data.Get.channel]?"ON":"OFF");
                }
                else if(data.Get.channel==CHANNELS/8)
                {
                    sprintf(bufSend, "Get ASG :%s",sysdata::getInstance()->devicedata.asg?"ON":"OFF");
                }
            }
            if(data.optSecond == MSG_TRIGGER_ASG_CHANNEL)
            {
              sprintf(bufSend, "Get ASG : %s",sysdata::getInstance()->devicedata.asg?"ON":"OFF");
            }
        }break;
        case cmd_type_allgroup:
        {
        }break;
        case cmd_type_network:
        {

                 if(data.optSecond == MSG_NETWORK_MAC){
                     string mac=Tools::getInstanc()->getMacAddress();
                     sprintf(bufSend, "Get MAC Add %s",mac.c_str());
                 }
                 else if(data.optSecond ==MSG_NETWORK_AUTONETWORKSTANDBY)
                 {
                     sprintf(bufSend, "Auto Standby %s",sysdata::getInstance()->devicedata.autostandby?"On":"Off");
                 }
                 else if(data.optSecond ==MSG_NETWORK_DHCP)
                 {
                     _networkinfo ip = sysdata::getInstance()->netinfo;
                     LOGOUT("DHCP ON:%s",ip.dhcpEnabled.c_str());
                     if(ip.dhcpEnabled.find("0")==ip.dhcpEnabled.npos)
                     {
                         sprintf(bufSend, "Get DHCP ON");
                     }
                     else {
                         sprintf(bufSend, "Get IP STATIC");
                     }
                 }

        }break;
        case cmd_type_internaltest:
        {

        }break;
        case cmd_type_audiosense:
        {
            if(data.optSecond==MSG_AUDIO_SENSE)
            {
                if(data.Get.channel<CHANNELS)
                {
                    sprintf(bufSend, "AudioSense:Input[%d]: %d",data.Get.channel,!!stream::getInstance()->workstat[data.Get.channel]);
                }
            }
            if(data.optSecond==MSG_AUDIO_SENSE_ENABLE)//MSG_AUDIO_SENSE_STATUS
            {
                 sprintf(bufSend, "Get AUTO SENSE :%s",sysdata::getInstance()->devicedata.audiosens?"On":"Off");
            }
        }break;





        default:break;
    }


}
void SocketServer::QueryBack(struct control4pack packet,int newcom)
{
   if(newcom)
   {
       if(packet.OptMaster==MSG_Output)
       {
           if(packet.Get.channel<CHANNELS)
           {
               QueryBack_Out_New(packet);
           }
       }
       else if(packet.OptMaster==MSG_Misc)
       {
           if(packet.Get.channel<CHANNELS)QueryBack_Misc_New(packet);
       }
       else if(packet.OptMaster==MSG_Input)
       {
           if(packet.Get.channel<CHANNELS)QueryBack_Input_New(packet);
       }
       else if(packet.OptMaster==MSG_EQ)
       {
           if(packet.Get.channel<CHANNELS)QueryBack_EQ(packet);
       }
       else if(packet.OptMaster==MSG_SYS)
       {
            if (packet.optSecond == MSG_Credential)
            {
                sprintf(bufSend, "Get Credentials:username->%s, passwd->%s",sysdata::getInstance()->mLoginInfo.mUserName.c_str(), sysdata::getInstance()->mLoginInfo.mUserPasswd.c_str());
            }
       }
       else
       {
           LOGOUT("QueryBack new-->master:%x,second:%d:%d\r\n",packet.OptMaster,packet.optSecond);

       }

   }
   else
   {
        if(packet.OptMaster==cmd_type_sys)
        {
            QueryBack_Sys_Old(packet);
        }
        else if(packet.OptMaster==cmd_type_input)
        {
            if(packet.Get.channel<CHANNELS)
            {
                QueryBack_Input_Old(packet);
            }
        }
        else if(packet.OptMaster==cmd_type_output)
        {
            if(packet.Get.channel<CHANNELS)
            {
                QueryBack_Output_Old(packet);
            }
        }
        else if(packet.OptMaster==cmd_type_group)
        {
            if(packet.Get.channel<CHANNELS)
            {
                QueryBack_Group_Old(packet);
            }
        }
        else
        {
            QueryBack_Old(packet);
            printf("QueryBack old-->master:%x,second:%d:%d\r\n",packet.OptMaster,packet.optSecond);
        }
   }

    //    //len=strlen(buf);


}

#define Head1 0
#define Head2 1
#define LENTH 2
#define BUFFSIZE 1024
#define ECHO_MSG_LEN  150
void SocketServer::decode(int len)
{
    int i;
    struct control4pack packet;
    int newversion=0;
    for(i=0;i<len;i++)
    {
        if(
               (
                (bufReceive[i+Head1]==0xff)&&(bufReceive[i+Head2]==0x55)&&(bufReceive[i+LENTH]>=2)&&(bufReceive[i+LENTH]<=0x0e)
               )
               ||
               (
                (bufReceive[i+Head1]==0xff)&&(bufReceive[i+Head2]==0x56)&&(bufReceive[i+LENTH]>=2)&&(bufReceive[i+LENTH]<=100)
               )
          )
        {
            if(bufReceive[i+Head2]==0x56)newversion=1;
            memcpy(&packet,bufReceive+i+LENTH,bufReceive[i+LENTH]+1);
            memset(bufSend,0,ECHO_MSG_LEN);
            if(packet.Get.query==0xf5)
            {
                LOGOUT("QueryBack-->master:%x,second:%x\r\n",packet.OptMaster,packet.optSecond);
                QueryBack(packet,newversion);
            }
            else
            {
                LOGOUT("Set-->master:%x,second:%x,v1:%x,v2:%x\r\n",packet.OptMaster,packet.optSecond,packet.Set.channel,packet.Set.value);
                Commhandle(packet,newversion);
            }

            if(!strlen(bufSend))
            {
               sprintf(bufSend, "Command error");
            }
            LOGOUT("send:%s\r\n",bufSend);
            send(client_sockfd, bufSend, ECHO_MSG_LEN, 0);
            memset(bufSend,0,sizeof(bufSend));

            memset(&packet,0,sizeof(struct control4pack));
            i+=(2+bufReceive[i+LENTH]);
            if(i>=1024)return;
        }
    }
}

void SocketServer::report_Signal_detect(unsigned char channel)
{
    int ret;
    ret=stream::getInstance()->OutSignal(channel);
    sprintf(bufSend, "Get Input[%d] Audio Detect %s",channel+1,ret?"Detected":"Undetected");
    send(client_sockfd, bufSend, ECHO_MSG_LEN, 0);
    memset(bufSend,0,sizeof(bufSend));
}

void signalhandler(int sig) {
    switch(sig) {
    case SIGUSR1:
        LOGOUT("sig:%d",sig);
        LEDMISC::getInstance()->SetUpgrade(1);
        break;
    case SIGUSR2:
        LOGOUT("sig:%d",sig);
        LEDMISC::getInstance()->SetUpgrade(1);
        break;
    default:
        LOGOUT("unsupport signal:%d",sig);
        break;
    }
}
SocketServer::SocketServer()
{
    signal(SIGUSR1,signalhandler);
    signal(SIGUSR2,signalhandler);
    server_sockfd = 0;
    client_sockfd = 0;
}
SocketServer::~SocketServer()
{
    if(client_sockfd)
    {
        close(client_sockfd);
        LOGOUT("close client_sockfd!\n");
    }
    if(server_sockfd)
    {
        close(server_sockfd);
        LOGOUT("close server_sockfd!\n");
    }

}
void SocketServer ::run()
{

    int len = 0;
    int on=1;
    int bindd;
    int i;
    // int sin_size = 0;
    socklen_t sin_size=0;
    struct sockaddr_in server_addr;
    struct sockaddr_in client_addr;
    // char buf[BUFFSIZE] = {0};
    LOGOUT("socket start!\n");
    bzero(&server_addr, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(52000);
    fd_set rset,allset;

    if((server_sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        LOGOUT("socket error!\n");
        return ;
    }

    setsockopt(server_sockfd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on) );
    for(i=0;i<100;i++)
    {
        bindd=bind(server_sockfd, (struct sockaddr *)&server_addr, sizeof(struct sockaddr));
        if( bindd< 0)
        {
            LOGOUT("bind error!:%x\n",bindd);
            sleep(1);
        }
        else break;
    }
    if(listen(server_sockfd, 5) < 0)
    {
        LOGOUT("listen error!\n");
        return ;
    }
    FD_ZERO(&allset);
    FD_SET(server_sockfd,&allset);
    LEDMISC::getInstance()->SetConnectd(0);
    unsigned int sizeList = 0;
    while(1)
    {
        sin_size= sizeof(struct sockaddr_in);
        rset = allset;

        int active = select(FD_SIZE_LEN+1,&rset,NULL,NULL,NULL);
        if(active <= 0)
        {
            continue;
        }

        if(FD_ISSET(server_sockfd,&rset))
        {
            int fd_cont = accept(server_sockfd, (struct sockaddr *)&client_addr, &sin_size);
            if(fd_cont != -1)
            {
                LEDMISC::getInstance()->SetConnectd(1);
                sizeList++;
                FD_SET(fd_cont,&allset);
            }
        }

        for(int i = 0; i < FD_SIZE_LEN; i++)
        {
            if(FD_ISSET(i,&rset))
            {
                memset(bufReceive,0,1024);
                if((len = recv(i, bufReceive, BUFFSIZE, 0)) == 0)
                {
                    close(i);
                    sizeList--;
                    FD_CLR(i,&allset);
                    if(0 == sizeList)
                    {
                        LEDMISC::getInstance()->SetConnectd(0);
                    }
                }else
                {
                    // int ;
                    client_sockfd = i;
                    decode(len);
                }
            }
        }

    }


    return ;
}
