#include "json_parser.h"

void
initJsonMemoryHandler()
{
    cJSON_Hooks memoryHooks;

    memoryHooks.malloc_fn = jsonMalloc;
    memoryHooks.free_fn = NULL;
    cJSON_InitHooks(&memoryHooks);
}

void *
jsonMalloc(
    IN size_t sz
    )
{
    void *ptr = NULL;
    ptr = malloc(sz);
    assert (ptr != NULL);
    return ptr;
}

JSON_PARSER_OBJ *
parseJsonString(
    IN char *jsonString
    )
{
    JSON_PARSER_OBJ *root = NULL;
    
    root = cJSON_Parse(jsonString);
    assert (root != NULL);
    return root;
}

JSON_PARSER_OBJ *
getJsonObjectForKey(
    IN JSON_PARSER_OBJ *root,
    IN char *key
    )
{
    JSON_PARSER_OBJ *child = NULL;
    
    child = cJSON_GetObjectItem(root, key);
    return child;
}

int
getJsonObjectType(
    IN JSON_PARSER_OBJ *obj
    )
{
    switch (obj->type) {
        case cJSON_False:
        case cJSON_True:
            return JSON_BOOL;
        case cJSON_Number:
            return JSON_NUMBER;
        case cJSON_String:
            return JSON_STRING;
        case cJSON_Array:
            return JSON_ARRAY;
        case cJSON_Object:
            return JSON_OBJECT;
        default:
            return JSON_NULL;
    }
}

int
getJsonArraySize(
    IN JSON_PARSER_OBJ *array
    )
{
    int arraySize;

    arraySize = cJSON_GetArraySize(array);
    return arraySize;
}

JSON_PARSER_OBJ *
getJsonArrayItem(
    IN JSON_PARSER_OBJ *array,
    IN int arrayIndex
    )
{
    JSON_PARSER_OBJ *arrayItem = NULL;

    arrayItem = cJSON_GetArrayItem(array, arrayIndex);
    return arrayItem;
}

char *
getJsonObjectStringValue(
    IN JSON_PARSER_OBJ *obj
    )
{
    return (obj->valuestring);
}

char *
getJsonStringValueForKey(
    IN JSON_PARSER_OBJ *obj,
    IN char *key
    )
{
    JSON_PARSER_OBJ *child = NULL;
    
    child = getJsonObjectForKey(obj, key);
    if (child == NULL) return NULL;
    return (child->valuestring);
}

int
getJsonObjectIntValue(
    IN JSON_PARSER_OBJ *obj
    )
{
    return (obj->valueint);
}

int
getJsonIntValueForKey(
    IN JSON_PARSER_OBJ *obj,
    IN char *key
    )
{
    JSON_PARSER_OBJ *child = NULL;
    
    child = getJsonObjectForKey(obj, key);
    if (child == NULL) return 0;
    return (child->valueint);
}

int
getJsonBoolValueForKey(
    IN JSON_PARSER_OBJ *obj,
    IN char *key
    )
{
    JSON_PARSER_OBJ *child = NULL;

    child = getJsonObjectForKey(obj, key);
    if (child == NULL) return 0;
    return (child->valueint);
}

double
getJsonObjectDoubleValue(
    IN JSON_PARSER_OBJ *obj
    )
{
    return (obj->valuedouble);
}

double
getJsonDoubleValueForKey(
    IN JSON_PARSER_OBJ *obj,
    IN char *key
    )
{
    JSON_PARSER_OBJ *child = NULL;
    
    child = getJsonObjectForKey(obj, key);
    if (child == NULL) return 0.;
    return (child->valuedouble);
}

JSON_PARSER_OBJ *
getJsonChildObject(
    IN JSON_PARSER_OBJ *obj
    )
{
    return (obj->child);
}

JSON_PARSER_OBJ *
getJsonNextObject(
    IN JSON_PARSER_OBJ *obj
    )
{
    return (obj->next);
}

JSON_PARSER_OBJ *
createJsonObject()
{
    JSON_PARSER_OBJ *root= NULL;

    root = cJSON_CreateObject();
    assert (root != NULL);
    return root;
}

void
addJsonObject(
    IN JSON_PARSER_OBJ *root,
    IN char *key,
    IN JSON_PARSER_OBJ *child
    )
{
    cJSON_AddItemToObject(root, key, child);
}

void
addJsonObjectStringItem(
    IN JSON_PARSER_OBJ *obj,
    IN char *key,
    IN char *value
    )
{
    cJSON_AddStringToObject(obj, key, value);
}

void
addJsonObjectIntItem(
    IN JSON_PARSER_OBJ *obj,
    IN char *key,
    IN int value
    )
{
    cJSON_AddNumberToObject(obj, key, value);
}

void
addJsonObjectBoolItem(
    IN JSON_PARSER_OBJ *obj,
    IN char *key,
    IN int value
    )
{
    cJSON_AddBoolToObject(obj, key, value);
}

void
addJsonObjectDoubleItem(
    IN JSON_PARSER_OBJ *obj,
    IN char *key,
    IN double value
    )
{
    cJSON_AddNumberToObject(obj, key, value);
}

JSON_PARSER_OBJ *
createJsonArray()
{
    JSON_PARSER_OBJ *root= NULL;

    root = cJSON_CreateArray();
    assert (root != NULL);
    return root;
}

void
addJsonArrayItem(
    IN JSON_PARSER_OBJ *array,
    IN JSON_PARSER_OBJ *item
    )
{
    cJSON_AddItemToArray(array, item);
}

JSON_PARSER_OBJ *
createJsonIntArray(
    IN const int *array,
    IN int count
    )
{
    JSON_PARSER_OBJ *root= NULL;

    root = cJSON_CreateIntArray(array, count);
    assert (root != NULL);
    return root;
}

JSON_PARSER_OBJ *
createJsonDoubleArray(
    IN const double *array,
    IN int count
    )
{
    JSON_PARSER_OBJ *root= NULL;

    root = cJSON_CreateDoubleArray(array, count);
    assert (root != NULL);
    return root;
}

JSON_PARSER_OBJ *
createJsonStringArray(
    IN const char **array,
    IN int count
    )
{
    JSON_PARSER_OBJ *root= NULL;

    root = cJSON_CreateStringArray(array, count);
    assert (root != NULL);
    return root;
}

void
deleteJsonObject(
    IN JSON_PARSER_OBJ *obj
    )
{
    cJSON_Delete(obj);
}

JSON_PARSER_OBJ *
initJsonRpcObject()
{
    JSON_PARSER_OBJ *root = NULL;

    root = createJsonObject();
    assert (NULL != root);
    /* create jsonrpc value in json */
    addJsonObjectStringItem(root, "jsonrpc", "2.0");
    return root;
}

void
copyJsonStringItem(
    IN JSON_PARSER_OBJ *srcObj,
    IN OUT JSON_PARSER_OBJ *dstObj,
    IN char *itemName
    )
{
    char *stringValue = NULL;

    stringValue = getJsonStringValueForKey(srcObj, itemName);
    addJsonObjectStringItem(dstObj, itemName, stringValue);
}

