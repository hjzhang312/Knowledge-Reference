#include "json_parser.h"

char jsonText[] = "{\"jsonrpc\":\"2.0\",\"id\":\"DEVICE_SERVICES|1\",\"method\":\"dxGetAbout\",\"params\":{\"deviceId\":\"00:00:00:00:00:01\", \"dummyIntVal\":123456, \"dummyDoubleVal\":12456.789, \"dummyArrayVal\":[{\"name\":\"array1\"}, {\"name\":\"array2\"}]}, \"intArray\":[0, 1, 2, 3, 4], \"stringArray\":[\"ab\",\"bc\",\"cd\"] }";

void
parseJson()
{
    JSON_PARSER_OBJ *root = NULL, *obj = NULL, *subobj = NULL, *arrayObj = NULL, *arrayItem = NULL;
    char *data = NULL;
    int i, arraySize;

    root = parseJsonString(jsonText);
    assert (NULL != root);

    data = cJSON_Print(root);
    printf ("%s\n\n", data);
    free (data);

    printf ("jsonrpc : %s\n", getJsonStringValueForKey(root, "jsonrpc"));
    printf ("id : %s\n", getJsonStringValueForKey(root, "id"));
    printf ("method : %s\n", getJsonStringValueForKey(root, "method"));

    obj = getJsonObjectForKey(root, "params");
    assert (NULL != obj);

    printf ("params -> deviceId: %s\n", getJsonStringValueForKey(obj, "deviceId"));
    printf ("params -> dummyIntVal: %d\n", getJsonIntValueForKey(obj, "dummyIntVal"));
    printf ("params -> dummyDoubleVal: %f\n", getJsonDoubleValueForKey(obj, "dummyDoubleVal"));

    subobj = getJsonObjectForKey(obj, "dummyArrayVal");
    assert (NULL != subobj);
    arraySize = getJsonArraySize(subobj);
    for (i=0; i<arraySize; i++) {
        arrayObj = getJsonArrayItem(subobj, i);
        assert (NULL != arrayObj);
        printf ("params -> dummyArrayVal -> name : %s\n", getJsonStringValueForKey(arrayObj, "name"));
    }

    arrayObj = getJsonObjectForKey(root, "intArray");
    assert (NULL != arrayObj);
    printf ("intArray : [ ");
    arraySize = getJsonArraySize(arrayObj);
    for (i=0; i<arraySize; i++) {
        arrayItem = getJsonArrayItem(arrayObj, i);
        assert (NULL != arrayItem);
        printf ("%d ", getJsonObjectIntValue(arrayItem));
    }
    printf ("]\n");

    arrayObj = getJsonObjectForKey(root, "stringArray");
    assert (NULL != arrayObj);
    printf ("stringArray : [ ");
    arraySize = getJsonArraySize(arrayObj);
    for (i=0; i<arraySize; i++) {
        arrayItem = getJsonArrayItem(arrayObj, i);
        assert (NULL != arrayItem);
        printf ("%s ", getJsonObjectStringValue(arrayItem));
    }
    printf ("]\n");

    deleteJsonObject(root);
}

void
createJson()
{
    JSON_PARSER_OBJ *root = NULL, *obj = NULL, *subobj = NULL, *arrayObj = NULL, *arrayItem = NULL;
    char *data = NULL;
    int i, arraySize;
    int intArray[] = {0, 1, 2, 3, 4};
    char *stringArray[] = {"ab", "bc", "cd"}; 

    root = createJsonObject();
    addJsonObjectStringItem(root, "jsonrpc", "2.0");
    addJsonObjectStringItem(root, "id", "DEVICE_SERVICES|1");
    addJsonObjectStringItem(root, "method", "dxGetAbout");

    obj = createJsonObject();
    addJsonObject(root, "params", obj);
    addJsonObjectStringItem(obj, "deviceId", "00:00:00:00:00:01");
    addJsonObjectIntItem(obj, "dummyIntVal", 123456);
    addJsonObjectDoubleItem(obj, "dummyDoubleVal", 12456.789);

    arrayObj = createJsonArray();
    addJsonObject(obj, "dummyArrayVal", arrayObj);
    arrayItem = createJsonObject();
    addJsonObjectStringItem(arrayItem, "name", "array1");
    addJsonArrayItem(arrayObj, arrayItem);
    arrayItem = createJsonObject();
    addJsonObjectStringItem(arrayItem, "name", "array2");
    addJsonArrayItem(arrayObj, arrayItem);

    arrayObj = createJsonIntArray(intArray, 5);
    addJsonObject(root, "intArray", arrayObj);
    
    arrayObj = createJsonStringArray(stringArray, 3);
    addJsonObject(root, "stringArray", arrayObj);

    arrayObj = createJsonStringArray(NULL, 0);
    addJsonObject(root, "stringArrayEmpty", arrayObj);

    data = cJSON_Print(root);
    printf ("%s\n\n", data);
    free (data);

    deleteJsonObject(root);
}

int main()
{
    initJsonMemoryHandler();
    parseJson();
    createJson();

    return 0;
}
