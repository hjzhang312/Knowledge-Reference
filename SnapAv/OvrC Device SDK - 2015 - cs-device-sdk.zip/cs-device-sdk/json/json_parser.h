#ifndef JSON_PARSER_H
#define JSON_PARSER_H

#include "platform.h"
#include "cJSON.h"

/* This will be useful if tomorrow we want to change the parser. */
/* Below interface won't get changed even we change the parser lib */
typedef cJSON JSON_PARSER_OBJ;

#define JSON_NULL   0
#define JSON_BOOL   1
#define JSON_NUMBER 2
#define JSON_STRING 3
#define JSON_OBJECT 4
#define JSON_ARRAY  5

void
initJsonMemoryHandler();

void *
jsonMalloc(
    IN size_t sz
    );

JSON_PARSER_OBJ *
parseJsonString(
    IN char *jsonString
    );

JSON_PARSER_OBJ *
getJsonObjectForKey(
    IN JSON_PARSER_OBJ *root,
    IN char *key
    );

int
getJsonObjectType(
    IN JSON_PARSER_OBJ *obj
    );

int
getJsonArraySize(
    IN JSON_PARSER_OBJ *array
    );

JSON_PARSER_OBJ *
getJsonArrayItem(
    IN JSON_PARSER_OBJ *array,
    IN int arrayIndex
    );

char *
getJsonObjectStringValue(
    IN JSON_PARSER_OBJ *obj
    );

char *
getJsonStringValueForKey(
    IN JSON_PARSER_OBJ *obj,
    IN char *key
    );

int
getJsonObjectIntValue(
    IN JSON_PARSER_OBJ *obj
    );

int
getJsonIntValueForKey(
    IN JSON_PARSER_OBJ *obj,
    IN char *key
    );

int
getJsonBoolValueForKey(
    IN JSON_PARSER_OBJ *obj,
    IN char *key
    );

double
getJsonObjectDoubleValue(
    IN JSON_PARSER_OBJ *obj
    );

double
getJsonDoubleValueForKey(
    IN JSON_PARSER_OBJ *obj,
    IN char *key
    );

JSON_PARSER_OBJ *
getJsonChildObject(
    IN JSON_PARSER_OBJ *obj
    );

JSON_PARSER_OBJ *
getJsonNextObject(
    IN JSON_PARSER_OBJ *obj
    );

JSON_PARSER_OBJ *
createJsonObject();

void
addJsonObject(
    IN JSON_PARSER_OBJ *root,
    IN char *key,
    IN JSON_PARSER_OBJ *child
    );

void
addJsonObjectStringItem(
    IN JSON_PARSER_OBJ *obj,
    IN char *key,
    IN char *value
    );

void
addJsonObjectIntItem(
    IN JSON_PARSER_OBJ *obj,
    IN char *key,
    IN int value
    );

void
addJsonObjectBoolItem(
    IN JSON_PARSER_OBJ *obj,
    IN char *key,
    IN int value
    );

void
addJsonObjectDoubleItem(
    IN JSON_PARSER_OBJ *obj,
    IN char *key,
    IN double value
    );

JSON_PARSER_OBJ *
createJsonArray();

void
addJsonArrayItem(
    IN JSON_PARSER_OBJ *array,
    IN JSON_PARSER_OBJ *item
    );

JSON_PARSER_OBJ *
createJsonIntArray(
    IN const int *array,
    IN int count
    );

JSON_PARSER_OBJ *
createJsonDoubleArray(
    IN const double *array,
    IN int count
    );

JSON_PARSER_OBJ *
createJsonStringArray(
    IN const char **array,
    IN int count
    );

void
deleteJsonObject(
    IN JSON_PARSER_OBJ *obj
    );

/* specific APIs for OvrC use case */

JSON_PARSER_OBJ *
initJsonRpcObject();

void
copyJsonStringItem(
    IN JSON_PARSER_OBJ *srcObj,
    IN OUT JSON_PARSER_OBJ *dstObj,
    IN char *itemName
    );


#endif // JSON_PARSER_H
