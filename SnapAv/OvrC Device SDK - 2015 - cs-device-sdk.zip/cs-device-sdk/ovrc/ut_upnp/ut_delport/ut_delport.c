#include "ovrc_pub.h"

int main(int argc, char **argv)
{
    int retCode;
    int exPort;

    if (2 != argc) {
        printf ("Usage: %s external_port\n", argv[0]);
        return 1;
    }

    exPort = atoi(argv[1]);
    retCode = deletePortForwarding(exPort);

    if (UPnP_E_OK == retCode) {
        printf ("Port deleted successful!\n");
    } else if (UPnP_ERROR_NO_ROUTER_SUPPORT == retCode) {
        printf ("Router doesn't support port forwarding.\n");
    } else {
        printf ("Router refused port forwarding request.\n");
    }

    return 0;
}
