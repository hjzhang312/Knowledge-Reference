#include "ovrc_pub.h"

int main(int argc, char **argv)
{
    int retCode;
    int inPort;
    char exIPaddr[64];
    int exPort;

    if (2 != argc) {
        printf ("Usage: %s internal_port\n", argv[0]);
        return 1;
    }

    inPort = atoi(argv[1]);
    retCode = addPortForwarding(inPort, 60*5, "OvrC:Test", exIPaddr, &exPort);

    if (UPnP_E_OK == retCode) {
        printf ("Port forwarding successful!\n");
        printf ("External IP addr: %s\n", exIPaddr);
        printf ("External port: %d\n", exPort);
    } else if (UPnP_ERROR_NO_ROUTER_SUPPORT == retCode) {
        printf ("Router doesn't support port forwarding.\n");
    } else {
        printf ("Router refused port forwarding request.\n");
    }

    return 0;
}
