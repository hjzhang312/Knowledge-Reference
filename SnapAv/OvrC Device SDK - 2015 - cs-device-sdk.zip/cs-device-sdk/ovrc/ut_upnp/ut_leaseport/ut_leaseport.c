#include "ovrc_pub.h"

int main(int argc, char **argv)
{
    int retCode;
    int idx;
    char exIPaddr[64];
    int inPort[] = { 6171, 4213, 9860, 2198 };
    int leaseTime[] = {160, 0, 90, 200};
    int exPort[4];

    initUPnPService();

    for(idx = 0; idx < 4; ++idx) {
        retCode = addPortForwarding(inPort[idx], leaseTime[idx], "UPnP:Test", exIPaddr, &exPort[idx]);

        if (UPnP_E_OK == retCode) {
            printf ("Port forwarding successful!\n");
            printf ("External IP addr: %s\n", exIPaddr);
            printf ("External port: %d\n", exPort[idx]);
        } else if (UPnP_ERROR_NO_ROUTER_SUPPORT == retCode) {
            printf ("Router doesn't support port forwarding.\n");
        } else {
            printf ("Router refused port forwarding request.\n");
        }
    }

    for (idx=0; idx<5; idx++) {
        osSleep(60);
        printf ("After %d minutes:\n", idx+1);
        displayPortForwardingLease();
    }

    deleteUPnPService();
    return 0;
}
