#include "reader_writer.h"

void
initRWLock(
    IN RWLock *pRWLock
    )
{
    initMutex(&(pRWLock->mutex1));
    initMutex(&(pRWLock->mutex2));
    initMutex(&(pRWLock->mutex3));
    initSemaphore(&(pRWLock->r), 1);
    initSemaphore(&(pRWLock->w), 1);
    pRWLock->readerCount = 0;
    pRWLock->writerCount = 0;
}

void
deleteRWLock(
    IN RWLock *pRWLock
    )
{
    deleteMutex(&(pRWLock->mutex1));
    deleteMutex(&(pRWLock->mutex2));
    deleteMutex(&(pRWLock->mutex3));
    deleteSemaphore(&(pRWLock->r));
    deleteSemaphore(&(pRWLock->w));
}

void
acquireSharedLock(
    IN RWLock *pRWLock
    )
{
    lockMutex(&(pRWLock->mutex3));
        waitSemaphore(&(pRWLock->r));
            lockMutex(&(pRWLock->mutex1));
                pRWLock->readerCount++;
                if (1 == pRWLock->readerCount) {
                    waitSemaphore(&(pRWLock->w));
                }
            unlockMutex(&(pRWLock->mutex1));
        postSemaphore(&(pRWLock->r));
    unlockMutex(&(pRWLock->mutex3));
}

void
releaseSharedLock(
    IN RWLock *pRWLock
    )
{
    lockMutex(&(pRWLock->mutex1));
        pRWLock->readerCount--;
        if (0 == pRWLock->readerCount) {
            postSemaphore(&(pRWLock->w));
        }
    unlockMutex(&(pRWLock->mutex1));
}

void
acquireExclusiveLock(
    IN RWLock *pRWLock
    )
{
    lockMutex(&(pRWLock->mutex2));
        pRWLock->writerCount++;
        if (1 == pRWLock->writerCount) {
            waitSemaphore(&(pRWLock->r));
        }
    unlockMutex(&(pRWLock->mutex2));
    waitSemaphore(&(pRWLock->w));
}

void
releaseExclusiveLock(
    IN RWLock *pRWLock
    )
{
    postSemaphore(&(pRWLock->w));
    lockMutex(&(pRWLock->mutex2));
        pRWLock->writerCount--;
        if (0 == pRWLock->writerCount) {
            postSemaphore(&(pRWLock->r));
        }
    unlockMutex(&(pRWLock->mutex2));
}

