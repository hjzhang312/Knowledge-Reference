#ifndef CMD_QUEUE_MANAGER_H
#define CMD_QUEUE_MANAGER_H

#include "ovrc_pub.h"

#define COMMAND_QUEUE_LENGTH 10

#define BLOCKING_PRODUCTION    1
#define NONBLOCKING_PRODUCTION 2
#define OVERWRITING_PRODUCTION 3

typedef struct queue {
    JSON_PARSER_OBJ **queue;
    Semaphore emptySemaphore;
    Semaphore fullSemaphore;
    Mutex indexMutex;
    INT32 producerIndex;
    INT32 consumerIndex;
    INT32 queueSize;
    INT32 fillCount;
} Queue;

void
initQueue(
    IN Queue *pQueue,
    IN UINT32 queueSize
    );

void
deleteQueue(
    IN Queue *pQueue
    );

BOOL
produceObject(
    IN Queue *pQueue,
    IN JSON_PARSER_OBJ *object,
    IN BYTE productionType 
    );

void
consumeObject(
    IN Queue *pQueue,
    OUT JSON_PARSER_OBJ **object
    );
    

#endif // CMD_QUEUE_MANAGER_H
