#include "queue_manager.h"

void
initQueue(
    IN Queue *pQueue,
    IN UINT32 queueSize
    )
{
    pQueue->queue = (JSON_PARSER_OBJ **) 
                       malloc(sizeof(JSON_PARSER_OBJ *) * queueSize);
    assert (NULL != pQueue->queue);
    pQueue->producerIndex = 0;
    pQueue->consumerIndex = 0;
    initSemaphore(&(pQueue->emptySemaphore), queueSize);
    initSemaphore(&(pQueue->fullSemaphore), 0);
    initMutex(&(pQueue->indexMutex));
    pQueue->queueSize = queueSize;
    pQueue->fillCount = 0;
}

void
deleteQueue(
    IN Queue *pQueue
    )
{
    free (pQueue->queue);
    pQueue->queue = NULL;
    deleteSemaphore(&(pQueue->emptySemaphore));
    deleteSemaphore(&(pQueue->fullSemaphore));
    deleteMutex(&(pQueue->indexMutex));
}

BOOL
produceObject(
    IN Queue *pQueue,
    IN JSON_PARSER_OBJ *object,
    IN BYTE productionType 
    )
{
    INT32 pIndex;
    BOOL ret;

    if (BLOCKING_PRODUCTION == productionType) {
        /* wait for an empty slot for this object */
        waitSemaphore(&(pQueue->emptySemaphore));
    } 
    else if (NONBLOCKING_PRODUCTION == productionType) {
        /* check if there is an empty slot for this object */
        ret = trywaitSemaphore(&(pQueue->emptySemaphore));
        /* if currently queue is full & there is no space for this object */
        if (FALSE == ret) {
            /* drop the incoming object as there is no space left for it */
            deleteJsonObject(object);
            return FALSE;
        }
    }

        /* acquire lock to produce item */
        lockMutex(&(pQueue->indexMutex));
            pIndex = pQueue->producerIndex;
            /* place production index at apt location for next call */
            pQueue->producerIndex++;
            pQueue->producerIndex %= pQueue->queueSize;

            /* place the object at the pIndex in the queue */
            pQueue->queue[pIndex] = object;

            /* Check if the queue is full */
            if (pQueue->fillCount == pQueue->queueSize) {
                /* Make sure that type of production is overwrite */
                assert (OVERWRITING_PRODUCTION == productionType);
                /* Shift the consumer index so that consumption goes in FIFO order */
                pQueue->consumerIndex++;
                pQueue->consumerIndex %= pQueue->queueSize;
            } else {
                /* Increase the queue fill count */
                pQueue->fillCount ++;
    
                /* inform consumers that one object added for consumption */
                postSemaphore(&(pQueue->fullSemaphore));
            }
        /* release lock */
        unlockMutex(&(pQueue->indexMutex));

    return TRUE;
}

void
consumeObject(
    IN Queue *pQueue,
    OUT JSON_PARSER_OBJ **object
    )
{
    int cIndex;

    /* wait till there is any object available for consumption */
    waitSemaphore(&(pQueue->fullSemaphore));

        /* acquire lock to consume index */
        lockMutex(&(pQueue->indexMutex));
            cIndex = pQueue->consumerIndex;
            /* place consumption index at apt location for next call */
            pQueue->consumerIndex++;
            pQueue->consumerIndex %= pQueue->queueSize;

            /* consume the object from cIndex */
            *object = pQueue->queue[cIndex];

            /* Decrease the queue fill count */
            pQueue->fillCount --;
        /* release lock */
        unlockMutex(&(pQueue->indexMutex));

    /* inform producers that one object slot is freed for production */
    postSemaphore(&(pQueue->emptySemaphore));

    return;
}
    
