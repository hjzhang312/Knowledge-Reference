#ifndef LOG_HANDLER_H
#define LOG_HANDLER_H

#include "ovrc_pub.h"

#define OvrC_LOG_LEVEL_PRODUCTION 20
#define OvrC_LOG_LEVEL_DEBUG      30

#define JSON_RPC_ID_LENGTH 128

typedef struct ovrc_log_handler {
    BOOL logEnabled;
    BYTE logLevel;
    Mutex logMutex;
    char jsonRpcId[JSON_RPC_ID_LENGTH];
    char dateIsoFormat[64];
} OvrCLogHandler;

void
initLogHandler();

void
deleteLogHandler(); 

void
enableLogHandler(
    IN char *rpcCommandId
    );

void
disableLogHandler();

void
setLogLevel(
    IN INT32 logLevel
    );

void
ovrcDebugLog(
    IN char *fileName,
    IN INT32 lineNumber,
    IN char *systemLog
    );

void
ovrcInfoLog(
    IN char *fileName,
    IN INT32 lineNumber,
    IN char *systemLog
    );

void
getDateIsoFormat(
    IN OUT char *timestampStr,
    IN int length
    );

BOOL
validDateIsoFormat(
    IN char *date
    );

#endif // LOG_HANDLER_H
