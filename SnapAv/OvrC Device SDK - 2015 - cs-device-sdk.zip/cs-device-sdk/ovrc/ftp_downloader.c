#include "ftp_downloader.h"

static ftpCallback appCallback = NULL;

static size_t libCallback(
    IN void *buffer, 
    IN size_t size, 
    IN size_t nmemb, 
    IN void *stream
    );

size_t libCallback(
    IN void *buffer, 
    IN size_t size, 
    IN size_t nmemb, 
    IN void *stream
    )
{
    appCallback(buffer, size*nmemb);
    return size*nmemb;
}

BOOL
ftpDownloader(
    IN char *url,
    IN ftpCallback callback
    )
{
    CURL *curl = NULL;
    CURLcode res;

    curl_global_init(CURL_GLOBAL_DEFAULT);

    curl = curl_easy_init();
    if(NULL == curl) {
        return FALSE;
    }

    res = curl_easy_setopt(curl, CURLOPT_URL, url);
    if (CURLE_OK != res) {
        return FALSE;
    }

    /* Set application's callback */
    appCallback = callback;

    /* Define our callback to get called when there's data to be written */
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, libCallback);
    /* Set a pointer to NULL to pass to the callback */
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, NULL);
    /* Start ftp download */
    res = curl_easy_perform(curl);
    /* always cleanup */
    curl_easy_cleanup(curl);

    if(CURLE_OK != res) {
        return FALSE;
    }

    /* Inform application callback the end of download */
    appCallback(NULL, 0);
    appCallback = NULL;

    return TRUE;
}

