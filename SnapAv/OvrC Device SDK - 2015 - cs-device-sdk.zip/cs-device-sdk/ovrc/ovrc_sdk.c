#include "ovrc_sdk.h"

#define OvrC_QUEUE_WRITER_THREADS 1
#define OvrC_QUEUE_READER_THREADS 3

#define OvrC_COMMAND_WRITER_ID 0

#define OvrC_REPLY_READER_ID   0
#define OvrC_STATUS_READER_ID  1
#define OvrC_EVENT_READER_ID   2

#define Ovrc_COMMAND_QUEUE_SIZE 10
#define Ovrc_REPLY_QUEUE_SIZE   10
#define Ovrc_STATUS_QUEUE_SIZE  10
#define Ovrc_EVENT_QUEUE_SIZE   10

UINT32 OvrC_writerQueueSize[] = {
                                    Ovrc_COMMAND_QUEUE_SIZE
                                };

UINT32 OvrC_readerQueueSize[] = {
                                    Ovrc_REPLY_QUEUE_SIZE,
                                    Ovrc_STATUS_QUEUE_SIZE,
                                    Ovrc_EVENT_QUEUE_SIZE
                                };

OvrCConnector wbsConnector;
RWLock wbsLocker;
WEBSOCKET *wbsConnection;

Queue writerQueue[OvrC_QUEUE_WRITER_THREADS];
Queue readerQueue[OvrC_QUEUE_READER_THREADS];

Thread queueWriterThread[OvrC_QUEUE_WRITER_THREADS];
Thread queueReaderThread[OvrC_QUEUE_READER_THREADS];

/* max size of JSON command is 16K at the time of writing this code */
BYTE readBuffer[16*1024+1];

BOOL reconnectFlag;

/************** PRIVATE FUNCTION DECLARATIONS **************/

static void *
establishWbsConnection(
    IN void *pdata
    );

static void
initOvrCQueues();

static void
initOvrCThreads();

static void
handleWbsPing();

static void
handleWbsClose();

static void *
queueWriter(
    IN void *pdata
    );

static void *
queueReader(
    IN void *pdata
    );

static void
produceDummyObjects();

static void
deleteOvrCThreads();

static void
deleteOvrCQueues();

/************** END OF PRIVATE FUNCTION DECLARATIONS **************/

void
initConnection(
    IN OvrCConnector connectionInfo
    )
{
    /* 
     * Take care of errors for writing data on closed socket.
     * It results into fatal termination of program on POSIX systems.
     * On Windows it don't terminate the program, just returns the error.
     */
    osHandleSIGPIPE();
    
    /* initialize json parser's memory handler routines */
    initJsonMemoryHandler();

    /* initialize status update frequency handler */
    initStatusFrequencyHandler();

    /* initialize log handler */
    initLogHandler();

    wbsConnector = connectionInfo;

    /* initialize read write locker for websocket */
    initRWLock(&wbsLocker);

    /* After every connection drop attempt reconnection */
    reconnectFlag = TRUE;

    /* establish websocket connection */
    wbsConnection = NULL;
    establishWbsConnection(NULL);

    /* initialize OvrC read-write queues */
    initOvrCQueues();

    /* initialize OvrC reader-writer threads */
    initOvrCThreads();

    /* initialize UPnP service */
    initUPnPService();

    return;
}

void *
establishWbsConnection(
    IN void *pdata
    )
{
    BOOL ret = FALSE;
    BOOL reconnectFlag = FALSE;
    BOOL hourWaitingFlag = FALSE;
    time_t attemptStartTime;
    time_t currentTime;
    time_t waitTime;
    UINT32 sleepTime;
    
    /* acquire the exclusive lock on websocket connection for reconnecting */
    acquireExclusiveLock(&wbsLocker);
        /* If we are trying to establish connection for the first time, initialize connection object. */
        if (NULL == wbsConnection) {
            wbsExtraInfo extraInfo;

            extraInfo.pingCallback = handleWbsPing;
            extraInfo.closeCallback = handleWbsClose;
            wbsConnection = initWebsocketConnection(wbsConnector.deviceUrl, wbsConnector.macAddress, extraInfo);
        } else {
            reconnectFlag = TRUE;
        }
        
        /* Note the time stamp as the start of connection etsbalishment attempt. */
        attemptStartTime = time(NULL);
        /* keep on attempting to establish connection till you successed */
        while (TRUE) {
            ret = connectWebSocket(wbsConnection);
            if (FALSE == ret) {
                /* Attempt to establish connection failed. */
                /* Check if we are already attempting for more that 1 hr, 10  mins. */
                if (TRUE == hourWaitingFlag) {
                    /* Set sleep time of 10 minutes. */
                    sleepTime = 10 * 60;
                } else {
                    /* Get current time. */
                    currentTime = time(NULL);
                    /* Get the total reconnection attempt time. */
                    waitTime = currentTime - attemptStartTime;
                    if (waitTime < 10 * 60) {
                        /* If wait time is less than 10 mins. */
                        sleepTime = 10;
                    } else {
                        /* If wait time is greater than 10 mins. */
                        sleepTime = 60;
                        /* Check if the ait time is greater than 1 hr. 10 mins. */
                        if (waitTime > 70 * 60) {
                            hourWaitingFlag = TRUE;
                        }
                    }
                }
                /* Sleep before retrying connection establishment. */
                osSleep(sleepTime);
            }
            else {
                break;
            }
        }

    /* release the exclusive lock on websocket connection */
    releaseExclusiveLock(&wbsLocker);

    /* callback the application informing connection reestablished */
    if ((TRUE == reconnectFlag) && wbsConnector.reconnectCallback) {
        (*wbsConnector.reconnectCallback)();
    }

    return NULL;
}

static void
initOvrCQueues()
{
    int i;

    for (i=0; i<OvrC_QUEUE_WRITER_THREADS; i++) {
        initQueue(&writerQueue[i], OvrC_writerQueueSize[i]);
    }

    for (i=0; i<OvrC_QUEUE_READER_THREADS; i++) {
        initQueue(&readerQueue[i], OvrC_readerQueueSize[i]);
    }
}

static void
initOvrCThreads()
{
    int i;

    for (i=0; i<OvrC_QUEUE_WRITER_THREADS; i++) {
        initThread(queueWriter, &writerQueue[i], &queueWriterThread[i]);
    }

    for (i=0; i<OvrC_QUEUE_READER_THREADS; i++) {
        initThread(queueReader, &readerQueue[i], &queueReaderThread[i]);
    }
}

/* This function is set as a callback for websocket PING event */
void
handleWbsPing()
{
    /* callback the application informing PING event */
    if (wbsConnector.pingCallback) {
        (*wbsConnector.pingCallback)();
    }
}

/* This function is set as a callback for websocket CLOSE event */
void
handleWbsClose()
{
    int ret;
    Thread reconnectionThread;

    /* callback the application informing connection is closed*/
    if (wbsConnector.closeCallback) {
        (*wbsConnector.closeCallback)();
    }

    /* If SDK set not to reconnect the server */
    if (FALSE == reconnectFlag) {
        return;
    }

    /*
     * The websocket cleint lib has been designed such that any open websocket
     * will be closed only once. That means this function will be called for
     * any websocket only once. In OvrC SDK there are three threads:
     * 1. commandReader 2. connectionStatus 3. replyWriter
     * any one of this thread can result in invocation of this callback.
     * The operation that can invoke this callback are protected by the
     * shared access of the websocket. 
     * The connection establishing operation needs exclusive access of websocket.
     * So there is a situation of deadlick here. Unless the thread which triggered
     * this callback releases shared access we can not call establishWbsConnection.
     * To handle this deadlock we spawn a new thread to handle establishWbsConnection
     * and we return this thread of execution to release the shared access.
     */

    /* spawn a thread to start reconnection */
    initThread(establishWbsConnection, NULL, &reconnectionThread);

    /* return this thread of execution to release shared lock on websocket connection */
    return;
}

void *
queueWriter(
    IN void *pdata
    )
{
    int ret;
    Queue *jsonQueue = NULL;
    JSON_PARSER_OBJ *root = NULL;

    jsonQueue = (Queue *) pdata;

    while (TRUE) {
        /* acquire shared lock on websocket connection for reading */
        acquireSharedLock(&wbsLocker);
            /* check if connection is closed by application */
            if (NULL == wbsConnection) {
                return NULL;
            }
            ret = readWebsocketFrame(wbsConnection, readBuffer, 16*1024);
        /* release shared lock on websocket connection */
        releaseSharedLock(&wbsLocker);

        if (-1 == ret) {
            /* connection failure detected */
            /* failed connections will be automatically reconnected by handleWbsClose callback */
            continue;
        }

        readBuffer[ret] = '\0';
        printf ("Received text frame: %d\n%s\n", ret, readBuffer);

        /* parse the JSON command */
        root = parseJsonString((char *)readBuffer);
        assert (NULL != root);

        /* produce the JSON command in command queue, discard the command if queue is full */
        produceObject(jsonQueue, root, NONBLOCKING_PRODUCTION);
    }

    return NULL;
}

void
readJsonCommand(
    OUT JSON_PARSER_OBJ **jsonCommand
    )
{
    /* consume the JSON command from the command queue */
    consumeObject(&writerQueue[OvrC_COMMAND_WRITER_ID], jsonCommand);
}

void *
queueReader(
    IN void *pdata
    )
{
    Queue *jsonQueue = NULL;
    char *jsonReplyString = NULL;
    JSON_PARSER_OBJ *root = NULL;
    int ret;

    jsonQueue = (Queue *) pdata;

    while (TRUE) {
        /* consume the json object from queue */
        consumeObject(jsonQueue, &root);

        /* Check if it is indicator to exit thread */
        if (NULL == root) {
            return NULL;
        }

        /* convert json object to string */
        jsonReplyString = cJSON_PrintUnformatted(root);
        assert (NULL != jsonReplyString);
        printf ("Sending text frame:\n%s\n", jsonReplyString);

        /* write the json reply string as websocket frame */
        do {
            /* acquire shared lock on websocket connection for writing */
            acquireSharedLock(&wbsLocker);
                /* check if connection is closed by application */
                if (NULL == wbsConnection) {
                    return NULL;
                }
                ret = writeWebsocketFrame(wbsConnection, WEBSOCKET_FRAME_TEXT,
                                          (BYTE *)jsonReplyString, strlen(jsonReplyString));
            /* release shared lock on websocket connection */
            releaseSharedLock(&wbsLocker);
            /* repeat this until success, failure represents connection closure */
            /* failed connections will be automatically reconnected by handleWbsClose callback */
        } while (-1 == ret);    

        /* free json string & json object */
        free(jsonReplyString);
        jsonReplyString = NULL;
        deleteJsonObject(root);
    }
}

void
writeJsonReply(
    IN JSON_PARSER_OBJ *jsonReply
    )
{
    /* produce the JSON reply in reply queue, if queue is full wait for the room */
    produceObject(&readerQueue[OvrC_REPLY_READER_ID], jsonReply, BLOCKING_PRODUCTION);
}

void
writeJsonStatus(
    IN JSON_PARSER_OBJ *jsonStatus
    )
{
    /* produce the JSON status in status queue, if queue is full overwrite the oldest entry */
    produceObject(&readerQueue[OvrC_STATUS_READER_ID], jsonStatus, OVERWRITING_PRODUCTION);
}

void
writeJsonEvent(
    IN JSON_PARSER_OBJ *jsonEvent
    )
{
    /* produce the JSON event in event queue, if queue is full wait for the room */
    produceObject(&readerQueue[OvrC_EVENT_READER_ID], jsonEvent, BLOCKING_PRODUCTION);
}

char *
getClientMacAddress()
{
    return wbsConnector.macAddress;
}

void
deleteConnection()
{
    /* do not reconnect after closing the connection */
    reconnectFlag = FALSE;
    /* close websocket connection */
    closeWebsocket(wbsConnection);

    /* acquire the exclusive lock on websocket connection */
    acquireExclusiveLock(&wbsLocker);
        /* delete websocket connection */
        deleteWebsocketConnection(wbsConnection);
        /* set wbsConnection to NULL, as an indicator for threads to exit */
        wbsConnection = NULL;
    /* release the exclusive lock on websocket connection */
    releaseExclusiveLock(&wbsLocker);

    /* unblock threads waiting to consume object by producing dummy objects */
    produceDummyObjects();

    /* wait for all threads to exit */
    deleteOvrCThreads();

    /* cleanup all the queues */
    deleteOvrCQueues();

    /* delete status frequency handler */
    deleteStatusFrequencyHandler();

    /* delete log handler */
    deleteLogHandler();

    /* delete read write locker for websocket */
    deleteRWLock(&wbsLocker);

    /* delete UPnP service */
    deleteUPnPService();
}

static void
produceDummyObjects()
{
    int i;

    for (i=0; i<OvrC_QUEUE_READER_THREADS; i++) {
        produceObject(&readerQueue[i], NULL, OVERWRITING_PRODUCTION);
    }
}

static void
deleteOvrCThreads()
{
    int i;

    for (i=0; i<OvrC_QUEUE_WRITER_THREADS; i++) {
        waitForThreadExit(&queueWriterThread[i]);
    }

    for (i=0; i<OvrC_QUEUE_READER_THREADS; i++) {
        waitForThreadExit(&queueReaderThread[i]);
    }
}

static void
deleteOvrCQueues()
{
    int i;

    for (i=0; i<OvrC_QUEUE_WRITER_THREADS; i++) {
        deleteQueue(&writerQueue[i]);
    }

    for (i=0; i<OvrC_QUEUE_READER_THREADS; i++) {
        deleteQueue(&readerQueue[i]);
    }
}

