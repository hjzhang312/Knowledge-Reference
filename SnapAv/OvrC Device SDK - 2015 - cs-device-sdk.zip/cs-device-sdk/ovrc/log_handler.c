#include "log_handler.h"

#ifdef WIN32
char tz[6];
#endif

/* Single object for the log handling */
OvrCLogHandler logHandler;

/*********** PRIVATE FUNCTION DECLARATIONS ***********/

static JSON_PARSER_OBJ *
initJsonRpcLogObject();

static JSON_PARSER_OBJ *
getLogarray(
    IN JSON_PARSER_OBJ *jsonLog
    );

static void
addLogToStream(
    IN char *fileName,
    IN INT32 lineNumber,
    IN char *systemLog,
    IN INT32 logLevel,
    IN JSON_PARSER_OBJ *logArray
    );

/*********** END OF PRIVATE FUNCTION DECLARATIONS ***********/


void
initLogHandler()
{
    int e;
    long seconds;
    int hh, mm;

    logHandler.logEnabled = FALSE;
    logHandler.logLevel = OvrC_LOG_LEVEL_PRODUCTION;
    initMutex(&logHandler.logMutex);
#ifdef WIN32
    _tzset();
    e = _get_timezone(&seconds);
    tz[0] = (seconds < 0 ? '+' : '-');
    if (seconds < 0) {
        seconds *= -1;
    }
    seconds /= 60;
    hh = seconds/60;
    mm = seconds%60;
    sprintf(tz+1, "%02d", hh);
    sprintf(tz+3, "%02d", mm);
#endif
}

void
deleteLogHandler()
{
    deleteMutex(&logHandler.logMutex);
}

void
enableLogHandler(
    IN char *rpcCommandId
    )
{
    int length;
    
    length = strlen(rpcCommandId);
    assert(length < JSON_RPC_ID_LENGTH);
    logHandler.logEnabled = TRUE;
    /* by default keep log level as PRODUCTION */
    logHandler.logLevel = OvrC_LOG_LEVEL_PRODUCTION;
    strncpy(logHandler.jsonRpcId, rpcCommandId, length);
}

void
disableLogHandler()
{
    logHandler.logEnabled = FALSE;
}

void
setLogLevel(
    IN INT32 logLevel
    )
{
    logHandler.logLevel = logLevel;
}

void
ovrcDebugLog(
    IN char *fileName,
    IN INT32 lineNumber,
    IN char *systemLog
    )
{
    JSON_PARSER_OBJ *jsonLog = NULL;

    if (FALSE == logHandler.logEnabled) {
        return;
    }
    if (OvrC_LOG_LEVEL_PRODUCTION == logHandler.logLevel) {
        return;
    }

    jsonLog = initJsonRpcLogObject();

    addLogToStream(fileName, lineNumber, systemLog, OvrC_LOG_LEVEL_DEBUG, getLogarray(jsonLog));
    /* send log array to server */
    writeJsonReply(jsonLog);
}

void
ovrcInfoLog(
    IN char *fileName,
    IN INT32 lineNumber,
    IN char *systemLog
    )
{
    JSON_PARSER_OBJ *jsonLog = NULL;

    if (FALSE == logHandler.logEnabled) {
        return;
    }

    jsonLog = initJsonRpcLogObject();

    addLogToStream(fileName, lineNumber, systemLog, OvrC_LOG_LEVEL_PRODUCTION, getLogarray(jsonLog));
    /* send log array to server */
    writeJsonReply(jsonLog);
}

JSON_PARSER_OBJ *
initJsonRpcLogObject()
{
    JSON_PARSER_OBJ *jsonLog = NULL;
    JSON_PARSER_OBJ *objResult = NULL;
    JSON_PARSER_OBJ *logArray = NULL;

    /* This call adds the jsonrpc version field to the object. */
    jsonLog = initJsonRpcObject();

    /* The "id" must be the same "id" used for enbling the logging. */
    addJsonObjectStringItem(jsonLog, "id", logHandler.jsonRpcId);

    /* set stream to TRUE */
    addJsonObjectBoolItem(jsonLog, "stream", TRUE);

    /* Add a result object to the response json. */
    objResult = createJsonObject();
    addJsonObject(jsonLog, "result", objResult);

    /* Populate the result fields in the response json. */

    /* add mac address to result */
    addJsonObjectStringItem(objResult, "deviceId", getClientMacAddress());
    /* create the log array */
    logArray = createJsonArray();
    addJsonObject(objResult, "logs", logArray);

    return jsonLog;
}

JSON_PARSER_OBJ *
getLogarray(
    IN JSON_PARSER_OBJ *jsonLog
    )
{
    JSON_PARSER_OBJ *objResult = NULL;
    JSON_PARSER_OBJ *logArray = NULL;

    objResult = getJsonObjectForKey(jsonLog, "result");
    logArray = getJsonObjectForKey(objResult, "logs");

    return logArray;
}

void
addLogToStream(
    IN char *fileName,
    IN INT32 lineNumber,
    IN char *systemLog,
    IN INT32 logLevel,
    IN JSON_PARSER_OBJ *logArray
    )
{
    JSON_PARSER_OBJ *logItem = NULL;
    char location[256];
    char line[16];

    snprintf (line, 16, "%d", lineNumber);
    strcpy (location, fileName);
    strcat (location, ":");
    strcat (location, line);

    /* create log item */
    logItem = createJsonObject();

    /* populate values for log item */
    /* lock mutex for getting date in ISO format */
    lockMutex(&logHandler.logMutex);
    getDateIsoFormat(logHandler.dateIsoFormat, 64);
    addJsonObjectStringItem(logItem, "dateTime", logHandler.dateIsoFormat);
    addJsonObjectIntItem(logItem, "level", logLevel);
    addJsonObjectStringItem(logItem, "location", location);
    addJsonObjectStringItem(logItem, "message", systemLog);

    /* add log item to log array */
    addJsonArrayItem(logArray, logItem);
    unlockMutex(&logHandler.logMutex);
}

/* Note: before calling this function make sure that it is thread safe */

void
getDateIsoFormat(
    IN OUT char *timestampStr,
    IN int length
    )
{
    time_t rawTime;
    struct tm *localTime = NULL;
    int ret;

    time(&rawTime);
    localTime = localtime(&rawTime);
    assert (localTime != NULL);
    ret = strftime(timestampStr, length, ISO_DATE_FORMAT, localTime);
#ifdef WIN32
    strcat (timestampStr, tz);
#endif
    assert (ret != 0);
}

/*
 * Valid ISO date format is decided as:
 * yyyy-mm-ddTHH:MM:SS+/-HHMM
 *
 */

BOOL
validDateIsoFormat(
    IN char *date
    )
{
    int num;

    if (strlen(date) != 24) {
        return FALSE;
    }

    /* Year parsing */
    if (!ISDIGIT(date[0]) || !ISDIGIT(date[1]) || !ISDIGIT(date[2]) || !ISDIGIT(date[3])) {
        return FALSE;
    }
    if (date[4] != '-') {
        return FALSE;
    }

    /* Month parsing */
    if (!ISDIGIT(date[5]) || !ISDIGIT(date[6])) {
        return FALSE;
    }
    num = (date[5]-'0')*10 + (date[6]-'0');
    if (num<1 || num>12) {
        return FALSE;
    }
    if (date[7] != '-') {
        return FALSE;
    }

    /* Day parsing */
    if (!ISDIGIT(date[8]) || !ISDIGIT(date[9])) {
        return FALSE;
    }
    num = (date[8]-'0')*10 + (date[9]-'0');
    if (num<1 || num>31) {
        return FALSE;
    }
    if (date[10]!='T' && date[10]!=' ') {
        return FALSE;
    }

    /* Hour parsing */
    if (!ISDIGIT(date[11]) || !ISDIGIT(date[12])) {
        return FALSE;
    }
    num = (date[11]-'0')*10 + (date[12]-'0');
    if (num>23) {
        return FALSE;
    }
    if (date[13]!=':') {
        return FALSE;
    }

    /* Minute parsing */
    if (!ISDIGIT(date[14]) || !ISDIGIT(date[15])) {
        return FALSE;
    }
    num = (date[14]-'0')*10 + (date[15]-'0');
    if (num>59) {
        return FALSE;
    }
    if (date[16]!=':') {
        return FALSE;
    }

    /* Second parsing */
    if (!ISDIGIT(date[17]) || !ISDIGIT(date[18])) {
        return FALSE;
        return FALSE;
    }
    num = (date[17]-'0')*10 + (date[18]-'0');
    if (num>59) {
        return FALSE;
    }
    
    /* Timezone parsing */
    if (date[19]!='+' && date[19]!='-') {
        return FALSE;
    }
    /* HH parsing */
    if (!ISDIGIT(date[20]) || !ISDIGIT(date[21])) {
        return FALSE;
    }
    num = (date[20]-'0')*10 + (date[21]-'0');
    if (num>23) {
        return FALSE;
    }
    /* MM parsing */
    if (!ISDIGIT(date[22]) || !ISDIGIT(date[23])) {
        return FALSE;
    }
    num = (date[22]-'0')*10 + (date[23]-'0');
    if (num>59) {
        return FALSE;
    }

    return TRUE;
}

