#include "upnp_helper.h"

/* two sets, one for dx commands another for leasetime implementation thread */
struct UPNPDev *devlist[2];
char lanaddr[2][64];   
struct UPNPUrls urls[2];
struct IGDdatas data[2];

struct PortForwardList {
    int inPort;
    int exPort;
    int leaseDuration;
    time_t leaseTime;
    struct PortForwardList *next;
};

struct PortForwardList *fwdList = NULL;
Mutex fwdListMutex;
Thread fwdingThread;
int fwdingStop = 0;

/**********  PRIVATE FUNCTIONS  **********/

static int
initUPnPEnv(
    IN int setID
    );

static void
deleteUPnPEnv(
    IN int setID
    );

static int
deletePortForwardingInternal(
    IN int exPort,
    IN int id
    );

static void *
deletor(
    IN void *data
    );

/****************************************/

void
initUPnPService()
{
    initMutex(&fwdListMutex);
    initThread(deletor, NULL, &fwdingThread);
}

void
deleteUPnPService()
{
    struct PortForwardList *nextNode = NULL;
    fwdingStop = 1;
    lockMutex(&fwdListMutex);
    nextNode = fwdList;
    while (nextNode) {
        struct PortForwardList *curNode = nextNode;
        nextNode = nextNode->next;
        deletePortForwardingInternal(curNode->exPort, 1);
        free(curNode);
    }

    fwdList = NULL;
    unlockMutex(&fwdListMutex);

    waitForThreadExit(&fwdingThread);
    deleteMutex(&fwdListMutex);
}

int
initUPnPEnv(
    IN int setID
    )
{
    int retCode;

    devlist[setID] = upnpDiscover(2000, NULL, NULL, 0);
    if (NULL == devlist[setID]) {
        /* if no UPnP device found on the network */
        return UPnP_ERROR_NO_ROUTER_SUPPORT;
    }

    retCode = UPNP_GetValidIGD(devlist[setID], &urls[setID], &data[setID], lanaddr[setID], sizeof(lanaddr[setID]));
    if (0 == retCode) {
        /* if no IGD device found on the network */    
        freeUPNPDevlist(devlist[setID]);
        devlist[setID] = NULL;
        return UPnP_ERROR_NO_ROUTER_SUPPORT;
    }

    return UPnP_E_OK;
}

void
deleteUPnPEnv(
    IN int setID
    )
{
    FreeUPNPUrls(&urls[setID]);
    freeUPNPDevlist(devlist[setID]);
    devlist[setID] = NULL;
}

void *
deletor(
    IN void *data
    )
{
    while (!fwdingStop) {
        time_t curtime = time(NULL);
        struct PortForwardList *prevNode = NULL;
        struct PortForwardList *fwdNode = NULL;
        lockMutex(&fwdListMutex);
        fwdNode = fwdList;
        while (fwdNode) {
            /* Remember: 0 lease duration means infinite retention */
            if ((0 != fwdNode->leaseDuration) &&
                ((fwdNode->leaseTime + fwdNode->leaseDuration) < curtime)) {
                struct PortForwardList *curNode = fwdNode;

                deletePortForwardingInternal(curNode->exPort, 1);
                if (prevNode) {
                    prevNode->next = curNode->next;
                } else {
                    fwdList = curNode->next;
                }
                fwdNode = fwdNode->next;
                free(curNode);
            } else {
                prevNode = fwdNode;
                fwdNode = fwdNode->next;
            }
        }
        unlockMutex(&fwdListMutex);
        osSleep(60);
    }

    return NULL;
}

int
addPortForwarding(
    IN int inPort,
    IN int leaseDuration,
    IN char *description,
    OUT char *exIPaddr,
    OUT int *exPort
    )
{
    int retCode;
    int retries;
    char intClient[16];
    char s_inPort[8];
    char s_exPort[8];
    char s_leaseDuration[8] = {'0', '\0'};
    UINT32 randomPort;
    struct PortForwardList *fwdNode = NULL;

    /* find UPnP IGD device on the network */
    retCode = initUPnPEnv(0);
    if (UPnP_E_OK != retCode) {
        return retCode;
    }

    /* get the external IP address of the IGD device */
    retCode = UPNP_GetExternalIPAddress(urls[0].controlURL, data[0].first.servicetype, exIPaddr);
    if (UPnP_E_OK != retCode) {
        retCode = UPnP_ERROR_ROUTER_REFUSED;
        goto CLEANUP;
    }

    /*
     * Check if this request is for already opened port.
     * In that case just refersh the port forwarding request
     * with new lease duration time.
     */

    lockMutex(&fwdListMutex);
    fwdNode = fwdList;
    while (fwdNode != NULL) {
        if (fwdNode->inPort == inPort) {
            fwdNode->leaseTime = time(NULL);
            fwdNode->leaseDuration = leaseDuration;
            if(exPort) {
                *exPort = fwdNode->exPort;
            }
            unlockMutex(&fwdListMutex);
            retCode = UPnP_E_OK;
            goto CLEANUP;
        }
        fwdNode = fwdNode->next;
    }
    unlockMutex(&fwdListMutex);

    retCode = snprintf (s_inPort, 8, "%d", inPort);
    assert (retCode > 0);

    for (retries=0; retries<UPnP_PORT_FORWARDING_MAX_RETRIES; retries++) {
        /* generate a random external port within range */
        randomPort = UPnP_MIN_EXTERNAL_PORT + 
                     (random32Simple() % (UPnP_MAX_EXTERNAL_PORT - UPnP_MIN_EXTERNAL_PORT + 1));
        retCode = snprintf (s_exPort, 8, "%u", randomPort);
        assert (retCode > 0);

        /* do the UPnP port forwarding */
        /* always set lease duration to "0" -> infinite */
        /* closing of port after timeout is done by deletor thread */
        retCode = UPNP_AddPortMapping(urls[0].controlURL, data[0].first.servicetype,
                                      s_exPort, s_inPort, lanaddr[0], description, 
                                      "TCP", NULL, s_leaseDuration); 
        if (UPNPCOMMAND_SUCCESS != retCode) {
            retCode = UPnP_ERROR_ROUTER_REFUSED;
            continue;
        }

        /* check if the port forwarding is done */
        retCode = UPNP_GetSpecificPortMappingEntry(urls[0].controlURL, data[0].first.servicetype,
                                                   s_exPort, "TCP", intClient, s_inPort);
        if (UPNPCOMMAND_SUCCESS != retCode) {
            retCode = UPnP_ERROR_ROUTER_REFUSED;
            continue;
        } else {
            /* done port forwarding */
            retCode = UPnP_E_OK;
            *exPort = randomPort;
            break;
        }
    }

    /* Add the port forwarding info to global list */

    if (UPnP_E_OK == retCode) {
        fwdNode = (struct PortForwardList *) calloc(1, sizeof(struct PortForwardList));
        assert(fwdNode != NULL);
        fwdNode->inPort = inPort;
        fwdNode->exPort = *exPort;
        fwdNode->leaseTime = time(NULL);
        fwdNode->leaseDuration = leaseDuration;
        fwdNode->next = fwdList;
        lockMutex(&fwdListMutex);
        fwdList = fwdNode;
        unlockMutex(&fwdListMutex);
    }

CLEANUP:
    deleteUPnPEnv(0);
    return retCode;
}

int
deletePortForwardingInternal(
    IN int exPort,
    IN int id
    )
{
    int retCode;
    char s_exPort[8];
    retCode = snprintf (s_exPort, 8, "%d", exPort);
    assert (retCode > 0);

    /* find UPnP IGD device on the network */
    retCode = initUPnPEnv(id);
    if (UPnP_E_OK != retCode) {
        return retCode;
    }

    /* delete port forwarding */
    retCode = UPNP_DeletePortMapping(urls[id].controlURL, data[id].first.servicetype, s_exPort, "TCP", 0);

    deleteUPnPEnv(id);
    return retCode;
}

int
deletePortForwarding(
    IN int exPort
    )
{
    int retCode;
    struct PortForwardList *prevNode = NULL;
    struct PortForwardList *fwdNode = NULL;

    retCode = deletePortForwardingInternal(exPort, 0);

    lockMutex(&fwdListMutex);
    fwdNode = fwdList;
    while (fwdNode != NULL) {
        if (fwdNode->exPort == exPort) {
            break;
        }
        prevNode = fwdNode;
        fwdNode = fwdNode->next;
    }

    if (fwdNode == NULL) {
        unlockMutex(&fwdListMutex);
        return UPnP_E_OK;
    }

    if (fwdNode == fwdList) {
        fwdList = fwdNode->next;
    } else if (prevNode != NULL) {
        prevNode->next = fwdNode->next;
    }

    free(fwdNode);
    unlockMutex(&fwdListMutex);

    return retCode;
}

void
displayPortForwardingLease()
{
    struct PortForwardList *fwdNode = NULL;
    lockMutex(&fwdListMutex);
    fwdNode = fwdList;
    while (fwdNode != NULL) {
        printf ("inPort = %d exPort = %d leaseDuration = %d\n",
                fwdNode->inPort, fwdNode->exPort, fwdNode->leaseDuration);

        fwdNode = fwdNode->next;
    }
    unlockMutex(&fwdListMutex);
}

