#include "ovrc_pub.h"

void
appCallback(
    IN void *buffer, 
    IN size_t size
    )
{
    static int fd = -1;

    if (-1 == fd) {
        fd = osFileCreate("download_file.bin");
        assert (fd != -1);
    }
    
    if (NULL == buffer) {
        osFileClose(fd);
        return;
    }
    osFileWrite(fd, buffer, size);
}

int main (int argc, char **argv)
{
    BOOL ret;

    if (argc != 2) {
        printf ("Usage: %s download_url\n", argv[0]);
        exit(1);
    }

    ret = ftpDownloader(argv[1], appCallback);
    if (TRUE == ret) {
        printf ("Downloading %s completed.\n", argv[1]);
    } else {
        printf ("Downloading %s failed.\n", argv[1]);
    }

    return 0;
}
