#include "status_frequency.h"

/* Single object for the status update frequency handler */
statusFrequency freqHandler;

void
initStatusFrequencyHandler()
{
    initSemaphore(&(freqHandler.statusSem), 1);
    /* set default frequency, 60 seconds */
    freqHandler.frequency = 60;
}

void
deleteStatusFrequencyHandler()
{
    deleteSemaphore(&(freqHandler.statusSem));
}

INT32
getStatusUpdateFrequency()
{
    INT32 frequency;

    waitSemaphore(&(freqHandler.statusSem));
        frequency = freqHandler.frequency;
    postSemaphore(&(freqHandler.statusSem));

    return frequency;
}

void
setStatusUpdateFrequency(
    INT32 frequency
    )
{
    waitSemaphore(&(freqHandler.statusSem));
        freqHandler.frequency = frequency;
    postSemaphore(&(freqHandler.statusSem));
}

