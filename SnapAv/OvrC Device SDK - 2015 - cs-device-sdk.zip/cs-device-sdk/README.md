cs-hub
======

C library which communicates with device server.

