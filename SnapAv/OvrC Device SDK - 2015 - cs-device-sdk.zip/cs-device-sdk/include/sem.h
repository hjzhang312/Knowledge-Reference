#ifndef SEMAPHORE_H
#define SEMAPHORE_H

void
initSemaphore(
    IN Semaphore *pSemaphore,
    IN UINT32 initialValue
    );

void
deleteSemaphore(    		
    IN Semaphore *pSemaphore
    );

void
waitSemaphore(
    IN Semaphore *pSemaphore
    );

BOOL
trywaitSemaphore(
    IN Semaphore *pSemaphore
    );

void
postSemaphore(
    IN Semaphore *pSemaphore
    );


#endif //SEMAPHORE_H
