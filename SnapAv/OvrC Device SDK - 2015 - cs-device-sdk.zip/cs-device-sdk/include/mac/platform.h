#ifndef PLATFORM_H
#define PLATFORM_H

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <semaphore.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdlib.h>
#include <signal.h>
#include <netdb.h>
#include <time.h>
#include <assert.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/tcp.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <openssl/evp.h>
#include <arpa/inet.h>

#define IN
#define OUT

#define TRUE  (1)
#define FALSE (0)
#define SOCKET_ERROR (-1)
#define INVALID_SOCKET -1
#define SSL_ERROR -1
#define SOCKET_EINTR EINTR
#define ISO_DATE_FORMAT "%FT%T%z"

/* typedef for basic data types */

typedef unsigned char BYTE;
typedef int BOOL;
typedef unsigned short USHORT;
typedef unsigned long ULONG;
typedef u_int16_t UINT16;
typedef __int32_t INT32;
typedef u_int32_t UINT32;
typedef __int64_t INT64;
typedef u_int64_t UINT64;

/* typedef for system internal data types */

typedef int Socket;
typedef pthread_mutex_t Mutex;
typedef struct mac_sem_t 
{
    sem_t *sem;
    char *name;
}Semaphore;
typedef pthread_t Thread;

typedef int SocketError;

#endif //PLATFORM_H
