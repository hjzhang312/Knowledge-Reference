#ifndef PLATFORM_H
#define PLATFORM_H

#define IN
#define OUT
#define OPT

#ifndef TRUE
#define TRUE (1)
#endif

#ifndef FALSE
#define FALSE (0)
#endif

#pragma comment(lib, "ws2_32.lib") 
#include <winsock2.h>
#include <Ws2tcpip.h>
#include <assert.h>
#include <direct.h>
#include <fcntl.h>    
#include <io.h>
#include <stdlib.h>
#include <stdio.h>
#include <share.h>
#include <sys/stat.h>
#include <tchar.h>
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <openssl/evp.h>

#define SSL_ERROR -1
#define snprintf _snprintf
#define strncasecmp _strnicmp
#define SOCKET_EINTR WSAEINTR
#define ISO_DATE_FORMAT "%Y-%m-%dT%X"

/* typedef for basic data types */

typedef unsigned char BYTE;
typedef unsigned __int64 u_int64_t;

/* typedef for system internal data types */
typedef SOCKET Socket;
typedef CRITICAL_SECTION Mutex;
typedef struct win_sem_t
{
    HANDLE hSemHandle;
}Semaphore;
typedef struct win_thread_t
{
    HANDLE hThreadHandle;
    DWORD dwThreadID;
}Thread;

typedef int SocketError;

#endif //PLATFORM_H
