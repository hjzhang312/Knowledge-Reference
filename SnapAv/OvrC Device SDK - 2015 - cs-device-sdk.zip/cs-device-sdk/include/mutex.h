#ifndef MUTEX_H
#define MUTEX_H

void
initMutex(
    IN Mutex *pMutex
    );

void
deleteMutex(
    IN Mutex *pMutex
    );

void
lockMutex(
    IN Mutex *pMutex
    );

void
unlockMutex(
    IN Mutex *pMutex
    );


#endif // MUTEX_H
