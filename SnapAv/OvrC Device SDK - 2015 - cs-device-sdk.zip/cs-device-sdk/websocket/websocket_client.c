/*
 * Websocket client library.
 * Author: Ashish G. Khurange
 *         ashish.khurange@mindstix.com
 */

#include "websocket_client.h"

/*********** PRIVATE FUNCTION DECLARATIONS ***********/

/* Websocket management functions */

static INT32
readWebSocket(
    IN WEBSOCKET *wbsConnection,
    OUT BYTE *buffer,
    IN INT32 length
    );

static INT32
writeWebSocket(
    IN WEBSOCKET *wbsConnection,
    IN BYTE *buffer,
    IN INT32 length
    );

static BOOL
sendClientHandshake(
    IN WEBSOCKET *wbsConnection
    );

static BOOL
getServerHandshake(
    IN WEBSOCKET *wbsConnection
    );

static BOOL
verifyServerResponse(
    IN WEBSOCKET *wbsConnection,
    IN char *acceptKey
    );


/*********** END OF PRIVATE FUNCTION DECLARATIONS ***********/

char clientHandshake[1024];

/***** Websocket management functions *****/

WEBSOCKET *
initWebsocketConnection(
    IN const char *url,
    IN const char *origin,
    IN wbsExtraInfo extraInfo
    )
{
    WEBSOCKET *wbsConnection = NULL;
    BOOL ret;

    wbsConnection = (WEBSOCKET *) malloc(sizeof(WEBSOCKET));
    assert (NULL != wbsConnection);
    if (NULL == wbsConnection) {
        return NULL;
    };

    wbsConnection->fdSocket = INVALID_SOCKET;
    wbsConnection->connectionState = WBS_STATE_INVALID;

    initMutex(&(wbsConnection->readerMutex));
    initMutex(&(wbsConnection->writerMutex));

    wbsConnection->isSSL = FALSE;

    /* non secured web socket address */
    if (sscanf(url, "ws://%[^:/]:%d/%s", wbsConnection->host, &wbsConnection->port, wbsConnection->path) == 3) {
    }
    else if (sscanf(url, "ws://%[^:/]/%s", wbsConnection->host, wbsConnection->path) == 2) {
        wbsConnection->port = 80;
    }
    else if (sscanf(url, "ws://%[^:/]:%d", wbsConnection->host, &wbsConnection->port) == 2) {
        wbsConnection->path[0] = '\0';
    }
    else if (sscanf(url, "ws://%[^:/]", wbsConnection->host) == 1) {
        wbsConnection->port = 80;
        wbsConnection->path[0] = '\0';
    }
    /* secured web socket address */
    else if (sscanf(url, "wss://%[^:/]:%d/%s", wbsConnection->host, &wbsConnection->port, wbsConnection->path) == 3) {
    }
    else if (sscanf(url, "wss://%[^:/]/%s", wbsConnection->host, wbsConnection->path) == 2) {
        wbsConnection->port = 443;
    }
    else if (sscanf(url, "wss://%[^:/]:%d", wbsConnection->host, &wbsConnection->port) == 2) {
        wbsConnection->path[0] = '\0';
    }
    else if (sscanf(url, "wss://%[^:/]", wbsConnection->host) == 1) {
        wbsConnection->port = 443;
        wbsConnection->path[0] = '\0';
    }
    /* invalid url entered */
    else {
        goto EXIT;
    }

    /* check if the communication with server requires SSL */
    if (strncasecmp(url, "wss", 3)==0) {
        wbsConnection->isSSL = TRUE;
        /* initialize ssl channel */
        initSslSocket(&(wbsConnection->sslChannel));
    }

    strncpy(wbsConnection->origin, origin, URL_SIZE);
    wbsConnection->extraInfo = extraInfo;
    return wbsConnection;

EXIT:
    deleteWebsocketConnection(wbsConnection);
    return NULL;
}

void
deleteWebsocketConnection(
    IN WEBSOCKET *wbsConnection
    )
{
    if (NULL == wbsConnection) {
        return;
    }
    /* if the websocket is connected send the close frame to peer & close connection */
    if (WBS_STATE_CONNECTED == wbsConnection->connectionState) {
        /* disable the close callback as this is hard close intended by application */
        wbsConnection->extraInfo.closeCallback = NULL;
        closeWebsocket(wbsConnection);
    }
    deleteMutex(&(wbsConnection->writerMutex));
    deleteMutex(&(wbsConnection->readerMutex));
    if (wbsConnection->isSSL) {
        deleteSslSocket(&(wbsConnection->sslChannel));
    }
    free(wbsConnection);
    wbsConnection = NULL;
}

BOOL
connectWebSocket(
    IN WEBSOCKET *wbsConnection
    )
{
    BOOL ret;

    wbsConnection->fdSocket = connectSocket(wbsConnection->host, wbsConnection->port);
    if (INVALID_SOCKET == wbsConnection->fdSocket) {
        return FALSE;
    }

    wbsConnection->connectionState = WBS_STATE_CONNECTED;
    /* setup the TLS communication with server using openSSL */
    if (TRUE == wbsConnection->isSSL) {
        ret = connectSslSocket(&(wbsConnection->sslChannel), wbsConnection->fdSocket);
        if (FALSE == ret) {
            closeSslSocket(&(wbsConnection->sslChannel));
            return FALSE;
        }
    }

    /* set a seed based on current time to random number generator */
    random32Seed(time(NULL)%874563);

    /* send websocket client handshake */
    ret = sendClientHandshake(wbsConnection);
    if (FALSE == ret) {
        return FALSE;
    }

    /* recieve & verify websocket server handshake */
    ret = getServerHandshake(wbsConnection);
    if (FALSE == ret) {
        return FALSE;
    }

    return TRUE;
}

INT32
readWebSocket(
    IN WEBSOCKET *wbsConnection,
    OUT BYTE *buffer,
    IN INT32 length
    )
{
    if (INVALID_SOCKET == wbsConnection->fdSocket) {
        return -1;
    }
    if (TRUE == wbsConnection->isSSL) {
        return readSslSocket(&(wbsConnection->sslChannel), buffer, length);
    }
    else {
        return readSocket(wbsConnection->fdSocket, buffer, length);
    }
}

INT32
writeWebSocket(
    IN WEBSOCKET *wbsConnection,
    IN BYTE *buffer,
    IN INT32 length
    )
{
    if (INVALID_SOCKET == wbsConnection->fdSocket) {
        return -1;
    }
    if (TRUE == wbsConnection->isSSL) {
        return writeSslSocket(&(wbsConnection->sslChannel), buffer, length);
    }
    else {
        return writeSocket(wbsConnection->fdSocket, buffer, length);
    }
}

/*
 * The expected client handshake format is as below:
 * 
    GET / HTTP/1.1
    Host: localhost:3001
    Upgrade: websocket
    Connection: Upgrade
    Sec-WebSocket-Key: <any base64-encoded value>
    Sec-WebSocket-Protocol: ovrc-protocol
    Sec-WebSocket-Version: 13
    Origin: <WattBox MAC address>
 */

BOOL
sendClientHandshake(
    IN WEBSOCKET *wbsConnection
    )
{
    char keyBase64[64];
    char line[256];
    int i;

    snprintf(line, 256, "GET /%s HTTP/1.1\r\n", wbsConnection->path);
    strcpy (clientHandshake, line);

    if (wbsConnection->port == 80) {
        snprintf(line, 256, "Host: %s\r\n",wbsConnection->host); 
    } else {
        snprintf(line, 256, "Host: %s:%d\r\n", wbsConnection->host, wbsConnection->port); 
    }
    strcat (clientHandshake, line);

    snprintf(line, 256, "Upgrade: websocket\r\n"); 
    strcat (clientHandshake, line);

    snprintf(line, 256, "Connection: Upgrade\r\n"); 
    strcat (clientHandshake, line);

    /* generate 16 byte random buffer */
    for (i=0; i<16; i++) {
        wbsConnection->nonce[i] = (BYTE) (random32Simple() & 0XFF);
    }
    /* generate 64 bit encoding of random buffer */
    i = base64EncodeString((const char *)wbsConnection->nonce, 16, keyBase64, sizeof(keyBase64));
    assert (-1 != i);
    snprintf(line, 256, "Sec-WebSocket-Key: %s\r\n", keyBase64); 
    strcat (clientHandshake, line);

    snprintf(line, 256, "Sec-WebSocket-Protocol: ovrc-protocol\r\n"); 
    strcat (clientHandshake, line);

    snprintf(line, 256, "Sec-WebSocket-Version: 13\r\n"); 
    strcat (clientHandshake, line);

    snprintf(line, 256, "Origin: %s\r\n", wbsConnection->origin); 
    strcat (clientHandshake, line);

    /* Mark the end of hand shake. */
    snprintf(line, 256, "\r\n"); 
    strcat (clientHandshake, line);
//    printf ("%s\n", clientHandshake);

    if (writeWebSocket(wbsConnection, (BYTE *)clientHandshake, strlen(clientHandshake)) == -1) {
        return FALSE;
    }

//    printf ("Sent client handshake.\n");
    return TRUE;
}

BOOL
getServerHandshake(
    IN WEBSOCKET *wbsConnection
    )
{
    char line[256];
    int i;
    int status;
    BOOL ret;

    for (i = 0; i < 2 || (i < 255 && line[i-2] != '\r' && line[i-1] != '\n'); ++i) { 
        if (readWebSocket(wbsConnection, (BYTE *)line+i, 1) == -1) { 
            return FALSE; 
        } 
    }
    if (i == 255) { 
//        fprintf(stderr, "ERROR: Got invalid status line connecting to\n"); 
        return FALSE; 
    }
    line[i] = 0;
//    printf ("%s\n", line);
    if (sscanf(line, "HTTP/1.1 %d", &status) != 1 || status != 101) { 
//        fprintf(stderr, "ERROR: Got bad status connecting to  %s", line); 
        return FALSE; 
    }
    
    while (TRUE) {
        for (i = 0; i < 2 || (i < 255 && line[i-2] != '\r' && line[i-1] != '\n'); ++i) { 
            if (readWebSocket(wbsConnection, (BYTE *)line+i, 1) == -1) { 
                return FALSE; 
            }
        }
        line[i] = 0;
//        printf ("%s", line);
        if (strncmp(line, "Sec-WebSocket-Accept:", strlen("Sec-WebSocket-Accept:")) == 0) {
            ret = verifyServerResponse(wbsConnection, line);
            if (FALSE==ret) {
                return ret;
            }
        }
        /* Only CRLF marks the end of response HTTP header. */
        if (line[0] == '\r' && line[1] == '\n') {
             break; 
        }
    }
    return TRUE;
}

BOOL
verifyServerResponse(
    IN WEBSOCKET *wbsConnection,
    IN char *acceptKey
    )
{
    char acceptKeyHeader[] = "Sec-WebSocket-Accept: ";
    char *serverKey = NULL;
    int keyLen;
    int ret;
    char keyBase64[64];
    char buf[128];
    char shaKey[20];

    serverKey = acceptKey + strlen(acceptKeyHeader);
    /* get rid of CRLF chars at the end */
    keyLen = strlen(serverKey);
    serverKey[keyLen-2] = '\0';

    /* 
     * generate 64 bit encoding of random buffer selected by client.
     * this was the original key sent at the time of cleint hanshake.
     */
    ret = base64EncodeString((const char *)wbsConnection->nonce, 16, keyBase64, sizeof(keyBase64));
    assert (-1 != ret);
    
    /* try same things the server is supposed to do on this key and generate the output to match */
    /* 1. append the server's predefined key to base 64 key */
    ret = sprintf (buf, "%s258EAFA5-E914-47DA-95CA-C5AB0DC85B11", keyBase64);
    /* 2. generate the sha-1 hash of this concatenated string */
    SHA1((unsigned char *)buf, ret, (unsigned char *)shaKey);
    /* 3. generate the base 64 encoding of this sha hash */
    ret = base64EncodeString((const char *)shaKey, 20, keyBase64, sizeof(keyBase64));
    assert (-1 != ret);
    /* now the keyBase64 is the key that server has sent us as accept key */
    /* match the two keys: sent by the server and the key we computed */
    if (strcmp(serverKey, keyBase64) == 0) {
        return TRUE;
    }

    return FALSE;
}

/*
 * The websocket uses following data frame format for the communication:
 * http://tools.ietf.org/html/rfc6455#section-5.2
 *
      0                   1                   2                   3
      0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
     +-+-+-+-+-------+-+-------------+-------------------------------+
     |F|R|R|R| opcode|M| Payload len |    Extended payload length    |
     |I|S|S|S|  (4)  |A|     (7)     |             (16/64)           |
     |N|V|V|V|       |S|             |   (if payload len==126/127)   |
     | |1|2|3|       |K|             |                               |
     +-+-+-+-+-------+-+-------------+ - - - - - - - - - - - - - - - +
     |     Extended payload length continued, if payload len == 127  |
     + - - - - - - - - - - - - - - - +-------------------------------+
     |                               |Masking-key, if MASK set to 1  |
     +-------------------------------+-------------------------------+
     | Masking-key (continued)       |          Payload Data         |
     +-------------------------------- - - - - - - - - - - - - - - - +
     :                     Payload Data continued ...                :
     + - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - +
     |                     Payload Data continued ...                |
     +---------------------------------------------------------------+

 */

int
readWebsocketFrame(
    IN WEBSOCKET *wbsConnection,
    IN BYTE *buffer,
    IN UINT32 bufferLength
    )
{
    BYTE finFlag;
    BYTE rsvInfo;
    BYTE opcode;
    BYTE maskFlag;
    BYTE payloadLen;
    UINT64 exactPayloadLen;
    BYTE maskKey[4];
    INT32 extHeaderLen;
    INT32 maskOffset;
    BYTE wbsHeader[12];
    int ret;
    int i;

    /* acquire reader lock */
    lockMutex(&wbsConnection->readerMutex);

    if (INVALID_SOCKET == wbsConnection->fdSocket) {
        /* release reader lock */
        unlockMutex(&wbsConnection->readerMutex);
        return -1;
    }

    while (TRUE) {
        /* 
         * The minimal required length of the websocket header is 2 bytes.
         * Read first these 2 bytes, these 2 bytes will give us the complete
         * information about the exact size of websocket header & payload data.
         */

        ret = readWebSocket(wbsConnection, wbsHeader, 2);
        if (2 != ret) {
            closeWebsocket(wbsConnection);
            /* release reader lock */
            unlockMutex(&wbsConnection->readerMutex);
            return -1;
        }
        finFlag = (wbsHeader[0] & 0X80 ? TRUE : FALSE);
        rsvInfo = wbsHeader[0] & 0X70;
        /* rsv is non zero only if extension is negotiated */
        if (0 != rsvInfo) {
            /* TODO: decide to throw error */
        }
        opcode = wbsHeader[0] & 0X0F;
        maskFlag = (wbsHeader[1] & 0X80 ? TRUE : FALSE);
        payloadLen = wbsHeader[1] & 0X7F;

        /* 
         * Based on payload length value & mask bit, decide how many extra bytes
         * we need to read to completely read the websocket header.
         * If payload length is 0-125, it is stored in 7 bits only.
         * If payload length is 126, it is stored in 2 bytes.
         * If payload length is 127, it is stored in 8 bytes.
         * If mask flag is on, mask key is stored in 4 bytes.
         */
        extHeaderLen = (payloadLen == 126? 2 : 0) + (payloadLen == 127? 8 : 0) + (maskFlag? 4 : 0);
        if (extHeaderLen) {
            ret = readWebSocket(wbsConnection, wbsHeader, extHeaderLen);
            if (extHeaderLen != ret) {
                closeWebsocket(wbsConnection);
                /* release reader lock */
                unlockMutex(&wbsConnection->readerMutex);
                return -1;
            }
        }
        
        /*
         * Calculate exact payload length for this websocket header.
         * Fill the mask key if the mask flag is on.
         */
        exactPayloadLen = 0;

        if (payloadLen < 126) {
            exactPayloadLen = payloadLen;
            maskOffset = 0;
        } else if (126 == payloadLen) {
            exactPayloadLen |= ((UINT64) wbsHeader[0]) <<  8;
            exactPayloadLen |= ((UINT64) wbsHeader[1]) <<  0;
            maskOffset = 2;
        } else if (127 == payloadLen) {
            exactPayloadLen |= ((UINT64) wbsHeader[7]) <<  56;
            exactPayloadLen |= ((UINT64) wbsHeader[6]) <<  48;
            exactPayloadLen |= ((UINT64) wbsHeader[5]) <<  40;
            exactPayloadLen |= ((UINT64) wbsHeader[4]) <<  32;
            exactPayloadLen |= ((UINT64) wbsHeader[3]) <<  24;
            exactPayloadLen |= ((UINT64) wbsHeader[2]) <<  16;
            exactPayloadLen |= ((UINT64) wbsHeader[1]) <<  8;
            exactPayloadLen |= ((UINT64) wbsHeader[0]) <<  0;
            maskOffset = 8;
        }
        /* read the mask key */
        if (maskFlag) {
            maskKey[0] = wbsHeader[maskOffset+0];
            maskKey[1] = wbsHeader[maskOffset+1];
            maskKey[2] = wbsHeader[maskOffset+2];
            maskKey[3] = wbsHeader[maskOffset+3];
        }

        /* read the payload data from the websocket data frame */
        /* TODO: check buffer has exactPayloadLen length */
        if (bufferLength < exactPayloadLen) {
            closeWebsocket(wbsConnection);
            /* release reader lock */
            unlockMutex(&wbsConnection->readerMutex);
            return -1;
        }
        ret = readWebSocket(wbsConnection, buffer, exactPayloadLen);
        if (exactPayloadLen != ret) {
            closeWebsocket(wbsConnection);
            /* release reader lock */
            unlockMutex(&wbsConnection->readerMutex);
            return -1;
        }

        /*
         * Entire websocket frame is read. Now take the appropriate 
         * decision based on the type of the the frame i.e. the opcode.
         */
        if ((WEBSOCKET_FRAME_TEXT == opcode) || (WEBSOCKET_FRAME_BINARY == opcode)) {
            /* currently we do not support frame fragmentation */
            if (TRUE != finFlag) {
                closeWebsocket(wbsConnection);
                /* release reader lock */
                unlockMutex(&wbsConnection->readerMutex);
                return -1;
            }
            /*
             * If mask flag is set. Unmask the payload data. For detail algo check:
             * http://tools.ietf.org/html/rfc6455#section-5.2  Base Framing Protocol
             */
            if (maskFlag) {
                for (i=0; i<exactPayloadLen; i++) {
                    buffer[i] ^= maskKey[i&0X3];
                }
            }
            /* release reader lock */
            unlockMutex(&wbsConnection->readerMutex);
            return (int)exactPayloadLen;
        } else if (WEBSOCKET_FRAME_PING == opcode) {
//            printf ("Received PING frame.\n");
            /*
             * For the PING control frame respond with PONG control frame.
             * Keep the original payload data intact in the PONG reply.
             */
            if (maskFlag) {
                for (i=0; i<exactPayloadLen; i++) {
                    buffer[i] ^= maskKey[i&0X3];
                }
            }
            /* send the PONG frame with same payload data */
            ret = writeWebsocketFrame(wbsConnection, WEBSOCKET_FRAME_PONG, buffer, exactPayloadLen);
            if (ret != exactPayloadLen) {
                closeWebsocket(wbsConnection);
                /* release reader lock */
                unlockMutex(&wbsConnection->readerMutex);
                return -1;
            }
//            printf ("Sent PONG frame.\n");
            /* check if ping callback is set, if set give the callback */
            if (NULL != wbsConnection->extraInfo.pingCallback) {
                (*wbsConnection->extraInfo.pingCallback)();
            }
        } else if (WEBSOCKET_FRAME_PONG == opcode) {
//            printf ("Received PONG frame.\n");
            /* for the PONG response do nothing */
        } else if (WEBSOCKET_FRAME_CLOSE == opcode) {
//            printf ("Received CLOSE frame.\n");
            closeWebsocket(wbsConnection);
            /* release reader lock */
            unlockMutex(&wbsConnection->readerMutex);
            return -1;
        }
    }
}

int
writeWebsocketFrame(
    IN WEBSOCKET *wbsConnection,
    IN BYTE frameType,
    IN BYTE *data,
    IN UINT32 dataLength
    )
{
    BYTE wbsHeader[12];
    BYTE maskKey[4];
    INT32 extHeaderLen;
    INT32 maskOffset;
    INT32 random32BitKey;
    int ret;
    int i;

    /* acquire writer lock */
    lockMutex(&wbsConnection->writerMutex);

    if (INVALID_SOCKET == wbsConnection->fdSocket) {
        /* release writer lock */
        unlockMutex(&wbsConnection->writerMutex);
        return -1;
    }

    extHeaderLen = 2 + (dataLength >= 126 ? 2 : 0) + (dataLength >= 65536 ? 6 : 0) + 4;

    memset (wbsHeader, 0, 12);

    /* set FIN & opcode in the first byte of header */
    wbsHeader[0] = 0X80 | frameType;
    /*
     * Every frame sent from client must be masked.
     * Set the mask flag ON in 2nd byte of header.
     */
    wbsHeader[1] = 0X80;

    /* set the payload length in the message header */
    if (dataLength < 126) {
        wbsHeader[1] |= dataLength;
        maskOffset = 2;
    } else if (dataLength < 65536) {
        wbsHeader[1] |= 126;
        wbsHeader[2] = (dataLength >> 8) & 0xff;
        wbsHeader[3] = (dataLength >> 0) & 0xff;
        maskOffset = 4;
    } else {
        UINT64 dataLength64 = (UINT64) dataLength;
        wbsHeader[1] |= 127;
        /* in this case most significant bit must be zero */
        wbsHeader[2] = (dataLength64 >> 56) & 0x7f;
        wbsHeader[3] = (dataLength64 >> 48) & 0xff;
        wbsHeader[4] = (dataLength64 >> 40) & 0xff;
        wbsHeader[5] = (dataLength64 >> 32) & 0xff;
        wbsHeader[6] = (dataLength64 >> 24) & 0xff;
        wbsHeader[7] = (dataLength64 >> 16) & 0xff;
        wbsHeader[8] = (dataLength64 >>  8) & 0xff;
        wbsHeader[9] = (dataLength64 >>  0) & 0xff;
        maskOffset = 10;
    }

    /* generate a random 32 bit key & save it as mask key */
    random32BitKey = random32Simple();
    maskKey[0] = (random32BitKey >> 24) & 0xff;
    maskKey[1] = (random32BitKey >> 16) & 0xff;
    maskKey[2] = (random32BitKey >>  8) & 0xff;
    maskKey[3] = (random32BitKey >>  0) & 0xff;

    /* set the mask key in the header */
    wbsHeader[maskOffset+0] = maskKey[0];
    wbsHeader[maskOffset+1] = maskKey[1];
    wbsHeader[maskOffset+2] = maskKey[2];
    wbsHeader[maskOffset+3] = maskKey[3];

    /* send the websocket header */
    ret = writeWebSocket(wbsConnection, wbsHeader, extHeaderLen);
    if (ret != extHeaderLen) {
        closeWebsocket(wbsConnection);
        /* release writer lock */
        unlockMutex(&wbsConnection->writerMutex);
        return -1;
    }

    /* mask the data to be sent */
    for (i=0; i<dataLength; i++) {
        data[i] ^= maskKey[i&0X3];
    }
    ret = writeWebSocket(wbsConnection, data, dataLength);
    if (ret != dataLength) {
        closeWebsocket(wbsConnection);
        /* release writer lock */
        unlockMutex(&wbsConnection->writerMutex);
        return -1;
    }

    /* release writer lock */
    unlockMutex(&wbsConnection->writerMutex);
    return dataLength;
}

BOOL
sendWebsocketPing(
    IN WEBSOCKET *wbsConnection
    )
{
    BYTE wbsHeader[6];
    INT32 random32BitKey;
    int ret;

    /* acquire writer lock */
    lockMutex(&wbsConnection->writerMutex);

    if (INVALID_SOCKET == wbsConnection->fdSocket) {
        unlockMutex(&wbsConnection->writerMutex);
        return FALSE;
    }

    /* in the first byte set FIN flag & close opcode */
    wbsHeader[0] = 0X80 | WEBSOCKET_FRAME_PING;
    /* in the second byte set mask flag ON & payload length zero */
    wbsHeader[1] = 0X80;
    /* generate a random 32 bit key & save it as mask key */
    random32BitKey = random32Simple();
    wbsHeader[2] = (random32BitKey >> 24) & 0xff;
    wbsHeader[3] = (random32BitKey >> 16) & 0xff;
    wbsHeader[4] = (random32BitKey >>  8) & 0xff;
    wbsHeader[5] = (random32BitKey >>  0) & 0xff;

    /* send this ping frame without any payload data */
    ret = writeWebSocket(wbsConnection, wbsHeader, 6);
    if (ret != 6) {
        closeWebsocket(wbsConnection);
        /* release writer lock */
        unlockMutex(&wbsConnection->writerMutex);
        return FALSE;
    }
//    printf ("Sent PING frame.\n");

    /* release writer lock */
    unlockMutex(&wbsConnection->writerMutex);
    return TRUE;
} 

void
closeWebsocket(
    IN WEBSOCKET *wbsConnection
    )
{
    BYTE wbsHeader[6];
    INT32 random32BitKey;

    /* acquire writer lock */
    lockMutex(&wbsConnection->writerMutex);

    if (INVALID_SOCKET == wbsConnection->fdSocket) {
        unlockMutex(&wbsConnection->writerMutex);
        return;
    }

    /* in the first byte set FIN flag & close opcode */
    wbsHeader[0] = 0X80 | WEBSOCKET_FRAME_CLOSE;
    /* in the second byte set mask flag ON & payload length zero */
    wbsHeader[1] = 0X80;
    /* generate a random 32 bit key & save it as mask key */
    random32BitKey = random32Simple();
    wbsHeader[2] = (random32BitKey >> 24) & 0xff;
    wbsHeader[3] = (random32BitKey >> 16) & 0xff;
    wbsHeader[4] = (random32BitKey >>  8) & 0xff;
    wbsHeader[5] = (random32BitKey >>  0) & 0xff;

    /* send this close frame without any payload data */
    writeWebSocket(wbsConnection, wbsHeader, 6);
//    printf ("Sent CLOSE frame.\n");
    if (TRUE == wbsConnection->isSSL) {
        closeSslSocket(&(wbsConnection->sslChannel));
    }
    closeSocket(wbsConnection->fdSocket);
    wbsConnection->fdSocket = INVALID_SOCKET;
    wbsConnection->connectionState = WBS_STATE_CLOSED;

    /* release writer lock */
    unlockMutex(&wbsConnection->writerMutex);

    /* check if close callback is set, if set give the callback */
    if (NULL != wbsConnection->extraInfo.closeCallback) {
        (*wbsConnection->extraInfo.closeCallback)();
    }
}

