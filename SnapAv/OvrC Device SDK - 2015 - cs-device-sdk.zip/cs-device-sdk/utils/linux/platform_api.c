#include "utils.h"
#define _XOPEN_SOURCE

void
osSleep(
    IN UINT32 seconds
    )
{
    sleep(seconds);
}

void
osHandleSIGPIPE()
{
    int ret;
    struct sigaction sa;

    /* 
     * There are chances that our application sends data to a closed socket.
     * This generates SIGPIPE signal, and results into process termination.
     * We must ignore this signal, as our application is equipped to handle
     * errors happening on socket writes.
     */

    sa.sa_handler = SIG_IGN;
    sa.sa_flags = 0;
    ret = sigaction(SIGPIPE, &sa, NULL);
    assert(-1 != ret);
}

int
osFileCreate(
    IN char *fileName
    )
{
    int fd;

    fd = open(fileName, O_CREAT|O_WRONLY, S_IRWXU);
    return fd;
}

int
osFileWrite(
    IN int fd,
    IN void *data,
    IN int size
    )
{
    int ret;

    ret = write(fd, data, size);
    return ret;
}

void
osFileClose(
    IN int fd
    )
{
    close(fd);
}

SocketError
osGetSocketError()
{
    return errno;
}
