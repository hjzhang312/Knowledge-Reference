#include "utils.h"

void
initThread(
    IN threadFunction functionAddress,
    IN void *parameter,
    OUT Thread *threadID
    )
{
    int ret;

    ret = pthread_create(threadID, NULL, functionAddress, parameter);
    assert(0 == ret);
}

void
waitForThreadExit(
    IN Thread *threadID
    )
{
    int ret;

    ret = pthread_join(*threadID, NULL);
    assert(0 == ret);
}

