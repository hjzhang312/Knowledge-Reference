#include "utils.h"

void
initSemaphore(
    IN Semaphore *pSemaphore,
    IN UINT32 initialValue
    )
{
    int ret;

    ret = sem_init(pSemaphore, 0, initialValue);
    assert (0 == ret);
}

void
deleteSemaphore(    		
    IN Semaphore *pSemaphore
    )
{
    int ret;

    ret = sem_destroy(pSemaphore);
    assert (0 == ret);
}

void
waitSemaphore(
    IN Semaphore *pSemaphore
    )
{
    int ret;

    ret = sem_wait(pSemaphore);
    assert (0 == ret);
}

BOOL
trywaitSemaphore(
    IN Semaphore *pSemaphore
    )
{
    int ret;

    ret = sem_trywait(pSemaphore);
    if (0 == ret) {
        return TRUE;
    }
    assert (errno == EAGAIN);
    return FALSE;    
}

void
postSemaphore(
    IN Semaphore *pSemaphore
    )
{
    int ret;

    ret = sem_post(pSemaphore);
    assert (0 == ret);
}

