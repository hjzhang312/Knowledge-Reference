#include "utils.h"

Socket
connectSocket(
    IN const char *hostAddr,
    IN INT32 port
    )
{
    struct addrinfo hints;
    struct addrinfo *result;
    struct addrinfo *p;
    int ret;
    Socket sockfd = INVALID_SOCKET;
    char sport[16];

    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    snprintf(sport, 16, "%d", port);
    if ((ret = getaddrinfo(hostAddr, sport, &hints, &result)) != 0) {
//      fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(ret));
      return INVALID_SOCKET;
    }
    for(p = result; p != NULL; p = p->ai_next) {
        sockfd = socket(p->ai_family, p->ai_socktype, p->ai_protocol);
        if (sockfd == INVALID_SOCKET) { continue; }
        if (connect(sockfd, p->ai_addr, p->ai_addrlen) != SOCKET_ERROR) {
//            printf ("Socket connection established.\n");
            break;
        }
        closeSocket(sockfd);
        sockfd = INVALID_SOCKET;
    }
    freeaddrinfo(result);

    if (INVALID_SOCKET != sockfd) {
        int optVal = 1;

        /* this is highly interactive system, tcp packet level buffering MUST be avoided */
        /* disable Nagle's algorithm */
        ret = setsockopt(sockfd, IPPROTO_TCP, TCP_NODELAY, (const void*) &optVal, sizeof(optVal));
        assert (-1 != ret);
        /* enable TCP keep alive */
        ret = setsockopt(sockfd, SOL_SOCKET, SO_KEEPALIVE, (const void*) &optVal, sizeof(optVal));
//        assert (-1 != ret);
    }

    return sockfd;
}

void
closeSocket(
    IN Socket fdSocket
    )
{
    if (INVALID_SOCKET == fdSocket) {
        return;
    }
    close(fdSocket);
}

INT32
readSocket(
    IN Socket fdSocket,
    OUT BYTE *buffer,
    IN INT32 length
    )
{
    INT32 totalRead;
    INT32 thisTimeRead;
    fd_set readSet;
    int result;
    struct timeval timeout;

    for (totalRead = 0; totalRead < length; ) {
        FD_ZERO(&readSet);
        FD_SET(fdSocket, &readSet);
        timeout.tv_sec= 40;
        timeout.tv_usec = 0;
        /* wait till there is data to be read on the socket or timeout happens */
        result = select(fdSocket+1, &readSet, NULL, NULL, &timeout);
        if (-1 == result) {
            if (EINTR == errno) {
                continue;
            }
            return -1;
        }
        /* check if timeout happened */
        if (0 == result) {
            return -1;
        }

        thisTimeRead = read(fdSocket, buffer+totalRead, length-totalRead);
        if (thisTimeRead < 0) {
            if (EINTR == errno) {
                continue;
            }
            return -1;
        } else if (0 == thisTimeRead) {
            /* EOF detected */
            break;
        }
        /* data is read from the socket, make the connection status active */
        totalRead += thisTimeRead;
    }

    return totalRead;
}

INT32
writeSocket(
    IN Socket fdSocket,
    IN BYTE *buffer,
    IN INT32 length
    )
{

    INT32 totalWrote;
    INT32 thisTimeWrote;

    for (totalWrote = 0; totalWrote < length; ) {
        thisTimeWrote = write (fdSocket, buffer+totalWrote, length-totalWrote);
        if (thisTimeWrote < 0) {
            if (EINTR == errno) {
                continue;
            }
            return -1;
        }
        totalWrote += thisTimeWrote;
    }

    return totalWrote;
}

void
setSocketNonBlocking(
    IN Socket fdSocket
    )
{
    int flags;
    int ret;

    flags = fcntl(fdSocket, F_GETFL, 0);
    assert(flags != -1);
    flags |= O_NONBLOCK;
    ret = fcntl(fdSocket, F_SETFL, flags);
    assert(ret != -1);
}

BOOL
isValidIPAddress(
    IN char *ipAddr
    )
{
    unsigned char buf[sizeof(struct in6_addr)];
    int ret;

    ret = inet_pton(AF_INET, ipAddr, buf);
    if (1 == ret) {
        return TRUE;
    }

    ret = inet_pton(AF_INET6, ipAddr, buf);
    if (1 == ret) {
        return TRUE;
    }
    return FALSE;
}

