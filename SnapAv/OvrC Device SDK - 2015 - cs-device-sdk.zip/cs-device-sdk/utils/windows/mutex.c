#include "utils.h"

void
initMutex(
    IN Mutex *pMutex
    )
{
    InitializeCriticalSection(pMutex);
}

void
deleteMutex(
    IN Mutex *pMutex
    )
{
    DeleteCriticalSection(pMutex);
}

void
lockMutex(
    IN Mutex *pMutex
    )
{
    EnterCriticalSection(pMutex);
}

void
unlockMutex(
    IN Mutex *pMutex
    )
{
    LeaveCriticalSection(pMutex);
}

