#include "utils.h"

typedef struct win_thread_data_t
{
    threadFunction functionAddress;
    void *parameter;
}pvtWinThreadData;

/* Private windows thread launcher function */

static DWORD WINAPI 
winThreadRunner(
    IN LPVOID lpData
    );

void
initThread(
    IN threadFunction functionAddress,
    IN void *parameter,
    OUT Thread *threadID
    )
{
    pvtWinThreadData *threadData = NULL;

    threadData = (pvtWinThreadData *) malloc (sizeof(pvtWinThreadData));
    assert (NULL != threadData);

    threadData->functionAddress = functionAddress;
    threadData->parameter = parameter;

    threadID->hThreadHandle = CreateThread(
                                            NULL,
                                            0,
                                            winThreadRunner,
                                            threadData,
                                            0,
                                            &(threadID->dwThreadID));

    assert (NULL != threadID->hThreadHandle);
}

DWORD WINAPI 
winThreadRunner(
    IN LPVOID lpData
    )
{
    pvtWinThreadData *threadData = (pvtWinThreadData *)lpData;

    threadData->functionAddress(threadData->parameter);
    free (lpData);
    return 0;
}

void
waitForThreadExit(
    IN Thread *threadID
    )
{
    DWORD ret;

    ret = WaitForSingleObject(threadID->hThreadHandle, INFINITE);
    assert(ret != WAIT_FAILED);
}

