#include "utils.h"

Socket
connectSocket(
    IN const char *hostAddr,
    IN INT32 port
    )
{
    struct addrinfo hints;
    struct addrinfo *result;
    struct addrinfo *p;
    int ret;
    Socket sockfd = INVALID_SOCKET;
    char sport[16];
    WSADATA wsaData;

    /* Initialize Winsock */
    ret = WSAStartup(MAKEWORD(2,2), &wsaData);
    if (ret != 0) {
        return SOCKET_ERROR;
    }

    ZeroMemory( &hints, sizeof(hints));
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    snprintf(sport, 16, "%d", port);
    if ((ret = getaddrinfo(hostAddr, sport, &hints, &result)) != 0) {
        WSACleanup();
        return SOCKET_ERROR;
    }
    for(p = result; p != NULL; p = p->ai_next) {
        sockfd = socket(p->ai_family, p->ai_socktype, p->ai_protocol);
        if (sockfd == INVALID_SOCKET) { continue; }
        if (connect(sockfd, p->ai_addr, p->ai_addrlen) != SOCKET_ERROR) {
            break;
        }
        closesocket(sockfd);
        sockfd = INVALID_SOCKET;
    }
    freeaddrinfo(result);

    if (INVALID_SOCKET != sockfd) {
        int optVal = 1;

        /* this is highly interactive system, tcp packet level buffering MUST be avoided */
        /* disable Nagle's algorithm */
        ret = setsockopt(sockfd, IPPROTO_TCP, TCP_NODELAY, (const void*) &optVal, sizeof(optVal));
        assert (0 == ret);
        /* enable TCP keep alive */
        ret = setsockopt(sockfd, SOL_SOCKET, SO_KEEPALIVE, (const void*) &optVal, sizeof(optVal));
//        assert (-1 != ret);
        return sockfd;

    } else {
        WSACleanup();
        return SOCKET_ERROR;
    }
}

void
closeSocket(
    IN Socket fdSocket
    )
{
    if (INVALID_SOCKET == fdSocket) {
        return;
    }
    closesocket(fdSocket);
    WSACleanup();
}

INT32
readSocket(
    IN Socket fdSocket,
    OUT BYTE *buffer,
    IN INT32 length
    )
{
    INT32 totalRead;
    INT32 thisTimeRead;
    fd_set readSet;
    int result;
    struct timeval timeout;

    for (totalRead = 0; totalRead < length; ) {
        FD_ZERO(&readSet);
        FD_SET(fdSocket, &readSet);
        timeout.tv_sec = 40;
        timeout.tv_usec = 0;
        /* wait till there is data to be read on the socket or timeout happens */
        result = select(fdSocket+1, &readSet, NULL, NULL, &timeout);
        if (SOCKET_ERROR == result) {
            if (WSAEINTR == WSAGetLastError()) {
                continue;
            }
            return SOCKET_ERROR;
        }
        /* check if timeout happened */
        if (0 == result) {
            return SOCKET_ERROR;
        }

        thisTimeRead = recv(fdSocket, buffer+totalRead, length-totalRead, 0);
        if (SOCKET_ERROR == thisTimeRead) {
            if (WSAEINTR == WSAGetLastError()) {
                continue;
            }
            return SOCKET_ERROR;
        } else if (0 == thisTimeRead) {
            /* EOF detected */
            break;
        }
        /* data is read from the socket, make the connection status active */
        totalRead += thisTimeRead;
    }

    return totalRead;
}

INT32
writeSocket(
    IN Socket fdSocket,
    IN BYTE *buffer,
    IN INT32 length
    )
{

    INT32 totalWrote;
    INT32 thisTimeWrote;

    for (totalWrote = 0; totalWrote < length; ) {
        thisTimeWrote = send(fdSocket, buffer+totalWrote, length-totalWrote, 0);
        if (SOCKET_ERROR == thisTimeWrote) {
            if (WSAEINTR == WSAGetLastError()) {
                continue;
            }
            return SOCKET_ERROR;
        }
        totalWrote += thisTimeWrote;
    }

    return totalWrote;
}

void
setSocketNonBlocking(
    IN Socket fdSocket
    )
{
    // TODO.
}

BOOL
isValidIPAddress(
    IN char *ipAddr
    )
{
    unsigned char buf[sizeof(IN6_ADDR)];
    int ret;

    ret = inet_pton(AF_INET, ipAddr, buf);
    if (1 == ret) {
        return TRUE;
    }

    ret = inet_pton(AF_INET6, ipAddr, buf);
    if (1 == ret) {
        return TRUE;
    }
    return FALSE;
}

