#include "utils.h"

#define MAX_SEM_COUNT 256

void
initSemaphore(
    IN Semaphore *pSemaphore,
    IN UINT32 initialValue
    )
{
    pSemaphore->hSemHandle = CreateSemaphore (
                                               NULL,
                                               (LONG) initialValue,
                                               (LONG) MAX_SEM_COUNT,
                                               NULL);
    assert (NULL != pSemaphore->hSemHandle);
}

void
deleteSemaphore(    		
    IN Semaphore *pSemaphore
    )
{
    BOOL ret;

    ret = CloseHandle(pSemaphore->hSemHandle);
    assert (0 != ret);
}

void
waitSemaphore(
    IN Semaphore *pSemaphore
    )
{
    DWORD dwResult;

    dwResult = WaitForSingleObject(
                                    pSemaphore->hSemHandle,
                                    INFINITE);
    assert (WAIT_OBJECT_0 == dwResult);
}

BOOL
trywaitSemaphore(
    IN Semaphore *pSemaphore
    )
{
    DWORD dwResult;

    dwResult = WaitForSingleObject(
                                    pSemaphore->hSemHandle,
                                    0);
    assert ((WAIT_OBJECT_0 == dwResult) || (WAIT_TIMEOUT == dwResult));
    return ((WAIT_OBJECT_0 == dwResult) ? TRUE : FALSE);
}

void
postSemaphore(
    IN Semaphore *pSemaphore
    )
{
    BOOL ret;

    ret = ReleaseSemaphore(
                            pSemaphore->hSemHandle,
                            (LONG) 1,
                            NULL);
    assert (FALSE != ret);
}

