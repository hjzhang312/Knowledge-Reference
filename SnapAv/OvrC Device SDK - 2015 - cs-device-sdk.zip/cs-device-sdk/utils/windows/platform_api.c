#include "utils.h"

void
osSleep(
    IN UINT32 seconds
    )
{
    Sleep(1000*seconds);
}

void
osHandleSIGPIPE()
{
    /*
     * Under Winsock, the SIGPIPE/EPIPE functionality does not exist at all: 
     * send() will either return 0 for a normal disconnect 
     * or -1 for an abnormal disconnect.
     */
    return;
}

int
osFileCreate(
    IN char *fileName
    )
{
    int fd;

    fd = _open(fileName, _O_CREAT | _O_WRONLY,  _S_IREAD | _S_IWRITE);
    return fd;
}

int
osFileWrite(
    IN int fd,
    IN void *data,
    IN int size
    )
{
    int ret;

    ret = _write(fd, data, size);
    return ret;
}

void
osFileClose(
    IN int fd
    )
{
    _close(fd);
}

SocketError
osGetSocketError()
{
    return WSAGetLastError();
}
