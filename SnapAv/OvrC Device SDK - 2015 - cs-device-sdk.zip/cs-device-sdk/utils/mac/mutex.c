#include "utils.h"

void
initMutex(
    IN Mutex *pMutex
    )
{
    int ret;
    pthread_mutexattr_t attr;

    ret = pthread_mutexattr_init(&attr);
    assert (0==ret);
//    ret = pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE_NP);
//    assert (0==ret);
    ret = pthread_mutex_init(pMutex, &attr);
    assert (0==ret);
}

void
deleteMutex(
    IN Mutex *pMutex
    )
{
    int ret;

    ret = pthread_mutex_destroy(pMutex);
    assert (0==ret);
}

void
lockMutex(
    IN Mutex *pMutex
    )
{
    int ret;

    ret = pthread_mutex_lock(pMutex);
    assert (0==ret);
}

void
unlockMutex(
    IN Mutex *pMutex
    )
{
    int ret;

    ret = pthread_mutex_unlock(pMutex);
    assert (0==ret);
}

