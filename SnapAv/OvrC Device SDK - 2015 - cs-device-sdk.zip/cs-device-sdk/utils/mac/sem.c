#include "utils.h"

void
initSemaphore(
    IN Semaphore *pSemaphore,
    IN UINT32 initialValue
    )
{
    int ret;

    pSemaphore->name = tempnam(NULL, "ovrc_sem");
    assert(NULL != pSemaphore->name);
    pSemaphore->sem = sem_open(pSemaphore->name, O_CREAT|O_EXCL, 0755, initialValue);
    assert (SEM_FAILED != pSemaphore->sem);
}

void
deleteSemaphore(    		
    IN Semaphore *pSemaphore
    )
{
    int ret;

    ret = sem_close(pSemaphore->sem);
    assert (0 == ret);
    ret = sem_unlink(pSemaphore->name);
    assert (0 == ret);
    free(pSemaphore->name);
}

void
waitSemaphore(
    IN Semaphore *pSemaphore
    )
{
    int ret;

    ret = sem_wait(pSemaphore->sem);
    assert (0 == ret);
}

BOOL
trywaitSemaphore(
    IN Semaphore *pSemaphore
    )
{
    int ret;

    ret = sem_trywait(pSemaphore->sem);
    if (0 == ret) {
        return TRUE;
    }
    assert (errno == EAGAIN);
    return FALSE;    
}

void
postSemaphore(
    IN Semaphore *pSemaphore
    )
{
    int ret;

    ret = sem_post(pSemaphore->sem);
    assert (0 == ret);
}

