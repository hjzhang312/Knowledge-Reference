#include "utils.h"

/* 
 * This simple pseudo-random number generator is the multiply-with-carry 
 * method invented by George Marsaglia.
 */

UINT32 m_w = 1;
UINT32 m_z = 2;

void
random32Seed(
    UINT32 seed
    )
{
    m_w = (seed ? seed : 1);
    m_z = m_w + 3412;
}

UINT32
random32Simple()
{
    m_z = 36969 * (m_z & 65535) + (m_z >> 16);
    m_w = 18000 * (m_w & 65535) + (m_w >> 16);
    return (m_z << 16) + m_w;  /* 32-bit result */
}

