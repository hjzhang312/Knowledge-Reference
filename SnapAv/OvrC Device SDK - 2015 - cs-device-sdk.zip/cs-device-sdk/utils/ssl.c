#include "utils.h"

void
initSslSocket(
    IN SslSocket *pSslSocket
    )
{
    BOOL ret;

    /* global initalization must be done only once before using any SSL call */
    /* Global system initialization*/
    SSL_library_init();
    SSL_load_error_strings();

    /* add algorithms to internal table */
    OpenSSL_add_all_algorithms();

    /* SSLv23 is the best choice when compatibility is a concern */
    /* create a new SSL_CTX object as framework for TLS/SSL enabled functions */
    pSslSocket->ctx = SSL_CTX_new(SSLv23_client_method());
    assert (NULL != pSslSocket->ctx);
    SSL_CTX_set_mode(pSslSocket->ctx, SSL_MODE_ENABLE_PARTIAL_WRITE |
                     SSL_MODE_ACCEPT_MOVING_WRITE_BUFFER | SSL_MODE_AUTO_RETRY);

//    ret = SSL_CTX_set_cipher_list(pSslSocket->ctx, "RC4-MD5:RC4-SHA");
//    assert(TRUE == ret);

    initMutex(&(pSslSocket->sslMutex));
   
    /* set ssl to null */ 
    pSslSocket->ssl = NULL;
    /* set session to null, as no session has been established yet. */
    pSslSocket->sess = NULL;
    /* since no socket is connected yet, set socket to invalid */
    pSslSocket->fdSocket = INVALID_SOCKET;
}

void
deleteSslSocket(
    IN SslSocket *pSslSocket
    )
{
    if (NULL == pSslSocket->ctx) {
        return;
    }
    deleteMutex(&(pSslSocket->sslMutex));
    if (pSslSocket->sess) {
        SSL_SESSION_free(pSslSocket->sess);
        pSslSocket->sess = NULL;
    }
    SSL_CTX_free(pSslSocket->ctx);
    pSslSocket->ctx = NULL;
}

BOOL
connectSslSocket(
    IN SslSocket *pSslSocket,
    IN Socket fdSocket
    )
{
    BOOL ret;

    /* create a new SSL structure for a connection */
    pSslSocket->ssl = SSL_new(pSslSocket->ctx);
    if (NULL == pSslSocket->ssl) {
        return FALSE;
    }

    /* connect the SSL object with the socket */
    ret = SSL_set_fd(pSslSocket->ssl, fdSocket);
    if (TRUE != ret) {
        return FALSE;
    }

    /* if SSL session already exists try to resume the session */
    /* resuming existing session helps to greatly improve server performance */
    if (pSslSocket->sess) {
        ret = SSL_set_session(pSslSocket->ssl, pSslSocket->sess);
//        ret = SSL_session_reused(pSslSocket->ssl);
//        printf ("Session reused: %s\n", (ret ? "YES" : "NO"));
    }

    /* initiate the SSL handshake with server */
    ret = SSL_connect(pSslSocket->ssl);
    if (TRUE != ret) {
        return FALSE;
    }

    /* make the socket non-blocking for improving ssl performance */
//    setSocketNonBlocking(fdSocket);

    pSslSocket->fdSocket = fdSocket;
    return TRUE;
}

void
closeSslSocket(
    IN SslSocket *pSslSocket
    )
{
    if (NULL == pSslSocket->ssl) {
        return;
    }

    /* 
     * before clossing the ssl connection, check if we have saved the ssl session.
     * ssl session is needed to resume the session for subsequent connections.
     */
    if (NULL == pSslSocket->sess) {
        pSslSocket->sess = SSL_get1_session(pSslSocket->ssl);
    }
    
    /* close ssl connection */
    SSL_shutdown(pSslSocket->ssl);

    /* free ssl connection */
    SSL_free(pSslSocket->ssl);

    pSslSocket->ssl = NULL;
    pSslSocket->fdSocket = INVALID_SOCKET;
}

INT32
readSslSocket(
    IN SslSocket *pSslSocket,
    OUT BYTE *buffer,
    IN INT32 length
    )
{
    INT32 totalRead;
    INT32 thisTimeRead;
    fd_set readSet;
    int result;
    struct timeval timeout;

    for (totalRead = 0; totalRead < length; ) {
        /* if there is no data available in SSL buffer you have to wait */
        if (!SSL_pending(pSslSocket->ssl)) {
            FD_ZERO(&readSet);
            FD_SET(pSslSocket->fdSocket, &readSet);
            timeout.tv_sec= 40;
            timeout.tv_usec = 0;
            /* wait till there is data to be read on the socket or timeout happens */
            result = select(pSslSocket->fdSocket+1, &readSet, NULL, NULL, &timeout);
            if (-1 == result) {
                if (SOCKET_EINTR == osGetSocketError()) {
                    continue;
                }
                return -1;
            }
            /* check if timeout happened */
            if (0 == result) {
                return -1;
            }
        }

        /* socket is ready with data get exclusive access of SSL channel & read data */
        lockMutex(&(pSslSocket->sslMutex));
        thisTimeRead = SSL_read(pSslSocket->ssl, buffer+totalRead, length-totalRead);
        /* end of SSL read, release exclusive access of SSL channel */
        unlockMutex(&(pSslSocket->sslMutex));

        /* check the result of SSL read and take apt decision */
        switch(SSL_get_error(pSslSocket->ssl, thisTimeRead)) {
            case SSL_ERROR_NONE:
                /* read successful */
                totalRead += thisTimeRead;
                break;
            case SSL_ERROR_ZERO_RETURN:
                /* EOF detected */
                goto END_OF_READ;
                break;
            case SSL_ERROR_WANT_READ:
            case SSL_ERROR_WANT_WRITE:
                /* something related to renogotiation happening retry read */
                continue;
                break;
            default:
                goto END_OF_READ;
        }
    }

END_OF_READ:
    return totalRead;
}

INT32
writeSslSocket(
    IN SslSocket *pSslSocket,
    OUT BYTE *buffer,
    IN INT32 length
    )
{
    INT32 totalWrote;
    INT32 thisTimeWrote;

    for (totalWrote = 0; totalWrote < length; ) {
        /* get exclusive access of SSL chanel for writing */
        lockMutex(&(pSslSocket->sslMutex));
        thisTimeWrote = SSL_write(pSslSocket->ssl, buffer+totalWrote, length-totalWrote);
        /* end of SSL write, release exclusive access of SSL chanel */
        unlockMutex(&(pSslSocket->sslMutex));

        /* check the result of SSL read and take apt decision */
        switch(SSL_get_error(pSslSocket->ssl, thisTimeWrote)) {
            case SSL_ERROR_NONE:
                /* write successful */
                totalWrote += thisTimeWrote;
                break;
            case SSL_ERROR_ZERO_RETURN:
                /* EOF detected */
                totalWrote = -1;
                goto END_OF_WRITE;
                break;
            case SSL_ERROR_WANT_READ:
            case SSL_ERROR_WANT_WRITE:
                /* something related to renogotiation happening retry write */
                continue;
                break;
            default:
                totalWrote = -1;
                goto END_OF_WRITE;
        }
    }

END_OF_WRITE:
    return totalWrote;
}

