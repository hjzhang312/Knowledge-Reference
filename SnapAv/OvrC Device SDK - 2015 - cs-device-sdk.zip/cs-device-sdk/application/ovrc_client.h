/* ovrc_client.h */

#include "ovrc_sdk.h"
#include "json_parser.h"

#define FIRMWARE_DOWNLOAD_FILE "ovrc_firmware.bin"
#define UPnP_APP_DESCRIPTION "OvrC:UPnP:Port"

/* structure for the device's network settings */
typedef struct NETWORK_SETTINGS {
    char deviceName[21];
    char deviceIpAddress[65];
    char deviceSubnetMask[65];
    char deviceDefaultGateway[65];
    bool dhcpEnabled;
    char dnsServer1[65];
    char dnsServer2[65];
    int webPagePort;
} NETWORK_SETTINGS;

/* structure for the device's time settings */
typedef struct TIME_SETTINGS {
    char timeZone[7];
    char currentTime[64];
    char daylightSavings[10];
} TIME_SETTINGS;


/* Initialize the device's variables */
void
initDeviceVars(void);

/* Set the cloud server url */
void
setCloudServerUrl(
    IN char *serverUrl
    );

/* Initialize connection with cloud server */
void
initCloudServerConnection();

/* Close connection with cloud server */
void
deleteCloudServerConnection();

/* Generic handler for all commands received from server */
void genericCommandHandler( IN JSON_PARSER_OBJ *root );

/* Callback for ping notification */
void ackPing();

/* Callback for WebSocket close notification */
void ackClose();

/* Callback for WebSocket reconnect */
void ackReconnect();

/* Method to send periodic status upadates. */
void *
statusUpdater(
    IN void *pdata
    );

/* Method to send event notifications. */
void
eventNotifier(
    IN char *event,
    IN char *eventType
    );


/*
 * API Handlers for the methods of the Base Specification
 */

/* Handler for the dxGetAbout method */
void
dxGetAboutHandler(
    IN JSON_PARSER_OBJ *rootIP
    );

/* Handler for the dxGetNetworkSettings method */
void
dxGetNetworkSettingsHandler(
    IN JSON_PARSER_OBJ *rootIP
    );

/* Handler for the dxSetNetworkSettings method */
void
dxSetNetworkSettingsHandler(
    IN JSON_PARSER_OBJ *rootIP
    );

/* Handler for the dxGetTimeSettings method */
void
dxGetTimeSettingsHandler(
    IN JSON_PARSER_OBJ *rootIP
    );

/* Handler for the dxSetTimeSettings method */
void
dxSetTimeSettingsHandler(
    IN JSON_PARSER_OBJ *rootIP
    );

/* Handler for the dxResetDevice method */
void
dxResetDeviceHandler(
    IN JSON_PARSER_OBJ *rootIP
    );

/* Handler for the dxUpdateFirmware method */
void
dxUpdateFirmwareHandler(
    IN JSON_PARSER_OBJ *rootIP
    );

/* The callback for the ftp downloading functionality provided by OvrC SDK.*/
void
ovrcClientFtpDownloader(
    IN void *buffer,
    IN size_t size
    );

/* Handler for the dxEnableRemoteWebUiAccess method. */
void 
dxEnableRemoteWebUiAccessHandler(
    IN JSON_PARSER_OBJ *rootIP
    );

/* Handler for the dxDisableRemoteWebUiAccess method. */
void 
dxDisableRemoteWebUiAccessHandler(
    IN JSON_PARSER_OBJ *rootIP
    );

/* Handler for dxStreamSystemLogs method. */
void
dxStreamSystemLogsHandler(
    IN JSON_PARSER_OBJ *rootIP
    );

/* Handler for dxSetLoggingMode method. */
void
dxSetLoggingModeHandler(
    IN JSON_PARSER_OBJ *rootIP
    );

/* Handler for dxGetStatusUpdateFrequency method. */
void
dxGetStatusUpdateFrequencyHandler(
    IN JSON_PARSER_OBJ *rootIP
    );

/* Handler for dxSetStatusUpdateFrequency method. */
void
dxSetStatusUpdateFrequencyHandler(
    IN JSON_PARSER_OBJ *rootIP
    );

/* Handler for dxSetCloudServerUrl method. */
void
dxSetCloudServerUrlHandler(
    IN JSON_PARSER_OBJ *rootIP
    );

/* Send an error code in response to a received method */
void
sendError(
    IN JSON_PARSER_OBJ *root,
    IN int errorCode
    );

BOOL 
timeZoneValidator(
    IN char *timeZone
    );

