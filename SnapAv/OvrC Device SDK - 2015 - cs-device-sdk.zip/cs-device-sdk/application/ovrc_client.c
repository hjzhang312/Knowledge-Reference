#include "ovrc_client.h"
#define CLIENT_PORT     80
#define CLIENT_PROTOCOL "http"

char *macAddress;
NETWORK_SETTINGS networkSettings;
TIME_SETTINGS timeSettings;
OvrCConnector connector;
Thread statusUpdateThread;
BOOL changeCloudServer;
char url[URL_SIZE];


/************************************
 *
 * ENTRY POINT FOR THE PROGRAM
 *
 ************************************/

int main(
    IN int argc,
    IN char **argv
    )
{
    /* This sample client requires parameters on the command line.  */
    /* A real OvrC client will get this information from elsewhere. */
    if (argc != 3) {
        printf ("Usage: %s device_server_url mac_address\n", argv[0]);
        return -1;
    }

    /* Initialize the connector. */
    macAddress = argv[2];
    connector.macAddress = argv[2];
    connector.pingCallback = ackPing;
    connector.closeCallback = ackClose;
    connector.reconnectCallback = ackReconnect;

    /* Initialize variables maintained by this program. */
    initDeviceVars();

    /* Set the cloud server url */
    setCloudServerUrl(argv[1]);

    /* Establish connection with cloud server */
    initCloudServerConnection();

    return 0;
}

/*
 * Set the cloud server url
 */

void
setCloudServerUrl(
    IN char *serverUrl
    )
{
    connector.deviceUrl = serverUrl;
    changeCloudServer = TRUE;
}

/*
 * Initialize connection with cloud server
 */

void
initCloudServerConnection(
    IN char *serverUrl
    )
{
    JSON_PARSER_OBJ *root = NULL;

    do {
        /* Initialize a WebSocket connection with the changed cloud server. */
        initConnection (connector);
        changeCloudServer = FALSE;

        /* Initialize status update thread. */
        initThread(statusUpdater, NULL, &statusUpdateThread);

        /* Read and execute commands received from the server, till url is not changed. */
        while (!changeCloudServer) {
            readJsonCommand(&root);
            genericCommandHandler(root);
         }
    } while(TRUE); /* Infinite loop */
}

/*
 * Close connection with cloud server
 */

void
deleteCloudServerConnection()
{
    /* Inform status updater thread to exit */
    setStatusUpdateFrequency(0);

    /* Wait for status update thread to exit */
    waitForThreadExit(&statusUpdateThread);

    /* Call OvrC-SDK to cleanup existing connection */
    deleteConnection();
}


/*
 * Method to send periodic status upadates.
 */

void *
statusUpdater(
    IN void *pdata
    )
{
    int frequency;
    JSON_PARSER_OBJ *rootOP = NULL;
    JSON_PARSER_OBJ *objOP = NULL;
    JSON_PARSER_OBJ *updateArray = NULL;
    JSON_PARSER_OBJ *updateItem = NULL;
    char timeStamp[64];

    while (TRUE) {
        /* Get the frequency for status update. */
        frequency = getStatusUpdateFrequency();

        /* frequency 0 indicates that the connection with webserver is closed */
        if (0 == frequency) {
            return NULL;
        }

        osSleep(frequency);

        /* Initialize a json rpc response object.                  */
        /* This call adds the jsonrpc version field to the object. */
        rootOP = initJsonRpcObject();
        addJsonObjectStringItem(rootOP, "method", "dsLogStatusUpdates");

        /* Add a result object to the response json. */
        objOP = createJsonObject();
        addJsonObject(rootOP, "params", objOP);

        /* Populate the result fields in the response json. */
        addJsonObjectStringItem(objOP, "deviceId", macAddress);
        addJsonObjectIntItem(objOP, "version", 0);

        /* Create status update array. */
        updateArray = createJsonArray();
        addJsonObject(objOP, "updates", updateArray);

        /* Create status update item. */
        updateItem = createJsonObject();
        getDateIsoFormat(timeStamp, 64);
        addJsonObjectStringItem(updateItem, "dateTime", timeStamp);

        /* Add update item to update array. */
        addJsonArrayItem(updateArray, updateItem);

        /* Write status update to device server */
        /* NOTE: we are using writeJsonStatus and not writeJsonReply to send status updates. */
        writeJsonStatus(rootOP);
    }

    return NULL;
}

/*
 * Method to send event notifications.
 */

void 
eventNotifier(
    IN char *event,
    IN char *eventType 
    )
{
    JSON_PARSER_OBJ *rootOP = NULL;
    JSON_PARSER_OBJ *objOP = NULL;
    JSON_PARSER_OBJ *eventArray = NULL;
    JSON_PARSER_OBJ *eventItem = NULL;
    char timeStamp[64];
    static int eventNumber = 1;

    /* Initialize a json rpc response object.                  */
    /* This call adds the jsonrpc version field to the object. */
    rootOP = initJsonRpcObject();
    addJsonObjectStringItem(rootOP, "method", "dsEventNotifications");

    /* Add a result object to the response json. */
    objOP = createJsonObject();
    addJsonObject(rootOP, "params", objOP);

    /* Populate the result fields in the response json. */
    addJsonObjectStringItem(objOP, "deviceId", macAddress);
    addJsonObjectIntItem(objOP, "version", 0);

    /* Create event array. */
    eventArray = createJsonArray();
    addJsonObject(objOP, "events", eventArray);

    /* Create event item. */
    eventItem = createJsonObject();
    addJsonObjectIntItem(eventItem, "number", eventNumber);
    eventNumber++;
    getDateIsoFormat(timeStamp, 64);
    addJsonObjectStringItem(eventItem, "dateTime", timeStamp);
    addJsonObjectStringItem(eventItem, "type", eventType);
    addJsonObjectStringItem(eventItem, "event", event);

    /* Add event item to event array. */
    addJsonArrayItem(eventArray, eventItem);

    /* Write event to device server */
    /* NOTE: we are using writeJsonEvent and not writeJsonReply to send status updates. */
    writeJsonEvent(rootOP);
}

/*
 * All commands (methods) from the server come here first.
 */

void genericCommandHandler(
    IN JSON_PARSER_OBJ *root
    )
{
    char *jsonrpc = NULL;
    char *method = NULL;
    char *id = NULL;
    JSON_PARSER_OBJ *params = NULL;

    /* Verify the presence of required parameters in the root object. */
    jsonrpc = getJsonStringValueForKey(root, "jsonrpc");
    method =  getJsonStringValueForKey(root, "method");
    id =      getJsonStringValueForKey(root, "id");
    params =  getJsonObjectForKey(root, "params");

    if (jsonrpc == NULL || method == NULL || params == NULL)
    {
        printf ("Invalid JSON command.\n");
        sendError(root, -32600);
        deleteJsonObject(root);
        return;
    }

    if (NULL == id) {
        return;
    }
    if ((0 == strlen(method)) || (0 == strlen(id))) {
        printf ("Invalid JSON command.\n");
        sendError(root, -32600);
        deleteJsonObject(root);
        return;
    }

    /* Verify that the json is formatted in the jsonrpc version that this client supports. */
    if (strcmp(jsonrpc, "2.0") != 0) {
        printf ("Invalid JSONRPC version.\n");
        sendError(root, -32603);
        deleteJsonObject(root);
        return;
    }

    /* Call the specific command handler for this method. */
    if (strcmp(method, "dxGetAbout") == 0) {
        dxGetAboutHandler(root);
    } else if (strcmp(method, "dxGetNetworkSettings") == 0) {
        dxGetNetworkSettingsHandler(root);
    } else if (strcmp(method, "dxSetNetworkSettings") == 0) {
        dxSetNetworkSettingsHandler(root);
    } else if (strcmp(method, "dxGetTimeSettings") == 0) {
        dxGetTimeSettingsHandler(root);
    } else if (strcmp(method, "dxSetTimeSettings") == 0) {
        dxSetTimeSettingsHandler(root);
    } else if (strcmp(method, "dxResetDevice") == 0) {
        dxResetDeviceHandler(root);
    } else if (strcmp(method, "dxUpdateFirmware") == 0) {
        dxUpdateFirmwareHandler(root);
    } else if (strcmp(method, "dxEnableRemoteWebUiAccess") == 0) {
        dxEnableRemoteWebUiAccessHandler(root);
    } else if (strcmp(method, "dxDisableRemoteWebUiAccess") == 0) {
        dxDisableRemoteWebUiAccessHandler(root);
    } else if (strcmp(method, "dxStreamSystemLogs") == 0) {
        dxStreamSystemLogsHandler(root);
    } else if (strcmp(method, "dxSetLoggingMode") == 0) {
        dxSetLoggingModeHandler(root);
    } else if (strcmp(method, "dxGetStatusUpdateFrequency") == 0) {
        dxGetStatusUpdateFrequencyHandler(root);
    } else if (strcmp(method, "dxSetStatusUpdateFrequency") == 0) {
        dxSetStatusUpdateFrequencyHandler(root);
    } else if (strcmp(method, "dxSetCloudServerUrl") == 0) {
        dxSetCloudServerUrlHandler(root);
    } else {
        printf ("Command handler not yet implemented for: %s\n", method);
        sendError(root, -32601);
    }

    /* Release the memory for this command. */
    deleteJsonObject(root);
    return;
}


/*
 * Handle the dxGetAbout method.
 */

void dxGetAboutHandler(
    IN JSON_PARSER_OBJ *rootIP
    )
{
    JSON_PARSER_OBJ *rootOP = NULL;
    JSON_PARSER_OBJ *objOP = NULL;
    JSON_PARSER_OBJ *objIP = NULL;
    char *deviceId = NULL;
    int version = 0;

    /* Verify the presence of required parameters. */
    objIP = getJsonObjectForKey(rootIP, "params");
    deviceId = getJsonStringValueForKey(objIP, "deviceId");
    version  = getJsonIntValueForKey(objIP, "version");
    if (deviceId == NULL || version != 0) {
        sendError(rootIP, -32602);
        return;
    }

    /* Initialize a json rpc response object.                  */
    /* This call adds the jsonrpc version field to the object. */
    rootOP = initJsonRpcObject();

    /* Echo the id field from the request to the response. */
    /* WARNING: This field must not be altered.            */
    copyJsonStringItem(rootIP, rootOP, "id");

    /* Add a result object to the response json. */
    objOP = createJsonObject();
    addJsonObject(rootOP, "result", objOP);

    /* Populate the result object.                            */
    /* Per the Base Specification, these fields are required: */
    /*   - deviceId                                           */
    /*   - macAddress                                         */
    /*   - firmware                                           */
    /*   - model                                              */
    /*   - lanAddress                                         */
    /* Per the Base Specification, these fields are optional: */
    /*   - serialNumber                                       */
    /*   - serviceTag                                         */
    /*   - platform                                           */
    /* See the device-specific supplement for which optional  */
    /* fields to include.                                     */
    addJsonObjectStringItem(objOP, "deviceId", macAddress);
    addJsonObjectStringItem(objOP, "macAddress", macAddress);
    addJsonObjectStringItem(objOP, "firmware", "FW-Version-1.0");
    addJsonObjectStringItem(objOP, "model", "Generic-OvrC-Device");
    addJsonObjectStringItem(objOP, "lanAddress", "192.168.1.110");

    /* Send the response to the server. */
    writeJsonReply(rootOP);
}


/*
 * Handle the dxGetNetworkSettingsHandler method.
 */

void dxGetNetworkSettingsHandler(
    IN JSON_PARSER_OBJ *rootIP
    )
{
    JSON_PARSER_OBJ *rootOP = NULL;
    JSON_PARSER_OBJ *objOP = NULL;
    JSON_PARSER_OBJ *objIP = NULL;
    char *deviceId = NULL;
    int version = 0;

    /* Verify the presence of required parameters. */
    objIP = getJsonObjectForKey(rootIP, "params");
    deviceId = getJsonStringValueForKey(objIP, "deviceId");
    version  = getJsonIntValueForKey(objIP, "version");
    if (deviceId == NULL || version != 1) {
        sendError(rootIP, -32602);
        return;
    }

    /* Initialize a json rpc response object.                  */
    /* This call adds the jsonrpc version field to the object. */
    rootOP = initJsonRpcObject();

    /* Echo the id field from the request to the response. */
    /* WARNING: This field must not be altered.            */
    copyJsonStringItem(rootIP, rootOP, "id");

    /* Add a result object to the response json. */
    objOP = createJsonObject();
    addJsonObject(rootOP, "result", objOP);

    /* Populate the result fields in the response json. */
    addJsonObjectStringItem(objOP, "deviceId", macAddress);
    addJsonObjectStringItem(objOP, "deviceName", networkSettings.deviceName);
    addJsonObjectStringItem(objOP, "deviceIpAddress", networkSettings.deviceIpAddress);
    addJsonObjectStringItem(objOP, "deviceSubnetMask", networkSettings.deviceSubnetMask);
    addJsonObjectStringItem(objOP, "deviceDefaultGateway", networkSettings.deviceDefaultGateway);
    addJsonObjectBoolItem(objOP, "dhcpEnabled", networkSettings.dhcpEnabled);
    addJsonObjectStringItem(objOP, "dnsServer1", networkSettings.dnsServer1);
    addJsonObjectStringItem(objOP, "dnsServer2", networkSettings.dnsServer2);
    addJsonObjectIntItem(objOP, "webPagePort", networkSettings.webPagePort);

    /* Send the response to the server. */
    writeJsonReply(rootOP);
}


/*
 * Handle the dxSetNetworkSettingsHandler method.
 */

void dxSetNetworkSettingsHandler(
    IN JSON_PARSER_OBJ *rootIP
    )
{
    JSON_PARSER_OBJ *rootOP = NULL;
    JSON_PARSER_OBJ *objOP = NULL;
    JSON_PARSER_OBJ *objIP = NULL;
    JSON_PARSER_OBJ *objBool = NULL;
	JSON_PARSER_OBJ *objInt = NULL;	
    char *deviceId = NULL;
    int version = 0;
    char *deviceName = NULL;
    char *deviceIpAddress = NULL;
    char *deviceSubnetMask = NULL;
    char *deviceDefaultGateway = NULL;
    bool dhcpEnabled = true;
    char *dnsServer1 = NULL;
    char *dnsServer2 = NULL;
    int webPagePort;
    int objectType,webPageObjectType;

    /* Verify the presence of required parameters. */
    objIP = getJsonObjectForKey(rootIP, "params");
    deviceId = getJsonStringValueForKey(objIP, "deviceId");
    version  = getJsonIntValueForKey(objIP, "version");
    deviceName = getJsonStringValueForKey(objIP, "deviceName");
    deviceIpAddress = getJsonStringValueForKey(objIP, "deviceIpAddress");
    deviceSubnetMask = getJsonStringValueForKey(objIP, "deviceSubnetMask");
    deviceDefaultGateway = getJsonStringValueForKey(objIP, "deviceDefaultGateway");
    dnsServer1 = getJsonStringValueForKey(objIP, "dnsServer1");
    dnsServer2 = getJsonStringValueForKey(objIP, "dnsServer2");
	objInt = getJsonObjectForKey(objIP,"webPagePort");	

    if (deviceId == NULL || version != 1) {
        sendError(rootIP, -32602);
        return;
    }

    objBool = getJsonObjectForKey(objIP, "dhcpEnabled");
    if (NULL == objBool) {
        sendError(rootIP, -32602);
        return;
    }
    objectType = getJsonObjectType(objBool);
    if (JSON_BOOL != objectType) {
        sendError(rootIP, -32602);
        return;
    }
    dhcpEnabled = (bool) getJsonBoolValueForKey(objIP, "dhcpEnabled");

    if (dhcpEnabled == false && (deviceIpAddress == NULL || deviceSubnetMask == NULL || deviceDefaultGateway == NULL)) {
        sendError(rootIP, -32602);
        return;
    }
    /* Update the device's settings. */
    if (deviceName && strlen(deviceName)) {
        memset (networkSettings.deviceName, 0, sizeof networkSettings.deviceName);
        strncpy (networkSettings.deviceName, deviceName, sizeof networkSettings.deviceName-1);
    } else {
        sendError(rootIP, -32602);
        return;
    }
    if (deviceIpAddress && strlen(deviceIpAddress) && isValidIPAddress(deviceIpAddress)) {
        memset (networkSettings.deviceIpAddress, 0, sizeof networkSettings.deviceIpAddress);
        strncpy (networkSettings.deviceIpAddress, deviceIpAddress, sizeof networkSettings.deviceIpAddress-1);
    } else {
        sendError(rootIP, -32602);
        return;
    }
    if (deviceSubnetMask && strlen(deviceSubnetMask) && isValidIPAddress(deviceSubnetMask)) {
        memset (networkSettings.deviceSubnetMask, 0, sizeof networkSettings.deviceSubnetMask);
        strncpy (networkSettings.deviceSubnetMask, deviceSubnetMask, sizeof networkSettings.deviceSubnetMask-1);
    } else {
        sendError(rootIP, -32602);
        return;
    }
    if (deviceDefaultGateway && strlen(deviceDefaultGateway) && isValidIPAddress(deviceDefaultGateway)) {
        memset (networkSettings.deviceDefaultGateway, 0, sizeof networkSettings.deviceDefaultGateway);
        strncpy (networkSettings.deviceDefaultGateway, deviceDefaultGateway, sizeof networkSettings.deviceDefaultGateway);
    } else {
        sendError(rootIP, -32602);
        return;
    }
    if (dnsServer1 && strlen(dnsServer1)) {
		if (isValidIPAddress(dnsServer1)) {
        	memset (networkSettings.dnsServer1, 0, sizeof networkSettings.dnsServer1);
       		strncpy (networkSettings.dnsServer1, dnsServer1, sizeof networkSettings.dnsServer1-1);
    	} else {
        	sendError(rootIP, -32602);
        	return;
    	}
    }   
    if (dnsServer2 && strlen(dnsServer2)) {
		if (isValidIPAddress(dnsServer2)) {
        	memset (networkSettings.dnsServer2, 0, sizeof networkSettings.dnsServer2);
        	strncpy (networkSettings.dnsServer2, dnsServer2, sizeof networkSettings.dnsServer2-1);
        } else {
        	sendError(rootIP, -32602);
    	   	return;
    	}
    }
	if(objInt) {
		webPageObjectType = getJsonObjectType(objInt);
		if(JSON_NUMBER != webPageObjectType) {
			sendError(rootIP, -32602);
			return;
		}
		webPagePort=getJsonIntValueForKey(objIP,"webPagePort");	
		if (webPagePort) {
			if (webPagePort > 0 && webPagePort < 65535) {
				networkSettings.webPagePort = webPagePort;
			}
			else {
				sendError(rootIP, -32602);
				return;
			}
    	}
	}
    networkSettings.dhcpEnabled = dhcpEnabled;

    /* Initialize a json rpc response object.                  */
    /* This call adds the jsonrpc version field to the object. */
    rootOP = initJsonRpcObject();

    /* Echo the id field from the request to the response. */
    /* WARNING: This field must not be altered.            */
    copyJsonStringItem(rootIP, rootOP, "id");

    /* Add a result object to the response json. */
    objOP = createJsonObject();
    addJsonObject(rootOP, "result", objOP);

    /* Populate the result fields in the response json. */
    addJsonObjectStringItem(objOP, "deviceId", macAddress);

    /* Send the response to the server. */
    writeJsonReply(rootOP);
    /* Send the even notification to server. */
    eventNotifier("Network settings changed.", OvrC_EVENT_TYPE_INFO);
}

/*
 * Simple validation function for get & set time settings.
 */

BOOL timeZoneValidator(
    IN char *timeZone
    )
{
    int l = strlen(timeZone);

    if (l != 5) {
        return FALSE;
    }

    if (timeZone[0]!='+' && timeZone[0]!='-') {
        return FALSE;
    }

    if (!(timeZone[1]>='0' && timeZone[1]<='9')) {
        return FALSE;
    }

    if (timeZone[2] != ':') {
        return FALSE;
    }

    if (!(timeZone[3]>='0' && timeZone[3]<='9')) {
        return FALSE;
    }

    if (!(timeZone[4]>='0' && timeZone[4]<='9')) {
        return FALSE;
    }

    return TRUE;
}


/*
 * Handle the dxGetTimeSettingsHandler method.
 */

void dxGetTimeSettingsHandler(
    IN JSON_PARSER_OBJ *rootIP
    )
{
    JSON_PARSER_OBJ *rootOP = NULL;
    JSON_PARSER_OBJ *objOP = NULL;
    JSON_PARSER_OBJ *objIP = NULL;
    char *deviceId = NULL;
    int version = 0;

    /* Verify the presence of required parameters. */
    objIP = getJsonObjectForKey(rootIP, "params");
    deviceId = getJsonStringValueForKey(objIP, "deviceId");
    version  = getJsonIntValueForKey(objIP, "version");
    if (deviceId == NULL || version != 1) {
        sendError(rootIP, -32602);
        return;
    }

    /* Initialize a json rpc response object.                  */
    /* This call adds the jsonrpc version field to the object. */
    rootOP = initJsonRpcObject();

    /* Echo the id field from the request to the response. */
    /* WARNING: This field must not be altered.            */
    copyJsonStringItem(rootIP, rootOP, "id");

    /* Add a result object to the response json. */
    objOP = createJsonObject();
    addJsonObject(rootOP, "result", objOP);

    /* Populate the result fields in the response json. */
    addJsonObjectStringItem(objOP, "deviceId", macAddress);
    addJsonObjectStringItem(objOP, "timeZone", timeSettings.timeZone);
    getDateIsoFormat(timeSettings.currentTime, sizeof timeSettings.currentTime);
    addJsonObjectStringItem(objOP, "currentTime", timeSettings.currentTime);
    addJsonObjectStringItem(objOP, "daylightSavings", timeSettings.daylightSavings);

    /* Send the response to the server. */
    writeJsonReply(rootOP);
}


/*
 * Handle the dxSetTimeSettingsHandler method.
 */

void dxSetTimeSettingsHandler(
    IN JSON_PARSER_OBJ *rootIP
    )
{
    JSON_PARSER_OBJ *rootOP = NULL;
    JSON_PARSER_OBJ *objOP = NULL;
    JSON_PARSER_OBJ *objIP = NULL;
    JSON_PARSER_OBJ *objDate = NULL;
    char *deviceId = NULL;
    int version = 0;
    char *timeZone = NULL;
    char *daylightSavings = NULL;
    char *currentTime = NULL;
    int objectType;

    /* Verify the presence of required parameters. */
    objIP = getJsonObjectForKey(rootIP, "params");
    deviceId = getJsonStringValueForKey(objIP, "deviceId");


    if (deviceId == NULL || strcmp(deviceId, macAddress)) {
      sendError(rootIP, -32602);
      return;
    }

    version  = getJsonIntValueForKey(objIP, "version");

    if (version != 1) {
        sendError(rootIP, -32602);
        return;
    }

    timeZone = getJsonStringValueForKey(objIP, "timeZone");

    if ((timeZone == NULL) || (timeZoneValidator(timeZone) == FALSE)) {
        sendError(rootIP, -32602);
        return;
    }

    memset (timeSettings.timeZone, 0, sizeof timeSettings.timeZone);
    strncpy (timeSettings.timeZone, timeZone, sizeof timeSettings.timeZone-1);

    daylightSavings = getJsonStringValueForKey(objIP, "daylightSavings");

    if ((daylightSavings == NULL) ||
        ( (strcmp(daylightSavings, "enabled") != 0) &&
          (strcmp(daylightSavings, "disabled") != 0) ) ) {
        sendError(rootIP, -32602);
        return;
    }

    memset (timeSettings.daylightSavings, 0, sizeof timeSettings.daylightSavings);
    strncpy (timeSettings.daylightSavings, daylightSavings, sizeof timeSettings.daylightSavings-1);

    objDate = getJsonObjectForKey(objIP, "currentTime");
    if (objDate && (getJsonObjectType(objDate) != JSON_STRING)) {
        sendError(rootIP, -32602);
        return;
    }
    currentTime = getJsonStringValueForKey(objIP, "currentTime");
    if (currentTime) {
        if (validDateIsoFormat(currentTime)) {
            memset(timeSettings.currentTime, 0, sizeof timeSettings.currentTime-1);
            strncpy(timeSettings.currentTime, currentTime, sizeof timeSettings.currentTime-1);
        } else {
            sendError(rootIP, -32602);
            return;
        }
    }

    /* Initialize a json rpc response object.                  */
    /* This call adds the jsonrpc version field to the object. */
    rootOP = initJsonRpcObject();

    /* Echo the id field from the request to the response. */
    /* WARNING: This field must not be altered.            */
    copyJsonStringItem(rootIP, rootOP, "id");

    /* Add a result object to the response json. */
    objOP = createJsonObject();
    addJsonObject(rootOP, "result", objOP);

    /* Populate the result fields in the response json. */
    addJsonObjectStringItem(objOP, "deviceId", macAddress);

    /* Send the response to the server. */
    writeJsonReply(rootOP);
}


/*
 * Handle the dxResetDeviceHandler method.
 */

void dxResetDeviceHandler(
    IN JSON_PARSER_OBJ *rootIP
    )
{
    JSON_PARSER_OBJ *rootOP = NULL;
    JSON_PARSER_OBJ *objOP = NULL;
    JSON_PARSER_OBJ *objIP = NULL;
    char *deviceId = NULL;
    int version = 0;

    /* Verify the presence of required parameters. */
    objIP = getJsonObjectForKey(rootIP, "params");
    deviceId = getJsonStringValueForKey(objIP, "deviceId");
    version  = getJsonIntValueForKey(objIP, "version");
    if (deviceId == NULL || version != 0) {
        sendError(rootIP, -32602);
        return;
    }

    /* Initialize a json rpc response object.                  */
    /* This call adds the jsonrpc version field to the object. */
    rootOP = initJsonRpcObject();

    /* Echo the id field from the request to the response. */
    /* WARNING: This field must not be altered.            */
    copyJsonStringItem(rootIP, rootOP, "id");

    /* Add a result object to the response json. */
    objOP = createJsonObject();
    addJsonObject(rootOP, "result", objOP);

    /* Populate the result fields in the response json. */
    addJsonObjectStringItem(objOP, "deviceId", macAddress);

    /* Send the response to the server. */
    writeJsonReply(rootOP);

    /* Execute the device reset... */
    /* TODO: device reset code goes here. */

    /* Before the device reset close all the open ports */
    deleteUPnPService(); 

    /* Send the even notification to server. */
    eventNotifier("Device just made a cold boot.", OvrC_EVENT_TYPE_INFO);
}


/*
 * Handle the dxUpdateFirmware method.
 */

void dxUpdateFirmwareHandler(
    IN JSON_PARSER_OBJ *rootIP
    )
{
    JSON_PARSER_OBJ *rootOP = NULL;
    JSON_PARSER_OBJ *objOP = NULL;
    JSON_PARSER_OBJ *objIP = NULL;
    char *deviceId = NULL;
    int version = 0;
    char *url = NULL;
    bool saveAndRestore = true;

    /* Verify the presence of required parameters. */
    objIP = getJsonObjectForKey(rootIP, "params");
    deviceId = getJsonStringValueForKey(objIP, "deviceId");
    version  = getJsonIntValueForKey(objIP, "version");
    url = getJsonStringValueForKey(objIP, "url");
    saveAndRestore = (bool) getJsonBoolValueForKey(objIP, "saveAndRestore");

    if (deviceId == NULL || version != 0 || url == NULL) {
        sendError(rootIP, -32602);
        return;
    }
    if (0 == strlen(url)) {
        sendError(rootIP, -32602);
        return;
    }

    /* Execute the update firmware... */
    ftpDownloader(url, ovrcClientFtpDownloader);

    /* Initialize a json rpc response object.                  */
    /* This call adds the jsonrpc version field to the object. */
    rootOP = initJsonRpcObject();

    /* Echo the id field from the request to the response. */
    /* WARNING: This field must not be altered.            */
    copyJsonStringItem(rootIP, rootOP, "id");

    /* Add a result object to the response json. */
    objOP = createJsonObject();
    addJsonObject(rootOP, "result", objOP);

    /* Populate the result fields in the response json. */
    addJsonObjectStringItem(objOP, "deviceId", macAddress);

    /* Send the response to the server. */
    writeJsonReply(rootOP);

    /* Send the even notification to server. */
    eventNotifier("Downloded new firmware.", OvrC_EVENT_TYPE_INFO);
}

/*
 * The callback for the ftp downloading functionality provided by OvrC SDK.
*/
void
ovrcClientFtpDownloader(
    IN void *buffer,
    IN size_t size
    )
{
    static int fd = -1;
    int ret;
    
    /* Create the download file on the first invocation of this callback function */
    if (-1 == fd) {
        fd = osFileCreate(FIRMWARE_DOWNLOAD_FILE);
        assert (fd != -1);
    }

    /* NULL buffer marks end of the download stream */
    if (NULL == buffer) {
        osFileClose(fd);
        fd = -1;
        return;
    }

    /* Write the download stream in the firmware file */
    ret = osFileWrite(fd, buffer, size);
    assert (ret != -1);
}

/*
 * Handle the dxEnableRemoteWebUiAccess method.
 */

void 
dxEnableRemoteWebUiAccessHandler(
    IN JSON_PARSER_OBJ *rootIP
    )
{
    JSON_PARSER_OBJ *rootOP = NULL;
    JSON_PARSER_OBJ *objOP = NULL;
    JSON_PARSER_OBJ *objIP = NULL;
    JSON_PARSER_OBJ *objTimeOut = NULL;
    char *deviceId = NULL;
    char *protocol = NULL;
    int version = 0;
    int timeout = 0;
    int retCode;
    int exPort;
    char s_exPort[8];
    char s_exIPaddr[64];
    int objectType;

    /* Verify the presence of required parameters. */
    objIP = getJsonObjectForKey(rootIP, "params");
    deviceId = getJsonStringValueForKey(objIP, "deviceId");
    version  = getJsonIntValueForKey(objIP, "version");
    protocol = getJsonStringValueForKey(objIP, "protocol");

    if (deviceId == NULL || version != 0 || protocol == NULL) {
        sendError(rootIP, -32602);
        return;
    }

    if ((strcmp(protocol, "http") != 0) &&
        (strcmp(protocol, "https") != 0)) {
        sendError(rootIP, -32602);
        return;
    }

    /* get the optional parameter timeout */
    objTimeOut = getJsonObjectForKey(objIP, "timeout");
    if (objTimeOut && (getJsonObjectType(objTimeOut) != JSON_NUMBER)) {
        sendError(rootIP, -32602);
        return;
    }
    timeout = getJsonIntValueForKey(objIP, "timeout");
    if (timeout < 0) {
        sendError(rootIP, -32602);
        return;
    }

    /* use the UPnP helper function for port forwarding */
    retCode = addPortForwarding(CLIENT_PORT, timeout, UPnP_APP_DESCRIPTION, s_exIPaddr, &exPort);

    /* Based on the result of port forwarding decide whether to send result or error. */
    if (UPnP_E_OK == retCode) {
        /* Port forwarding is successful. Add a result object to the response json. */
        retCode = snprintf (s_exPort, 8, "%d", exPort);
        assert (retCode > 0);

        /* Initialize a json rpc response object.                  */
        /* This call adds the jsonrpc version field to the object. */
        rootOP = initJsonRpcObject();

        /* Echo the id field from the request to the response. */
        /* WARNING: This field must not be altered.            */
        copyJsonStringItem(rootIP, rootOP, "id");

        objOP = createJsonObject();
        addJsonObject(rootOP, "result", objOP);
        /* Populate the result fields in the response json. */
        addJsonObjectStringItem(objOP, "deviceId", macAddress);
        addJsonObjectStringItem(objOP, "protocol", CLIENT_PROTOCOL);
        addJsonObjectStringItem(objOP, "ipAddress", s_exIPaddr);
        addJsonObjectStringItem(objOP, "port", s_exPort);

        /* Send the response to the server. */
        writeJsonReply(rootOP);
        /* Send the even notification to server. */
        eventNotifier("UPnP port forwarding done.", OvrC_EVENT_TYPE_INFO);
    } else {
        /* Port forwarding is failed. */
        /* Send error based on the return code. */
        if (UPnP_ERROR_NO_ROUTER_SUPPORT == retCode) {
            sendError(rootIP, 10100);
        } else {
            sendError(rootIP, 10101);
        }
    }
}


/*
 * Handle the dxDisableRemoteWebUiAccess method.
 */

void 
dxDisableRemoteWebUiAccessHandler(
    IN JSON_PARSER_OBJ *rootIP
    )
{
    JSON_PARSER_OBJ *rootOP = NULL;
    JSON_PARSER_OBJ *objOP = NULL;
    JSON_PARSER_OBJ *objIP = NULL;
    char *deviceId = NULL;
    int version = 0;
    char *s_exPort = NULL;
    char *s_exIPaddr = NULL;
    int exPort;
    int retCode;

    /* Verify the presence of required parameters. */
    objIP = getJsonObjectForKey(rootIP, "params");
    deviceId = getJsonStringValueForKey(objIP, "deviceId");
    version  = getJsonIntValueForKey(objIP, "version");
    s_exIPaddr = getJsonStringValueForKey(objIP, "ipAddress");
    s_exPort = getJsonStringValueForKey(objIP, "port");

    if (deviceId == NULL || version != 0 || s_exIPaddr == NULL || s_exPort == NULL) {
        sendError(rootIP, -32602);
        return;
    }
    if (!isValidIPAddress(s_exIPaddr)) {
        sendError(rootIP, -32602);
        return;
    }
    if (0 == strlen(s_exPort)) {
        sendError(rootIP, -32602);
        return;
    }

    exPort = atoi(s_exPort);

    /* use the UPnP helper function to stop port forwarding */
    retCode = deletePortForwarding(exPort);

    /* Initialize a json rpc response object.                  */
    /* This call adds the jsonrpc version field to the object. */
    rootOP = initJsonRpcObject();

    /* Echo the id field from the request to the response. */
    /* WARNING: This field must not be altered.            */
    copyJsonStringItem(rootIP, rootOP, "id");

    /* Add a result object to the response json. */
    objOP = createJsonObject();
    addJsonObject(rootOP, "result", objOP);

    /* Populate the result fields in the response json. */
    addJsonObjectStringItem(objOP, "deviceId", macAddress);

    /* Send the response to the server. */
    writeJsonReply(rootOP);
    /* Send the even notification to server. */
    eventNotifier("UPnP stopped port forwarding.", OvrC_EVENT_TYPE_INFO);
}


/*
 * Handle the dxStreamSystemLogs method.
 */

void 
dxStreamSystemLogsHandler(
    IN JSON_PARSER_OBJ *rootIP
    )
{
    JSON_PARSER_OBJ *rootOP = NULL;
    JSON_PARSER_OBJ *objOP = NULL;
    JSON_PARSER_OBJ *objIP = NULL;
    char *deviceId = NULL;
    int version = 0;
    BOOL enable;
    char *requestId = NULL;

    /* Verify the presence of required parameters. */
    objIP = getJsonObjectForKey(rootIP, "params");
    deviceId = getJsonStringValueForKey(objIP, "deviceId");
    version  = getJsonIntValueForKey(objIP, "version");
    enable = getJsonBoolValueForKey(objIP, "enable");

    if (deviceId == NULL || version != 0) {
        sendError(rootIP, -32602);
        return;
    }

    /* if stream logging is enabled */
    if (TRUE == enable) {
        requestId = getJsonStringValueForKey(rootIP, "id");
        enableLogHandler(requestId);
    } else if (FALSE == enable) {
        /* else if stream logging is disabled */
        disableLogHandler();

        /* Initialize a json rpc response object.                  */
        /* This call adds the jsonrpc version field to the object. */
        rootOP = initJsonRpcObject();

        /* Echo the id field from the request to the response. */
        /* WARNING: This field must not be altered.            */
        copyJsonStringItem(rootIP, rootOP, "id");

        /* set stream to false */
        addJsonObjectBoolItem(rootOP, "stream", FALSE);

        /* Add a result object to the response json. */
        objOP = createJsonObject();
        addJsonObject(rootOP, "result", objOP);

        /* Populate the result fields in the response json. */
        addJsonObjectStringItem(objOP, "deviceId", macAddress);

        /* Send the response to the server. */
        writeJsonReply(rootOP);
    } else {
        /* enable was not set as boolean value in incoming json rpc command */
        /* revert back with an error */
        sendError(rootIP, -32602);
    }
}

/*
 * Handle the dxSetLoggingMode method.
 */

void 
dxSetLoggingModeHandler(
    IN JSON_PARSER_OBJ *rootIP
    )
{
    JSON_PARSER_OBJ *rootOP = NULL;
    JSON_PARSER_OBJ *objOP = NULL;
    JSON_PARSER_OBJ *objIP = NULL;
    char *deviceId = NULL;
    int version = 0;
    char *logMode = NULL;

    /* Verify the presence of required parameters. */
    objIP = getJsonObjectForKey(rootIP, "params");
    deviceId = getJsonStringValueForKey(objIP, "deviceId");
    version  = getJsonIntValueForKey(objIP, "version");
    logMode = getJsonStringValueForKey(objIP, "mode");

    if (deviceId == NULL || version != 0 || logMode == NULL) {
        sendError(rootIP, -32602);
        return;
    }

    /* set the appropriate log level in log handler */
    if (strncmp(logMode, "PRODUCTION", strlen("PRODUCTION")) == 0) {
        setLogLevel(OvrC_LOG_LEVEL_PRODUCTION);
    } else if (strncmp(logMode, "DEBUG", strlen("DEBUG")) == 0) {
        setLogLevel(OvrC_LOG_LEVEL_DEBUG);
    } else {
        sendError(rootIP, -32602);
        return;
    }

    /* Initialize a json rpc response object.                  */
    /* This call adds the jsonrpc version field to the object. */
    rootOP = initJsonRpcObject();

    /* Echo the id field from the request to the response. */
    /* WARNING: This field must not be altered.            */
    copyJsonStringItem(rootIP, rootOP, "id");

    /* Add a result object to the response json. */
    objOP = createJsonObject();
    addJsonObject(rootOP, "result", objOP);

    /* Populate the result fields in the response json. */
    addJsonObjectStringItem(objOP, "deviceId", macAddress);

    /* Send the response to the server. */
    writeJsonReply(rootOP);
    return;
}

/*
 * Handle the dxGetStatusUpdateFrequency method.
 */

void 
dxGetStatusUpdateFrequencyHandler(
    IN JSON_PARSER_OBJ *rootIP
    )
{
    JSON_PARSER_OBJ *rootOP = NULL;
    JSON_PARSER_OBJ *objOP = NULL;
    JSON_PARSER_OBJ *objIP = NULL;
    char *deviceId = NULL;
    int version = 0;
    int frequency;

    /* Verify the presence of required parameters. */
    objIP = getJsonObjectForKey(rootIP, "params");
    deviceId = getJsonStringValueForKey(objIP, "deviceId");
    version  = getJsonIntValueForKey(objIP, "version");

    if (deviceId == NULL || version != 0) {
        sendError(rootIP, -32602);
        return;
    }

    frequency = getStatusUpdateFrequency();
    /* Initialize a json rpc response object.                  */
    /* This call adds the jsonrpc version field to the object. */
    rootOP = initJsonRpcObject();

    /* Echo the id field from the request to the response. */
    /* WARNING: This field must not be altered.            */
    copyJsonStringItem(rootIP, rootOP, "id");

    /* Add a result object to the response json. */
    objOP = createJsonObject();
    addJsonObject(rootOP, "result", objOP);

    /* Populate the result fields in the response json. */
    addJsonObjectStringItem(objOP, "deviceId", macAddress);
    addJsonObjectIntItem(objOP, "frequency", frequency);

    /* Send the response to the server. */
    writeJsonReply(rootOP);
    return;
}


/*
 * Handle the dxSetStatusUpdateFrequency method.
 */

void 
dxSetStatusUpdateFrequencyHandler(
    IN JSON_PARSER_OBJ *rootIP
    )
{
    JSON_PARSER_OBJ *rootOP = NULL;
    JSON_PARSER_OBJ *objOP = NULL;
    JSON_PARSER_OBJ *objIP = NULL;
    JSON_PARSER_OBJ *objVal = NULL;
    char *deviceId = NULL;
    int version = 0;
    int frequency;

    /* Verify the presence of required parameters. */
    objIP = getJsonObjectForKey(rootIP, "params");
    deviceId = getJsonStringValueForKey(objIP, "deviceId");
    version  = getJsonIntValueForKey(objIP, "version");
    objVal = getJsonObjectForKey(objIP, "frequency");

    if (deviceId == NULL || version != 0 || objVal == NULL) {
        sendError(rootIP, -32602);
        return;
    }

    frequency = getJsonIntValueForKey(objIP, "frequency");
    if (frequency <= 0) {
        sendError(rootIP, -32602);
        return;
    }
    setStatusUpdateFrequency(frequency);
    /* Initialize a json rpc response object.                  */
    /* This call adds the jsonrpc version field to the object. */
    rootOP = initJsonRpcObject();

    /* Echo the id field from the request to the response. */
    /* WARNING: This field must not be altered.            */
    copyJsonStringItem(rootIP, rootOP, "id");

    /* Add a result object to the response json. */
    objOP = createJsonObject();
    addJsonObject(rootOP, "result", objOP);

    /* Populate the result fields in the response json. */
    addJsonObjectStringItem(objOP, "deviceId", macAddress);

    /* Send the response to the server. */
    writeJsonReply(rootOP);
    return;
}

void
dxSetCloudServerUrlHandler(
    IN JSON_PARSER_OBJ *rootIP
    )
{
    JSON_PARSER_OBJ *rootOP = NULL;
    JSON_PARSER_OBJ *objOP = NULL;
    JSON_PARSER_OBJ *objIP = NULL;
    char *deviceId = NULL;
    char *serverUrl = NULL;
    char *serverPort = NULL;
    int version = 0;

    /* Verify the presence of required parameters. */
    objIP = getJsonObjectForKey(rootIP, "params");
    deviceId = getJsonStringValueForKey(objIP, "deviceId");
    version  = getJsonIntValueForKey(objIP, "version");
    serverUrl = getJsonStringValueForKey(objIP, "url");
    serverPort = getJsonStringValueForKey(objIP, "port");

    if (deviceId == NULL || version != 0 || serverUrl == NULL || serverPort == NULL) {
        sendError(rootIP, -32602);
        return;
    }
    if ((0 == strlen(serverUrl)) || (0 == strlen(serverPort))) {
        sendError(rootIP, -32602);
        return;
    }

    /* Make sure url size is less than URL_SIZE */
    assert (strlen(serverUrl)+strlen(serverPort) < URL_SIZE);
    strcpy (url, serverUrl);
    strcat (url, ":");
    strcat (url, serverPort);

    /* Initialize a json rpc response object.                  */
    /* This call adds the jsonrpc version field to the object. */
    rootOP = initJsonRpcObject();

    /* Echo the id field from the request to the response. */
    /* WARNING: This field must not be altered.            */
    copyJsonStringItem(rootIP, rootOP, "id");

    /* Add a result object to the response json. */
    objOP = createJsonObject();
    addJsonObject(rootOP, "result", objOP);

    /* Populate the result fields in the response json. */
    addJsonObjectStringItem(objOP, "deviceId", macAddress);

    /* Send the response to the server. */
    writeJsonReply(rootOP);

    /* Close existing cloud server connection */
    deleteCloudServerConnection();

    /* Change the server url with new cloud server */
    setCloudServerUrl(url);

    return;
}

/*
 * Handle notice of a received ping. (The library will send the pong.)
 */

void ackPing()
{
    printf ("ACK ping.\n");
    ovrcDebugLog(__FILE__, __LINE__, "Recieved PING.");
}


/*
 * Handle notice of a WebSocket close connection. (The library will do the reconnect.)
 */

void ackClose()
{
    printf ("ACK close.\n");
}


/*
 * Handle notice of a WebSocket reconnection.
 */

void ackReconnect()
{
    printf ("ACK reconnection.\n");
}


/*
 * Send an error response to the received request.
 */

void sendError(
    IN JSON_PARSER_OBJ *rootIP,
    IN int errorCode
    )
{
    JSON_PARSER_OBJ *rootOP = NULL;
    JSON_PARSER_OBJ *objOP = NULL;
    char *errMsg;

    /* init json rpc response object */
    rootOP = initJsonRpcObject();

    /* set id value from source in json */
    copyJsonStringItem(rootIP, rootOP, "id");

    /* create result object in json */
    objOP = createJsonObject();
    addJsonObject(rootOP, "error", objOP);

    /* add the error info to the json */
    addJsonObjectIntItem(objOP, "code", errorCode);
    switch (errorCode) {
    case -32700:
        errMsg = "Invalid JSON was received";
        break;
    case -32600:
        errMsg = "The JSON sent is not a valid Request object";
        break;
    case -32601:
        errMsg = "The method is not available";
        break;
    case -32602:
        errMsg = "Invalid method parameter";
        break;
    case -32603:
        errMsg = "Internal JSON-RPC error";
        break;
    case 10001:
        errMsg = "Cannot execute request because the device is not in an appropriate state";
        break;
    case 10002:
        errMsg = "Too many items in a list";
        break;
    case 10100:
        errMsg = "The router is not a UPnP router";
        break;
    case 10101:
        errMsg = "The router could not perform the request";
        break;
    default:
        errMsg = "Unknown error";
        break;
    }
    addJsonObjectStringItem(objOP, "message", errMsg);
    addJsonObjectStringItem(objOP, "data", "");

    /* send response to server */
    writeJsonReply(rootOP);
}


/*
 * When this program starts, initialize any variables it retains.
 */
void initDeviceVars (void) {
    strcpy (networkSettings.deviceName, "Device Name");
    strcpy (networkSettings.deviceIpAddress, "192.168.1.110");
    strcpy (networkSettings.deviceSubnetMask, "255.255.0.0");
    strcpy (networkSettings.deviceDefaultGateway, "192.168.1.1");
    networkSettings.dhcpEnabled = true;
    strcpy (networkSettings.dnsServer1, "");
    strcpy (networkSettings.dnsServer2, "");
    networkSettings.webPagePort = 80;
   

    strcpy (timeSettings.timeZone, "-5:00");
    getDateIsoFormat(timeSettings.currentTime, sizeof timeSettings.currentTime);
    strcpy (timeSettings.daylightSavings, "disabled");
}
